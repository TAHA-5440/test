// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package f3;
public interface n {

    public abstract void i(android.graphics.Bitmap p0, z2.a p1);

    public abstract void l();
}
