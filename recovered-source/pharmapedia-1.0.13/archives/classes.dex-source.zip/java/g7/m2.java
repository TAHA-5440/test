// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package g7;
public interface m2 {
}
