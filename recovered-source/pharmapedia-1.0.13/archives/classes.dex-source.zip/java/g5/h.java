// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package g5;
public interface h {

    public abstract q0.o1 b(android.view.View p0, q0.o1 p1, g5.i p2);
}
