// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package f2;
public interface g {

    public abstract String B();

    public abstract void h(f2.f p0);
}
