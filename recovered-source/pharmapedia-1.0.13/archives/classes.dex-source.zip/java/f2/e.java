// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package f2;
public interface e implements java.io.Closeable {

    public abstract f2.a H();

    public abstract String getDatabaseName();

    public abstract void setWriteAheadLoggingEnabled(boolean p0);
}
