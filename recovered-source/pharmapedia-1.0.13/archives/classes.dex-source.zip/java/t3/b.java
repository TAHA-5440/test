// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package t3;
public interface b {

    public abstract t3.d b();
}
