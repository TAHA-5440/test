// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package c2;
public interface g implements androidx.lifecycle.v {

    public abstract c2.e getSavedStateRegistry();
}
