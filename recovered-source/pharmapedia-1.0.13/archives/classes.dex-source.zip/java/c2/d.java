// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package c2;
public interface d {

    public abstract android.os.Bundle a();
}
