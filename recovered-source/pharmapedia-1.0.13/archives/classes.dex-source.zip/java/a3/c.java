// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a3;
public final class c {
    public final java.util.ArrayDeque a;

    public c(int p2)
    {
        switch (p2) {
            case 1:
                this.a = new java.util.ArrayDeque(0);
                return;
            default:
                this.a = new java.util.ArrayDeque();
                return;
        }
    }

    public declared_synchronized void a(v2.c p2)
    {
        p2.b = 0;
        p2.c = 0;
        this.a.offer(p2);
        return;
    }
}
