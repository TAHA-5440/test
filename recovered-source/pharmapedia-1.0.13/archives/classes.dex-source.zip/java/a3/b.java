// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a3;
public final class b {
    public final java.util.concurrent.locks.ReentrantLock a;
    public int b;

    public b()
    {
        this.a = new java.util.concurrent.locks.ReentrantLock();
        return;
    }
}
