// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a3;
public final class d implements a3.a {
    public long g;
    public boolean h;
    public final Object i;
    public Object j;
    public Object k;
    public Object l;

    public d()
    {
        this.g = -1;
        this.l = new k.i(this);
        this.i = new java.util.ArrayList();
        return;
    }

    public d(java.io.File p3)
    {
        this.k = new a0.i(1);
        this.j = p3;
        this.g = 262144000;
        this.h = 1;
        this.i = new a0.i(2);
        return;
    }

    public void a()
    {
        if (this.h) {
            java.util.ArrayList v0_2 = ((java.util.ArrayList) this.i);
            int v1 = v0_2.size();
            int v3 = 0;
            while (v3 < v1) {
                q0.q0 v4_0 = v0_2.get(v3);
                v3++;
                ((q0.q0) v4_0).b();
            }
            this.h = 0;
            return;
        } else {
            return;
        }
    }

    public declared_synchronized u2.d b()
    {
        if (((u2.d) this.l) == null) {
            this.l = u2.d.L(((java.io.File) this.j), this.g, this.h);
        }
        return ((u2.d) this.l);
    }

    public void c()
    {
        if (!this.h) {
            int v0_2 = ((java.util.ArrayList) this.i);
            int v1 = v0_2.size();
            int v2 = 0;
            while (v2 < v1) {
                android.view.ViewPropertyAnimator v3_0 = v0_2.get(v2);
                v2++;
                android.view.ViewPropertyAnimator v3_1 = ((q0.q0) v3_0);
                k.i v4_0 = this.g;
                if (v4_0 >= 0) {
                    v3_1.c(v4_0);
                }
                k.i v4_2 = ((android.view.animation.Interpolator) this.j);
                if (v4_2 != null) {
                    android.view.ViewPropertyAnimator v5_2 = ((android.view.View) v3_1.a.get());
                    if (v5_2 != null) {
                        v5_2.animate().setInterpolator(v4_2);
                    }
                }
                if (((q0.r0) this.k) != null) {
                    v3_1.d(((k.i) this.l));
                }
                android.view.ViewPropertyAnimator v3_4 = ((android.view.View) v3_1.a.get());
                if (v3_4 != null) {
                    v3_4.animate().start();
                }
            }
            this.h = 1;
            return;
        } else {
            return;
        }
    }

    public void e(w2.d p8, y2.d p9)
    {
        String v2_2 = ((a0.i) this.i).s(p8);
        Object v3_6 = ((a0.i) this.k);
        StringBuilder v4_1 = ((a3.b) ((java.util.HashMap) v3_6.h).get(v2_2));
        if (v4_1 == null) {
            v4_1 = ((a3.b) ((a3.c) v3_6.i).a.poll());
            if (v4_1 == null) {
                v4_1 = new a3.b();
            }
            ((java.util.HashMap) v3_6.h).put(v2_2, v4_1);
        }
        v4_1.b = (v4_1.b + 1);
        v4_1.a.lock();
        try {
            if (android.util.Log.isLoggable("DiskLruCacheWrapper", 2)) {
                StringBuilder v4_9 = new StringBuilder("Put: Obtained: ");
                v4_9.append(v2_2);
                v4_9.append(" for for Key: ");
                v4_9.append(p8);
                android.util.Log.v("DiskLruCacheWrapper", v4_9.toString());
            }
            try {
                IllegalStateException v8_6 = this.b();
            } catch (IllegalStateException v8_10) {
                if (!android.util.Log.isLoggable("DiskLruCacheWrapper", 5)) {
                    ((a0.i) this.k).w(v2_2);
                    return;
                } else {
                    android.util.Log.w("DiskLruCacheWrapper", "Unable to put to disk cache", v8_10);
                    ((a0.i) this.k).w(v2_2);
                    return;
                }
            } catch (java.io.IOException) {
                ((a0.i) this.k).w(v2_2);
                return;
            }
            if (v8_6.Z(v2_2) == null) {
                IllegalStateException v8_7 = v8_6.B(v2_2);
                if (v8_7 == null) {
                    throw new IllegalStateException("Had two simultaneous puts for: ".concat(v2_2));
                } else {
                    try {
                        if (((w2.a) p9.a).g(p9.b, v8_7.h(), ((w2.g) p9.c))) {
                            u2.d.d(((u2.d) v8_7.e), v8_7, 1);
                            v8_7.b = 1;
                        }
                    } catch (boolean v9_7) {
                        if (!v8_7.b) {
                            v8_7.a();
                        }
                        throw v9_7;
                    }
                    if (v8_7.b) {
                        ((a0.i) this.k).w(v2_2);
                        return;
                    } else {
                        v8_7.a();
                        ((a0.i) this.k).w(v2_2);
                        return;
                    }
                }
            } else {
                ((a0.i) this.k).w(v2_2);
                return;
            }
        } catch (IllegalStateException v8_11) {
            ((a0.i) this.k).w(v2_2);
            throw v8_11;
        }
    }

    public java.io.File g(w2.d p6)
    {
        java.io.File v1_6 = ((a0.i) this.i).s(p6);
        if (android.util.Log.isLoggable("DiskLruCacheWrapper", 2)) {
            java.io.File v2_1 = new StringBuilder("Get: Obtained: ");
            v2_1.append(v1_6);
            v2_1.append(" for for Key: ");
            v2_1.append(p6);
            android.util.Log.v("DiskLruCacheWrapper", v2_1.toString());
        }
        try {
            String v6_3 = this.b().Z(v1_6);
        } catch (String v6_9) {
            if (!android.util.Log.isLoggable("DiskLruCacheWrapper", 5)) {
                return 0;
            } else {
                android.util.Log.w("DiskLruCacheWrapper", "Unable to get from disk cache", v6_9);
                return 0;
            }
        }
        if (v6_3 == null) {
            return 0;
        } else {
            java.io.File v1_3 = ((java.io.File[]) v6_3.i);
            if (v1_3 == null) {
                return new java.io.File(((u2.d) v6_3.j).g, ((String) v6_3.h).concat(".0"));
            } else {
                return v1_3[0];
            }
        }
    }
}
