// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a3;
public interface a {

    public abstract void e(w2.d p0, y2.d p1);

    public abstract java.io.File g(w2.d p0);
}
