// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a3;
public final class h {
    public static final int e;
    public final android.content.Context a;
    public final android.app.ActivityManager b;
    public final a3.f c;
    public final float d;

    static h()
    {
        int v0_1;
        if (android.os.Build$VERSION.SDK_INT >= 26) {
            v0_1 = 1;
        } else {
            v0_1 = 4;
        }
        a3.h.e = v0_1;
        return;
    }

    public h(android.content.Context p4)
    {
        this.d = ((float) a3.h.e);
        this.a = p4;
        android.app.ActivityManager v0_4 = ((android.app.ActivityManager) p4.getSystemService("activity"));
        this.b = v0_4;
        this.c = new a3.f(p4.getResources().getDisplayMetrics(), 1);
        if ((android.os.Build$VERSION.SDK_INT >= 26) && (v0_4.isLowRamDevice())) {
            this.d = 0;
        }
        return;
    }
}
