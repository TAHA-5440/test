// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a3;
public final class e implements c3.t, e1.j, s3.g {
    public final synthetic int g;
    public android.content.Context h;

    public synthetic e()
    {
        this.g = 10;
        return;
    }

    public e(android.content.Context p2)
    {
        this.g = 11;
        this.h = p2.getApplicationContext();
        return;
    }

    public synthetic e(android.content.Context p1, int p2)
    {
        this.g = p2;
        this.h = p1;
        return;
    }

    public void a(com.bumptech.glide.i p9)
    {
        java.util.concurrent.ThreadPoolExecutor v0_1 = new java.util.concurrent.ThreadPoolExecutor(0, 1, 15, java.util.concurrent.TimeUnit.SECONDS, new java.util.concurrent.LinkedBlockingDeque(), new e1.a("EmojiCompatInitializer"));
        v0_1.allowCoreThreadTimeOut(1);
        v0_1.execute(new androidx.fragment.app.n(this, p9, v0_1, 16));
        return;
    }

    public d4.l b()
    {
        IllegalStateException v0_0 = this.h;
        if (v0_0 == null) {
            String v1_4 = android.content.Context.getCanonicalName();
            StringBuilder v2_11 = new StringBuilder();
            v2_11.append(v1_4);
            v2_11.append(" must be set");
            throw new IllegalStateException(v2_11.toString());
        } else {
            String v1_2 = new d4.l();
            v1_2.g = f4.a.a(d4.n.a);
            StringBuilder v2_3 = new e4.d(v0_0, 1);
            v1_2.h = v2_3;
            v1_2.i = f4.a.a(new e4.f(v2_3, new e4.d(v2_3, 0), 0));
            IllegalStateException v0_6 = v1_2.h;
            v1_2.j = new k4.c(v0_6, 1);
            IllegalStateException v0_7 = f4.a.a(new k4.c(v0_6, 0));
            v1_2.k = v0_7;
            fa.a v8_0 = f4.a.a(new e4.f(v1_2.j, v0_7, 1));
            v1_2.l = v8_0;
            StringBuilder v2_9 = v1_2.h;
            fa.a v6_0 = v1_2.g;
            fa.a v7 = v1_2.i;
            d4.t v9_2 = v8_0;
            fa.a v8_1 = new d4.t(v2_9, v8_0, new i4.c(), 1);
            d4.t v9_3 = v8_1;
            fa.a v8_2 = v9_2;
            fa.a v10_1 = v6_0;
            v1_2.m = f4.a.a(new d4.t(new i4.b(v6_0, v7, v8_1, v9_2, v8_0), new j4.f(v2_9, v7, v8_2, v9_3, v10_1, v8_2, v8_2), new j4.g(v10_1, v8_2, v9_3, v8_2), 0));
            return v1_2;
        }
    }

    public Object get()
    {
        return ((android.net.ConnectivityManager) this.h.getSystemService("connectivity"));
    }

    public c3.s i(c3.z p5)
    {
        switch (this.g) {
            case 2:
                return new c3.b(this.h, this);
            case 3:
                return new c3.b(this.h, this);
            case 4:
                return new c3.b(this.h, this);
            case 5:
                return new c3.o(this.h, 0);
            case 6:
                return new c3.b(this.h, p5.a(Integer, android.content.res.AssetFileDescriptor));
            case 7:
                return new c3.b(this.h, p5.a(Integer, java.io.InputStream));
            case 8:
                return new c3.o(this.h, 1);
            default:
                return new c3.o(this.h, 2);
        }
    }
}
