// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a3;
public final class i {
    public final int a;
    public final int b;
    public final int c;

    public i(a3.h p10)
    {
        long v3_1;
        boolean v0_0 = p10.a;
        String v1_0 = p10.d;
        android.app.ActivityManager v2 = p10.b;
        if (!v2.isLowRamDevice()) {
            v3_1 = 4194304;
        } else {
            v3_1 = 2097152;
        }
        long v5_2;
        this.c = v3_1;
        int v4_1 = (v2.getMemoryClass() * 1048576);
        if (!v2.isLowRamDevice()) {
            v5_2 = 1053609165;
        } else {
            v5_2 = 1051260355;
        }
        int v4_4 = Math.round((((float) v4_1) * v5_2));
        String v10_4 = ((android.util.DisplayMetrics) p10.c.h);
        String v10_6 = ((float) ((v10_4.widthPixels * v10_4.heightPixels) * 4));
        long v5_7 = Math.round((v10_6 * v1_0));
        String v10_8 = Math.round((v10_6 * 1073741824));
        int v7 = (v4_4 - v3_1);
        int v8 = (v10_8 + v5_7);
        if (v8 > v7) {
            String v10_10 = (((float) v7) / (v1_0 + 1073741824));
            this.b = Math.round((1073741824 * v10_10));
            this.a = Math.round((v10_10 * v1_0));
        } else {
            this.b = v10_8;
            this.a = v5_7;
        }
        if (android.util.Log.isLoggable("MemorySizeCalculator", 3)) {
            long v3_4;
            String v10_16 = new StringBuilder("Calculation complete, Calculated memory cache size: ");
            v10_16.append(android.text.format.Formatter.formatFileSize(v0_0, ((long) this.b)));
            v10_16.append(", pool size: ");
            v10_16.append(android.text.format.Formatter.formatFileSize(v0_0, ((long) this.a)));
            v10_16.append(", byte array size: ");
            v10_16.append(android.text.format.Formatter.formatFileSize(v0_0, ((long) v3_1)));
            v10_16.append(", memory class limited? ");
            if (v8 <= v4_4) {
                v3_4 = 0;
            } else {
                v3_4 = 1;
            }
            v10_16.append(v3_4);
            v10_16.append(", max size: ");
            v10_16.append(android.text.format.Formatter.formatFileSize(v0_0, ((long) v4_4)));
            v10_16.append(", memoryClass: ");
            v10_16.append(v2.getMemoryClass());
            v10_16.append(", isLowMemoryDevice: ");
            v10_16.append(v2.isLowRamDevice());
            android.util.Log.d("MemorySizeCalculator", v10_16.toString());
        }
        return;
    }
}
