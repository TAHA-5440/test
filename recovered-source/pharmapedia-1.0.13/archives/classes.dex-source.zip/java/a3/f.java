// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a3;
public final class f implements q0.s, c3.t, w2.a, g7.m2, e2.b, f2.g, l.k, m.s1 {
    public final synthetic int g;
    public Object h;

    public f(int p3)
    {
        this.g = p3;
        switch (p3) {
            case 6:
                this.h = new c3.c0(7);
                return;
            case 7:
                this.h = new c3.p(500);
                return;
            case 9:
                this.h = new java.util.LinkedHashSet();
                return;
            case 12:
                this.h = new a3.f(7);
                return;
            case 16:
                this.h = 0;
                return;
            case 25:
                return;
            case 28:
                this.h = new b9.c();
                return;
            default:
                this.h = new java.util.LinkedHashMap();
                return;
        }
    }

    public f(android.content.Context p3)
    {
        this.g = 0;
        a3.e v0_2 = new a3.e(p3, 0);
        this.h = v0_2;
        return;
    }

    public f(android.widget.EditText p2)
    {
        this.g = 14;
        this.h = new a0.i(p2);
        return;
    }

    public f(android.widget.TextView p2)
    {
        this.g = 15;
        this.h = new g1.g(p2);
        return;
    }

    public f(c3.v p2)
    {
        this.g = 10;
        this.h = java.util.Collections.unmodifiableMap(new java.util.HashMap(p2.a));
        return;
    }

    public f(f2.e p2)
    {
        this.g = 21;
        p2.getClass();
        this.h = p2;
        return;
    }

    public f(g7.c1 p2)
    {
        this.g = 27;
        String[] v2_1 = p2.b;
        String[] v0_2 = new String[v2_1.size()];
        this.h = ((String[]) v2_1.toArray(v0_2));
        return;
    }

    public synthetic f(Object p1, int p2)
    {
        this.g = p2;
        this.h = p1;
        return;
    }

    public f(zb.d p10)
    {
        this.g = 3;
        this.h = new java.util.concurrent.ThreadPoolExecutor(0, 2147483647, 60, java.util.concurrent.TimeUnit.SECONDS, new java.util.concurrent.SynchronousQueue(), p10);
        return;
    }

    public f(boolean p2)
    {
        this.g = 5;
        this.h = new java.util.concurrent.atomic.AtomicBoolean(p2);
        return;
    }

    public String B()
    {
        return ((h2.c) this.h).h;
    }

    public void a(z1.b p5)
    {
        p5.getClass();
        int v1 = p5.endVersion;
        String v2_6 = ((java.util.LinkedHashMap) this.h);
        Integer v0_7 = Integer.valueOf(p5.startVersion);
        java.util.TreeMap v3_1 = v2_6.get(v0_7);
        if (v3_1 == null) {
            v3_1 = new java.util.TreeMap();
            v2_6.put(v0_7, v3_1);
        }
        java.util.TreeMap v3_2 = ((java.util.TreeMap) v3_1);
        if (v3_2.containsKey(Integer.valueOf(v1))) {
            Integer v0_4 = new StringBuilder("Overriding migration ");
            v0_4.append(v3_2.get(Integer.valueOf(v1)));
            v0_4.append(" with ");
            v0_4.append(p5);
            android.util.Log.w("ROOM", v0_4.toString());
        }
        v3_2.put(Integer.valueOf(v1), p5);
        return;
    }

    public e2.a b(String p10)
    {
        p10.getClass();
        String v0_1 = ((f2.e) this.h);
        String v1_0 = v0_1.getDatabaseName();
        if (v1_0 != null) {
            if (!v1_0.equals(p10)) {
                int v6_0 = db.i.c0(v1_0, 47, 0, 6);
                if (v6_0 != -1) {
                    v1_0 = v1_0.substring((v6_0 + 1), v1_0.length());
                }
                String v3_3;
                String v3_1 = db.i.c0(p10, 47, 0, 6);
                if (v3_1 != -1) {
                    v3_3 = p10.substring((v3_1 + 1), p10.length());
                } else {
                    v3_3 = p10;
                }
                if (!v1_0.equals(v3_3)) {
                    androidx.fragment.app.a.u("This driver is configured to open a database named \'", v0_1.getDatabaseName(), "\' but \'", p10, "\' was requested.");
                    return 0;
                }
            }
        } else {
            if (!p10.equals(":memory:")) {
                oc.l.d(f0.a.d("This driver is configured to open an in-memory database but a file-based named \'", p10, "\' was requested."));
                return 0;
            }
        }
        return new androidx.sqlite.driver.a(v0_1.H());
    }

    public boolean c()
    {
        return 1;
    }

    public void d(l.m p1, android.view.MenuItem p2)
    {
        ((l.g) this.h).m.removeCallbacksAndMessages(p1);
        return;
    }

    public void e(boolean p3)
    {
        g7.j0 v0_1 = ((io.grpc.internal.g) this.h);
        v0_1.b0.h(v0_1.F, p3);
        return;
    }

    public void f(l.m p1)
    {
        return;
    }

    public boolean g(Object p6, java.io.File p7, w2.g p8)
    {
        yb.q v0_1 = ((yb.q) this.h);
        byte[] v1_2 = ((byte[]) v0_1.e(byte[], 65536));
        int v2_0 = 0;
        java.io.FileOutputStream v3_0 = 0;
        try {
            java.io.FileOutputStream v4_1 = new java.io.FileOutputStream(p7);
        } catch (Throwable v6_2) {
            if (android.util.Log.isLoggable("StreamEncoder", 3)) {
                android.util.Log.d("StreamEncoder", "Failed to encode data onto the OutputStream", v6_2);
            }
            try {
                if (v3_0 != null) {
                    v3_0.close();
                }
            } catch (java.io.IOException) {
            }
            v0_1.j(v1_2);
            return v2_0;
        } catch (Throwable v6_3) {
            try {
                if (v3_0 != null) {
                    v3_0.close();
                }
            } catch (java.io.IOException) {
            }
            v0_1.j(v1_2);
            throw v6_3;
        }
        while(true) {
            String v7_1 = ((java.io.InputStream) p6).read(v1_2);
            if (v7_1 == -1) {
                break;
            }
            v4_1.write(v1_2, 0, v7_1);
        }
        v4_1.close();
        try {
            v4_1.close();
        } catch (java.io.IOException) {
        }
        v0_1.j(v1_2);
        v2_0 = 1;
        return v2_0;
    }

    public void h(f2.f p8)
    {
        h2.c v0_1 = ((h2.c) this.h);
        int v1_1 = v0_1.j.length;
        int v3 = 1;
        while (v3 < v1_1) {
            byte[] v4_7 = v0_1.j[v3];
            if (v4_7 == 1) {
                p8.c(v3, v0_1.k[v3]);
            } else {
                if (v4_7 == 2) {
                    p8.s(v3, v0_1.l[v3]);
                } else {
                    if (v4_7 == 3) {
                        byte[] v4_3 = v0_1.m[v3];
                        v4_3.getClass();
                        p8.m(v3, v4_3);
                    } else {
                        if (v4_7 == 4) {
                            byte[] v4_5 = v0_1.n[v3];
                            v4_5.getClass();
                            p8.F(v3, v4_5);
                        } else {
                            if (v4_7 == 5) {
                                p8.O(v3);
                            }
                        }
                    }
                }
            }
            v3++;
        }
        return;
    }

    public c3.s i(c3.z p3)
    {
        switch (this.g) {
            case 6:
                return new c3.c(((c3.c0) this.h), 1);
            default:
                return new d3.a(((a3.f) this.h));
        }
    }

    public void j(java.io.OutputStream p10)
    {
        b9.c v0_1 = ((b9.c) this.h);
        long v2_2 = s6.f.g;
        oc.i v1_4 = Integer.valueOf(v0_1.c);
        v2_2.getClass();
        p10.getClass();
        oc.c v3_0 = new oc.c(p10, new oc.f0());
        long v4_2 = new oc.x(v3_0);
        long v5_1 = new s6.h();
        v2_2.e(v5_1, v1_4);
        v5_1.a();
        oc.i v1_0 = v5_1.a;
        while (v1_0.N(8192, v4_2.h) != -1) {
            v4_2.d();
        }
        if (v4_2.i) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.w("closed");
            return;
        } else {
            oc.i v1_3 = v4_2.h;
            long v4_3 = v1_3.h;
            if (v4_3 > 0) {
                v3_0.D(v4_3, v1_3);
            }
            v0_1.b(p10);
            return;
        }
    }

    public q0.o1 k(android.view.View p6, q0.o1 p7)
    {
        p6 = p7.a;
        androidx.coordinatorlayout.widget.CoordinatorLayout v0_1 = ((androidx.coordinatorlayout.widget.CoordinatorLayout) this.h);
        if (!java.util.Objects.equals(v0_1.t, p7)) {
            int v1_0;
            v0_1.t = p7;
            int v2 = 0;
            boolean v3_0 = 1;
            if (p7.d() <= 0) {
                v1_0 = 0;
            } else {
                v1_0 = 1;
            }
            v0_1.u = v1_0;
            if ((v1_0 != 0) || (v0_1.getBackground() != null)) {
                v3_0 = 0;
            }
            v0_1.setWillNotDraw(v3_0);
            if (!p6.n()) {
                int v1_3 = v0_1.getChildCount();
                while (v2 < v1_3) {
                    boolean v3_1 = v0_1.getChildAt(v2);
                    if ((v3_1.getFitsSystemWindows()) && ((((c0.d) v3_1.getLayoutParams()).a != null) && (p6.n()))) {
                        break;
                    }
                    v2++;
                }
            }
            v0_1.requestLayout();
        }
        return p7;
    }

    public void l(e7.y0 p4, byte[] p5)
    {
        ea.b.c();
        h7.h v1_5 = new StringBuilder("/");
        v1_5.append(((h7.i) this.h).h.b);
        String v0_1 = v1_5.toString();
        if (p5 != null) {
            ((h7.i) this.h).o = 1;
            h7.h v1_3 = new StringBuilder();
            v1_3.append(v0_1);
            v1_3.append("?");
            v1_3.append(w5.e.a.c(p5));
            v0_1 = v1_3.toString();
        }
        h7.h.j(((h7.i) this.h).l, p4, v0_1);
        ea.b.a.getClass();
        return;
    }

    public boolean m(l.m p4, android.view.MenuItem p5)
    {
        androidx.viewpager2.widget.ViewPager2 v4_2 = ((com.google.android.material.bottomnavigation.BottomNavigationView) this.h).k;
        if (v4_2 == null) {
            return 0;
        } else {
            androidx.viewpager2.widget.ViewPager2 v4_6 = ((uc.i) ((androidx.work.impl.b) v4_2).h).c;
            Class vtmp1 = p5.getClass();
            int v5_1 = p5.getItemId();
            if (v5_1 != 2131362199) {
                if (v5_1 != 2131362198) {
                    if (v5_1 != 2131362200) {
                        return 1;
                    } else {
                        v4_6.setCurrentItem(2);
                        return 0;
                    }
                } else {
                    v4_6.setCurrentItem(1);
                    return 0;
                }
            } else {
                v4_6.setCurrentItem(0);
                return 0;
            }
        }
    }

    public void o(l.m p10, l.p p11)
    {
        Object v0_1 = ((l.g) this.h);
        android.os.Handler v1 = v0_1.m;
        l.f v2_1 = 0;
        v1.removeCallbacksAndMessages(0);
        Object v0_3 = v0_1.o;
        g7.a v3_3 = v0_3.size();
        long v4_0 = 0;
        while (v4_0 < v3_3) {
            if (p10 != ((l.f) v0_3.get(v4_0)).b) {
                v4_0++;
            }
            if (v4_0 != -1) {
                long v4_1 = (v4_0 + 1);
                if (v4_1 < v0_3.size()) {
                    v2_1 = ((l.f) v0_3.get(v4_1));
                }
                v1.postAtTime(new g7.a(this, v2_1, p11, p10, 4), p10, (android.os.SystemClock.uptimeMillis() + 200));
                return;
            } else {
                return;
            }
        }
        v4_0 = -1;
    }

    public String toString()
    {
        switch (this.g) {
            case 27:
                String v0_3 = new StringBuilder();
                String[] v1_1 = ((String[]) this.h);
                int v2_1 = (v1_1.length / 2);
                int v3 = 0;
                while (v3 < v2_1) {
                    int v6_1;
                    String v4_0 = (v3 * 2);
                    String v5 = 0;
                    if ((v4_0 >= null) && (v4_0 < v1_1.length)) {
                        v6_1 = v1_1[v4_0];
                    } else {
                        v6_1 = 0;
                    }
                    v0_3.append(v6_1);
                    v0_3.append(": ");
                    String v4_1 = (v4_0 + 1);
                    if ((v4_1 >= null) && (v4_1 < v1_1.length)) {
                        v5 = v1_1[v4_1];
                    }
                    v0_3.append(v5);
                    v0_3.append("\n");
                    v3++;
                }
                return v0_3.toString();
            default:
                return super.toString();
        }
    }
}
