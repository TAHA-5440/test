// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a3;
public final class j implements t3.b {
    public final java.security.MessageDigest g;
    public final t3.d h;

    public j(java.security.MessageDigest p2)
    {
        this.h = new t3.d();
        this.g = p2;
        return;
    }

    public final t3.d b()
    {
        return this.h;
    }
}
