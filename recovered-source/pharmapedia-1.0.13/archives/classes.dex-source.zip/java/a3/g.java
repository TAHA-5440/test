// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a3;
public final class g extends s3.j {
    public com.bumptech.glide.load.engine.b d;

    public final int b(Object p1)
    {
        if (((y2.u) p1) != null) {
            return ((y2.u) p1).c();
        } else {
            return 1;
        }
    }

    public final void c(Object p2, Object p3)
    {
        a7.j v2_1 = this.d;
        if ((v2_1 != null) && (((y2.u) p3) != null)) {
            v2_1.e.i(((y2.u) p3), 1);
        }
        return;
    }
}
