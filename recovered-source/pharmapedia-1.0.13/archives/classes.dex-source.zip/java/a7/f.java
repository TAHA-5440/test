// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a7;
public interface f {
}
