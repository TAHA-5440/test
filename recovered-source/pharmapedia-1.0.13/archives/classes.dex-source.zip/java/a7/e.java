// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a7;
public final class e extends androidx.lifecycle.c1 {
    public final qc.h a;
    public final a7.j b;

    public e(qc.h p1, a7.j p2)
    {
        this.a = p1;
        this.b = p2;
        return;
    }

    public final void onCleared()
    {
        ((z6.f) ((qc.h) ((a7.f) com.bumptech.glide.h.i(this.a, a7.f))).c.get()).a();
        return;
    }
}
