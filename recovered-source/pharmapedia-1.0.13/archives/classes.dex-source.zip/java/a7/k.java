// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a7;
public final class k extends android.content.ContextWrapper {
    public android.view.LayoutInflater a;
    public android.view.LayoutInflater b;

    public k(android.content.Context p2, qc.c p3)
    {
        p2.getClass();
        super(p2);
        c2.b v2_2 = new c2.b(super, 1);
        super.a = 0;
        p3.getLifecycle().a(v2_2);
        return;
    }

    public k(android.view.LayoutInflater p3, qc.c p4)
    {
        p3.getClass();
        c2.b v0_0 = p3.getContext();
        v0_0.getClass();
        super(v0_0);
        c2.b v0_2 = new c2.b(super, 1);
        super.a = p3;
        p4.getLifecycle().a(v0_2);
        return;
    }

    public final Object getSystemService(String p3)
    {
        if ("layout_inflater".equals(p3)) {
            if (this.b == null) {
                if (this.a == null) {
                    this.a = ((android.view.LayoutInflater) this.getBaseContext().getSystemService("layout_inflater"));
                }
                this.b = this.a.cloneInContext(this);
            }
            return this.b;
        } else {
            return this.getBaseContext().getSystemService(p3);
        }
    }
}
