// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a7;
public final class g implements c7.b {
    public final qc.b g;
    public final qc.b h;
    public volatile qc.h i;
    public final Object j;

    public g(qc.b p2)
    {
        this.j = new Object();
        this.g = p2;
        this.h = p2;
        return;
    }

    public final Object a()
    {
        if (this.i == null) {
            if (this.i == null) {
                qc.h v1_4;
                qc.h v1_9 = this.g;
                String v3_0 = new androidx.lifecycle.h1(v1_9.getViewModelStore(), new a7.c(this.h, 0), v1_9.getDefaultViewModelCreationExtras());
                qc.h v1_2 = kotlin.jvm.internal.h.a(a7.e);
                c0.g v2_2 = ((c0.g) v3_0.a);
                String v3_1 = v1_2.b();
                if (v3_1 == null) {
                    com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("Local and anonymous classes can not be ViewModels");
                    v1_4 = 0;
                } else {
                    v1_4 = v2_2.h(v1_2, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(v3_1));
                }
                this.i = ((a7.e) v1_4).a;
            }
        }
        return this.i;
    }
}
