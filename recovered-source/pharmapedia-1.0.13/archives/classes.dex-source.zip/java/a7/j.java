// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a7;
public class j implements g5.h {
    public boolean g;
    public Object h;

    public synthetic j(Object p2)
    {
        this.g = 1;
        this.h = p2;
        return;
    }

    public j(String p1, boolean p2)
    {
        this.g = p2;
        this.h = p1;
        return;
    }

    public void a()
    {
        this.g = 0;
        return;
    }

    public q0.o1 b(android.view.View p17, q0.o1 p18, g5.i p19)
    {
        int v8_2;
        i0.c v4_1 = p18.a;
        int v5_2 = v4_1.f(519);
        i0.c v4_0 = v4_1.f(32);
        com.google.android.material.bottomsheet.BottomSheetBehavior v6_1 = ((com.google.android.material.bottomsheet.BottomSheetBehavior) this.h);
        boolean v7 = v6_1.p;
        int v9 = v5_2.c;
        int v10 = v5_2.a;
        v6_1.x = v5_2.b;
        int v12 = 1;
        if (p17.getLayoutDirection() != 1) {
            v8_2 = 0;
        } else {
            v8_2 = 1;
        }
        int v13_0 = p17.getPaddingBottom();
        int v14 = p17.getPaddingLeft();
        int v15 = p17.getPaddingRight();
        if (v7) {
            int v13_1 = p18.a();
            v6_1.w = v13_1;
            v13_0 = (v13_1 + p19.d);
        }
        if (v6_1.q) {
            int v11_2;
            if (v8_2 == 0) {
                v11_2 = p19.a;
            } else {
                v11_2 = p19.c;
            }
            v14 = (v11_2 + v10);
        }
        if (v6_1.r) {
            int v3_1;
            if (v8_2 == 0) {
                v3_1 = p19.c;
            } else {
                v3_1 = p19.a;
            }
            v15 = (v3_1 + v9);
        }
        int v11_4;
        int v3_3 = ((android.view.ViewGroup$MarginLayoutParams) p17.getLayoutParams());
        if ((!v6_1.t) || (v3_3.leftMargin == v10)) {
            v11_4 = 0;
        } else {
            v3_3.leftMargin = v10;
            v11_4 = 1;
        }
        if ((v6_1.u) && (v3_3.rightMargin != v9)) {
            v3_3.rightMargin = v9;
            v11_4 = 1;
        }
        if (!v6_1.v) {
            v12 = v11_4;
        } else {
            int v5_1 = v5_2.b;
            if (v3_3.topMargin == v5_1) {
            } else {
                v3_3.topMargin = v5_1;
            }
        }
        if (v12 != 0) {
            p17.setLayoutParams(v3_3);
        }
        p17.setPadding(v14, p17.getPaddingTop(), v15, v13_0);
        boolean v1_1 = this.g;
        if (v1_1) {
            v6_1.n = v4_0.d;
        }
        if ((!v7) && (!v1_1)) {
            return p18;
        } else {
            v6_1.R();
            return p18;
        }
    }

    public void c(byte p4)
    {
        ((cc.z) this.h).r(String.valueOf(((long) p4)));
        return;
    }

    public void d(char p5)
    {
        cc.z v0_1 = ((cc.z) this.h);
        v0_1.d(v0_1.h, 1);
        char[] v1_2 = ((char[]) v0_1.i);
        int v2_1 = v0_1.h;
        v0_1.h = (v2_1 + 1);
        v1_2[v2_1] = p5;
        return;
    }

    public void e(int p4)
    {
        ((cc.z) this.h).r(String.valueOf(((long) p4)));
        return;
    }

    public void f(long p2)
    {
        ((cc.z) this.h).r(String.valueOf(p2));
        return;
    }

    public void g(short p4)
    {
        ((cc.z) this.h).r(String.valueOf(((long) p4)));
        return;
    }

    public void h(String p12)
    {
        p12.getClass();
        cc.z v0_1 = ((cc.z) this.h);
        v0_1.d(v0_1.h, (p12.length() + 2));
        int v1_0 = ((char[]) v0_1.i);
        int v3_0 = v0_1.h;
        char[] v4_0 = (v3_0 + 1);
        v1_0[v3_0] = 34;
        int v3_1 = p12.length();
        p12.getChars(0, v3_1, v1_0, v4_0);
        int v3_2 = (v3_1 + v4_0);
        int v7 = v4_0;
        while (v7 < v3_2) {
            int v8_0 = v1_0[v7];
            char v9_0 = wb.k.b;
            if ((v8_0 >= v9_0.length) || (v9_0[v8_0] == 0)) {
                v7++;
            } else {
                int v1_1 = (v7 - v4_0);
                int v3_3 = p12.length();
                while (v1_1 < v3_3) {
                    char v9_2;
                    v0_1.d(v7, 2);
                    int v8_2 = p12.charAt(v1_1);
                    char v9_1 = wb.k.b;
                    if (v8_2 >= v9_1.length) {
                        v9_2 = (v7 + 1);
                        ((char[]) v0_1.i)[v7] = ((char) v8_2);
                        v7 = v9_2;
                    } else {
                        char v9_3 = v9_1[v8_2];
                        if (v9_3 != 0) {
                            if (v9_3 != 1) {
                                char[] v4_5 = ((char[]) v0_1.i);
                                v4_5[v7] = 92;
                                v4_5[(v7 + 1)] = ((char) v9_3);
                                v7 += 2;
                                v0_1.h = v7;
                            } else {
                                char[] v4_7 = wb.k.a[v8_2];
                                v4_7.getClass();
                                v0_1.d(v7, v4_7.length());
                                v4_7.getChars(0, v4_7.length(), ((char[]) v0_1.i), v7);
                                char[] v4_9 = (v4_7.length() + v7);
                                v0_1.h = v4_9;
                                v7 = v4_9;
                            }
                        } else {
                            v9_2 = (v7 + 1);
                            ((char[]) v0_1.i)[v7] = ((char) v8_2);
                        }
                    }
                    v1_1++;
                }
                v0_1.d(v7, 1);
                int v1_3 = (v7 + 1);
                ((char[]) v0_1.i)[v7] = 34;
                v0_1.h = v1_3;
                return;
            }
        }
        char[] v12_1 = (v3_2 + 1);
        v1_0[v3_2] = 34;
        v0_1.h = v12_1;
        return;
    }

    public declared_synchronized void i(y2.u p3, boolean p4)
    {
        if (this.g) {
            ((android.os.Handler) this.h).obtainMessage(1, p3).sendToTarget();
        } else {
            if (p4 == null) {
                this.g = 1;
                p3.a();
                this.g = 0;
            } else {
            }
        }
        return;
    }

    public void j()
    {
        return;
    }

    public void k()
    {
        return;
    }
}
