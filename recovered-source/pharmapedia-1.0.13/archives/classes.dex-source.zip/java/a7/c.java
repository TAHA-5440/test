// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a7;
public final class c implements androidx.lifecycle.f1 {
    public final synthetic int a;
    public final synthetic Object b;

    public synthetic c(Object p1, int p2)
    {
        this.a = p2;
        this.b = p1;
        return;
    }

    public final androidx.lifecycle.c1 c(Class p6, n1.c p7)
    {
        switch (this.a) {
            case 0:
                return new a7.e(new qc.h(((qc.j) ((a7.d) com.bumptech.glide.j.O(((qc.b) this.b), a7.d))).b), new a7.j(p7));
            default:
                String v6_8;
                String v0_4 = new z6.f();
                androidx.lifecycle.w.c(p7);
                String v1_1 = new qc.k();
                ((qc.k) ((z6.d) com.bumptech.glide.h.i(v1_1, z6.d))).getClass();
                fa.a v3_5 = ((fa.a) com.google.common.collect.ImmutableMap.c().get(p6));
                z6.c v7_7 = ((ua.l) p7.a.get(z6.e.d));
                ((qc.k) ((z6.d) com.bumptech.glide.h.i(v1_1, z6.d))).getClass();
                String v1_6 = com.google.common.collect.ImmutableMap.c().get(p6);
                if (v1_6 != null) {
                    if (v3_5 != null) {
                        String v6_3 = p6.getName();
                        String v0_6 = new StringBuilder("Found the @HiltViewModel-annotated class ");
                        v0_6.append(v6_3);
                        v0_6.append(" in both the multi-bindings of @HiltViewModelMap and @HiltViewModelAssistedMap.");
                        throw new AssertionError(v0_6.toString());
                    } else {
                        if (v7_7 == null) {
                            androidx.fragment.app.a.h(p6.getName(), "Found @HiltViewModel-annotated class ", " using @AssistedInject but no creation callback was provided in CreationExtras.");
                            v6_8 = 0;
                        } else {
                            v6_8 = ((androidx.lifecycle.c1) v7_7.invoke(v1_6));
                            v6_8.addCloseable(new z6.c(v0_4));
                        }
                    }
                } else {
                    if (v7_7 != null) {
                        androidx.fragment.app.a.h(p6.getName(), "Found creation callback but class ", " does not have an assisted factory specified in @HiltViewModel.");
                    } else {
                        if (v3_5 == null) {
                            androidx.fragment.app.a.h(p6.getName(), "Expected the @HiltViewModel-annotated class ", " to be available in the multi-binding of @HiltViewModelMap but none was found.");
                        } else {
                            v6_8 = ((androidx.lifecycle.c1) v3_5.get());
                        }
                    }
                }
                return v6_8;
        }
    }
}
