// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a7;
public final class b implements c7.b {
    public volatile qc.f g;
    public final Object h;
    public final qc.b i;
    public final a7.g j;
    public a7.j k;

    public b(qc.b p2)
    {
        this.h = new Object();
        this.i = p2;
        this.j = new a7.g(p2);
        return;
    }

    public final Object a()
    {
        if (this.g == null) {
            if (this.g == null) {
                this.g = this.b();
            }
        }
        return this.g;
    }

    public final qc.f b()
    {
        String v0_0 = this.i;
        if ((v0_0.getApplication() instanceof c7.b)) {
            qc.h v1_0 = ((qc.h) ((a7.a) com.bumptech.glide.h.i(this.j, a7.a)));
            return new qc.f(v1_0.a, v1_0.b, v0_0);
        } else {
            String v0_3;
            if (!android.app.Application.equals(v0_0.getApplication().getClass())) {
                String v2_5 = new StringBuilder("Found: ");
                v2_5.append(v0_0.getApplication().getClass());
                v0_3 = v2_5.toString();
            } else {
                v0_3 = "Did you forget to specify your Application\'s class name in your manifest\'s <application />\'s android:name attribute?";
            }
            throw new IllegalStateException("Hilt Activity must be attached to an @HiltAndroidApp Application. ".concat(v0_3));
        }
    }
}
