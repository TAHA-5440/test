// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a7;
public final class h implements c7.b {
    public final synthetic int g;
    public final Object h;
    public volatile c7.a i;
    public final Object j;

    public h(l.o p2)
    {
        this.g = 0;
        this.h = new Object();
        this.j = p2;
        return;
    }

    public h(qc.c p2)
    {
        this.g = 1;
        this.h = new Object();
        this.j = p2;
        return;
    }

    public static final android.content.Context c(a7.k p1)
    {
        while (((p1 instanceof android.content.ContextWrapper)) && (!(p1 instanceof android.app.Activity))) {
            p1 = ((android.content.ContextWrapper) p1).getBaseContext();
        }
        return p1;
    }

    public final Object a()
    {
        switch (this.g) {
            case 0:
                if (((qc.j) this.i) == null) {
                    if (((qc.j) this.i) == null) {
                        this.i = new qc.j(new a3.e(((vet.pharmapedia.vetpharmapediapakistan.MyAppClass) ((l.o) this.j).h), 1));
                    }
                }
                return ((qc.j) this.i);
            default:
                if (((qc.i) this.i) == null) {
                    if (((qc.i) this.i) == null) {
                        this.i = this.b();
                    }
                }
                return ((qc.i) this.i);
        }
    }

    public qc.i b()
    {
        int v0_1 = ((qc.c) this.j);
        if (v0_1.getHost() == null) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.j("Hilt Fragments must be attached before creating the component.");
            return 0;
        } else {
            com.bumptech.glide.j.C((v0_1.getHost() instanceof c7.c), "Hilt Fragments must be attached to an @AndroidEntryPoint Activity. Found: %s", new Object[] {v0_1.getHost().getClass()}));
            int v0_5 = ((qc.f) ((a7.i) com.bumptech.glide.h.i(v0_1.getHost(), a7.i)));
            return new qc.i(v0_5.b, v0_5.c, v0_5.d);
        }
    }
}
