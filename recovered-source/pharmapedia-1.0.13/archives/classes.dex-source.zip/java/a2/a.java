// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a2;
public abstract class a {
}
