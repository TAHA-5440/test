// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a2;
public abstract class b implements f2.e, androidx.room.b {
}
