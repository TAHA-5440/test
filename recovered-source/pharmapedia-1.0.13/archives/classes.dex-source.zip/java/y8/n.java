// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package y8;
public interface n {

    public abstract int b(Object p0, Object p1, y8.g p2);

    public abstract void c(y8.m p0, Object p1, Object p2, y8.g p3);
}
