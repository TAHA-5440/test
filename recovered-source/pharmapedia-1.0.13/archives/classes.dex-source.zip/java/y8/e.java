// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package y8;
public abstract class e {

    public abstract int a();

    public final void b(java.io.OutputStream p2)
    {
        Throwable v0_1 = new y8.k(p2);
        try {
            this.c(v0_1);
            v0_1.close();
            return;
        } catch (Throwable v2_1) {
            try {
                v0_1.close();
            } catch (Throwable v0_2) {
                v2_1.addSuppressed(v0_2);
            }
            throw v2_1;
        }
    }

    public abstract void c(y8.m p0);
}
