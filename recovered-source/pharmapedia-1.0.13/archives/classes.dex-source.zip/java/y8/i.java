// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package y8;
public abstract class i extends y8.e {
    public final int a;

    public i(int p1)
    {
        this.a = p1;
        return;
    }

    public final int a()
    {
        return this.a;
    }
}
