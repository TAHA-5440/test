// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package y8;
public interface o {

    public abstract void a(y8.m p0, Object p1, y8.g p2);

    public abstract int d(Object p0, y8.g p1);
}
