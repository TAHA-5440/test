// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package e2;
public interface b {

    public abstract e2.a b(String p0);

    public abstract boolean c();
}
