// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public final class n extends y8.i {
    public static final byte[] d;
    public static final a9.n[] e;
    public final byte[] b;
    public final y8.e c;

    static n()
    {
        byte[] v1 = new byte[0];
        a9.n.d = v1;
        a9.n[] v0_1 = new a9.n[0];
        a9.n.e = v0_1;
        return;
    }

    public n(byte[] p3, y8.i p4)
    {
        super((y8.h.d(f9.d.b, p4) + y8.h.b(f9.d.a, p3)));
        super.b = p3;
        super.c = p4;
        return;
    }

    public static a9.n[] d(p7.b p3)
    {
        if (!p3.isEmpty()) {
            a9.n[] v0_2 = new a9.n[p3.size()];
            p3.forEach(new a9.i(v0_2, 1));
            return v0_2;
        } else {
            return a9.n.e;
        }
    }

    public final void c(y8.m p3)
    {
        p3.c0(f9.d.a, this.b);
        p3.d(f9.d.b, this.c);
        return;
    }
}
