// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public final class m extends y8.i {
    public final long b;

    public m(long p3)
    {
        super((y8.c.a(p3) + f9.a.c.c));
        super.b = p3;
        return;
    }

    public final void c(y8.m p4)
    {
        p4.n0(f9.a.c, this.b);
        return;
    }
}
