// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public final class k extends y8.i {
    public final synthetic int b;
    public final byte[] c;
    public final Object d;
    public final Object e;

    public k(a9.l p7, byte[] p8, java.util.List p9)
    {
        this.b = 1;
        int v1_3 = (y8.h.b(g9.c.c, p8) + y8.h.d(g9.c.a, p7));
        java.util.Iterator v2 = p9.iterator();
        int v3 = 0;
        while (v2.hasNext()) {
            int v4_3 = ((y8.e) v2.next()).a();
            v3 += ((y8.c.b(v4_3) + g9.c.b.c) + v4_3);
        }
        super((v1_3 + v3));
        super.d = p7;
        super.c = p8;
        super.e = p9;
        return;
    }

    public k(a9.o p3, byte[] p4, a9.k[] p5)
    {
        this.b = 2;
        super((y8.h.e(g9.b.b, p5) + (y8.h.b(g9.b.c, p4) + y8.h.d(g9.b.a, p3))));
        super.d = p3;
        super.c = p4;
        super.e = p5;
        return;
    }

    public k(byte[] p3, byte[] p4, a9.n[] p5)
    {
        this.b = 0;
        super((y8.h.e(f9.c.c, p5) + (y8.h.b(f9.c.b, p4) + y8.h.b(f9.c.a, p3))));
        super.c = p3;
        super.d = p4;
        super.e = p5;
        return;
    }

    public final void c(y8.m p3)
    {
        switch (this.b) {
            case 0:
                p3.c0(f9.c.a, this.c);
                p3.c0(f9.c.b, ((byte[]) this.d));
                p3.L(f9.c.c, ((a9.n[]) this.e));
                return;
            case 1:
                p3.d(g9.c.a, ((a9.l) this.d));
                p3.B(g9.c.b, ((java.util.List) this.e));
                p3.c0(g9.c.c, this.c);
                return;
            default:
                p3.d(g9.b.a, ((a9.o) this.d));
                p3.L(g9.b.b, ((a9.k[]) this.e));
                p3.c0(g9.b.c, this.c);
                return;
        }
    }
}
