// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public final class a implements y8.o, y8.n {
    public static final a9.a b;
    public static final a9.a c;
    public static final a9.a d;
    public static final a9.a e;
    public static final a9.a f;
    public static final a9.a g;
    public static final a9.a h;
    public static final a9.a i;
    public static final a9.a j;
    public static final a9.a k;
    public final synthetic int a;

    static synthetic a()
    {
        a9.a.b = new a9.a(0);
        a9.a.c = new a9.a(1);
        a9.a.d = new a9.a(2);
        a9.a.e = new a9.a(3);
        a9.a.f = new a9.a(4);
        a9.a.g = new a9.a(5);
        a9.a.h = new a9.a(6);
        a9.a.i = new a9.a(7);
        a9.a.j = new a9.a(8);
        a9.a.k = new a9.a(9);
        return;
    }

    public synthetic a(int p1)
    {
        this.a = p1;
        return;
    }

    public void a(y8.m p3, Object p4, y8.g p5)
    {
        switch (this.a) {
            case 0:
                switch (((p7.f) p4).a().ordinal()) {
                    case 0:
                        p3.d0(f9.a.a, ((String) ((p7.f) p4).getValue()), p5);
                        break;
                    case 1:
                        p3.e0(f9.a.b, ((Boolean) ((p7.f) p4).getValue()).booleanValue());
                        break;
                    case 2:
                        p3.n0(f9.a.c, ((Long) ((p7.f) p4).getValue()).longValue());
                        break;
                    case 3:
                        p3.g0(f9.a.d, ((Double) ((p7.f) p4).getValue()).doubleValue());
                        break;
                    case 4:
                        p7.f v4_15 = ((java.util.List) ((p7.f) p4).getValue());
                        p3.r0(f9.a.e, p5.e());
                        p3.M(f9.b.a, v4_15, a9.a.b, p5);
                        p3.h0();
                        break;
                    case 5:
                        p7.f v4_13 = ((java.util.List) ((p7.f) p4).getValue());
                        p3.r0(f9.a.f, p5.e());
                        p3.M(f9.e.a, v4_13, a9.a.j, p5);
                        p3.h0();
                        break;
                    case 6:
                        ((p7.f) p4).getValue();
                        p3.f0(f9.a.g, ((byte[]) p5.c(byte[])));
                        break;
                    default:
                        com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("Unsupported value type.");
                }
                return;
            case 1:
            case 2:
            case 3:
            case 6:
            default:
                p3.d0(f9.a.a, ((String) p4), p5);
                return;
            case 4:
                p3.e0(f9.a.b, ((Boolean) p4).booleanValue());
                return;
            case 5:
                p3.g0(f9.a.d, ((Double) p4).doubleValue());
                return;
            case 7:
                p3.n0(f9.a.c, ((Long) p4).longValue());
                return;
            case 8:
                y8.b v0_4 = ((p7.c) p4).a;
                if (!v0_4.isEmpty()) {
                    p3.d0(f9.d.a, v0_4, p5);
                }
                p3.i(f9.d.b, ((p7.c) p4).b, p5);
                return;
        }
    }

    public int b(Object p8, Object p9, y8.g p10)
    {
        int v1_0 = a9.a.c;
        int v3 = 0;
        switch (this.a) {
            case 1:
                int v0_2;
                int v8_31 = ((io.opentelemetry.api.common.AttributeType) p8).ordinal();
                if (v8_31 == 4) {
                    if (!((java.util.List) p9).isEmpty()) {
                        v0_2 = 0;
                        while (v3 < ((java.util.List) p9).size()) {
                            int v1_27 = ((java.util.List) p9).get(v3);
                            int v2_7 = p10.b();
                            int v1_29 = y8.r.d(f9.a.a, ((String) v1_27), p10);
                            p10.c[v2_7] = v1_29;
                            v0_2 += ((y8.c.b(v1_29) + f9.b.a.c) + v1_29);
                            v3++;
                        }
                        v3 = v0_2;
                    }
                } else {
                    if (v8_31 == 5) {
                        if (!((java.util.List) p9).isEmpty()) {
                            v0_2 = 0;
                            while (v3 < ((java.util.List) p9).size()) {
                                int v1_2 = ((java.util.List) p9).get(v3);
                                int v2_0 = p10.b();
                                ((Boolean) v1_2).getClass();
                                int v4_2 = (f9.a.b.c + 1);
                                p10.c[v2_0] = v4_2;
                                v0_2 += ((y8.c.b(v4_2) + f9.b.a.c) + v4_2);
                                v3++;
                            }
                        }
                    } else {
                        if (v8_31 == 6) {
                            if (!((java.util.List) p9).isEmpty()) {
                                v0_2 = 0;
                                while (v3 < ((java.util.List) p9).size()) {
                                    int v1_10 = ((java.util.List) p9).get(v3);
                                    int v2_1 = p10.b();
                                    int v1_13 = (y8.c.a(((Long) v1_10).longValue()) + f9.a.c.c);
                                    p10.c[v2_1] = v1_13;
                                    v0_2 += ((y8.c.b(v1_13) + f9.b.a.c) + v1_13);
                                    v3++;
                                }
                            }
                        } else {
                            if (v8_31 != 7) {
                                com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("Unsupported attribute type.");
                            } else {
                                if (!((java.util.List) p9).isEmpty()) {
                                    v0_2 = 0;
                                    while (v3 < ((java.util.List) p9).size()) {
                                        int v1_15 = ((java.util.List) p9).get(v3);
                                        int v2_5 = p10.b();
                                        ((Double) v1_15).getClass();
                                        int v4_8 = (f9.a.d.c + 8);
                                        p10.c[v2_5] = v4_8;
                                        v0_2 += ((y8.c.b(v4_8) + f9.b.a.c) + v4_8);
                                        v3++;
                                    }
                                }
                            }
                        }
                    }
                }
                return v3;
            case 2:
                int v8_21 = ((u7.e) p8).a;
                switch (v8_21.ordinal()) {
                    case 0:
                        v3 = y8.r.d(f9.a.a, ((String) p9), p10);
                        break;
                    case 1:
                        ((Boolean) p9).getClass();
                        v3 = (f9.a.b.c + 1);
                        break;
                    case 2:
                        v3 = (y8.c.a(((Long) p9).longValue()) + f9.a.c.c);
                        break;
                    case 3:
                        ((Double) p9).getClass();
                        v3 = (f9.a.d.c + 8);
                        break;
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                        v3 = y8.r.a(f9.a.e, v8_21, ((java.util.List) p9), v1_0, p10);
                        break;
                    default:
                        com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("Unsupported attribute type.");
                }
                return v3;
            case 3:
                if (!((u7.e) p8).b.isEmpty()) {
                    int v0_1 = ((u7.e) p8).d;
                    if (v0_1 == 0) {
                        v0_1 = ((u7.e) p8).b.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                        ((u7.e) p8).d = v0_1;
                    }
                    v3 = y8.h.b(f9.d.a, v0_1);
                }
                return (y8.r.a(f9.d.b, ((u7.e) p8), p9, a9.a.d, p10) + v3);
            default:
                switch (((r7.a) p8).a.ordinal()) {
                    case 0:
                        v3 = y8.r.d(f9.a.a, ((String) p9), p10);
                        break;
                    case 1:
                        ((Boolean) p9).getClass();
                        v3 = (f9.a.b.c + 1);
                        break;
                    case 2:
                        v3 = (y8.c.a(((Long) p9).longValue()) + f9.a.c.c);
                        break;
                    case 3:
                        ((Double) p9).getClass();
                        v3 = (f9.a.d.c + 8);
                        break;
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                        int v8_9 = ((r7.a) p8).a();
                        java.util.Objects.requireNonNull(v8_9);
                        v3 = y8.r.a(f9.a.e, v8_9.a, ((java.util.List) p9), v1_0, p10);
                        break;
                    case 8:
                        int v0_10 = p10.b();
                        java.util.List v9_2 = a9.j.f(f9.e.a, ((q7.b) p9), p10);
                        v3 = ((y8.c.b(v9_2) + f9.a.f.c) + v9_2);
                        p10.c[v0_10] = v9_2;
                        break;
                    default:
                        com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("Unsupported attribute type.");
                }
                return v3;
        }
    }

    public void c(y8.m p12, Object p13, Object p14, y8.g p15)
    {
        switch (this.a) {
            case 1:
                y8.b v12_13 = ((io.opentelemetry.api.common.AttributeType) p13).ordinal();
                if (v12_13 == 4) {
                    p12.M(f9.b.a, ((java.util.List) p14), a9.a.k, p15);
                } else {
                    if (v12_13 == 5) {
                        p12.M(f9.b.a, ((java.util.List) p14), a9.a.f, p15);
                    } else {
                        if (v12_13 == 6) {
                            p12.M(f9.b.a, ((java.util.List) p14), a9.a.i, p15);
                        } else {
                            if (v12_13 != 7) {
                                com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("Unsupported attribute type.");
                            } else {
                                p12.M(f9.b.a, ((java.util.List) p14), a9.a.g, p15);
                            }
                        }
                    }
                }
                return;
            case 2:
                u7.e v7_0 = ((u7.e) p13).a;
                switch (v7_0.ordinal()) {
                    case 0:
                        p12.d0(f9.a.a, ((String) p14), p15);
                        break;
                    case 1:
                        p12.e0(f9.a.b, ((Boolean) p14).booleanValue());
                        break;
                    case 2:
                        p12.n0(f9.a.c, ((Long) p14).longValue());
                        break;
                    case 3:
                        p12.g0(f9.a.d, ((Double) p14).doubleValue());
                        break;
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                        p12.h(f9.a.e, v7_0, ((java.util.List) p14), a9.a.c, p15);
                        break;
                    default:
                        com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("Unsupported attribute type.");
                }
                return;
            case 3:
                if (!((u7.e) p13).b.isEmpty()) {
                    y8.b v12_1 = ((u7.e) p13).d;
                    if (v12_1 == null) {
                        v12_1 = ((u7.e) p13).b.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                        ((u7.e) p13).d = v12_1;
                    }
                    p12.c0(f9.d.a, v12_1);
                } else {
                    Class vtmp15 = p12.getClass();
                }
                p12.h(f9.d.b, ((u7.e) p13), p14, a9.a.d, p15);
                return;
            default:
                switch (((r7.a) p13).a.ordinal()) {
                    case 0:
                        p12.d0(f9.a.a, ((String) p14), p15);
                        break;
                    case 1:
                        p12.e0(f9.a.b, ((Boolean) p14).booleanValue());
                        break;
                    case 2:
                        p12.n0(f9.a.c, ((Long) p14).longValue());
                        break;
                    case 3:
                        p12.g0(f9.a.d, ((Double) p14).doubleValue());
                        break;
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                        a9.a v13_2 = ((r7.a) p13).a();
                        java.util.Objects.requireNonNull(v13_2);
                        p12.h(f9.a.e, v13_2.a, ((java.util.List) p14), a9.a.c, p15);
                        break;
                    case 8:
                        p12.getClass();
                        p12.r0(f9.a.f, p15.e());
                        a9.j.e(p12, f9.e.a, ((q7.b) p14), p15);
                        p12.h0();
                        break;
                    default:
                        com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("Unsupported attribute type.");
                }
                return;
        }
    }

    public int d(Object p5, y8.g p6)
    {
        y8.b v1_0 = 0;
        switch (this.a) {
            case 0:
                y8.b v0_12;
                switch (((p7.f) p5).a().ordinal()) {
                    case 0:
                        v1_0 = y8.r.d(f9.a.a, ((String) ((p7.f) p5).getValue()), p6);
                        break;
                    case 1:
                        ((Boolean) ((p7.f) p5).getValue()).getClass();
                        v1_0 = (f9.a.b.c + 1);
                        break;
                    case 2:
                        v1_0 = (y8.c.a(((Long) ((p7.f) p5).getValue()).longValue()) + f9.a.c.c);
                        break;
                    case 3:
                        ((Double) ((p7.f) p5).getValue()).getClass();
                        v1_0 = (f9.a.d.c + 8);
                        break;
                    case 4:
                        int v5_29 = ((java.util.List) ((p7.f) p5).getValue());
                        y8.b v1_4 = p6.b();
                        int v5_30 = y8.r.c(f9.b.a, v5_29, a9.a.b, p6);
                        v0_12 = ((y8.c.b(v5_30) + f9.a.e.c) + v5_30);
                        p6.c[v1_4] = v5_30;
                        v1_0 = v0_12;
                        break;
                    case 5:
                        int v5_26 = ((java.util.List) ((p7.f) p5).getValue());
                        y8.b v1_2 = p6.b();
                        int v5_27 = y8.r.c(f9.e.a, v5_26, a9.a.j, p6);
                        v0_12 = ((y8.c.b(v5_27) + f9.a.f.c) + v5_27);
                        p6.c[v1_2] = v5_27;
                        break;
                    case 6:
                        int v5_22 = ((java.nio.ByteBuffer) ((p7.f) p5).getValue());
                        y8.b v0_9 = v5_22.remaining();
                        y8.b v1_1 = new byte[v0_9];
                        v5_22.get(v1_1);
                        p6.a(v1_1);
                        v1_0 = ((y8.c.b(v0_9) + v0_9) + f9.a.g.c);
                        break;
                    default:
                        com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("Unsupported value type.");
                }
                return v1_0;
            case 1:
            case 2:
            case 3:
            case 6:
            default:
                return y8.r.d(f9.a.a, ((String) p5), p6);
            case 4:
                ((Boolean) p5).getClass();
                return (f9.a.b.c + 1);
            case 5:
                ((Double) p5).getClass();
                return (f9.a.d.c + 8);
            case 7:
                return (y8.c.a(((Long) p5).longValue()) + f9.a.c.c);
            case 8:
                y8.b v0_6 = ((p7.c) p5).a;
                if (!v0_6.isEmpty()) {
                    v1_0 = y8.r.d(f9.d.a, v0_6, p6);
                }
                return (y8.r.b(f9.d.b, ((p7.c) p5).b, p6) + v1_0);
        }
    }
}
