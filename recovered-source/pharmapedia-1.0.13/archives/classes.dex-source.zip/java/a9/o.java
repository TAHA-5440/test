// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public final class o extends y8.i {
    public static final a8.f d;
    public final byte[] b;
    public final String c;

    static o()
    {
        a9.o.d = new a8.f();
        return;
    }

    public o(byte[] p2, String p3)
    {
        super(p2.length);
        super.b = p2;
        super.c = p3;
        return;
    }

    public static a9.o d(aa.c p4)
    {
        java.io.UncheckedIOException v0_0 = a9.o.d;
        String v1_4 = ((a9.o) v0_0.a(p4));
        if (v1_4 != null) {
            return v1_4;
        } else {
            String v1_0 = new a9.d(a9.n.d(((aa.a) p4).c));
            byte[] v2_2 = new java.io.ByteArrayOutputStream(v1_0.a);
            try {
                v1_0.b(v2_2);
                a9.o v3_2 = new a9.o(v2_2.toByteArray(), y8.h.a(v1_0));
                v0_0.c(p4, v3_2);
                return v3_2;
            } catch (java.io.IOException v4_1) {
                throw new java.io.UncheckedIOException("Serialization error, this is likely a bug in OpenTelemetry.", v4_1);
            }
        }
    }

    public final void c(y8.m p3)
    {
        p3.o0(this.b, this.c);
        return;
    }
}
