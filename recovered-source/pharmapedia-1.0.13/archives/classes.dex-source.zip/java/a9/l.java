// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public final class l extends y8.i {
    public static final a8.f d;
    public final byte[] b;
    public final String c;

    static l()
    {
        a9.l.d = new a8.f();
        return;
    }

    public l(byte[] p2, String p3)
    {
        super(p2.length);
        super.b = p2;
        super.c = p3;
        return;
    }

    public static a9.l d(j9.a p5)
    {
        java.io.UncheckedIOException v0_0 = a9.l.d;
        String v1_4 = ((a9.l) v0_0.a(p5));
        if (v1_4 != null) {
            return v1_4;
        } else {
            a9.k v4_1 = new a9.k(y8.h.f(p5.a), y8.h.f(p5.b), a9.n.d(p5.d));
            String v1_1 = new java.io.ByteArrayOutputStream(v4_1.a);
            try {
                v4_1.b(v1_1);
                a9.l v3_3 = new a9.l(v1_1.toByteArray(), y8.h.a(v4_1));
                v0_0.c(p5, v3_3);
                return v3_3;
            } catch (java.io.IOException v5_1) {
                throw new java.io.UncheckedIOException("Serialization error, this is likely a bug in OpenTelemetry.", v5_1);
            }
        }
    }

    public final void c(y8.m p3)
    {
        p3.o0(this.b, this.c);
        return;
    }
}
