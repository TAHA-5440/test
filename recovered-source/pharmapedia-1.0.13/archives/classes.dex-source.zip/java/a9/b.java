// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public final synthetic class b implements java.util.function.Function {
    public final synthetic int a;

    public synthetic b(int p1)
    {
        this.a = p1;
        return;
    }

    public final Object apply(Object p19)
    {
        switch (this.a) {
            case 0:
                return new a9.f(y8.h.f(((String) p19)), 1);
            case 1:
                return new a9.e(((Boolean) p19).booleanValue());
            case 2:
                return new a9.m(((Long) p19).longValue());
            case 3:
                return new a9.g(((Double) p19).doubleValue());
            case 4:
                return a9.j.a(((p7.f) p19));
            case 5:
                return ((n9.a) p19).j();
            case 6:
                return ((n9.a) p19).k();
            case 7:
                int v3_6;
                boolean v2_4 = (((n9.a) p19) instanceof o9.a);
                if (!v2_4) {
                    v3_6 = a9.n.d(((n9.a) p19).getAttributes());
                } else {
                    int v3_7 = a9.j.d(((n9.a) p19));
                    if (!v3_7.isEmpty()) {
                        b9.b v4_7 = new a9.n[v3_7.size()];
                        v3_7.forEach(new a9.i(v4_7, 0));
                        v3_6 = v4_7;
                    } else {
                        v3_6 = a9.j.b;
                    }
                }
                a9.n[] v12 = v3_6;
                boolean v2_6;
                if (!v2_4) {
                    v2_6 = ((n9.a) p19).getAttributes().size();
                } else {
                    v2_6 = a9.j.d(((n9.a) p19)).size();
                }
                y8.i v11;
                if (((n9.a) p19).b() != null) {
                    v11 = a9.j.a(((n9.a) p19).b());
                } else {
                    v11 = 0;
                }
                int v3_11 = ((n9.a) p19).g();
                long v5_3 = ((n9.a) p19).i();
                long v7_1 = ((n9.a) p19).c();
                byte[] v10_1 = b9.b.d(((n9.a) p19).a());
                int v13_1 = y8.h.f(((n9.a) p19).h());
                int v15_0 = v3_11.b;
                int v3_12 = v3_11.a;
                if (v3_12.equals("00000000000000000000000000000000")) {
                    v3_12 = 0;
                }
                String v16;
                if (!v15_0.equals("0000000000000000")) {
                    v16 = v15_0;
                } else {
                    v16 = 0;
                }
                return new b9.b(v5_3, v7_1, v10_1, v13_1, v11, v12, (((n9.a) p19).d() - v2_6), v3_11.c, v3_12, v16, y8.h.f(((n9.a) p19).e()));
            case 8:
                return com.google.firebase.crashlytics.internal.persistence.CrashlyticsReportPersistence.a(((java.io.File) p19));
            case 9:
                return Boolean.valueOf(v8.a.a.contains(Integer.valueOf(((yb.b0) p19).j)));
            case 10:
                boolean v2_2 = new StringBuilder();
                v2_2.append(((String) ((java.util.Map$Entry) p19).getKey()));
                v2_2.append("=");
                String v1_13 = ((Iterable) ((java.util.Map$Entry) p19).getValue());
                int v3_4 = new StringBuilder();
                String v1_14 = v1_13.iterator();
                if (v1_14.hasNext()) {
                    while(true) {
                        v3_4.append(((CharSequence) v1_14.next()));
                        if (!v1_14.hasNext()) {
                            break;
                        }
                        v3_4.append(",");
                    }
                }
                v2_2.append(v3_4.toString());
                return v2_2.toString();
            case 11:
                return ((io.opentelemetry.diskbuffering.proto.common.v1.KeyValue) p19).j;
            case 12:
                return t6.a.a(((io.opentelemetry.diskbuffering.proto.common.v1.KeyValue) p19).k);
            case 13:
                return t6.a.a(((io.opentelemetry.diskbuffering.proto.common.v1.AnyValue) p19));
            case 14:
                return new java.util.concurrent.atomic.AtomicInteger(0);
            case 15:
                String v1_93;
                if (p19 != null) {
                    com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.o();
                    v1_93 = 0;
                } else {
                    v1_93 = "null";
                }
                return v1_93;
            case 16:
                return ((u7.e) p19).b;
            case 17:
                return new p7.c(((String) ((java.util.Map$Entry) p19).getKey()), ((p7.f) ((java.util.Map$Entry) p19).getValue()));
            case 18:
                boolean v2_19 = new StringBuilder();
                v2_19.append(((p7.c) p19).a);
                v2_19.append("=");
                v2_19.append(((p7.c) p19).b.asString());
                return v2_19.toString();
            case 19:
                return ((p7.f) p19).asString();
            case 20:
                return ((r7.a) p19).b;
            case 21:
                return new y9.d();
            case 22:
                ((x9.a) p19).getClass();
                return 0;
            case 23:
                return ((java.util.Map$Entry) p19).getValue().toString();
            case 24:
                return ((String) ((java.util.Map$Entry) p19).getValue());
            case 25:
                return ((Integer) p19).toString();
            case 26:
                p19.getClass();
                throw new ClassCastException();
                break;
            case 27:
                return new java.util.IdentityHashMap(8);
            case 28:
                return new java.util.ArrayList();
            default:
                boolean v2_17 = new byte[16];
                u7.f.a(((String) p19), 32, v2_17);
                return v2_17;
        }
    }
}
