// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public final class c extends y8.i {
    public final synthetic int b;
    public final y8.e[] c;

    public c(a9.n[] p2)
    {
        this.b = 1;
        super(y8.h.e(f9.e.a, p2));
        super.c = p2;
        return;
    }

    public c(y8.e[] p2)
    {
        this.b = 0;
        super(y8.h.e(f9.b.a, p2));
        super.c = p2;
        return;
    }

    public final void c(y8.m p3)
    {
        switch (this.b) {
            case 0:
                p3.L(f9.b.a, this.c);
                return;
            default:
                p3.L(f9.e.a, this.c);
                return;
        }
    }
}
