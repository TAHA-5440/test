// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public final class i implements java.util.function.BiConsumer {
    public final synthetic int a;
    public int b;
    public final synthetic a9.n[] c;

    public synthetic i(a9.n[] p1, int p2)
    {
        this.a = p2;
        this.c = p1;
        this.b = 0;
        return;
    }

    public final void accept(Object p8, Object p9)
    {
        switch (this.a) {
            case 0:
                byte[] v1_3;
                int v0_2 = this.b;
                this.b = (v0_2 + 1);
                if (!((r7.a) p8).b.isEmpty()) {
                    v1_3 = ((r7.a) p8).d();
                } else {
                    v1_3 = a9.j.a;
                }
                a9.n v8_19;
                switch (((r7.a) p8).a.ordinal()) {
                    case 0:
                        v8_19 = new a9.n(v1_3, new a9.f(y8.h.f(((String) p9)), 1));
                        this.c[v0_2] = v8_19;
                        break;
                    case 1:
                        v8_19 = new a9.n(v1_3, new a9.e(((Boolean) p9).booleanValue()));
                        break;
                    case 2:
                        v8_19 = new a9.n(v1_3, new a9.m(((Long) p9).longValue()));
                        break;
                    case 3:
                        v8_19 = new a9.n(v1_3, new a9.g(((Double) p9).doubleValue()));
                        break;
                    case 4:
                        v8_19 = new a9.n(v1_3, a9.d.d(((java.util.List) p9), new a9.b(0)));
                        break;
                    case 5:
                        v8_19 = new a9.n(v1_3, a9.d.d(((java.util.List) p9), new a9.b(1)));
                        break;
                    case 6:
                        v8_19 = new a9.n(v1_3, a9.d.d(((java.util.List) p9), new a9.b(2)));
                        break;
                    case 7:
                        v8_19 = new a9.n(v1_3, a9.d.d(((java.util.List) p9), new a9.b(3)));
                        break;
                    case 8:
                        int v9_21;
                        if (!((q7.b) p9).isEmpty()) {
                            a9.n[] v4_2 = new a9.n[((q7.b) p9).size()];
                            ((q7.b) p9).forEach(new a9.i(v4_2, 0));
                            v9_21 = v4_2;
                        } else {
                            v9_21 = a9.j.b;
                        }
                        v8_19 = new a9.n(v1_3, new a9.d(new a9.c(v9_21), 0));
                        break;
                    default:
                        com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("Unsupported attribute type.");
                }
                return;
            default:
                byte[] v1_4;
                int v0_1 = this.b;
                this.b = (v0_1 + 1);
                if (!((u7.e) p8).b.isEmpty()) {
                    v1_4 = ((u7.e) p8).d;
                    if (v1_4 == null) {
                        v1_4 = ((u7.e) p8).b.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                        ((u7.e) p8).d = v1_4;
                    }
                } else {
                    v1_4 = a9.n.d;
                }
                a9.n v8_7;
                switch (((u7.e) p8).a.ordinal()) {
                    case 0:
                        v8_7 = new a9.n(v1_4, new a9.f(y8.h.f(((String) p9)), 1));
                        this.c[v0_1] = v8_7;
                        break;
                    case 1:
                        v8_7 = new a9.n(v1_4, new a9.e(((Boolean) p9).booleanValue()));
                        break;
                    case 2:
                        v8_7 = new a9.n(v1_4, new a9.m(((Long) p9).longValue()));
                        break;
                    case 3:
                        v8_7 = new a9.n(v1_4, new a9.g(((Double) p9).doubleValue()));
                        break;
                    case 4:
                        v8_7 = new a9.n(v1_4, a9.d.d(((java.util.List) p9), new a9.b(0)));
                        break;
                    case 5:
                        v8_7 = new a9.n(v1_4, a9.d.d(((java.util.List) p9), new a9.b(1)));
                        break;
                    case 6:
                        v8_7 = new a9.n(v1_4, a9.d.d(((java.util.List) p9), new a9.b(2)));
                        break;
                    case 7:
                        v8_7 = new a9.n(v1_4, a9.d.d(((java.util.List) p9), new a9.b(3)));
                        break;
                    default:
                        com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("Unsupported attribute type.");
                }
                return;
        }
    }
}
