// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public final synthetic class h implements java.util.function.BiConsumer {
    public final synthetic int a;
    public final synthetic y8.b b;
    public final synthetic y8.g c;
    public final synthetic Object d;

    public synthetic h(y8.g p2, int[] p3, y8.b p4)
    {
        this.a = 0;
        this.c = p2;
        this.d = p3;
        this.b = p4;
        return;
    }

    public synthetic h(y8.m p2, y8.b p3, y8.g p4)
    {
        this.a = 1;
        this.d = p2;
        this.b = p3;
        this.c = p4;
        return;
    }

    public final void accept(Object p10, Object p11)
    {
        int v1_0 = this.b;
        int[] v2_0 = this.d;
        switch (this.a) {
            case 0:
                int v3_2;
                int[] v2_1 = ((int[]) v2_0);
                int v11_5 = this.c;
                int v0_4 = v11_5.b();
                if (((r7.a) p10).b.isEmpty()) {
                    v3_2 = 0;
                } else {
                    v3_2 = y8.h.b(f9.d.a, ((r7.a) p10).d());
                }
                int v10_2 = (y8.r.a(f9.d.b, ((r7.a) p10), p11, a9.a.h, v11_5) + v3_2);
                v11_5.c[v0_4] = v10_2;
                v2_1[0] = (((y8.c.b(v10_2) + v1_0.c) + v10_2) + v2_1[0]);
                return;
            default:
                int v3_5 = ((y8.m) v2_0);
                y8.g v8 = this.c;
                try {
                    v3_5.t0(v1_0, v8.e());
                } catch (int v0_3) {
                    throw new java.io.UncheckedIOException(v0_3);
                }
                if (!((r7.a) p10).b.isEmpty()) {
                    v3_5.c0(f9.d.a, ((r7.a) p10).d());
                } else {
                }
                v3_5.h(f9.d.b, ((r7.a) p10), p11, a9.a.h, v8);
                v3_5.j0();
                return;
        }
    }
}
