// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public abstract class j implements y8.n {
    public static final byte[] a;
    public static final a9.n[] b;

    static j()
    {
        byte[] v1 = new byte[0];
        a9.j.a = v1;
        a9.n[] v0_1 = new a9.n[0];
        a9.j.b = v0_1;
        return;
    }

    public static y8.i a(p7.f p7)
    {
        switch (p7.a().ordinal()) {
            case 0:
                return new a9.f(y8.h.f(((String) p7.getValue())), 1);
            case 1:
                return new a9.e(((Boolean) p7.getValue()).booleanValue());
            case 2:
                return new a9.m(((Long) p7.getValue()).longValue());
            case 3:
                return new a9.g(((Double) p7.getValue()).doubleValue());
            case 4:
                return a9.d.d(((java.util.List) p7.getValue()), new a9.b(4));
            case 5:
                a9.d v7_4 = ((java.util.List) p7.getValue());
                a9.c v0_2 = v7_4.size();
                int v1_2 = new a9.n[v7_4.size()];
                int v2 = 0;
                while (v2 < v0_2) {
                    y8.i v3_1 = ((p7.c) v7_4.get(v2));
                    v1_2[v2] = new a9.n(v3_1.a.getBytes(java.nio.charset.StandardCharsets.UTF_8), a9.j.a(v3_1.b));
                    v2++;
                }
                return new a9.d(new a9.c(v1_2), 0);
            case 6:
                a9.d v7_19 = ((java.nio.ByteBuffer) p7.getValue());
                a9.c v0_1 = new byte[v7_19.remaining()];
                v7_19.get(v0_1);
                return new a9.f(v0_1, 0);
            default:
                androidx.fragment.app.a.n(p7.a(), "Unsupported Value type: ");
                return 0;
        }
    }

    public static q7.b d(n9.a p1)
    {
        if (!(p1 instanceof o9.a)) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("logRecordData must be ExtendedLogRecordData");
            return 0;
        } else {
            return ((o9.a) p1).f();
        }
    }

    public static void e(y8.m p1, y8.b p2, q7.b p3, y8.g p4)
    {
        p1.s0(p2);
        if (!p3.isEmpty()) {
            try {
                p3.forEach(new a9.h(p1, p2, p4));
            } catch (java.io.IOException v1_1) {
                throw v1_1.getCause();
            }
        }
        p1.i0();
        return;
    }

    public static int f(y8.b p3, q7.b p4, y8.g p5)
    {
        if (!p4.isEmpty()) {
            int[] v0_1 = new int[] {0});
            p4.forEach(new a9.h(p5, v0_1, p3));
            return v0_1[0];
        } else {
            return 0;
        }
    }
}
