// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public final class d extends y8.i {
    public final synthetic int b;
    public final Object c;

    public d(a9.c p2)
    {
        this.b = 0;
        super(y8.h.d(f9.a.e, p2));
        super.c = p2;
        return;
    }

    public d(a9.c p1, byte p2)
    {
        this.b = 1;
        super(y8.h.d(f9.a.f, p1));
        super.c = p1;
        return;
    }

    public d(a9.k[] p2)
    {
        this.b = 3;
        super(y8.h.e(e9.a.a, p2));
        super.c = p2;
        return;
    }

    public d(a9.n[] p2)
    {
        this.b = 2;
        super(y8.h.e(h9.a.a, p2));
        super.c = p2;
        return;
    }

    public static a9.d d(java.util.List p4, java.util.function.Function p5)
    {
        int v0 = p4.size();
        y8.e[] v1 = new y8.e[v0];
        int v2 = 0;
        while (v2 < v0) {
            v1[v2] = ((y8.e) p5.apply(p4.get(v2)));
            v2++;
        }
        return new a9.d(new a9.c(v1));
    }

    public final void c(y8.m p3)
    {
        switch (this.b) {
            case 0:
                p3.d(f9.a.e, ((a9.c) this.c));
                return;
            case 1:
                p3.d(f9.a.f, ((a9.c) this.c));
                return;
            case 2:
                p3.L(h9.a.a, ((a9.n[]) this.c));
                return;
            default:
                p3.L(e9.a.a, ((a9.k[]) this.c));
                return;
        }
    }
}
