// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public final class e extends y8.i {
    public final boolean b;

    public e(boolean p3)
    {
        super((f9.a.b.c + 1));
        super.b = p3;
        return;
    }

    public final void c(y8.m p3)
    {
        p3.e0(f9.a.b, this.b);
        return;
    }
}
