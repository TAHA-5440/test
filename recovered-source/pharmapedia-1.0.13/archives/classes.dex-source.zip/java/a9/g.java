// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public final class g extends y8.i {
    public final double b;

    public g(double p3)
    {
        super((f9.a.d.c + 8));
        super.b = p3;
        return;
    }

    public final void c(y8.m p4)
    {
        p4.g0(f9.a.d, this.b);
        return;
    }
}
