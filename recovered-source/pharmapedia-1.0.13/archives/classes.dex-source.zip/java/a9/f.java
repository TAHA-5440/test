// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a9;
public final class f extends y8.i {
    public final synthetic int b;
    public final byte[] c;

    public f(byte[] p3, int p4)
    {
        this.b = p4;
        switch (p4) {
            case 1:
                int v4_1;
                if (p3.length != 0) {
                    int v0_1 = p3.length;
                    v4_1 = (f9.a.a.c + (y8.c.b(v0_1) + v0_1));
                } else {
                    v4_1 = 0;
                }
                super(v4_1);
                super.c = p3;
                return;
            default:
                int v0_0 = p3.length;
                super(((y8.c.b(v0_0) + v0_0) + f9.a.g.c));
                super.c = p3;
                return;
        }
    }

    public final void c(y8.m p3)
    {
        switch (this.b) {
            case 0:
                p3.f0(f9.a.g, this.c);
                return;
            default:
                y8.b v0_2 = this.c;
                if (v0_2.length != 0) {
                    p3.v0(f9.a.a, v0_2);
                }
                return;
        }
    }
}
