// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a8;
public final class f extends a8.g {

    public f()
    {
        int v1;
        java.util.concurrent.ConcurrentHashMap v0_3 = a8.e.getClassLoader();
        try {
            if (v0_3 == null) {
                v1 = 1;
            } else {
                v1 = 0;
                if ((v0_3 == ClassLoader.getSystemClassLoader()) || (v0_3 == ClassLoader.getSystemClassLoader().getParent())) {
                }
            }
        } catch (Throwable) {
        }
        super(v1, new java.util.concurrent.ConcurrentHashMap());
        return;
    }

    public final Object a(Object p3)
    {
        while(true) {
            ref.Reference v0 = this.poll();
            if (v0 == null) {
                break;
            }
            this.g.remove(v0);
        }
        return super.a(p3);
    }

    public final a8.e b(Object p2)
    {
        a8.e v0_2;
        if (!this.h) {
            v0_2 = new a8.e();
        } else {
            v0_2 = ((a8.e) a8.g.i.get());
        }
        v0_2.a = p2;
        v0_2.b = System.identityHashCode(p2);
        return v0_2;
    }

    public final Object c(Object p3, Object p4)
    {
        while(true) {
            ref.Reference v0 = this.poll();
            if (v0 == null) {
                break;
            }
            this.g.remove(v0);
        }
        return super.c(p3, p4);
    }

    public final void e(Object p2)
    {
        ((a8.e) p2).a = 0;
        ((a8.e) p2).b = 0;
        return;
    }

    public final java.util.Iterator iterator()
    {
        while(true) {
            java.util.Iterator v0_0 = this.poll();
            if (v0_0 == null) {
                break;
            }
            this.g.remove(v0_0);
        }
        return super.iterator();
    }
}
