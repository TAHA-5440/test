// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a8;
public final class c extends java.lang.ref.WeakReference {
    public final int a;

    public c(Object p1, a8.g p2)
    {
        super(p1, p2);
        super.a = System.identityHashCode(p1);
        return;
    }

    public final boolean equals(Object p2)
    {
        if (!(p2 instanceof a8.c)) {
            return p2.equals(this);
        } else {
            if (((a8.c) p2).get() != this.get()) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public final int hashCode()
    {
        return this.a;
    }

    public final String toString()
    {
        return String.valueOf(this.get());
    }
}
