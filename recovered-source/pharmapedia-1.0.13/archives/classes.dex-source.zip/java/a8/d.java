// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a8;
public final class d extends java.lang.ThreadLocal {
    public final synthetic int a;

    public synthetic d(int p1)
    {
        this.a = p1;
        return;
    }

    public final Object initialValue()
    {
        switch (this.a) {
            case 0:
                return new a8.e();
            case 1:
                StringBuilder v0_8 = new java.text.SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss \'GMT\'", java.util.Locale.US);
                v0_8.setLenient(0);
                v0_8.setTimeZone(zb.e.a);
                return v0_8;
            case 2:
                return new StringBuilder("Picasso-");
            default:
                return new java.util.Random();
        }
    }
}
