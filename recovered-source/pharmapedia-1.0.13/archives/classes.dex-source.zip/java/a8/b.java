// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a8;
public final class b implements java.util.Map$Entry {
    public final Object g;
    public final java.util.Map$Entry h;

    public b(Object p1, java.util.Map$Entry p2)
    {
        this.g = p1;
        this.h = p2;
        return;
    }

    public final Object getKey()
    {
        return this.g;
    }

    public final Object getValue()
    {
        return this.h.getValue();
    }

    public final Object setValue(Object p2)
    {
        p2.getClass();
        return this.h.setValue(p2);
    }
}
