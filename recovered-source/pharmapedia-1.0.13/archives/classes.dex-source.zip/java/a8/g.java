// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a8;
public abstract class g extends java.lang.ref.ReferenceQueue implements java.lang.Runnable, java.lang.Iterable {
    public static final a8.d i;
    public final java.util.concurrent.ConcurrentHashMap g;
    public final boolean h;

    static g()
    {
        a8.g.i = new a8.d(0);
        new java.util.concurrent.atomic.AtomicLong();
        return;
    }

    public g(boolean p1, java.util.concurrent.ConcurrentHashMap p2)
    {
        this.g = p2;
        this.h = p1;
        return;
    }

    public Object a(Object p2)
    {
        p2.getClass();
        int v2_2 = this.b(p2);
        try {
            Throwable v0_1 = this.g.get(v2_2);
            this.e(v2_2);
        } catch (Throwable v0_2) {
            this.e(v2_2);
            throw v0_2;
        }
        if (v0_1 != null) {
            return v0_1;
        } else {
            return 0;
        }
    }

    public a8.e b(Object p2)
    {
        a8.e v0_2;
        if (!this.h) {
            v0_2 = new a8.e();
        } else {
            v0_2 = ((a8.e) a8.g.i.get());
        }
        v0_2.a = p2;
        v0_2.b = System.identityHashCode(p2);
        return v0_2;
    }

    public Object c(Object p2, Object p3)
    {
        if (p2 == 0) {
            throw 0;
        } else {
            return this.g.put(new a8.c(p2, this), p3);
        }
    }

    public void e(Object p2)
    {
        ((a8.e) p2).a = 0;
        ((a8.e) p2).b = 0;
        return;
    }

    public java.util.Iterator iterator()
    {
        return new a8.a(this, this.g.entrySet().iterator());
    }

    public void run()
    {
        try {
            while (!Thread.interrupted()) {
                this.g.remove(this.remove());
            }
        } catch (InterruptedException) {
        }
        return;
    }

    public final String toString()
    {
        return this.g.toString();
    }
}
