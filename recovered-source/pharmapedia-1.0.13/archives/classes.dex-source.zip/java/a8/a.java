// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a8;
public final class a implements java.util.Iterator {
    public final java.util.Iterator g;
    public java.util.Map$Entry h;
    public Object i;

    public a(a8.g p1, java.util.Iterator p2)
    {
        this.g = p2;
        this.a();
        return;
    }

    public final void a()
    {
        do {
            int v0_0 = this.g;
            if (!v0_0.hasNext()) {
                this.h = 0;
                this.i = 0;
                return;
            } else {
                int v0_1 = ((java.util.Map$Entry) v0_0.next());
                this.h = v0_1;
                int v0_4 = ((a8.c) v0_1.getKey()).get();
                this.i = v0_4;
            }
        } while(v0_4 == 0);
        return;
    }

    public final boolean hasNext()
    {
        if (this.i == null) {
            return 0;
        } else {
            return 1;
        }
    }

    public final Object next()
    {
        Throwable v0_0 = this.i;
        if (v0_0 == null) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.c();
            return 0;
        } else {
            try {
                a8.b v1_1 = new a8.b(v0_0, this.h);
                this.a();
                return v1_1;
            } catch (Throwable v0_1) {
                this.a();
                throw v0_1;
            }
        }
    }

    public final void remove()
    {
        throw new UnsupportedOperationException();
    }
}
