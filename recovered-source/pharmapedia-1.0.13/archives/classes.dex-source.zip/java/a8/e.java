// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a8;
public final class e {
    public Object a;
    public int b;

    public final boolean equals(Object p4)
    {
        if (!(p4 instanceof a8.e)) {
            if (((a8.c) p4).get() != this.a) {
                return 0;
            } else {
                return 1;
            }
        } else {
            if (((a8.e) p4).a != this.a) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public final int hashCode()
    {
        return this.b;
    }
}
