// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package android.app;
public synthetic class AppComponentFactory {

    static synthetic AppComponentFactory()
    {
        throw new NoClassDefFoundError();
    }
}
