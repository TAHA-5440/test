// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package android.app;
public final synthetic class ForegroundServiceStartNotAllowedException extends android.app.ServiceStartNotAllowedException implements android.os.Parcelable {

    static synthetic ForegroundServiceStartNotAllowedException()
    {
        throw new NoClassDefFoundError();
    }
}
