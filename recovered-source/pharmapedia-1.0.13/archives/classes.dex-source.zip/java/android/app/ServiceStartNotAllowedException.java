// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package android.app;
public synthetic class ServiceStartNotAllowedException extends java.lang.IllegalStateException {

    static synthetic ServiceStartNotAllowedException()
    {
        throw new NoClassDefFoundError();
    }
}
