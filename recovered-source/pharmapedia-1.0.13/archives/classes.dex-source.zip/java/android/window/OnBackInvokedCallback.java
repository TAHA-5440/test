// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package android.window;
public interface synthetic OnBackInvokedCallback {

    static synthetic OnBackInvokedCallback()
    {
        throw new NoClassDefFoundError();
    }
}
