// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package android.window;
public interface synthetic OnBackAnimationCallback implements android.window.OnBackInvokedCallback {

    static synthetic OnBackAnimationCallback()
    {
        throw new NoClassDefFoundError();
    }
}
