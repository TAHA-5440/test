// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package android.support.annotation;
public interface annotation Keep implements java.lang.annotation.Annotation {
}
