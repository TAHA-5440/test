// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package android.graphics;
public interface synthetic ImageDecoder$OnPartialImageListener {

    static synthetic ImageDecoder$OnPartialImageListener()
    {
        throw new NoClassDefFoundError();
    }
}
