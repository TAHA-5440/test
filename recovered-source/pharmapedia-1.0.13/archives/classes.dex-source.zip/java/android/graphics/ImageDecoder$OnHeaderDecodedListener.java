// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package android.graphics;
public interface synthetic ImageDecoder$OnHeaderDecodedListener {

    static synthetic ImageDecoder$OnHeaderDecodedListener()
    {
        throw new NoClassDefFoundError();
    }
}
