// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package android.view;
public synthetic class WindowInsetsAnimation$Callback {

    static synthetic WindowInsetsAnimation$Callback()
    {
        throw new NoClassDefFoundError();
    }
}
