// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package android.os;
public interface synthetic OutcomeReceiver {

    static synthetic OutcomeReceiver()
    {
        throw new NoClassDefFoundError();
    }
}
