// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a;
public abstract class a {
    public static Thread a;

    public static final void a(int p2, StringBuilder p3)
    {
        int v0 = 0;
        while (v0 < p2) {
            p3.append("?");
            if (v0 < (p2 - 1)) {
                p3.append(",");
            }
            v0++;
        }
        return;
    }

    public static void b(int p3, int p4, int p5)
    {
        if ((p3 < null) || (p4 > p5)) {
            com.google.firebase.firestore.v.c(p5, f0.a.e(p3, p4, "startIndex: ", ", endIndex: ", ", size: "));
            return;
        } else {
            if (p3 > p4) {
                com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u(r1.a.l("startIndex: ", " > endIndex: ", p3, p4));
                return;
            } else {
                return;
            }
        }
    }

    public static void c(int p5)
    {
        if ((2 > p5) || (p5 >= 37)) {
            String v5_2 = r1.a.v(p5, "radix ", " was not in valid range ");
            v5_2.append(new ab.c(2, 36, 1));
            throw new IllegalArgumentException(v5_2.toString());
        } else {
            return;
        }
    }

    public static void d(int p3, int p4, int p5)
    {
        if ((p3 < null) || (p4 > p5)) {
            com.google.firebase.firestore.v.c(p5, f0.a.e(p3, p4, "fromIndex: ", ", toIndex: ", ", size: "));
            return;
        } else {
            if (p3 > p4) {
                com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u(r1.a.l("fromIndex: ", " > toIndex: ", p3, p4));
                return;
            } else {
                return;
            }
        }
    }

    public static int e(android.content.Context p6, String p7)
    {
        int v0_0 = android.os.Process.myPid();
        int v1 = android.os.Process.myUid();
        int v2_2 = p6.getPackageName();
        if (p6.checkPermission(p7, v0_0, v1) != -1) {
            String v7_1 = android.app.AppOpsManager.permissionToOp(p7);
            if (v7_1 != null) {
                if (v2_2 == 0) {
                    int v2_1 = p6.getPackageManager().getPackagesForUid(v1);
                    if ((v2_1 != 0) && (v2_1.length > 0)) {
                        v2_2 = v2_1[0];
                    } else {
                        return -1;
                    }
                }
                int v2_3;
                android.app.AppOpsManager v3_0 = android.os.Process.myUid();
                int v4_1 = p6.getPackageName();
                if ((v3_0 != v1) || (!java.util.Objects.equals(v4_1, v2_2))) {
                    v2_3 = ((android.app.AppOpsManager) p6.getSystemService(android.app.AppOpsManager)).noteProxyOpNoThrow(v7_1, v2_2);
                } else {
                    if (android.os.Build$VERSION.SDK_INT < 29) {
                        v2_3 = ((android.app.AppOpsManager) p6.getSystemService(android.app.AppOpsManager)).noteProxyOpNoThrow(v7_1, v2_2);
                    } else {
                        android.app.AppOpsManager v3_4 = ((android.app.AppOpsManager) p6.getSystemService(android.app.AppOpsManager));
                        int v4_3 = android.os.Binder.getCallingUid();
                        int v5_1 = 1;
                        if (v3_4 != null) {
                            v2_3 = v3_4.checkOpNoThrow(v7_1, v4_3, v2_2);
                        } else {
                            v2_3 = 1;
                        }
                        if (v2_3 == 0) {
                            String v6_5 = e0.e.a(p6);
                            if (v3_4 != null) {
                                v5_1 = v3_4.checkOpNoThrow(v7_1, v1, v6_5);
                            }
                            v2_3 = v5_1;
                        }
                    }
                }
                if (v2_3 != 0) {
                    return -2;
                }
            }
            return 0;
        }
        return -1;
    }

    public static final void f(java.io.Closeable p0, Throwable p1)
    {
        if (p0 != null) {
            if (p1 != null) {
                try {
                    p0.close();
                    return;
                } catch (Throwable v0_1) {
                    com.bumptech.glide.i.d(p1, v0_1);
                }
            } else {
                p0.close();
                return;
            }
        }
        return;
    }

    public static final boolean g(char p2, char p3, boolean p4)
    {
        if (p2 != p3) {
            if (p4) {
                char v2_2 = Character.toUpperCase(p2);
                char v3_2 = Character.toUpperCase(p3);
                if ((v2_2 != v3_2) && (Character.toLowerCase(v2_2) != Character.toLowerCase(v3_2))) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                return 0;
            }
        } else {
            return 1;
        }
    }

    public static android.view.View h(android.view.View p4, int p5)
    {
        if ((p4 instanceof android.view.ViewGroup)) {
            int v0_1 = ((android.view.ViewGroup) p4).getChildCount();
            int v2 = 0;
            while (v2 < v0_1) {
                android.view.View v3_1 = ((android.view.ViewGroup) p4).getChildAt(v2).findViewById(p5);
                if (v3_1 == null) {
                    v2++;
                } else {
                    return v3_1;
                }
            }
            return 0;
        } else {
            return 0;
        }
    }

    public static int k(android.content.Context p1, int p2)
    {
        int v1_2;
        android.util.TypedValue v2_1 = com.bumptech.glide.f.C(p1.getTheme(), p2);
        if (v2_1 == null) {
            v1_2 = 0;
        } else {
            int v1_1;
            int v0_1 = v2_1.resourceId;
            if (v0_1 == 0) {
                v1_1 = v2_1.data;
            } else {
                v1_1 = p1.getColor(v0_1);
            }
            v1_2 = Integer.valueOf(v1_1);
        }
        if (v1_2 == 0) {
            return 0;
        } else {
            return v1_2.intValue();
        }
    }

    public static int l(android.view.View p3, int p4)
    {
        android.content.res.Resources v0_0 = p3.getContext();
        android.content.Context v1 = p3.getContext();
        int v3_7 = p3.getClass().getCanonicalName();
        android.util.TypedValue v2_0 = com.bumptech.glide.f.C(v1.getTheme(), p4);
        if (v2_0 == null) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.m("%1$s requires a value for the %2$s attribute to be set in your app theme. You can either set the attribute in your theme or update your theme to inherit from Theme.MaterialComponents (or a descendant).", new Object[] {v3_7, v1.getResources().getResourceName(p4)}));
            return 0;
        } else {
            int v3_3 = v2_0.resourceId;
            if (v3_3 == 0) {
                return v2_0.data;
            } else {
                return v0_0.getColor(v3_3);
            }
        }
    }

    public static ka.c n(ka.c p1)
    {
        ka.c v0_1;
        p1.getClass();
        if (!(p1 instanceof kotlin.coroutines.jvm.internal.ContinuationImpl)) {
            v0_1 = 0;
        } else {
            v0_1 = ((kotlin.coroutines.jvm.internal.ContinuationImpl) p1);
        }
        if (v0_1 != null) {
            ka.c v0_3 = v0_1.intercepted();
            if (v0_3 != null) {
                return v0_3;
            }
        }
        return p1;
    }

    public static boolean o(int p21)
    {
        int v20;
        if (p21 == 0) {
            v20 = 0;
        } else {
            double v1_1 = i0.a.a;
            double[] v2_1 = ((double[]) v1_1.get());
            if (v2_1 == null) {
                v2_1 = new double[3];
                v1_1.set(v2_1);
            }
            double v1_0 = android.graphics.Color.red(p21);
            int v4 = android.graphics.Color.green(p21);
            int v5_0 = android.graphics.Color.blue(p21);
            if (v2_1.length != 3) {
                com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("outXyz must have a length of 3.");
                return 0;
            } else {
                long v6_5;
                long v6_2 = (((double) v1_0) / 4643176031446892544);
                if (v6_2 >= 4585990280393462802) {
                    v6_5 = Math.pow(((v6_2 + 4588087156379966505) / 4607430116779522785), 4612586738352862003);
                } else {
                    v6_5 = (v6_2 / 4623462931452961751);
                }
                int v3_4;
                int v3_1 = (((double) v4) / 4643176031446892544);
                if (v3_1 >= 4585990280393462802) {
                    v3_4 = Math.pow(((v3_1 + 4588087156379966505) / 4607430116779522785), 4612586738352862003);
                } else {
                    v3_4 = (v3_1 / 4623462931452961751);
                }
                double v0_6;
                v20 = 0;
                double v0_3 = (((double) v5_0) / 4643176031446892544);
                if (v0_3 >= 4585990280393462802) {
                    v0_6 = Math.pow(((v0_3 + 4588087156379966505) / 4607430116779522785), 4612586738352862003);
                } else {
                    v0_6 = (v0_3 / 4623462931452961751);
                }
                v2_1[0] = (((4595671218152458420 * v0_6) + ((4600113568824896677 * v3_4) + (4601100757863216290 * v6_5))) * 4636737291354636288);
                double v8_12 = (((4589866978952703325 * v0_6) + ((4604617168452267173 * v3_4) + (4596827742536767164 * v6_5))) * 4636737291354636288);
                v2_1[1] = v8_12;
                v2_1[2] = (((v0_6 * 4606736562436907729) + ((v3_4 * 4593253685872485938) + (v6_5 * 4581220067668151973))) * 4636737291354636288);
                if ((v8_12 / 4636737291354636288) > 4602678819172646912) {
                    return 1;
                }
            }
        }
        return v20;
    }

    public static final boolean q(char p1)
    {
        if ((!Character.isWhitespace(p1)) && (!Character.isSpaceChar(p1))) {
            return 0;
        } else {
            return 1;
        }
    }

    public static int r(int p1, float p2, int p3)
    {
        return i0.a.b(i0.a.d(p3, Math.round((((float) android.graphics.Color.alpha(p3)) * p2))), p1);
    }

    public static double s(double p2, double p4)
    {
        if ((p4 > 0) && (p4 != 4607182418800017408)) {
            return (Math.log(p2) / Math.log(p4));
        } else {
            return 9221120237041090560;
        }
    }

    public static int u(float p1)
    {
        if (Float.isNaN(p1)) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("Cannot round NaN value.");
            return 0;
        } else {
            return Math.round(p1);
        }
    }

    public static int v(int p4)
    {
        return ((int) (((long) Integer.rotateLeft(((int) (((long) p4) * -862048943)), 15)) * 461845907));
    }

    public static Object w(ua.p p2, Object p3, ka.c p4)
    {
        kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt$createSimpleCoroutineForSuspendFunction$2 v0_1;
        p2.getClass();
        kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt$createSimpleCoroutineForSuspendFunction$2 v0_0 = p4.getContext();
        if (v0_0 != kotlin.coroutines.EmptyCoroutineContext.g) {
            v0_1 = new kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt$createSimpleCoroutineForSuspendFunction$2(p4, v0_0);
        } else {
            v0_1 = new kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt$createSimpleCoroutineForSuspendFunction$1(p4);
        }
        kotlin.jvm.internal.j.c(2, p2);
        return p2.invoke(p3, v0_1);
    }

    public abstract reflect.Method i(Class p0, reflect.Field p1);

    public abstract reflect.Constructor j(Class p0);

    public abstract String[] m(Class p0);

    public abstract boolean p(Class p0);

    public abstract boolean t(char p0);
}
