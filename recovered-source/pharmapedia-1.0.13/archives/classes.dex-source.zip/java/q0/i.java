// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package q0;
public interface i {

    public abstract boolean superDispatchKeyEvent(android.view.KeyEvent p0);
}
