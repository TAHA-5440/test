// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package q0;
public interface j {

    public abstract void addMenuProvider(q0.o p0);

    public abstract void removeMenuProvider(q0.o p0);
}
