// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package q0;
public interface s {

    public abstract q0.o1 k(android.view.View p0, q0.o1 p1);
}
