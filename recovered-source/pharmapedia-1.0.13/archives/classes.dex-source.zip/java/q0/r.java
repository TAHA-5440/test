// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package q0;
public interface r implements q0.q {

    public abstract void a(android.view.View p0, int p1, int p2, int p3, int p4, int p5, int[] p6);
}
