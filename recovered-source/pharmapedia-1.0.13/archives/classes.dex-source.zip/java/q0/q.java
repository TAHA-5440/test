// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package q0;
public interface q {

    public abstract void b(android.view.View p0, int p1, int p2, int p3, int p4, int p5);

    public abstract boolean c(android.view.View p0, android.view.View p1, int p2, int p3);

    public abstract void d(android.view.View p0, android.view.View p1, int p2, int p3);

    public abstract void e(android.view.View p0, int p1);

    public abstract void f(android.view.View p0, int p1, int p2, int[] p3, int p4);
}
