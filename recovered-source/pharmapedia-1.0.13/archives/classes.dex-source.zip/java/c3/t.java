// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package c3;
public interface t {

    public abstract c3.s i(c3.z p0);
}
