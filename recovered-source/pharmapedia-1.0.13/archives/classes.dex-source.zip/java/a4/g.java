// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a4;
public interface g {

    public abstract void a(Exception p0);
}
