// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a4;
public final class c {
    public final String a;

    public c(String p1)
    {
        if (p1 == 0) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.j("name is null");
            throw 0;
        } else {
            this.a = p1;
            return;
        }
    }

    public final boolean equals(Object p2)
    {
        if (this != p2) {
            if ((p2 instanceof a4.c)) {
                return this.a.equals(((a4.c) p2).a);
            } else {
                return 0;
            }
        } else {
            return 1;
        }
    }

    public final int hashCode()
    {
        return (this.a.hashCode() ^ 1000003);
    }

    public final String toString()
    {
        return r1.a.n(this.a, "\"}", new StringBuilder("Encoding{name=\""));
    }
}
