// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a4;
public final class b {
    public final Integer a;

    public b(Integer p1)
    {
        this.a = p1;
        return;
    }

    public final boolean equals(Object p2)
    {
        if (p2 != this) {
            if (!(p2 instanceof a4.b)) {
                return 0;
            } else {
                return this.a.equals(((a4.b) p2).a);
            }
        } else {
            return 1;
        }
    }

    public final int hashCode()
    {
        return (this.a.hashCode() ^ 1000003);
    }

    public final String toString()
    {
        String v0_1 = new StringBuilder("ProductData{productId=");
        v0_1.append(this.a);
        v0_1.append("}");
        return v0_1.toString();
    }
}
