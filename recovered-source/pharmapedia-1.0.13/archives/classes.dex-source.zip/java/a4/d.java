// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a4;
public interface d {

    public abstract Object apply(Object p0);
}
