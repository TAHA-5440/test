// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a4;
public final class a {
    public final Object a;
    public final com.google.android.datatransport.Priority b;
    public final a4.b c;

    public a(Object p1, com.google.android.datatransport.Priority p2, a4.b p3)
    {
        if (p1 == 0) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.j("Null payload");
            throw 0;
        } else {
            this.a = p1;
            this.b = p2;
            this.c = p3;
            return;
        }
    }

    public final boolean equals(Object p3)
    {
        if (p3 != this) {
            if (((p3 instanceof a4.a)) && ((this.a.equals(((a4.a) p3).a)) && (this.b.equals(((a4.a) p3).b)))) {
                boolean v3_1 = ((a4.a) p3).c;
                a4.b v0_2 = this.c;
                if (v0_2 != null) {
                    if (v0_2.equals(v3_1)) {
                        return 1;
                    }
                } else {
                    if (!v3_1) {
                        return 1;
                    }
                }
            }
            return 0;
        }
        return 1;
    }

    public final int hashCode()
    {
        int v2_1;
        int v1_2 = (((((1000003 * 1000003) ^ this.a.hashCode()) * 1000003) ^ this.b.hashCode()) * 1000003);
        int v2_0 = this.c;
        if (v2_0 != 0) {
            v2_1 = v2_0.hashCode();
        } else {
            v2_1 = 0;
        }
        return ((v1_2 ^ v2_1) * 1000003);
    }

    public final String toString()
    {
        String v0_2 = new StringBuilder("Event{code=null, payload=");
        v0_2.append(this.a);
        v0_2.append(", priority=");
        v0_2.append(this.b);
        v0_2.append(", productData=");
        v0_2.append(this.c);
        v0_2.append(", eventContext=null}");
        return v0_2.toString();
    }
}
