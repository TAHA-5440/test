// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a0;
public final class h {
    public final float a;
    public final float b;
    public final float c;
    public final float d;
    public final int e;

    public h(android.content.Context p6, android.content.res.XmlResourceParser p7)
    {
        this.a = 2143289344;
        this.b = 2143289344;
        this.c = 2143289344;
        this.d = 2143289344;
        this.e = -1;
        android.content.res.TypedArray v7_1 = p6.obtainStyledAttributes(android.util.Xml.asAttributeSet(p7), a0.t.j);
        int v0_2 = v7_1.getIndexCount();
        int v1 = 0;
        while (v1 < v0_2) {
            String v2_0 = v7_1.getIndex(v1);
            if (v2_0 != null) {
                if (v2_0 != 1) {
                    if (v2_0 != 2) {
                        if (v2_0 != 3) {
                            if (v2_0 != 4) {
                                android.util.Log.v("ConstraintLayoutStates", "Unknown tag");
                            } else {
                                this.a = v7_1.getDimension(v2_0, this.a);
                            }
                        } else {
                            this.c = v7_1.getDimension(v2_0, this.c);
                        }
                    } else {
                        this.b = v7_1.getDimension(v2_0, this.b);
                    }
                } else {
                    this.d = v7_1.getDimension(v2_0, this.d);
                }
            } else {
                String v2_6 = v7_1.getResourceId(v2_0, this.e);
                this.e = v2_6;
                String v3_11 = p6.getResources().getResourceTypeName(v2_6);
                p6.getResources().getResourceName(v2_6);
                if ("layout".equals(v3_11)) {
                    new a0.p().a(p6, v2_6);
                }
            }
            v1++;
        }
        v7_1.recycle();
        return;
    }
}
