// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a0;
public final class p {
    public static final int[] d;
    public static final android.util.SparseIntArray e;
    public static final android.util.SparseIntArray f;
    public final java.util.HashMap a;
    public final boolean b;
    public final java.util.HashMap c;

    static p()
    {
        a0.p.d = new int[] {0, 4, 8});
        int v0_74 = new android.util.SparseIntArray();
        a0.p.e = v0_74;
        android.util.SparseIntArray v3_0 = new android.util.SparseIntArray();
        a0.p.f = v3_0;
        v0_74.append(82, 25);
        v0_74.append(83, 26);
        v0_74.append(85, 29);
        v0_74.append(86, 30);
        v0_74.append(92, 36);
        v0_74.append(91, 35);
        v0_74.append(63, 4);
        v0_74.append(62, 3);
        v0_74.append(58, 1);
        v0_74.append(60, 91);
        v0_74.append(59, 92);
        v0_74.append(101, 6);
        v0_74.append(102, 7);
        v0_74.append(70, 17);
        v0_74.append(71, 18);
        v0_74.append(72, 19);
        v0_74.append(54, 99);
        v0_74.append(0, 27);
        v0_74.append(87, 32);
        v0_74.append(88, 33);
        v0_74.append(69, 10);
        v0_74.append(68, 9);
        v0_74.append(106, 13);
        v0_74.append(109, 16);
        v0_74.append(107, 14);
        v0_74.append(104, 11);
        v0_74.append(108, 15);
        v0_74.append(105, 12);
        v0_74.append(95, 40);
        v0_74.append(80, 39);
        v0_74.append(79, 41);
        v0_74.append(94, 42);
        v0_74.append(78, 20);
        v0_74.append(93, 37);
        v0_74.append(67, 5);
        v0_74.append(81, 87);
        v0_74.append(90, 87);
        v0_74.append(84, 87);
        v0_74.append(61, 87);
        v0_74.append(57, 87);
        v0_74.append(5, 24);
        v0_74.append(7, 28);
        v0_74.append(23, 31);
        v0_74.append(24, 8);
        v0_74.append(6, 34);
        v0_74.append(8, 2);
        v0_74.append(3, 23);
        v0_74.append(4, 21);
        v0_74.append(96, 95);
        v0_74.append(73, 96);
        v0_74.append(2, 22);
        v0_74.append(13, 43);
        v0_74.append(26, 44);
        v0_74.append(21, 45);
        v0_74.append(22, 46);
        v0_74.append(20, 60);
        v0_74.append(18, 47);
        v0_74.append(19, 48);
        v0_74.append(14, 49);
        v0_74.append(15, 50);
        v0_74.append(16, 51);
        v0_74.append(17, 52);
        v0_74.append(25, 53);
        v0_74.append(97, 54);
        v0_74.append(74, 55);
        v0_74.append(98, 56);
        v0_74.append(75, 57);
        v0_74.append(99, 58);
        v0_74.append(76, 59);
        v0_74.append(64, 61);
        v0_74.append(66, 62);
        v0_74.append(65, 63);
        v0_74.append(28, 64);
        v0_74.append(121, 65);
        v0_74.append(35, 66);
        v0_74.append(122, 67);
        v0_74.append(113, 79);
        v0_74.append(1, 38);
        v0_74.append(112, 68);
        v0_74.append(100, 69);
        v0_74.append(77, 70);
        v0_74.append(111, 97);
        v0_74.append(32, 71);
        v0_74.append(30, 72);
        v0_74.append(31, 73);
        v0_74.append(33, 74);
        v0_74.append(29, 75);
        v0_74.append(114, 76);
        v0_74.append(89, 77);
        v0_74.append(123, 78);
        v0_74.append(56, 80);
        v0_74.append(55, 81);
        v0_74.append(116, 82);
        v0_74.append(120, 83);
        v0_74.append(119, 84);
        v0_74.append(118, 85);
        v0_74.append(117, 86);
        v3_0.append(85, 6);
        v3_0.append(85, 7);
        v3_0.append(0, 27);
        v3_0.append(89, 13);
        v3_0.append(92, 16);
        v3_0.append(90, 14);
        v3_0.append(87, 11);
        v3_0.append(91, 15);
        v3_0.append(88, 12);
        v3_0.append(78, 40);
        v3_0.append(71, 39);
        v3_0.append(70, 41);
        v3_0.append(77, 42);
        v3_0.append(69, 20);
        v3_0.append(76, 37);
        v3_0.append(60, 5);
        v3_0.append(72, 87);
        v3_0.append(75, 87);
        v3_0.append(73, 87);
        v3_0.append(57, 87);
        v3_0.append(56, 87);
        v3_0.append(5, 24);
        v3_0.append(7, 28);
        v3_0.append(23, 31);
        v3_0.append(24, 8);
        v3_0.append(6, 34);
        v3_0.append(8, 2);
        v3_0.append(3, 23);
        v3_0.append(4, 21);
        v3_0.append(79, 95);
        v3_0.append(64, 96);
        v3_0.append(2, 22);
        v3_0.append(13, 43);
        v3_0.append(26, 44);
        v3_0.append(21, 45);
        v3_0.append(22, 46);
        v3_0.append(20, 60);
        v3_0.append(18, 47);
        v3_0.append(19, 48);
        v3_0.append(14, 49);
        v3_0.append(15, 50);
        v3_0.append(16, 51);
        v3_0.append(17, 52);
        v3_0.append(25, 53);
        v3_0.append(80, 54);
        v3_0.append(65, 55);
        v3_0.append(81, 56);
        v3_0.append(66, 57);
        v3_0.append(82, 58);
        v3_0.append(67, 59);
        v3_0.append(59, 62);
        v3_0.append(58, 63);
        v3_0.append(28, 64);
        v3_0.append(105, 65);
        v3_0.append(34, 66);
        v3_0.append(106, 67);
        v3_0.append(96, 79);
        v3_0.append(1, 38);
        v3_0.append(97, 98);
        v3_0.append(95, 68);
        v3_0.append(83, 69);
        v3_0.append(68, 70);
        v3_0.append(32, 71);
        v3_0.append(30, 72);
        v3_0.append(31, 73);
        v3_0.append(33, 74);
        v3_0.append(29, 75);
        v3_0.append(98, 76);
        v3_0.append(74, 77);
        v3_0.append(107, 78);
        v3_0.append(55, 80);
        v3_0.append(54, 81);
        v3_0.append(100, 82);
        v3_0.append(104, 83);
        v3_0.append(103, 84);
        v3_0.append(102, 85);
        v3_0.append(101, 86);
        v3_0.append(94, 97);
        return;
    }

    public p()
    {
        this.a = new java.util.HashMap();
        this.b = 1;
        this.c = new java.util.HashMap();
        return;
    }

    public static int[] b(a0.a p10, String p11)
    {
        String[] v11_1 = p11.split(",");
        android.content.Context v0_1 = p10.getContext();
        int[] v1_0 = new int[v11_1.length];
        int v3 = 0;
        int v4 = 0;
        while (v3 < v11_1.length) {
            boolean v5_2 = v11_1[v3].trim();
            Integer v6_0 = 0;
            try {
                int v7_2 = a0.s.getField(v5_2).getInt(0);
            } catch (Exception) {
                v7_2 = 0;
            }
            if (v7_2 == 0) {
                v7_2 = v0_1.getResources().getIdentifier(v5_2, "id", v0_1.getPackageName());
            }
            if ((v7_2 == 0) && ((p10.isInEditMode()) && ((p10.getParent() instanceof androidx.constraintlayout.widget.ConstraintLayout)))) {
                androidx.constraintlayout.widget.ConstraintLayout v8_5 = ((androidx.constraintlayout.widget.ConstraintLayout) p10.getParent());
                if (!v5_2) {
                    v8_5.getClass();
                } else {
                    boolean v9_1 = v8_5.s;
                    if ((v9_1) && (v9_1.containsKey(v5_2))) {
                        v6_0 = v8_5.s.get(v5_2);
                    }
                }
                if ((v6_0 != null) && ((v6_0 instanceof Integer))) {
                    v7_2 = ((Integer) v6_0).intValue();
                }
            }
            boolean v5_4 = (v4 + 1);
            v1_0[v4] = v7_2;
            v3++;
            v4 = v5_4;
        }
        if (v4 != v11_1.length) {
            v1_0 = java.util.Arrays.copyOf(v1_0, v4);
        }
        return v1_0;
    }

    public static a0.k c(android.content.Context p21, android.util.AttributeSet p22, boolean p23)
    {
        android.content.res.TypedArray v1_0;
        a0.k v0_1 = new a0.k();
        if (p23 == 0) {
            v1_0 = a0.t.a;
        } else {
            v1_0 = a0.t.c;
        }
        android.content.res.TypedArray v1_1 = p21.obtainStyledAttributes(p22, v1_0);
        a0.n v5 = v0_1.b;
        a0.o v6 = v0_1.e;
        a0.m v7 = v0_1.c;
        a0.l v8 = v0_1.d;
        int v9_0 = a0.p.d;
        android.util.SparseIntArray v15 = a0.p.e;
        if (p23 == 0) {
            a0.j v16_0 = v9_0;
            int v2_121 = v1_1.getIndexCount();
            int v11_2 = 0;
            while (v11_2 < v2_121) {
                int v9_6 = v1_1.getIndex(v11_2);
                if ((v9_6 != 1) && ((23 != v9_6) && (24 != v9_6))) {
                    v7.getClass();
                    v8.getClass();
                    v6.getClass();
                }
                int v23_1;
                switch (v15.get(v9_6)) {
                    case 1:
                        v23_1 = v2_121;
                        v8.p = a0.p.e(v1_1, v9_6, v8.p);
                        break;
                    case 2:
                        v23_1 = v2_121;
                        v8.I = v1_1.getDimensionPixelSize(v9_6, v8.I);
                        break;
                    case 3:
                        v23_1 = v2_121;
                        v8.o = a0.p.e(v1_1, v9_6, v8.o);
                        break;
                    case 4:
                        v23_1 = v2_121;
                        v8.n = a0.p.e(v1_1, v9_6, v8.n);
                        break;
                    case 5:
                        v23_1 = v2_121;
                        v8.y = v1_1.getString(v9_6);
                        break;
                    case 6:
                        v23_1 = v2_121;
                        v8.C = v1_1.getDimensionPixelOffset(v9_6, v8.C);
                        break;
                    case 7:
                        v23_1 = v2_121;
                        v8.D = v1_1.getDimensionPixelOffset(v9_6, v8.D);
                        break;
                    case 8:
                        v23_1 = v2_121;
                        v8.J = v1_1.getDimensionPixelSize(v9_6, v8.J);
                        break;
                    case 9:
                        v23_1 = v2_121;
                        v8.v = a0.p.e(v1_1, v9_6, v8.v);
                        break;
                    case 10:
                        v23_1 = v2_121;
                        v8.u = a0.p.e(v1_1, v9_6, v8.u);
                        break;
                    case 11:
                        v23_1 = v2_121;
                        v8.P = v1_1.getDimensionPixelSize(v9_6, v8.P);
                        break;
                    case 12:
                        v23_1 = v2_121;
                        v8.Q = v1_1.getDimensionPixelSize(v9_6, v8.Q);
                        break;
                    case 13:
                        v23_1 = v2_121;
                        v8.M = v1_1.getDimensionPixelSize(v9_6, v8.M);
                        break;
                    case 14:
                        v23_1 = v2_121;
                        v8.O = v1_1.getDimensionPixelSize(v9_6, v8.O);
                        break;
                    case 15:
                        v23_1 = v2_121;
                        v8.R = v1_1.getDimensionPixelSize(v9_6, v8.R);
                        break;
                    case 16:
                        v23_1 = v2_121;
                        v8.N = v1_1.getDimensionPixelSize(v9_6, v8.N);
                        break;
                    case 17:
                        v23_1 = v2_121;
                        v8.d = v1_1.getDimensionPixelOffset(v9_6, v8.d);
                        break;
                    case 18:
                        v23_1 = v2_121;
                        v8.e = v1_1.getDimensionPixelOffset(v9_6, v8.e);
                        break;
                    case 19:
                        v23_1 = v2_121;
                        v8.f = v1_1.getFloat(v9_6, v8.f);
                        break;
                    case 20:
                        v23_1 = v2_121;
                        v8.w = v1_1.getFloat(v9_6, v8.w);
                        break;
                    case 21:
                        v23_1 = v2_121;
                        v8.c = v1_1.getLayoutDimension(v9_6, v8.c);
                        break;
                    case 22:
                        v23_1 = v2_121;
                        int v2_205 = v1_1.getInt(v9_6, v5.a);
                        v5.a = v2_205;
                        v5.a = v16_0[v2_205];
                        break;
                    case 23:
                        v23_1 = v2_121;
                        v8.b = v1_1.getLayoutDimension(v9_6, v8.b);
                        break;
                    case 24:
                        v23_1 = v2_121;
                        v8.F = v1_1.getDimensionPixelSize(v9_6, v8.F);
                        break;
                    case 25:
                        v23_1 = v2_121;
                        v8.h = a0.p.e(v1_1, v9_6, v8.h);
                        break;
                    case 26:
                        v23_1 = v2_121;
                        v8.i = a0.p.e(v1_1, v9_6, v8.i);
                        break;
                    case 27:
                        v23_1 = v2_121;
                        v8.E = v1_1.getInt(v9_6, v8.E);
                        break;
                    case 28:
                        v23_1 = v2_121;
                        v8.G = v1_1.getDimensionPixelSize(v9_6, v8.G);
                        break;
                    case 29:
                        v23_1 = v2_121;
                        v8.j = a0.p.e(v1_1, v9_6, v8.j);
                        break;
                    case 30:
                        v23_1 = v2_121;
                        v8.k = a0.p.e(v1_1, v9_6, v8.k);
                        break;
                    case 31:
                        v23_1 = v2_121;
                        v8.K = v1_1.getDimensionPixelSize(v9_6, v8.K);
                        break;
                    case 32:
                        v23_1 = v2_121;
                        v8.s = a0.p.e(v1_1, v9_6, v8.s);
                        break;
                    case 33:
                        v23_1 = v2_121;
                        v8.t = a0.p.e(v1_1, v9_6, v8.t);
                        break;
                    case 34:
                        v23_1 = v2_121;
                        v8.H = v1_1.getDimensionPixelSize(v9_6, v8.H);
                        break;
                    case 35:
                        v23_1 = v2_121;
                        v8.m = a0.p.e(v1_1, v9_6, v8.m);
                        break;
                    case 36:
                        v23_1 = v2_121;
                        v8.l = a0.p.e(v1_1, v9_6, v8.l);
                        break;
                    case 37:
                        v23_1 = v2_121;
                        v8.x = v1_1.getFloat(v9_6, v8.x);
                        break;
                    case 38:
                        v23_1 = v2_121;
                        v0_1.a = v1_1.getResourceId(v9_6, v0_1.a);
                        break;
                    case 39:
                        v23_1 = v2_121;
                        v8.U = v1_1.getFloat(v9_6, v8.U);
                        break;
                    case 40:
                        v23_1 = v2_121;
                        v8.T = v1_1.getFloat(v9_6, v8.T);
                        break;
                    case 41:
                        v23_1 = v2_121;
                        v8.V = v1_1.getInt(v9_6, v8.V);
                        break;
                    case 42:
                        v23_1 = v2_121;
                        v8.W = v1_1.getInt(v9_6, v8.W);
                        break;
                    case 43:
                        v23_1 = v2_121;
                        v5.c = v1_1.getFloat(v9_6, v5.c);
                        break;
                    case 44:
                        v23_1 = v2_121;
                        v6.l = 1;
                        v6.m = v1_1.getDimension(v9_6, v6.m);
                        break;
                    case 45:
                        v23_1 = v2_121;
                        v6.b = v1_1.getFloat(v9_6, v6.b);
                        break;
                    case 46:
                        v23_1 = v2_121;
                        v6.c = v1_1.getFloat(v9_6, v6.c);
                        break;
                    case 47:
                        v23_1 = v2_121;
                        v6.d = v1_1.getFloat(v9_6, v6.d);
                        break;
                    case 48:
                        v23_1 = v2_121;
                        v6.e = v1_1.getFloat(v9_6, v6.e);
                        break;
                    case 49:
                        v23_1 = v2_121;
                        v6.f = v1_1.getDimension(v9_6, v6.f);
                        break;
                    case 50:
                        v23_1 = v2_121;
                        v6.g = v1_1.getDimension(v9_6, v6.g);
                        break;
                    case 51:
                        v23_1 = v2_121;
                        v6.i = v1_1.getDimension(v9_6, v6.i);
                        break;
                    case 52:
                        v23_1 = v2_121;
                        v6.j = v1_1.getDimension(v9_6, v6.j);
                        break;
                    case 53:
                        v23_1 = v2_121;
                        v6.k = v1_1.getDimension(v9_6, v6.k);
                        break;
                    case 54:
                        v23_1 = v2_121;
                        v8.X = v1_1.getInt(v9_6, v8.X);
                        break;
                    case 55:
                        v23_1 = v2_121;
                        v8.Y = v1_1.getInt(v9_6, v8.Y);
                        break;
                    case 56:
                        v23_1 = v2_121;
                        v8.Z = v1_1.getDimensionPixelSize(v9_6, v8.Z);
                        break;
                    case 57:
                        v23_1 = v2_121;
                        v8.a0 = v1_1.getDimensionPixelSize(v9_6, v8.a0);
                        break;
                    case 58:
                        v23_1 = v2_121;
                        v8.b0 = v1_1.getDimensionPixelSize(v9_6, v8.b0);
                        break;
                    case 59:
                        v23_1 = v2_121;
                        v8.c0 = v1_1.getDimensionPixelSize(v9_6, v8.c0);
                        break;
                    case 60:
                        v23_1 = v2_121;
                        v6.a = v1_1.getFloat(v9_6, v6.a);
                        break;
                    case 61:
                        v23_1 = v2_121;
                        v8.z = a0.p.e(v1_1, v9_6, v8.z);
                        break;
                    case 62:
                        v23_1 = v2_121;
                        v8.A = v1_1.getDimensionPixelSize(v9_6, v8.A);
                        break;
                    case 63:
                        v23_1 = v2_121;
                        v8.B = v1_1.getFloat(v9_6, v8.B);
                        break;
                    case 64:
                        v23_1 = v2_121;
                        v7.a = a0.p.e(v1_1, v9_6, v7.a);
                        break;
                    case 65:
                        v23_1 = v2_121;
                        if (v1_1.peekValue(v9_6).type != 3) {
                            v1_1.getInteger(v9_6, 0);
                            Class vtmp223 = v7.getClass();
                        } else {
                            v1_1.getString(v9_6);
                            v7.getClass();
                        }
                        break;
                    case 66:
                        v23_1 = v2_121;
                        v1_1.getInt(v9_6, 0);
                        v7.getClass();
                        break;
                    case 67:
                        v23_1 = v2_121;
                        v7.e = v1_1.getFloat(v9_6, v7.e);
                        break;
                    case 68:
                        v23_1 = v2_121;
                        v5.d = v1_1.getFloat(v9_6, v5.d);
                        break;
                    case 69:
                        v23_1 = v2_121;
                        v8.d0 = v1_1.getFloat(v9_6, 1065353216);
                        break;
                    case 70:
                        v23_1 = v2_121;
                        v8.e0 = v1_1.getFloat(v9_6, 1065353216);
                        break;
                    case 71:
                        v23_1 = v2_121;
                        int vtmp191 = android.util.Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                        break;
                    case 72:
                        v23_1 = v2_121;
                        v8.f0 = v1_1.getInt(v9_6, v8.f0);
                        break;
                    case 73:
                        v23_1 = v2_121;
                        v8.g0 = v1_1.getDimensionPixelSize(v9_6, v8.g0);
                        break;
                    case 74:
                        v23_1 = v2_121;
                        v8.j0 = v1_1.getString(v9_6);
                        break;
                    case 75:
                        v23_1 = v2_121;
                        v8.n0 = v1_1.getBoolean(v9_6, v8.n0);
                        break;
                    case 76:
                        v23_1 = v2_121;
                        v7.c = v1_1.getInt(v9_6, v7.c);
                        break;
                    case 77:
                        v23_1 = v2_121;
                        v8.k0 = v1_1.getString(v9_6);
                        break;
                    case 78:
                        v23_1 = v2_121;
                        v5.b = v1_1.getInt(v9_6, v5.b);
                        break;
                    case 79:
                        v23_1 = v2_121;
                        v7.d = v1_1.getFloat(v9_6, v7.d);
                        break;
                    case 80:
                        v23_1 = v2_121;
                        v8.l0 = v1_1.getBoolean(v9_6, v8.l0);
                        break;
                    case 81:
                        v23_1 = v2_121;
                        v8.m0 = v1_1.getBoolean(v9_6, v8.m0);
                        break;
                    case 82:
                        v23_1 = v2_121;
                        v7.b = v1_1.getInteger(v9_6, v7.b);
                        break;
                    case 83:
                        v23_1 = v2_121;
                        v6.h = a0.p.e(v1_1, v9_6, v6.h);
                        break;
                    case 84:
                        v23_1 = v2_121;
                        v7.g = v1_1.getInteger(v9_6, v7.g);
                        break;
                    case 85:
                        v23_1 = v2_121;
                        v7.f = v1_1.getFloat(v9_6, v7.f);
                        break;
                    case 86:
                        v23_1 = v2_121;
                        int v2_348 = v1_1.peekValue(v9_6).type;
                        if (v2_348 != 1) {
                            if (v2_348 != 3) {
                                v1_1.getInteger(v9_6, v7.i);
                            } else {
                                int v2_19 = v1_1.getString(v9_6);
                                v7.h = v2_19;
                                if (v2_19.indexOf("/") <= 0) {
                                } else {
                                    v7.i = v1_1.getResourceId(v9_6, -1);
                                }
                            }
                        } else {
                            v7.i = v1_1.getResourceId(v9_6, -1);
                        }
                        break;
                    case 87:
                        v23_1 = v2_121;
                        int v2_303 = new StringBuilder("unused attribute 0x");
                        v2_303.append(Integer.toHexString(v9_6));
                        v2_303.append("   ");
                        v2_303.append(v15.get(v9_6));
                        android.util.Log.w("ConstraintSet", v2_303.toString());
                        break;
                    case 88:
                    case 89:
                    case 90:
                    default:
                        int v10_60 = new StringBuilder("Unknown attribute 0x");
                        v23_1 = v2_121;
                        v10_60.append(Integer.toHexString(v9_6));
                        v10_60.append("   ");
                        v10_60.append(v15.get(v9_6));
                        android.util.Log.w("ConstraintSet", v10_60.toString());
                        break;
                    case 91:
                        v23_1 = v2_121;
                        v8.q = a0.p.e(v1_1, v9_6, v8.q);
                        break;
                    case 92:
                        v23_1 = v2_121;
                        v8.r = a0.p.e(v1_1, v9_6, v8.r);
                        break;
                    case 93:
                        v23_1 = v2_121;
                        v8.L = v1_1.getDimensionPixelSize(v9_6, v8.L);
                        break;
                    case 94:
                        v23_1 = v2_121;
                        v8.S = v1_1.getDimensionPixelSize(v9_6, v8.S);
                        break;
                    case 95:
                        v23_1 = v2_121;
                        a0.p.f(v8, v1_1, v9_6, 0);
                        break;
                    case 96:
                        v23_1 = v2_121;
                        a0.p.f(v8, v1_1, v9_6, 1);
                        break;
                    case 97:
                        v23_1 = v2_121;
                        v8.o0 = v1_1.getInt(v9_6, v8.o0);
                        break;
                }
                v11_2++;
                v2_121 = v23_1;
            }
            if (v8.j0 != null) {
                v8.i0 = 0;
            }
        } else {
            int v2_87 = v1_1.getIndexCount();
            a0.j v16_1 = v9_0;
            int v9_8 = new a0.j();
            int v11_3 = new int[10];
            v9_8.a = v11_3;
            int v11_4 = new int[10];
            v9_8.b = v11_4;
            v9_8.c = 0;
            int v11_6 = new int[10];
            v9_8.d = v11_6;
            int v10_62 = new float[10];
            v9_8.e = v10_62;
            v9_8.f = 0;
            int v11_8 = new int[5];
            v9_8.g = v11_8;
            int v11_9 = new String[5];
            v9_8.h = v11_9;
            v9_8.i = 0;
            int v11_11 = new int[4];
            v9_8.j = v11_11;
            int v10_65 = new boolean[4];
            v9_8.k = v10_65;
            v9_8.l = 0;
            v7.getClass();
            v8.getClass();
            v6.getClass();
            int v10_45 = 0;
            while (v10_45 < v2_87) {
                int v20;
                int v11_13 = v1_1.getIndex(v10_45);
                int v19_1 = v2_87;
                switch (a0.p.f.get(v11_13)) {
                    case 2:
                        v20 = v10_45;
                        v9_8.b(2, v1_1.getDimensionPixelSize(v11_13, v8.I));
                        break;
                    case 3:
                    case 4:
                    case 9:
                    case 10:
                    case 25:
                    case 26:
                    case 29:
                    case 30:
                    case 32:
                    case 33:
                    case 35:
                    case 36:
                    case 61:
                    case 88:
                    case 89:
                    case 90:
                    case 91:
                    case 92:
                    default:
                        int v2_84 = new StringBuilder("Unknown attribute 0x");
                        v20 = v10_45;
                        v2_84.append(Integer.toHexString(v11_13));
                        v2_84.append("   ");
                        v2_84.append(v15.get(v11_13));
                        android.util.Log.w("ConstraintSet", v2_84.toString());
                        break;
                    case 5:
                        v20 = v10_45;
                        v9_8.c(5, v1_1.getString(v11_13));
                        break;
                    case 6:
                        v20 = v10_45;
                        v9_8.b(6, v1_1.getDimensionPixelOffset(v11_13, v8.C));
                        break;
                    case 7:
                        v20 = v10_45;
                        v9_8.b(7, v1_1.getDimensionPixelOffset(v11_13, v8.D));
                        break;
                    case 8:
                        v20 = v10_45;
                        v9_8.b(8, v1_1.getDimensionPixelSize(v11_13, v8.J));
                        break;
                    case 11:
                        v20 = v10_45;
                        v9_8.b(11, v1_1.getDimensionPixelSize(v11_13, v8.P));
                        break;
                    case 12:
                        v20 = v10_45;
                        v9_8.b(12, v1_1.getDimensionPixelSize(v11_13, v8.Q));
                        break;
                    case 13:
                        v20 = v10_45;
                        v9_8.b(13, v1_1.getDimensionPixelSize(v11_13, v8.M));
                        break;
                    case 14:
                        v20 = v10_45;
                        v9_8.b(14, v1_1.getDimensionPixelSize(v11_13, v8.O));
                        break;
                    case 15:
                        v20 = v10_45;
                        v9_8.b(15, v1_1.getDimensionPixelSize(v11_13, v8.R));
                        break;
                    case 16:
                        v20 = v10_45;
                        v9_8.b(16, v1_1.getDimensionPixelSize(v11_13, v8.N));
                        break;
                    case 17:
                        v20 = v10_45;
                        v9_8.b(17, v1_1.getDimensionPixelOffset(v11_13, v8.d));
                        break;
                    case 18:
                        v20 = v10_45;
                        v9_8.b(18, v1_1.getDimensionPixelOffset(v11_13, v8.e));
                        break;
                    case 19:
                        v20 = v10_45;
                        v9_8.a(19, v1_1.getFloat(v11_13, v8.f));
                        break;
                    case 20:
                        v20 = v10_45;
                        v9_8.a(20, v1_1.getFloat(v11_13, v8.w));
                        break;
                    case 21:
                        v20 = v10_45;
                        v9_8.b(21, v1_1.getLayoutDimension(v11_13, v8.c));
                        break;
                    case 22:
                        v20 = v10_45;
                        v9_8.b(22, v16_1[v1_1.getInt(v11_13, v5.a)]);
                        break;
                    case 23:
                        v20 = v10_45;
                        v9_8.b(23, v1_1.getLayoutDimension(v11_13, v8.b));
                        break;
                    case 24:
                        v20 = v10_45;
                        v9_8.b(24, v1_1.getDimensionPixelSize(v11_13, v8.F));
                        break;
                    case 27:
                        v20 = v10_45;
                        v9_8.b(27, v1_1.getInt(v11_13, v8.E));
                        break;
                    case 28:
                        v20 = v10_45;
                        v9_8.b(28, v1_1.getDimensionPixelSize(v11_13, v8.G));
                        break;
                    case 31:
                        v20 = v10_45;
                        v9_8.b(31, v1_1.getDimensionPixelSize(v11_13, v8.K));
                        break;
                    case 34:
                        v20 = v10_45;
                        v9_8.b(34, v1_1.getDimensionPixelSize(v11_13, v8.H));
                        break;
                    case 37:
                        v20 = v10_45;
                        v9_8.a(37, v1_1.getFloat(v11_13, v8.x));
                        break;
                    case 38:
                        v20 = v10_45;
                        int v2_29 = v1_1.getResourceId(v11_13, v0_1.a);
                        v0_1.a = v2_29;
                        v9_8.b(38, v2_29);
                        break;
                    case 39:
                        v20 = v10_45;
                        v9_8.a(39, v1_1.getFloat(v11_13, v8.U));
                        break;
                    case 40:
                        v20 = v10_45;
                        v9_8.a(40, v1_1.getFloat(v11_13, v8.T));
                        break;
                    case 41:
                        v20 = v10_45;
                        v9_8.b(41, v1_1.getInt(v11_13, v8.V));
                        break;
                    case 42:
                        v20 = v10_45;
                        v9_8.b(42, v1_1.getInt(v11_13, v8.W));
                        break;
                    case 43:
                        v20 = v10_45;
                        v9_8.a(43, v1_1.getFloat(v11_13, v5.c));
                        break;
                    case 44:
                        v20 = v10_45;
                        v9_8.d(44, 1);
                        v9_8.a(44, v1_1.getDimension(v11_13, v6.m));
                        break;
                    case 45:
                        v20 = v10_45;
                        v9_8.a(45, v1_1.getFloat(v11_13, v6.b));
                        break;
                    case 46:
                        v20 = v10_45;
                        v9_8.a(46, v1_1.getFloat(v11_13, v6.c));
                        break;
                    case 47:
                        v20 = v10_45;
                        v9_8.a(47, v1_1.getFloat(v11_13, v6.d));
                        break;
                    case 48:
                        v20 = v10_45;
                        v9_8.a(48, v1_1.getFloat(v11_13, v6.e));
                        break;
                    case 49:
                        v20 = v10_45;
                        v9_8.a(49, v1_1.getDimension(v11_13, v6.f));
                        break;
                    case 50:
                        v20 = v10_45;
                        v9_8.a(50, v1_1.getDimension(v11_13, v6.g));
                        break;
                    case 51:
                        v20 = v10_45;
                        v9_8.a(51, v1_1.getDimension(v11_13, v6.i));
                        break;
                    case 52:
                        v20 = v10_45;
                        v9_8.a(52, v1_1.getDimension(v11_13, v6.j));
                        break;
                    case 53:
                        v20 = v10_45;
                        v9_8.a(53, v1_1.getDimension(v11_13, v6.k));
                        break;
                    case 54:
                        v20 = v10_45;
                        v9_8.b(54, v1_1.getInt(v11_13, v8.X));
                        break;
                    case 55:
                        v20 = v10_45;
                        v9_8.b(55, v1_1.getInt(v11_13, v8.Y));
                        break;
                    case 56:
                        v20 = v10_45;
                        v9_8.b(56, v1_1.getDimensionPixelSize(v11_13, v8.Z));
                        break;
                    case 57:
                        v20 = v10_45;
                        v9_8.b(57, v1_1.getDimensionPixelSize(v11_13, v8.a0));
                        break;
                    case 58:
                        v20 = v10_45;
                        v9_8.b(58, v1_1.getDimensionPixelSize(v11_13, v8.b0));
                        break;
                    case 59:
                        v20 = v10_45;
                        v9_8.b(59, v1_1.getDimensionPixelSize(v11_13, v8.c0));
                        break;
                    case 60:
                        v20 = v10_45;
                        v9_8.a(60, v1_1.getFloat(v11_13, v6.a));
                        break;
                    case 62:
                        v20 = v10_45;
                        v9_8.b(62, v1_1.getDimensionPixelSize(v11_13, v8.A));
                        break;
                    case 63:
                        v20 = v10_45;
                        v9_8.a(63, v1_1.getFloat(v11_13, v8.B));
                        break;
                    case 64:
                        v20 = v10_45;
                        v9_8.b(64, a0.p.e(v1_1, v11_13, v7.a));
                        break;
                    case 65:
                        v20 = v10_45;
                        if (v1_1.peekValue(v11_13).type != 3) {
                            v9_8.c(65, w.a.a[v1_1.getInteger(v11_13, 0)]);
                        } else {
                            v9_8.c(65, v1_1.getString(v11_13));
                        }
                        break;
                    case 66:
                        v20 = v10_45;
                        v9_8.b(66, v1_1.getInt(v11_13, 0));
                        break;
                    case 67:
                        v20 = v10_45;
                        v9_8.a(67, v1_1.getFloat(v11_13, v7.e));
                        break;
                    case 68:
                        v20 = v10_45;
                        v9_8.a(68, v1_1.getFloat(v11_13, v5.d));
                        break;
                    case 69:
                        v20 = v10_45;
                        v9_8.a(69, v1_1.getFloat(v11_13, 1065353216));
                        break;
                    case 70:
                        v20 = v10_45;
                        v9_8.a(70, v1_1.getFloat(v11_13, 1065353216));
                        break;
                    case 71:
                        v20 = v10_45;
                        android.util.Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                        break;
                    case 72:
                        v20 = v10_45;
                        v9_8.b(72, v1_1.getInt(v11_13, v8.f0));
                        break;
                    case 73:
                        v20 = v10_45;
                        v9_8.b(73, v1_1.getDimensionPixelSize(v11_13, v8.g0));
                        break;
                    case 74:
                        v20 = v10_45;
                        v9_8.c(74, v1_1.getString(v11_13));
                        break;
                    case 75:
                        v20 = v10_45;
                        v9_8.d(75, v1_1.getBoolean(v11_13, v8.n0));
                        break;
                    case 76:
                        v20 = v10_45;
                        v9_8.b(76, v1_1.getInt(v11_13, v7.c));
                        break;
                    case 77:
                        v20 = v10_45;
                        v9_8.c(77, v1_1.getString(v11_13));
                        break;
                    case 78:
                        v20 = v10_45;
                        v9_8.b(78, v1_1.getInt(v11_13, v5.b));
                        break;
                    case 79:
                        v20 = v10_45;
                        v9_8.a(79, v1_1.getFloat(v11_13, v7.d));
                        break;
                    case 80:
                        v20 = v10_45;
                        v9_8.d(80, v1_1.getBoolean(v11_13, v8.l0));
                        break;
                    case 81:
                        v20 = v10_45;
                        v9_8.d(81, v1_1.getBoolean(v11_13, v8.m0));
                        break;
                    case 82:
                        v20 = v10_45;
                        v9_8.b(82, v1_1.getInteger(v11_13, v7.b));
                        break;
                    case 83:
                        v20 = v10_45;
                        v9_8.b(83, a0.p.e(v1_1, v11_13, v6.h));
                        break;
                    case 84:
                        v20 = v10_45;
                        v9_8.b(84, v1_1.getInteger(v11_13, v7.g));
                        break;
                    case 85:
                        v20 = v10_45;
                        v9_8.a(85, v1_1.getFloat(v11_13, v7.f));
                        break;
                    case 86:
                        v20 = v10_45;
                        int v2_279 = v1_1.peekValue(v11_13).type;
                        if (v2_279 != 1) {
                            if (v2_279 != 3) {
                                v9_8.b(88, v1_1.getInteger(v11_13, v7.i));
                            } else {
                                int v2_282 = v1_1.getString(v11_13);
                                v7.h = v2_282;
                                v9_8.c(90, v2_282);
                                if (v7.h.indexOf("/") <= 0) {
                                    v9_8.b(88, -1);
                                } else {
                                    int v2_286 = v1_1.getResourceId(v11_13, -1);
                                    v7.i = v2_286;
                                    v9_8.b(89, v2_286);
                                    v9_8.b(88, -2);
                                }
                            }
                        } else {
                            int v2_289 = v1_1.getResourceId(v11_13, -1);
                            v7.i = v2_289;
                            v9_8.b(89, v2_289);
                            if (v7.i == -1) {
                            } else {
                                v9_8.b(88, -2);
                            }
                        }
                        break;
                    case 87:
                        v20 = v10_45;
                        int v2_276 = new StringBuilder("unused attribute 0x");
                        v2_276.append(Integer.toHexString(v11_13));
                        v2_276.append("   ");
                        v2_276.append(v15.get(v11_13));
                        android.util.Log.w("ConstraintSet", v2_276.toString());
                        break;
                    case 93:
                        v20 = v10_45;
                        v9_8.b(93, v1_1.getDimensionPixelSize(v11_13, v8.L));
                        break;
                    case 94:
                        v20 = v10_45;
                        v9_8.b(94, v1_1.getDimensionPixelSize(v11_13, v8.S));
                        break;
                    case 95:
                        v20 = v10_45;
                        a0.p.f(v9_8, v1_1, v11_13, 0);
                        break;
                    case 96:
                        v20 = v10_45;
                        a0.p.f(v9_8, v1_1, v11_13, 1);
                        break;
                    case 97:
                        v20 = v10_45;
                        v9_8.b(97, v1_1.getInt(v11_13, v8.o0));
                        break;
                    case 98:
                        v20 = v10_45;
                        if (v1_1.peekValue(v11_13).type != 3) {
                            v0_1.a = v1_1.getResourceId(v11_13, v0_1.a);
                        } else {
                            v1_1.getString(v11_13);
                        }
                        break;
                    case 99:
                        v20 = v10_45;
                        v9_8.d(99, v1_1.getBoolean(v11_13, v8.g));
                        break;
                }
                v10_45 = (v20 + 1);
                v2_87 = v19_1;
            }
        }
        v1_1.recycle();
        return v0_1;
    }

    public static int e(android.content.res.TypedArray p1, int p2, int p3)
    {
        int v3_1 = p1.getResourceId(p2, p3);
        if (v3_1 != -1) {
            return v3_1;
        } else {
            return p1.getInt(p2, -1);
        }
    }

    public static void f(Object p7, android.content.res.TypedArray p8, int p9, int p10)
    {
        try {
            if (p7 != null) {
                int v0_5 = p8.peekValue(p9).type;
                int v4 = 1;
                int v6 = 0;
                if (v0_5 == 3) {
                    int v8_1 = p8.getString(p9);
                    if (v8_1 != 0) {
                        int v9_10 = v8_1.indexOf(61);
                        int v0_1 = v8_1.length();
                        if ((v9_10 > 0) && (v9_10 < (v0_1 - 1))) {
                            int v0_4 = v8_1.substring(0, v9_10);
                            int v8_8 = v8_1.substring((v9_10 + 1));
                            if (v8_8.length() > 0) {
                                int v9_13 = v0_4.trim();
                                int v8_9 = v8_8.trim();
                                if (!"ratio".equalsIgnoreCase(v9_13)) {
                                    if (!"weight".equalsIgnoreCase(v9_13)) {
                                        if ("parent".equalsIgnoreCase(v9_13)) {
                                            int v8_12 = Math.max(0, Math.min(1065353216, Float.parseFloat(v8_9)));
                                            if (!(p7 instanceof a0.e)) {
                                                if (!(p7 instanceof a0.l)) {
                                                    if ((p7 instanceof a0.j)) {
                                                        if (p10 != 0) {
                                                            ((a0.j) p7).b(21, 0);
                                                            ((a0.j) p7).b(55, 2);
                                                        } else {
                                                            ((a0.j) p7).b(23, 0);
                                                            ((a0.j) p7).b(54, 2);
                                                            return;
                                                        }
                                                    }
                                                } else {
                                                    if (p10 != 0) {
                                                        ((a0.l) p7).c = 0;
                                                        ((a0.l) p7).e0 = v8_12;
                                                        ((a0.l) p7).Y = 2;
                                                        return;
                                                    } else {
                                                        ((a0.l) p7).b = 0;
                                                        ((a0.l) p7).d0 = v8_12;
                                                        ((a0.l) p7).X = 2;
                                                        return;
                                                    }
                                                }
                                            } else {
                                                if (p10 != 0) {
                                                    ((a0.e) p7).height = 0;
                                                    ((a0.e) p7).S = v8_12;
                                                    ((a0.e) p7).M = 2;
                                                    return;
                                                } else {
                                                    ((a0.e) p7).width = 0;
                                                    ((a0.e) p7).R = v8_12;
                                                    ((a0.e) p7).L = 2;
                                                    return;
                                                }
                                            }
                                        }
                                    } else {
                                        int v8_16 = Float.parseFloat(v8_9);
                                        if (!(p7 instanceof a0.e)) {
                                            if (!(p7 instanceof a0.l)) {
                                                if ((p7 instanceof a0.j)) {
                                                    if (p10 != 0) {
                                                        ((a0.j) p7).b(21, 0);
                                                        ((a0.j) p7).a(40, v8_16);
                                                        return;
                                                    } else {
                                                        ((a0.j) p7).b(23, 0);
                                                        ((a0.j) p7).a(39, v8_16);
                                                        return;
                                                    }
                                                }
                                            } else {
                                                if (p10 != 0) {
                                                    ((a0.l) p7).c = 0;
                                                    ((a0.l) p7).T = v8_16;
                                                    return;
                                                } else {
                                                    ((a0.l) p7).b = 0;
                                                    ((a0.l) p7).U = v8_16;
                                                    return;
                                                }
                                            }
                                        } else {
                                            if (p10 != 0) {
                                                ((a0.e) p7).height = 0;
                                                ((a0.e) p7).I = v8_16;
                                                return;
                                            } else {
                                                ((a0.e) p7).width = 0;
                                                ((a0.e) p7).H = v8_16;
                                                return;
                                            }
                                        }
                                    }
                                } else {
                                    if (!(p7 instanceof a0.e)) {
                                        if (!(p7 instanceof a0.l)) {
                                            if ((p7 instanceof a0.j)) {
                                                ((a0.j) p7).c(5, v8_9);
                                                return;
                                            }
                                        } else {
                                            ((a0.l) p7).y = v8_9;
                                            return;
                                        }
                                    } else {
                                        if (p10 != 0) {
                                            ((a0.e) p7).height = 0;
                                        } else {
                                            ((a0.e) p7).width = 0;
                                        }
                                        a0.p.g(((a0.e) p7), v8_9);
                                        return;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    int v8_2;
                    if (v0_5 == 5) {
                        v8_2 = p8.getDimensionPixelSize(p9, 0);
                        v4 = 0;
                        v6 = v8_2;
                    } else {
                        v8_2 = p8.getInt(p9, 0);
                        if (v8_2 == -4) {
                            v6 = -2;
                        } else {
                            if ((v8_2 != -3) && ((v8_2 == -2) || (v8_2 == -1))) {
                            } else {
                                v4 = 0;
                            }
                        }
                    }
                    if (!(p7 instanceof a0.e)) {
                        if (!(p7 instanceof a0.l)) {
                            if ((p7 instanceof a0.j)) {
                                if (p10 != 0) {
                                    ((a0.j) p7).b(21, v6);
                                    ((a0.j) p7).d(81, v4);
                                    return;
                                } else {
                                    ((a0.j) p7).b(23, v6);
                                    ((a0.j) p7).d(80, v4);
                                    return;
                                }
                            }
                        } else {
                            if (p10 != 0) {
                                ((a0.l) p7).c = v6;
                                ((a0.l) p7).m0 = v4;
                                return;
                            } else {
                                ((a0.l) p7).b = v6;
                                ((a0.l) p7).l0 = v4;
                                return;
                            }
                        }
                    } else {
                        if (p10 != 0) {
                            ((a0.e) p7).height = v6;
                            ((a0.e) p7).X = v4;
                            return;
                        } else {
                            ((a0.e) p7).width = v6;
                            ((a0.e) p7).W = v4;
                            return;
                        }
                    }
                }
            }
        } catch (NumberFormatException) {
        }
        return;
    }

    public static void g(a0.e p7, String p8)
    {
        try {
            if (p8 != null) {
                float v0_0 = p8.length();
                float v1_7 = p8.indexOf(44);
                float v2_2 = 0;
                int v4 = -1;
                if ((v1_7 > 0) && (v1_7 < (v0_0 - 1))) {
                    float v5_1 = p8.substring(0, v1_7);
                    if (!v5_1.equalsIgnoreCase("W")) {
                        if (!v5_1.equalsIgnoreCase("H")) {
                            v2_2 = -1;
                        } else {
                            v2_2 = 1;
                        }
                    }
                    v4 = v2_2;
                    v2_2 = (v1_7 + 1);
                }
                float v1_2 = p8.indexOf(58);
                if ((v1_2 < 0) || (v1_2 >= (v0_0 - 1))) {
                    float v0_2 = p8.substring(v2_2);
                    if (v0_2.length() > 0) {
                        Float.parseFloat(v0_2);
                    }
                } else {
                    float v0_3 = p8.substring(v2_2, v1_2);
                    float v1_6 = p8.substring((v1_2 + 1));
                    if ((v0_3.length() > 0) && (v1_6.length() > 0)) {
                        float v0_4 = Float.parseFloat(v0_3);
                        float v1_8 = Float.parseFloat(v1_6);
                        if ((v0_4 > 0) && (v1_8 > 0)) {
                            if (v4 != 1) {
                                Math.abs((v0_4 / v1_8));
                            } else {
                                Math.abs((v1_8 / v0_4));
                            }
                        }
                    }
                }
            }
        } catch (NumberFormatException) {
        }
        p7.G = p8;
        return;
    }

    public final void a(android.content.Context p22, int p23)
    {
        a0.p v1_0 = this;
        androidx.constraintlayout.widget.ConstraintLayout v3_0 = ((androidx.constraintlayout.widget.ConstraintLayout) android.view.LayoutInflater.from(p22).inflate(p23, 0));
        long v4_0 = v3_0.getChildCount();
        java.util.HashMap v5_0 = this.c;
        v5_0.clear();
        int v6_0 = 0;
        while (v6_0 < v4_0) {
            a0.a v7_0 = v3_0.getChildAt(v6_0);
            a0.e v8_1 = ((a0.e) v7_0.getLayoutParams());
            int v9 = v7_0.getId();
            if ((v1_0.b) && (v9 == -1)) {
                com.google.firebase.firestore.v.f("All children of ConstraintLayout must have ids to use ConstraintSet");
                return;
            } else {
                if (!v5_0.containsKey(Integer.valueOf(v9))) {
                    v5_0.put(Integer.valueOf(v9), new a0.k());
                }
                int v20_1;
                int v16;
                java.util.HashMap v17;
                androidx.constraintlayout.widget.ConstraintLayout v23_1;
                a0.k v10_3 = ((a0.k) v5_0.get(Integer.valueOf(v9)));
                if (v10_3 != null) {
                    a0.n v11 = v10_3.b;
                    a0.l v12 = v10_3.d;
                    a0.o v13 = v10_3.e;
                    v23_1 = v3_0;
                    androidx.constraintlayout.widget.ConstraintLayout v3_3 = new java.util.HashMap();
                    v16 = v4_0;
                    long v4_2 = v7_0.getClass();
                    v17 = v5_0;
                    java.util.HashMap v5_16 = v1_0.a;
                    java.util.Iterator v18 = v5_16.keySet().iterator();
                    while (v18.hasNext()) {
                        a0.p v1_3 = ((String) v18.next());
                        int v0_69 = ((a0.b) v5_16.get(v1_3));
                        java.util.HashMap v19 = v5_16;
                        int v20_0;
                        if (!v1_3.equals("BackgroundColor")) {
                            v20_0 = v6_0;
                            java.util.HashMap v5_4 = new StringBuilder();
                            v5_4.append("getMap");
                            v5_4.append(v1_3);
                            v3_3.put(v1_3, new a0.b(v0_69, v4_2.getMethod(v5_4.toString(), 0).invoke(v7_0, 0)));
                        } else {
                            v20_0 = v6_0;
                            v3_3.put(v1_3, new a0.b(v0_69, Integer.valueOf(((android.graphics.drawable.ColorDrawable) v7_0.getBackground()).getColor())));
                        }
                        v5_16 = v19;
                        v6_0 = v20_0;
                    }
                    v20_1 = v6_0;
                    v10_3.f = v3_3;
                    v10_3.a = v9;
                    v12.h = v8_1.e;
                    v12.i = v8_1.f;
                    v12.j = v8_1.g;
                    v12.k = v8_1.h;
                    v12.l = v8_1.i;
                    v12.m = v8_1.j;
                    v12.n = v8_1.k;
                    v12.o = v8_1.l;
                    v12.p = v8_1.m;
                    v12.q = v8_1.n;
                    v12.r = v8_1.o;
                    v12.s = v8_1.s;
                    v12.t = v8_1.t;
                    v12.u = v8_1.u;
                    v12.v = v8_1.v;
                    v12.w = v8_1.E;
                    v12.x = v8_1.F;
                    v12.y = v8_1.G;
                    v12.z = v8_1.p;
                    v12.A = v8_1.q;
                    v12.B = v8_1.r;
                    v12.C = v8_1.T;
                    v12.D = v8_1.U;
                    v12.E = v8_1.V;
                    v12.f = v8_1.c;
                    v12.d = v8_1.a;
                    v12.e = v8_1.b;
                    v12.b = v8_1.width;
                    v12.c = v8_1.height;
                    v12.F = v8_1.leftMargin;
                    v12.G = v8_1.rightMargin;
                    v12.H = v8_1.topMargin;
                    v12.I = v8_1.bottomMargin;
                    v12.L = v8_1.D;
                    v12.T = v8_1.I;
                    v12.U = v8_1.H;
                    v12.W = v8_1.K;
                    v12.V = v8_1.J;
                    v12.l0 = v8_1.W;
                    v12.m0 = v8_1.X;
                    v12.X = v8_1.L;
                    v12.Y = v8_1.M;
                    v12.Z = v8_1.P;
                    v12.a0 = v8_1.Q;
                    v12.b0 = v8_1.N;
                    v12.c0 = v8_1.O;
                    v12.d0 = v8_1.R;
                    v12.e0 = v8_1.S;
                    v12.k0 = v8_1.Y;
                    v12.N = v8_1.x;
                    v12.P = v8_1.z;
                    v12.M = v8_1.w;
                    v12.O = v8_1.y;
                    v12.R = v8_1.A;
                    v12.Q = v8_1.B;
                    v12.S = v8_1.C;
                    v12.o0 = v8_1.Z;
                    v12.J = v8_1.getMarginEnd();
                    v12.K = v8_1.getMarginStart();
                    v11.a = v7_0.getVisibility();
                    v11.c = v7_0.getAlpha();
                    v13.a = v7_0.getRotation();
                    v13.b = v7_0.getRotationX();
                    v13.c = v7_0.getRotationY();
                    v13.d = v7_0.getScaleX();
                    v13.e = v7_0.getScaleY();
                    int v0_55 = v7_0.getPivotX();
                    a0.p v1_1 = v7_0.getPivotY();
                    if ((((double) v0_55) != 0) || (((double) v1_1) != 0)) {
                        v13.f = v0_55;
                        v13.g = v1_1;
                    }
                    v13.i = v7_0.getTranslationX();
                    v13.j = v7_0.getTranslationY();
                    v13.k = v7_0.getTranslationZ();
                    if (v13.l) {
                        v13.m = v7_0.getElevation();
                    }
                    if ((v7_0 instanceof a0.a)) {
                        a0.a v7_1 = ((a0.a) v7_0);
                        v12.n0 = v7_1.getAllowsGoneWidget();
                        v12.i0 = v7_1.getReferencedIds();
                        v12.f0 = v7_1.getType();
                        v12.g0 = v7_1.getMargin();
                    }
                } else {
                    v23_1 = v3_0;
                    v16 = v4_0;
                    v17 = v5_0;
                    v20_1 = v6_0;
                }
                v6_0 = (v20_1 + 1);
                v1_0 = this;
                v3_0 = v23_1;
                v4_0 = v16;
                v5_0 = v17;
            }
        }
        return;
    }

    public final void d(android.content.Context p8, int p9)
    {
        StringBuilder v2_5 = p8.getResources().getXml(p9);
        java.util.HashMap v3_4 = v2_5.getEventType();
        while (v3_4 != 1) {
            if (v3_4 == 2) {
                java.util.HashMap v3_0 = v2_5.getName();
                a0.k v5_2 = a0.p.c(p8, android.util.Xml.asAttributeSet(v2_5), 0);
                if (v3_0.equalsIgnoreCase("Guideline")) {
                    v5_2.d.a = 1;
                }
                this.c.put(Integer.valueOf(v5_2.a), v5_2);
            } else {
            }
            v3_4 = v2_5.next();
        }
        return;
    }
}
