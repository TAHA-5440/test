// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a0;
public final class i implements e2.b, oc.c0, yb.j, e1.o, f2.g, w2.i, f3.n, q0.s, jb.b {
    public final synthetic int g;
    public Object h;
    public Object i;

    public i(int p3)
    {
        this.g = p3;
        switch (p3) {
            case 2:
                this.h = new s3.j(1000);
                this.i = t3.c.a(10, new n5.f(1));
                return;
            case 9:
                this.h = android.view.Choreographer.getInstance();
                this.i = android.os.Looper.myLooper();
                return;
            default:
                this.h = new java.util.HashMap();
                this.i = new a3.c(0);
                return;
        }
    }

    public i(int p2, int p3)
    {
        this.g = 22;
        this.h = new int[] {p2, p3});
        float[] v2_3 = new float[2];
        v2_3 = {0, 1065353216};
        this.i = v2_3;
        return;
    }

    public i(int p2, int p3, int p4)
    {
        this.g = 22;
        this.h = new int[] {p2, p3, p4});
        float[] v2_3 = new float[3];
        v2_3 = {0, 1056964608, 1065353216};
        this.i = v2_3;
        return;
    }

    public synthetic i(int p1, Object p2, Object p3)
    {
        this.g = p1;
        this.h = p2;
        this.i = p3;
        return;
    }

    public synthetic i(int p1, boolean p2)
    {
        this.g = p1;
        return;
    }

    public i(android.content.Context p2)
    {
        this.g = 12;
        this.i = 0;
        this.h = p2;
        return;
    }

    public i(android.widget.EditText p6)
    {
        this.g = 20;
        this.h = p6;
        g1.a v0_3 = new g1.i(p6);
        this.i = v0_3;
        p6.addTextChangedListener(v0_3);
        if (g1.a.b == null) {
            if (g1.a.b == null) {
                g1.a v1_2 = new g1.a();
                g1.a.c = Class.forName("android.text.DynamicLayout$ChangeWatcher", 0, g1.a.getClassLoader());
                g1.a.b = v1_2;
            }
        }
        p6.setEditableFactory(g1.a.b);
        return;
    }

    public i(androidx.room.RoomDatabase p2)
    {
        this.g = 5;
        this.h = p2;
        java.util.Set v2_3 = java.util.Collections.newSetFromMap(new java.util.IdentityHashMap());
        v2_3.getClass();
        this.i = v2_3;
        return;
    }

    public i(androidx.room.b0 p2, e2.b p3)
    {
        this.g = 4;
        p3.getClass();
        this.i = p2;
        this.h = p3;
        return;
    }

    public i(cc.i p5)
    {
        this.g = 6;
        this.h = new cc.g(p5, p5.c.h().m(), -1);
        this.i = new cc.h(p5, p5.c.h().getSource(), -1);
        return;
    }

    public i(d1.c p2)
    {
        this.g = 8;
        this.i = p2;
        return;
    }

    public i(e7.b p2)
    {
        this.g = 13;
        this.h = p2;
        return;
    }

    public i(e7.g1 p2, Object p3)
    {
        this.g = 14;
        com.bumptech.glide.f.l(p2, "status");
        this.h = p2;
        this.i = p3;
        return;
    }

    public i(e7.j1 p2, java.util.concurrent.ScheduledFuture p3)
    {
        this.g = 15;
        this.h = p2;
        com.bumptech.glide.f.l(p3, "future");
        this.i = p3;
        return;
    }

    public i(i.w p2, c0.g p3)
    {
        this.g = 24;
        this.i = p2;
        this.h = p3;
        return;
    }

    public i(java.util.ArrayList p5, java.util.ArrayList p6)
    {
        this.g = 22;
        int v0_1 = p5.size();
        int v1_1 = new int[v0_1];
        this.h = v1_1;
        int v1_2 = new float[v0_1];
        this.i = v1_2;
        int v1_0 = 0;
        while (v1_0 < v0_1) {
            ((int[]) this.h)[v1_0] = ((Integer) p5.get(v1_0)).intValue();
            ((float[]) this.i)[v1_0] = ((Float) p6.get(v1_0)).floatValue();
            v1_0++;
        }
        return;
    }

    public i(p8.b p2, java.time.Duration p3)
    {
        this.g = 16;
        this.h = p2;
        this.i = p3;
        return;
    }

    public static String j(Class p2)
    {
        StringBuilder v0_0 = p2.getModifiers();
        if (!reflect.Modifier.isInterface(v0_0)) {
            if (!reflect.Modifier.isAbstract(v0_0)) {
                return 0;
            } else {
                StringBuilder v0_2 = new StringBuilder("Abstract classes can\'t be instantiated! Adjust the R8 configuration or register an InstanceCreator or a TypeAdapter for this type. Class name: ");
                v0_2.append(p2.getName());
                v0_2.append("\nSee ");
                v0_2.append("https://github.com/google/gson/blob/main/Troubleshooting.md#".concat("r8-abstract-class"));
                return v0_2.toString();
            }
        } else {
            return "Interfaces can\'t be instantiated! Register an InstanceCreator or a TypeAdapter for this type. Interface name: ".concat(p2.getName());
        }
    }

    public static f3.z o(android.graphics.ImageDecoder$Source p1, int p2, int p3, w2.g p4)
    {
        int v1_2 = androidx.work.impl.background.systemjob.a.k(p1, new e3.c(p2, p3, p4));
        if (!androidx.work.impl.background.systemjob.a.x(v1_2)) {
            oc.l.f(v1_2, "Received unexpected drawable type for animated image, failing: ");
            return 0;
        } else {
            return new f3.z(androidx.work.impl.background.systemjob.a.j(v1_2), 2);
        }
    }

    public String B()
    {
        return ((String) this.h);
    }

    public boolean a(CharSequence p4, int p5, int p6, e1.v p7)
    {
        if ((p7.c & 4) <= 0) {
            if (((e1.y) this.h) == null) {
                android.text.SpannableString v4_1;
                if (!(p4 instanceof android.text.Spannable)) {
                    v4_1 = new android.text.SpannableString(p4);
                } else {
                    v4_1 = ((android.text.Spannable) p4);
                }
                this.h = new e1.y(v4_1);
            }
            ((ea.c) this.i).getClass();
            ((e1.y) this.h).setSpan(new e1.w(p7), p5, p6, 33);
            return 1;
        } else {
            return 1;
        }
    }

    public e2.a b(String p9)
    {
        p9.getClass();
        Throwable v0_1 = ((androidx.room.b0) this.i);
        if (!p9.equals(":memory:")) {
            p9 = v0_1.c.a.getDatabasePath(p9).getAbsolutePath();
            p9.getClass();
        }
        int v1_1;
        String v4_0 = 1;
        if ((v0_1.a) || ((v0_1.b) || (p9.equals(":memory:")))) {
            v1_1 = 0;
        } else {
            v1_1 = 1;
        }
        IllegalStateException v2_1 = new x1.b(p9, v1_1);
        int v1_2 = v2_1.a;
        v1_2.lock();
        IllegalStateException v2_2 = v2_1.b;
        if (v2_2 == null) {
            try {
                if (v0_1.b) {
                    throw new IllegalStateException("Recursive database initialization detected. Did you try to use the database instance during initialization? Maybe in one of the callbacks?");
                } else {
                    Throwable v6_3 = ((e2.b) this.h).b(p9);
                    if (v0_1.a) {
                        androidx.room.b0.b(v6_3);
                        if (v0_1.c.g != androidx.room.RoomDatabase$JournalMode.i) {
                            g6.f0.e(v6_3, "PRAGMA synchronous = FULL");
                        } else {
                            g6.f0.e(v6_3, "PRAGMA synchronous = NORMAL");
                        }
                        v0_1.d.d(v6_3);
                    } else {
                        v0_1.b = 1;
                        androidx.room.b0.a(v0_1, v6_3);
                        v0_1.b = 0;
                    }
                    if (v2_2 != null) {
                        Throwable v0_8 = ((java.nio.channels.FileChannel) v2_2.i);
                        if (v0_8 != null) {
                            v0_8.close();
                            v2_2.i = 0;
                        }
                    }
                    v1_2.unlock();
                    return v6_3;
                }
            } catch (Throwable v0_2) {
            } catch (Throwable v0_5) {
                if (v2_2 != null) {
                    String v5_8 = ((java.nio.channels.FileChannel) v2_2.i);
                    if (v5_8 != null) {
                        v5_8.close();
                        v2_2.i = 0;
                    }
                }
                throw v0_5;
            }
        } else {
            try {
                v2_2.m();
            } catch (Throwable v0_2) {
                v4_0 = 0;
            }
        }
        if (v4_0 == null) {
            StringBuilder v3_4 = new StringBuilder("Unable to open database \'");
            v3_4.append(p9);
            v3_4.append("\'. Was a proper path / name used in Room\'s database builder?");
            throw new IllegalStateException(v3_4.toString(), v0_2);
        } else {
            throw v0_2;
        }
    }

    public boolean c()
    {
        return ((e2.b) this.h).c();
    }

    public Object collect(jb.c p7, ka.c p8)
    {
        switch (this.g) {
            case 27:
                kotlinx.coroutines.flow.FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1$1 v0_9;
                if (!(p8 instanceof kotlinx.coroutines.flow.FlowKt__EmittersKt$onStart$$inlined$unsafeFlow$1$1)) {
                    v0_9 = new kotlinx.coroutines.flow.FlowKt__EmittersKt$onStart$$inlined$unsafeFlow$1$1(this, p8);
                } else {
                    v0_9 = ((kotlinx.coroutines.flow.FlowKt__EmittersKt$onStart$$inlined$unsafeFlow$1$1) p8);
                    ga.p v1_5 = ((kotlinx.coroutines.flow.FlowKt__EmittersKt$onStart$$inlined$unsafeFlow$1$1) p8).h;
                    if ((v1_5 & -2147483648) == 0) {
                    } else {
                        ((kotlinx.coroutines.flow.FlowKt__EmittersKt$onStart$$inlined$unsafeFlow$1$1) p8).h = (v1_5 - -2147483648);
                    }
                }
                Object v7_9;
                int v4_3;
                ua.q v2_13;
                int v8_7 = v0_9.g;
                ga.p v1_0 = kotlin.coroutines.intrinsics.CoroutineSingletons.g;
                ua.q v2_7 = v0_9.h;
                if (v2_7 == null) {
                    kotlin.b.b(v8_7);
                    int v8_9 = new kotlinx.coroutines.flow.internal.SafeCollector(p7, v0_9.getContext());
                    try {
                        ua.q v2_11 = ((ua.p) this.h);
                        v0_9.j = this;
                        v0_9.k = p7;
                        v0_9.l = v8_9;
                        v0_9.h = 1;
                    } catch (Object v7_8) {
                        int v8_10 = v7_8;
                        v7_9 = v8_9;
                        v7_9.releaseIntercepted();
                        throw v8_10;
                    }
                    if (v2_11.invoke(v8_9, v0_9) != v1_0) {
                        v4_3 = this;
                        v2_13 = p7;
                        v7_9 = v8_9;
                        v7_9.releaseIntercepted();
                        Object v7_2 = ((jb.b) v4_3.i);
                        v0_9.j = 0;
                        v0_9.k = 0;
                        v0_9.l = 0;
                        v0_9.h = 2;
                        if (v7_2.collect(v2_13, v0_9) != v1_0) {
                            v1_0 = ga.p.a;
                        }
                    }
                } else {
                    if (v2_7 == 1) {
                        v7_9 = v0_9.l;
                        v2_13 = v0_9.k;
                        v4_3 = v0_9.j;
                        try {
                            kotlin.b.b(v8_7);
                        } catch (int v8_10) {
                        }
                    } else {
                        if (v2_7 != 2) {
                            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.w("call to \'resume\' before \'invoke\' with coroutine");
                            v1_0 = 0;
                        } else {
                            kotlin.b.b(v8_7);
                        }
                    }
                }
                return v1_0;
            case 28:
                kotlinx.coroutines.flow.FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1$1 v0_2;
                if (!(p8 instanceof kotlinx.coroutines.flow.FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1$1)) {
                    v0_2 = new kotlinx.coroutines.flow.FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1$1(this, p8);
                } else {
                    v0_2 = ((kotlinx.coroutines.flow.FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1$1) p8);
                    ga.p v1_6 = ((kotlinx.coroutines.flow.FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1$1) p8).h;
                    if ((v1_6 & -2147483648) == 0) {
                    } else {
                        ((kotlinx.coroutines.flow.FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1$1) p8).h = (v1_6 - -2147483648);
                    }
                }
                ua.q v2_3;
                int v8_3 = v0_2.g;
                ga.p v1_4 = kotlin.coroutines.intrinsics.CoroutineSingletons.g;
                ua.q v2_2 = v0_2.h;
                if (v2_2 == null) {
                    kotlin.b.b(v8_3);
                    int v8_5 = ((jb.b) this.h);
                    v0_2.j = this;
                    v0_2.k = p7;
                    v0_2.h = 1;
                    v8_3 = kotlinx.coroutines.flow.a.d(v8_5, p7, v0_2);
                    if (v8_3 != v1_4) {
                        v2_3 = this;
                        int v8_6 = ((Throwable) v8_3);
                        if (v8_6 == 0) {
                            v1_4 = ga.p.a;
                        } else {
                            ua.q v2_5 = ((ua.q) v2_3.i);
                            v0_2.j = 0;
                            v0_2.k = 0;
                            v0_2.h = 2;
                            if (v2_5.invoke(p7, v8_6, v0_2) != v1_4) {
                            }
                        }
                    }
                } else {
                    if (v2_2 == 1) {
                        p7 = v0_2.k;
                        v2_3 = v0_2.j;
                        kotlin.b.b(v8_3);
                    } else {
                        if (v2_2 != 2) {
                            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.w("call to \'resume\' before \'invoke\' with coroutine");
                            v1_4 = 0;
                        } else {
                            kotlin.b.b(v8_3);
                        }
                    }
                }
                return v1_4;
            default:
                Object v7_5 = ((jb.e) this.h).collect(new kotlinx.coroutines.flow.d(new kotlin.jvm.internal.Ref$BooleanRef(), p7, ((ua.p) this.i)), p8);
                if (v7_5 != kotlin.coroutines.intrinsics.CoroutineSingletons.g) {
                    v7_5 = ga.p.a;
                }
                return v7_5;
        }
    }

    public e7.b d()
    {
        if (((java.util.IdentityHashMap) this.i) != null) {
            int v0_11 = ((e7.b) this.h).a.entrySet().iterator();
            while (v0_11.hasNext()) {
                Object v1_4 = ((java.util.Map$Entry) v0_11.next());
                if (!((java.util.IdentityHashMap) this.i).containsKey(v1_4.getKey())) {
                    ((java.util.IdentityHashMap) this.i).put(((e7.a) v1_4.getKey()), v1_4.getValue());
                }
            }
            this.h = new e7.b(((java.util.IdentityHashMap) this.i));
            this.i = 0;
        }
        return ((e7.b) this.h);
    }

    public i9.d e()
    {
        m9.o v0_1 = new io.opentelemetry.sdk.trace.a();
        ba.h v1_0 = new ba.h(v0_1.b, v0_1.c, v0_1.d, v0_1.e, v0_1.f, v0_1.a, v0_1.g.e());
        r9.t v2_2 = new r9.t(new java.util.ArrayList(), new java.util.IdentityHashMap(), new java.util.ArrayList(), aa.c.a, w9.a.a, new g7.c1(4, 0).e());
        m9.o v0_5 = ((m9.o) this.i);
        if (v0_5 == null) {
            m9.o v0_7 = new java.util.ArrayList();
            b8.a v4_3 = new ba.i(3);
            java.util.ArrayList v5_5 = new java.util.ArrayList();
            l9.c.getDefault();
            v0_5 = new m9.o(aa.c.a, v4_3, v0_7, new l9.e(v5_5));
        }
        return new i9.d(v1_0, v2_2, v0_5, ((b8.a) this.h));
    }

    public void f()
    {
        ((e7.j1) this.h).h = 1;
        ((java.util.concurrent.ScheduledFuture) this.i).cancel(0);
        return;
    }

    public boolean g(Object p4, java.io.File p5, w2.g p6)
    {
        return ((f3.b) this.i).g(new f3.d(((android.graphics.drawable.BitmapDrawable) ((y2.u) p4).get()).getBitmap(), ((z2.a) this.h)), p5, p6);
    }

    public Object getResult()
    {
        return ((e1.y) this.h);
    }

    public oc.d0 getSource()
    {
        return ((cc.h) this.i);
    }

    public void h(f2.f p2)
    {
        com.bumptech.glide.d.b(p2, ((Object[]) this.i));
        return;
    }

    public void i(android.graphics.Bitmap p2, z2.a p3)
    {
        java.io.IOException v0_2 = ((s3.e) this.i).h;
        if (v0_2 == null) {
            return;
        } else {
            if (p2 != null) {
                p3.e(p2);
            }
            throw v0_2;
        }
    }

    public q0.o1 k(android.view.View p5, q0.o1 p6)
    {
        g5.h v0_1 = ((g5.h) this.h);
        int v2_2 = ((g5.i) this.i);
        g5.i v1_1 = new g5.i();
        v1_1.a = v2_2.a;
        v1_1.b = v2_2.b;
        v1_1.c = v2_2.c;
        v1_1.d = v2_2.d;
        return v0_1.b(p5, p6, v1_1);
    }

    public void l()
    {
        com.bumptech.glide.load.resource.bitmap.a v0_1 = ((com.bumptech.glide.load.resource.bitmap.a) this.h);
        v0_1.i = v0_1.g.length;
        return;
    }

    public oc.b0 m()
    {
        return ((cc.g) this.h);
    }

    public com.bumptech.glide.load.EncodeStrategy n(w2.g p1)
    {
        return com.bumptech.glide.load.EncodeStrategy.h;
    }

    public void onFailure(yb.i p1, java.io.IOException p2)
    {
        ((x8.a) this.h).accept(p2);
        return;
    }

    public void onResponse(yb.i p3, yb.b0 p4)
    {
        Throwable v3_0 = p4.m;
        try {
            ((x8.a) this.i).accept(new d9.c(p4, v3_0));
        } catch (Throwable v4_1) {
            if (v3_0 != null) {
                try {
                    v3_0.close();
                } catch (Throwable v3_1) {
                    v4_1.addSuppressed(v3_1);
                }
            }
            throw v4_1;
        }
        if (v3_0 != null) {
            v3_0.close();
        }
        return;
    }

    public com.google.android.datatransport.cct.CctBackendFactory q(String p14)
    {
        if (((java.util.Map) this.i) == null) {
            java.util.HashMap v2_16 = ((android.content.Context) this.h);
            try {
                java.util.HashMap v2_4;
                java.util.HashMap v5_0 = v2_16.getPackageManager();
            } catch (android.content.pm.PackageManager$NameNotFoundException) {
                android.util.Log.w("BackendRegistry", "Application info not found.");
                v2_4 = 0;
                java.util.HashMap v2_10;
                if (v2_4 != null) {
                    java.util.HashMap v5_4 = new java.util.HashMap();
                    java.util.Iterator v6_3 = v2_4.keySet().iterator();
                    while (v6_3.hasNext()) {
                        String v7_3 = ((String) v6_3.next());
                        String[] v8_0 = v2_4.get(v7_3);
                        if (((v8_0 instanceof String)) && (v7_3.startsWith("backend:"))) {
                            String[] v8_2 = ((String) v8_0).split(",", -1);
                            int v9_4 = v8_2.length;
                            int v10_1 = 0;
                            while (v10_1 < v9_4) {
                                String v11_1 = v8_2[v10_1].trim();
                                if (!v11_1.isEmpty()) {
                                    v5_4.put(v11_1, v7_3.substring(8));
                                }
                                v10_1++;
                            }
                        }
                    }
                    v2_10 = v5_4;
                } else {
                    android.util.Log.w("BackendRegistry", "Could not retrieve metadata, returning empty list of transport backends.");
                    v2_10 = java.util.Collections.EMPTY_MAP;
                }
                this.i = v2_10;
            }
            if (v5_0 != null) {
                java.util.HashMap v2_3 = v5_0.getServiceInfo(new android.content.ComponentName(v2_16, com.google.android.datatransport.runtime.backends.TransportBackendDiscovery), 128);
                if (v2_3 != null) {
                    v2_4 = v2_3.metaData;
                } else {
                    android.util.Log.w("BackendRegistry", "TransportBackendDiscovery has no service info.");
                }
            } else {
                android.util.Log.w("BackendRegistry", "Context has no PackageManager.");
            }
        }
        String v14_6 = ((String) ((java.util.Map) this.i).get(p14));
        if (v14_6 != null) {
            try {
                return ((com.google.android.datatransport.cct.CctBackendFactory) Class.forName(v14_6).asSubclass(com.google.android.datatransport.cct.CctBackendFactory).getDeclaredConstructor(int v3).newInstance(0));
            } catch (reflect.InvocationTargetException v0_1) {
                StringBuilder v1_2 = new StringBuilder("Class ");
                v1_2.append(v14_6);
                v1_2.append(" is not found.");
                android.util.Log.w("BackendRegistry", v1_2.toString(), v0_1);
                return 0;
            } catch (java.util.HashMap v2_0) {
                java.util.HashMap v5_2 = new StringBuilder("Could not instantiate ");
                v5_2.append(v14_6);
                v5_2.append(".");
                android.util.Log.w("BackendRegistry", v5_2.toString(), v2_0);
                return 0;
            } catch (java.util.HashMap v2_21) {
                java.util.HashMap v5_7 = new StringBuilder("Could not instantiate ");
                v5_7.append(v14_6);
                v5_7.append(".");
                android.util.Log.w("BackendRegistry", v5_7.toString(), v2_21);
                return 0;
            } catch (reflect.InvocationTargetException v0_3) {
                android.util.Log.w("BackendRegistry", "Could not instantiate ".concat(v14_6), v0_3);
                return 0;
            } catch (reflect.InvocationTargetException v0_2) {
                android.util.Log.w("BackendRegistry", "Could not instantiate ".concat(v14_6), v0_2);
                return 0;
            }
        } else {
            return 0;
        }
    }

    public com.google.gson.internal.k r(k6.a p8, boolean p9)
    {
        int v0_0 = p8.b;
        String v8_1 = p8.a;
        Class v1_9 = ((java.util.Map) this.h);
        com.google.firebase.firestore.v v3_1 = 0;
        if (v1_9.get(v0_0) != null) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.o();
            return 0;
        } else {
            if (v1_9.get(v8_1) != null) {
                com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.o();
                return 0;
            } else {
                Class v1_5;
                if (!java.util.EnumSet.isAssignableFrom(v8_1)) {
                    if (v8_1 != java.util.EnumMap) {
                        v1_5 = 0;
                    } else {
                        v1_5 = new com.google.gson.internal.a(v0_0, 1);
                    }
                } else {
                    v1_5 = new com.google.gson.internal.a(v0_0, 0);
                }
                if (v1_5 == null) {
                    Class v1_14;
                    com.google.gson.internal.f.e(((java.util.List) this.i));
                    try {
                        if (!reflect.Modifier.isAbstract(v8_1.getModifiers())) {
                            Class v1_13 = v8_1.getDeclaredConstructor(0);
                            try {
                                v1_13.setAccessible(1);
                                androidx.work.impl.b v2_1 = 0;
                            } catch (androidx.work.impl.b v2_2) {
                                int v5_1 = new StringBuilder("Failed making constructor \'");
                                v5_1.append(j6.c.b(v1_13));
                                v5_1.append("\' accessible; either increase its visibility or write a custom InstanceCreator or TypeAdapter for its declaring type: ");
                                v5_1.append(v2_2.getMessage());
                                v5_1.append(j6.c.e(v2_2));
                                v2_1 = v5_1.toString();
                            }
                            if (v2_1 == null) {
                                v1_14 = new androidx.work.impl.b(v1_13, 14);
                            } else {
                                v1_14 = new com.google.gson.internal.b(v2_1, 0);
                            }
                        } else {
                            v1_14 = 0;
                        }
                    } catch (NoSuchMethodException) {
                    }
                    if (v1_14 == null) {
                        if (!java.util.Collection.isAssignableFrom(v8_1)) {
                            if (java.util.Map.isAssignableFrom(v8_1)) {
                                if (v8_1.isAssignableFrom(com.google.gson.internal.LinkedTreeMap)) {
                                    if ((v0_0 instanceof reflect.ParameterizedType)) {
                                        int v0_26 = ((reflect.ParameterizedType) v0_0).getActualTypeArguments();
                                        if ((v0_26.length == 0) || (com.google.gson.internal.f.g(v0_26[0]) != String)) {
                                            if (!v8_1.isAssignableFrom(java.util.LinkedHashMap)) {
                                                if (!v8_1.isAssignableFrom(java.util.TreeMap)) {
                                                    if (!v8_1.isAssignableFrom(java.util.concurrent.ConcurrentHashMap)) {
                                                        if (v8_1.isAssignableFrom(java.util.concurrent.ConcurrentSkipListMap)) {
                                                            v3_1 = new com.google.firebase.firestore.v(20);
                                                        }
                                                    } else {
                                                        v3_1 = new com.google.firebase.firestore.v(19);
                                                    }
                                                } else {
                                                    v3_1 = new com.google.firebase.firestore.v(26);
                                                }
                                            } else {
                                                v3_1 = new com.google.firebase.firestore.v(25);
                                            }
                                            if (v3_1 == null) {
                                                int v0_22 = a0.i.j(v8_1);
                                                if (v0_22 == 0) {
                                                    if (p9 != null) {
                                                        return new androidx.work.impl.b(v8_1, 15);
                                                    } else {
                                                        androidx.work.impl.b v9_4 = new StringBuilder("Unable to create instance of ");
                                                        v9_4.append(v8_1);
                                                        v9_4.append("; Register an InstanceCreator or a TypeAdapter for this type.");
                                                        return new com.google.gson.internal.b(v9_4.toString(), 0);
                                                    }
                                                } else {
                                                    return new com.google.gson.internal.b(v0_22, 0);
                                                }
                                            } else {
                                                return v3_1;
                                            }
                                        }
                                    }
                                    v3_1 = new com.google.firebase.firestore.v(24);
                                }
                            }
                        } else {
                            if (!v8_1.isAssignableFrom(java.util.ArrayList)) {
                                if (!v8_1.isAssignableFrom(java.util.LinkedHashSet)) {
                                    if (!v8_1.isAssignableFrom(java.util.TreeSet)) {
                                        if (v8_1.isAssignableFrom(java.util.ArrayDeque)) {
                                            v3_1 = new com.google.firebase.firestore.v(23);
                                        }
                                    } else {
                                        v3_1 = new com.google.firebase.firestore.v(22);
                                    }
                                } else {
                                    v3_1 = new com.google.firebase.firestore.v(21);
                                }
                            } else {
                                v3_1 = new com.google.firebase.firestore.v(18);
                            }
                        }
                    } else {
                        return v1_14;
                    }
                } else {
                    return v1_5;
                }
            }
        }
    }

    public String s(w2.d p9)
    {
        String v1_5 = ((String) ((s3.j) this.h).a(p9));
        if (v1_5 == null) {
            s3.j v0_4 = ((a3.j) ((androidx.lifecycle.j) this.i).f());
            try {
                p9.b(v0_4.g);
                String v1_2 = v0_4.g.digest();
                androidx.lifecycle.j v2_0 = s3.m.b;
                int v3 = 0;
            } catch (Throwable v9_3) {
                ((androidx.lifecycle.j) this.i).b(v0_4);
                throw v9_3;
            }
            while (v3 < v1_2.length) {
                char v4_1 = v1_2[v3];
                int v6_0 = (v3 * 2);
                char[] v7 = s3.m.a;
                v2_0[v6_0] = v7[((v4_1 & 255) >> 4)];
                v2_0[(v6_0 + 1)] = v7[(v4_1 & 15)];
                v3++;
            }
            v1_5 = new String(v2_0);
            ((androidx.lifecycle.j) this.i).b(v0_4);
        }
        try {
            ((s3.j) this.h).d(p9, v1_5);
            return v1_5;
        } catch (Throwable v9_1) {
            throw v9_1;
        }
    }

    public void t(k.a p4)
    {
        q0.q0 v0_1 = ((c0.g) this.h);
        ((android.view.ActionMode$Callback) v0_1.h).onDestroyActionMode(v0_1.f(p4));
        i.w v4_3 = ((i.w) this.i);
        if (v4_3.C != null) {
            v4_3.r.getDecorView().removeCallbacks(v4_3.D);
        }
        if (v4_3.B != null) {
            q0.q0 v0_5 = v4_3.E;
            if (v0_5 != null) {
                v0_5.b();
            }
            q0.q0 v0_7 = q0.n0.a(v4_3.B);
            v0_7.a(0);
            v4_3.E = v0_7;
            v0_7.d(new i.q(this, 2));
        }
        v4_3.A = 0;
        q0.d0.c(v4_3.G);
        v4_3.H();
        return;
    }

    public String toString()
    {
        switch (this.g) {
            case 7:
                return ((java.util.Map) this.h).toString();
            default:
                return super.toString();
        }
    }

    public boolean u(k.a p6, android.view.Menu p7)
    {
        q0.d0.c(((i.w) this.i).G);
        android.content.Context v0_6 = ((c0.g) this.h);
        android.view.ActionMode$Callback v1_1 = ((android.view.ActionMode$Callback) v0_6.h);
        boolean v6_1 = v0_6.f(p6);
        t.l v2_1 = ((t.l) v0_6.i);
        l.c0 v3_1 = ((android.view.Menu) v2_1.get(p7));
        if (v3_1 == null) {
            v3_1 = new l.c0(((android.content.Context) v0_6.k), ((l.m) p7));
            v2_1.put(p7, v3_1);
        }
        return v1_1.onPrepareActionMode(v6_1, v3_1);
    }

    public void v(android.content.Context p12, android.content.res.XmlResourceParser p13)
    {
        a0.p v0_1 = new a0.p();
        int v1_6 = p13.getAttributeCount();
        String v3_1 = 0;
        while (v3_1 < v1_6) {
            int v4_2 = p13.getAttributeName(v3_1);
            String v5_0 = p13.getAttributeValue(v3_1);
            if ((v4_2 == 0) || ((v5_0 == null) || (!"id".equals(v4_2)))) {
                v3_1++;
            } else {
                int v1_2;
                if (!v5_0.contains("/")) {
                    v1_2 = -1;
                } else {
                    v1_2 = p12.getResources().getIdentifier(v5_0.substring((v5_0.indexOf(47) + 1)), "id", p12.getPackageName());
                }
                if (v1_2 == -1) {
                    if (v5_0.length() <= 1) {
                        android.util.Log.e("ConstraintLayoutStates", "error in parsing id");
                    } else {
                        v1_2 = Integer.parseInt(v5_0.substring(1));
                    }
                }
                java.util.HashMap v6_22 = p13.getEventType();
                int v8_0 = 0;
                while (v6_22 != 1) {
                    if (v6_22 == null) {
                        p13.getName();
                    } else {
                        if (v6_22 == 2) {
                            java.util.HashMap v6_23 = p13.getName();
                            switch (v6_23.hashCode()) {
                                case -2025855158:
                                    if (v6_23.equals("Layout")) {
                                        if (v8_0 == 0) {
                                            StringBuilder v2_7 = new StringBuilder();
                                            v2_7.append("XML parser error must be within a Constraint ");
                                            v2_7.append(p13.getLineNumber());
                                            throw new RuntimeException(v2_7.toString());
                                        } else {
                                            v8_0.d.a(p12, android.util.Xml.asAttributeSet(p13));
                                        }
                                    }
                                    break;
                                case -1984451626:
                                    if (v6_23.equals("Motion")) {
                                        if (v8_0 == 0) {
                                            StringBuilder v2_5 = new StringBuilder();
                                            v2_5.append("XML parser error must be within a Constraint ");
                                            v2_5.append(p13.getLineNumber());
                                            throw new RuntimeException(v2_5.toString());
                                        } else {
                                            v8_0.c.a(p12, android.util.Xml.asAttributeSet(p13));
                                        }
                                    }
                                    break;
                                case -1962203927:
                                    if (v6_23.equals("ConstraintOverride")) {
                                        v8_0 = a0.p.c(p12, android.util.Xml.asAttributeSet(p13), 1);
                                    }
                                    break;
                                case -1269513683:
                                    if (v6_23.equals("PropertySet")) {
                                        if (v8_0 == 0) {
                                            StringBuilder v2_3 = new StringBuilder();
                                            v2_3.append("XML parser error must be within a Constraint ");
                                            v2_3.append(p13.getLineNumber());
                                            throw new RuntimeException(v2_3.toString());
                                        } else {
                                            v8_0.b.a(p12, android.util.Xml.asAttributeSet(p13));
                                        }
                                    }
                                    break;
                                case -1238332596:
                                    if (v6_23.equals("Transform")) {
                                        if (v8_0 == 0) {
                                            StringBuilder v2_1 = new StringBuilder();
                                            v2_1.append("XML parser error must be within a Constraint ");
                                            v2_1.append(p13.getLineNumber());
                                            throw new RuntimeException(v2_1.toString());
                                        } else {
                                            v8_0.e.a(p12, android.util.Xml.asAttributeSet(p13));
                                        }
                                    }
                                    break;
                                case -71750448:
                                    if (v6_23.equals("Guideline")) {
                                        v8_0 = a0.p.c(p12, android.util.Xml.asAttributeSet(p13), 0);
                                        v8_0.d.a = 1;
                                    }
                                    break;
                                case 366511058:
                                    if (v6_23.equals("CustomMethod")) {
                                    }
                                    break;
                                case 1331510167:
                                    if (v6_23.equals("Barrier")) {
                                        v8_0 = a0.p.c(p12, android.util.Xml.asAttributeSet(p13), 0);
                                        v8_0.d.h0 = 1;
                                    }
                                    break;
                                case 1791837707:
                                    if (v6_23.equals("CustomAttribute")) {
                                    }
                                    break;
                                case 1803088381:
                                    if (v6_23.equals("Constraint")) {
                                        v8_0 = a0.p.c(p12, android.util.Xml.asAttributeSet(p13), 0);
                                    }
                                    break;
                                default:
                            }
                            if (v8_0 == 0) {
                                StringBuilder v2_10 = new StringBuilder();
                                v2_10.append("XML parser error must be within a Constraint ");
                                v2_10.append(p13.getLineNumber());
                                throw new RuntimeException(v2_10.toString());
                            } else {
                                a0.b.a(p12, p13, v8_0.f);
                            }
                        } else {
                            if (v6_22 == 3) {
                                java.util.HashMap v6_16 = p13.getName().toLowerCase(java.util.Locale.ROOT);
                                switch (v6_16.hashCode()) {
                                    case -2075718416:
                                        if (v6_16.equals("guideline")) {
                                        }
                                        break;
                                    case -190376483:
                                        if (v6_16.equals("constraint")) {
                                        }
                                        break;
                                    case 426575017:
                                        if (v6_16.equals("constraintoverride")) {
                                        }
                                        break;
                                    case 2146106725:
                                        if (v6_16.equals("constraintset")) {
                                            break;
                                        }
                                        break;
                                    default:
                                }
                                v0_1.c.put(Integer.valueOf(v8_0.a), v8_0);
                                v8_0 = 0;
                            } else {
                            }
                        }
                    }
                    v6_22 = p13.next();
                }
                ((android.util.SparseArray) this.i).put(v1_2, v0_1);
                return;
            }
        }
        return;
    }

    public void w(String p6)
    {
        a3.b v2_3 = ((a3.b) ((java.util.HashMap) this.h).get(p6));
        s3.f.c(v2_3, "Argument must not be null");
        int v3_9 = v2_3.b;
        if (v3_9 < 1) {
            int v3_1 = new StringBuilder("Cannot release a lock that is not held, safeKey: ");
            v3_1.append(p6);
            v3_1.append(", interestedThreads: ");
            v3_1.append(v2_3.b);
            throw new IllegalStateException(v3_1.toString());
        } else {
            int v3_2 = (v3_9 - 1);
            v2_3.b = v3_2;
            if (v3_2 == 0) {
                a3.b v1_4 = ((a3.b) ((java.util.HashMap) this.h).remove(p6));
                if (!v1_4.equals(v2_3)) {
                    int v4_2 = new StringBuilder("Removed the wrong lock, expected to remove: ");
                    v4_2.append(v2_3);
                    v4_2.append(", but actually removed: ");
                    v4_2.append(v1_4);
                    v4_2.append(", safeKey: ");
                    v4_2.append(p6);
                    throw new IllegalStateException(v4_2.toString());
                } else {
                    java.util.ArrayDeque v6_6 = ((a3.c) this.i);
                    if (v6_6.a.size() < 10) {
                        v6_6.a.offer(v1_4);
                    }
                }
            }
            v2_3.a.unlock();
            return;
        }
    }

    public void x(e7.a p3, Object p4)
    {
        if (((java.util.IdentityHashMap) this.i) == null) {
            this.i = new java.util.IdentityHashMap(1);
        }
        ((java.util.IdentityHashMap) this.i).put(p3, p4);
        return;
    }
}
