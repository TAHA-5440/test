// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a0;
public final class b {
    public boolean a;
    public androidx.constraintlayout.widget.ConstraintAttribute$AttributeType b;
    public int c;
    public float d;
    public String e;
    public boolean f;
    public int g;

    public b(a0.b p2, Object p3)
    {
        this.a = 0;
        p2.getClass();
        this.b = p2.b;
        this.b(p3);
        return;
    }

    public static void a(android.content.Context p12, android.content.res.XmlResourceParser p13, java.util.HashMap p14)
    {
        android.content.res.TypedArray v13_2 = p12.obtainStyledAttributes(android.util.Xml.asAttributeSet(p13), a0.t.d);
        int v0_1 = v13_2.getIndexCount();
        String v1_0 = 0;
        Integer v3_0 = 0;
        androidx.constraintlayout.widget.ConstraintAttribute$AttributeType v4_0 = 0;
        int v5 = 0;
        int v6 = 0;
        while (v5 < v0_1) {
            StringBuilder v7_3 = v13_2.getIndex(v5);
            if (v7_3 != null) {
                if (v7_3 != 10) {
                    if (v7_3 != 1) {
                        if (v7_3 != 3) {
                            if (v7_3 != 2) {
                                if (v7_3 != 7) {
                                    if (v7_3 != 4) {
                                        if (v7_3 != 5) {
                                            if (v7_3 != 6) {
                                                if (v7_3 != 9) {
                                                    if (v7_3 != 8) {
                                                        v5++;
                                                    } else {
                                                        Integer v3_1 = v13_2.getResourceId(v7_3, -1);
                                                        if (v3_1 == -1) {
                                                            v3_1 = v13_2.getInt(v7_3, -1);
                                                        }
                                                        v3_0 = Integer.valueOf(v3_1);
                                                        v4_0 = androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.n;
                                                    }
                                                } else {
                                                    v3_0 = v13_2.getString(v7_3);
                                                    v4_0 = androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.k;
                                                }
                                            } else {
                                                v3_0 = Integer.valueOf(v13_2.getInteger(v7_3, -1));
                                                v4_0 = androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.g;
                                            }
                                        } else {
                                            v3_0 = Float.valueOf(v13_2.getFloat(v7_3, 2143289344));
                                            v4_0 = androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.h;
                                        }
                                    } else {
                                        v3_0 = Float.valueOf(v13_2.getDimension(v7_3, 0));
                                    }
                                } else {
                                    v3_0 = Float.valueOf(android.util.TypedValue.applyDimension(1, v13_2.getDimension(v7_3, 0), p12.getResources().getDisplayMetrics()));
                                }
                                v4_0 = androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.m;
                            } else {
                                v3_0 = Integer.valueOf(v13_2.getColor(v7_3, 0));
                                v4_0 = androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.j;
                            }
                        } else {
                            v3_0 = Integer.valueOf(v13_2.getColor(v7_3, 0));
                            v4_0 = androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.i;
                        }
                    } else {
                        v3_0 = Boolean.valueOf(v13_2.getBoolean(v7_3, 0));
                        v4_0 = androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.l;
                    }
                } else {
                    v1_0 = v13_2.getString(v7_3);
                    v6 = 1;
                }
            } else {
                v1_0 = v13_2.getString(v7_3);
                if ((v1_0 != null) && (v1_0.length() > 0)) {
                    StringBuilder v7_2 = new StringBuilder();
                    v7_2.append(Character.toUpperCase(v1_0.charAt(0)));
                    v7_2.append(v1_0.substring(1));
                    v1_0 = v7_2.toString();
                }
            }
        }
        if ((v1_0 != null) && (v3_0 != null)) {
            a0.b v12_2 = new a0.b();
            v12_2.b = v4_0;
            v12_2.a = v6;
            v12_2.b(v3_0);
            p14.put(v1_0, v12_2);
        }
        v13_2.recycle();
        return;
    }

    public final void b(Object p2)
    {
        switch (this.b.ordinal()) {
            case 0:
            case 7:
                this.c = ((Integer) p2).intValue();
                return;
            case 1:
                this.d = ((Float) p2).floatValue();
                return;
            case 2:
            case 3:
                this.g = ((Integer) p2).intValue();
                return;
            case 4:
                this.e = ((String) p2);
                return;
            case 5:
                this.f = ((Boolean) p2).booleanValue();
                return;
            case 6:
                this.d = ((Float) p2).floatValue();
                return;
            default:
                return;
        }
    }
}
