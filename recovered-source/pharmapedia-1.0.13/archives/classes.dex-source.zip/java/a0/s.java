// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a0;
public abstract class s {
}
