// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a0;
public final class g {
    public final java.util.ArrayList a;
    public int b;
    public final int c;

    public g(int p2)
    {
        this.a = new java.util.ArrayList();
        this.c = p2;
        return;
    }

    public g(android.content.Context p6, android.content.res.XmlResourceParser p7)
    {
        this.a = new java.util.ArrayList();
        this.c = -1;
        android.content.res.TypedArray v7_1 = p6.obtainStyledAttributes(android.util.Xml.asAttributeSet(p7), a0.t.h);
        int v0_1 = v7_1.getIndexCount();
        int v1 = 0;
        while (v1 < v0_1) {
            int v2_0 = v7_1.getIndex(v1);
            if (v2_0 != 0) {
                if (v2_0 == 1) {
                    int v2_1 = v7_1.getResourceId(v2_0, this.c);
                    this.c = v2_1;
                    a0.p v3_3 = p6.getResources().getResourceTypeName(v2_1);
                    p6.getResources().getResourceName(v2_1);
                    if ("layout".equals(v3_3)) {
                        new a0.p().a(p6, v2_1);
                    }
                }
            } else {
                this.b = v7_1.getResourceId(v2_0, this.b);
            }
            v1++;
        }
        v7_1.recycle();
        return;
    }

    public byte[] a()
    {
        int v1_0 = this.a;
        if (this.b >= v1_0.size()) {
            byte[] v0_5 = new byte[this.c];
            v1_0.add(v0_5);
            this.b = (this.b + 1);
            return v0_5;
        } else {
            byte[] v0_1 = this.b;
            this.b = (v0_1 + 1);
            return ((byte[]) v1_0.get(v0_1));
        }
    }
}
