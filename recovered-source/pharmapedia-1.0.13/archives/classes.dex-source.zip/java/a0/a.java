// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a0;
public final class a extends a0.c {
    public int n;
    public int o;
    public x.a p;

    public final void g(android.util.AttributeSet p3)
    {
        x.a v3_1 = new x.a();
        int v0_1 = new x.d[4];
        v3_1.p0 = v0_1;
        v3_1.q0 = 0;
        v3_1.r0 = 0;
        v3_1.s0 = 1;
        v3_1.t0 = 0;
        v3_1.u0 = 0;
        this.p = v3_1;
        this.j = v3_1;
        this.j();
        return;
    }

    public boolean getAllowsGoneWidget()
    {
        return this.p.s0;
    }

    public int getMargin()
    {
        return this.p.t0;
    }

    public int getType()
    {
        return this.n;
    }

    public final void h(x.d p6, boolean p7)
    {
        int v0 = this.n;
        this.o = v0;
        if (p7 == 0) {
            if (v0 != 5) {
                if (v0 == 6) {
                    this.o = 1;
                }
            } else {
                this.o = 0;
            }
        } else {
            if (v0 != 5) {
                if (v0 == 6) {
                    this.o = 0;
                }
            } else {
                this.o = 1;
            }
        }
        if ((p6 instanceof x.a)) {
            ((x.a) p6).r0 = this.o;
        }
        return;
    }

    public void setAllowsGoneWidget(boolean p2)
    {
        this.p.s0 = p2;
        return;
    }

    public void setDpMargin(int p2)
    {
        this.p.t0 = ((int) ((((float) p2) * this.getResources().getDisplayMetrics().density) + 1056964608));
        return;
    }

    public void setMargin(int p2)
    {
        this.p.t0 = p2;
        return;
    }

    public void setType(int p1)
    {
        this.n = p1;
        return;
    }
}
