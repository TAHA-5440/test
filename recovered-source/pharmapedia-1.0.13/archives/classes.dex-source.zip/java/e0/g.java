// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package e0;
public abstract class g extends android.app.Activity implements androidx.lifecycle.v, q0.i {
    private final t.l extraDataMap;
    private final androidx.lifecycle.z lifecycleRegistry;

    public g()
    {
        this.extraDataMap = new t.l(0);
        this.lifecycleRegistry = new androidx.lifecycle.z(this);
        return;
    }

    public boolean dispatchKeyEvent(android.view.KeyEvent p3)
    {
        p3.getClass();
        android.view.View v0_1 = this.getWindow().getDecorView();
        v0_1.getClass();
        if (!com.bumptech.glide.h.f(v0_1, p3)) {
            return com.bumptech.glide.h.g(this, v0_1, this, p3);
        } else {
            return 1;
        }
    }

    public boolean dispatchKeyShortcutEvent(android.view.KeyEvent p2)
    {
        p2.getClass();
        boolean v0_1 = this.getWindow().getDecorView();
        v0_1.getClass();
        if (!com.bumptech.glide.h.f(v0_1, p2)) {
            return super.dispatchKeyShortcutEvent(p2);
        } else {
            return 1;
        }
    }

    public e0.f getExtraData(Class p2)
    {
        p2.getClass();
        if (this.extraDataMap.get(p2) != null) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.o();
            return 0;
        } else {
            return 0;
        }
    }

    public void onCreate(android.os.Bundle p1)
    {
        super.onCreate(p1);
        androidx.lifecycle.p0.b(this);
        return;
    }

    public void onSaveInstanceState(android.os.Bundle p4)
    {
        p4.getClass();
        androidx.lifecycle.z v0 = this.lifecycleRegistry;
        Class vtmp2 = v0.getClass();
        v0.d("setCurrentState");
        v0.f(androidx.lifecycle.Lifecycle$State.i);
        super.onSaveInstanceState(p4);
        return;
    }

    public void putExtraData(e0.f p1)
    {
        throw 0;
    }

    public final boolean shouldDumpInternalState(String[] p4)
    {
        int v1 = 0;
        if ((p4 != 0) && (p4.length != 0)) {
            int v4_11 = p4[0];
            switch (v4_11.hashCode()) {
                case -645125871:
                    if ((v4_11.equals("--translation")) && (android.os.Build$VERSION.SDK_INT >= 31)) {
                    }
                    break;
                case 100470631:
                    if (v4_11.equals("--dump-dumpable")) {
                        if (android.os.Build$VERSION.SDK_INT >= 33) {
                        }
                    }
                    break;
                case 472614934:
                    if (v4_11.equals("--list-dumpables")) {
                    }
                    break;
                case 1159329357:
                    if ((v4_11.equals("--contentcapture")) && (android.os.Build$VERSION.SDK_INT >= 29)) {
                    }
                    break;
                case 1455016274:
                    if ((v4_11.equals("--autofill")) && (android.os.Build$VERSION.SDK_INT >= 26)) {
                    }
                    break;
                default:
            }
            v1 = 1;
        }
        return (v1 ^ 1);
    }

    public boolean superDispatchKeyEvent(android.view.KeyEvent p1)
    {
        p1.getClass();
        return super.dispatchKeyEvent(p1);
    }
}
