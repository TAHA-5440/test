// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package e0;
public interface e0 {

    public abstract void addOnPictureInPictureModeChangedListener(p0.a p0);

    public abstract void removeOnPictureInPictureModeChangedListener(p0.a p0);
}
