// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package e0;
public interface d0 {

    public abstract void addOnMultiWindowModeChangedListener(p0.a p0);

    public abstract void removeOnMultiWindowModeChangedListener(p0.a p0);
}
