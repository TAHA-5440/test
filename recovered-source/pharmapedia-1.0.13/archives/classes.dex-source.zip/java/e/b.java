// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package e;
public interface b {

    public abstract void a(androidx.activity.p p0);
}
