// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
public final class c {
    public static final androidx.concurrent.futures.c b;
    public final Throwable a;

    static c()
    {
        androidx.concurrent.futures.c.b = new androidx.concurrent.futures.c(new androidx.concurrent.futures.AbstractResolvableFuture$Failure$1("Failure occurred while trying to finish a future."));
        return;
    }

    public c(Throwable p1)
    {
        this.a = ((Throwable) androidx.concurrent.futures.i.checkNotNull(p1));
        return;
    }
}
