// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
public final class f implements java.lang.Runnable {
    public final androidx.concurrent.futures.i g;
    public final com.google.common.util.concurrent.ListenableFuture h;

    public f(androidx.concurrent.futures.i p1, com.google.common.util.concurrent.ListenableFuture p2)
    {
        this.g = p1;
        this.h = p2;
        return;
    }

    public final void run()
    {
        if ((this.g.value == this) && (androidx.concurrent.futures.i.ATOMIC_HELPER.b(this.g, this, androidx.concurrent.futures.i.getFutureValue(this.h)))) {
            androidx.concurrent.futures.i.complete(this.g);
        }
        return;
    }
}
