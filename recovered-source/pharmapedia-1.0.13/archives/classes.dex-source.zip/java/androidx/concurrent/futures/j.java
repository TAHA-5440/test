// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
public final class j {
    public Object a;
    public androidx.concurrent.futures.l b;
    public androidx.concurrent.futures.m c;
    public boolean d;

    public final void finalize()
    {
        androidx.concurrent.futures.m v0_0 = this.b;
        if (v0_0 != null) {
            androidx.concurrent.futures.m v0_3 = v0_0.h;
            if (!v0_3.isDone()) {
                String v2_2 = new StringBuilder("The completer object was garbage collected - this future would otherwise never complete. The tag was: ");
                v2_2.append(this.a);
                v0_3.setException(new androidx.concurrent.futures.CallbackToFutureAdapter$FutureGarbageCollectedException(v2_2.toString()));
            }
        }
        if (!this.d) {
            androidx.concurrent.futures.m v0_2 = this.c;
            if (v0_2 != null) {
                v0_2.set(0);
            }
        }
        return;
    }
}
