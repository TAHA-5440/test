// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
public abstract class i implements com.google.common.util.concurrent.ListenableFuture {
    static final androidx.concurrent.futures.a ATOMIC_HELPER = None;
    static final boolean GENERATE_CANCELLATION_CAUSES = False;
    private static final Object NULL = None;
    private static final long SPIN_THRESHOLD_NANOS = 1000;
    private static final java.util.logging.Logger log;
    volatile androidx.concurrent.futures.d listeners;
    volatile Object value;
    volatile androidx.concurrent.futures.h waiters;

    static i()
    {
        androidx.concurrent.futures.i.GENERATE_CANCELLATION_CAUSES = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));
        androidx.concurrent.futures.i.log = java.util.logging.Logger.getLogger(androidx.concurrent.futures.i.getName());
        try {
            String v3_1 = new androidx.concurrent.futures.e(java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(androidx.concurrent.futures.h, Thread, "a"), java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(androidx.concurrent.futures.h, androidx.concurrent.futures.h, "b"), java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(androidx.concurrent.futures.i, androidx.concurrent.futures.h, "waiters"), java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(androidx.concurrent.futures.i, androidx.concurrent.futures.d, "listeners"), java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(androidx.concurrent.futures.i, Object, "value"));
            Object v0_3 = 0;
        } catch (Object v0_3) {
            v3_1 = new androidx.concurrent.futures.g();
        }
        androidx.concurrent.futures.i.ATOMIC_HELPER = v3_1;
        if (v0_3 != null) {
            androidx.concurrent.futures.i.log.log(java.util.logging.Level.SEVERE, "SafeAtomicHelper is broken!", v0_3);
        }
        androidx.concurrent.futures.i.NULL = new Object();
        return;
    }

    public static void b(Runnable p5, java.util.concurrent.Executor p6)
    {
        try {
            p6.execute(p5);
            return;
        } catch (RuntimeException v0) {
            StringBuilder v3_1 = new StringBuilder("RuntimeException while executing runnable ");
            v3_1.append(p5);
            v3_1.append(" with executor ");
            v3_1.append(p6);
            androidx.concurrent.futures.i.log.log(java.util.logging.Level.SEVERE, v3_1.toString(), v0);
            return;
        }
    }

    public static Object c(Object p2)
    {
        if ((p2 instanceof androidx.concurrent.futures.b)) {
            int v2_4 = ((androidx.concurrent.futures.b) p2).b;
            java.util.concurrent.ExecutionException v0_5 = new java.util.concurrent.CancellationException("Task was cancelled.");
            v0_5.initCause(v2_4);
            throw v0_5;
        } else {
            if ((p2 instanceof androidx.concurrent.futures.c)) {
                throw new java.util.concurrent.ExecutionException(((androidx.concurrent.futures.c) p2).a);
            } else {
                if (p2 == androidx.concurrent.futures.i.NULL) {
                    p2 = 0;
                }
                return p2;
            }
        }
    }

    public static Object checkNotNull(Object p0)
    {
        p0.getClass();
        return p0;
    }

    public static void complete(androidx.concurrent.futures.i p5)
    {
        androidx.concurrent.futures.d v1 = 0;
        do {
            boolean v2_1 = p5.waiters;
            if (androidx.concurrent.futures.i.ATOMIC_HELPER.c(p5, v2_1, androidx.concurrent.futures.h.c)) {
            }
            while (v2_1) {
                Object v3_7 = v2_1.a;
                if (v3_7 != null) {
                    v2_1.a = 0;
                    java.util.concurrent.locks.LockSupport.unpark(v3_7);
                }
                v2_1 = v2_1.b;
            }
            p5.afterDone();
            do {
                boolean v2_0 = p5.listeners;
            } while(!androidx.concurrent.futures.i.ATOMIC_HELPER.a(p5, v2_0, androidx.concurrent.futures.d.d));
            while(true) {
                androidx.concurrent.futures.d v5_1 = v1;
                v1 = v2_0;
                if (v1 == null) {
                    break;
                }
                v2_0 = v1.c;
                v1.c = v5_1;
            }
            while (v5_1 != null) {
                v1 = v5_1.c;
                boolean v2_2 = v5_1.a;
                if (!(v2_2 instanceof androidx.concurrent.futures.f)) {
                    androidx.concurrent.futures.i.b(v2_2, v5_1.b);
                } else {
                    boolean v2_3 = ((androidx.concurrent.futures.f) v2_2);
                    p5 = v2_3.g;
                }
                v5_1 = v1;
            }
            return;
        } while((p5.value != v2_3) || (!androidx.concurrent.futures.i.ATOMIC_HELPER.b(p5, v2_3, androidx.concurrent.futures.i.getFutureValue(v2_3.h))));
    }

    public static Object getFutureValue(com.google.common.util.concurrent.ListenableFuture p5)
    {
        if (!(p5 instanceof androidx.concurrent.futures.i)) {
            androidx.concurrent.futures.c v0_7 = p5.isCancelled();
            if (((androidx.concurrent.futures.i.GENERATE_CANCELLATION_CAUSES ^ 1) & v0_7) == 0) {
                try {
                    java.util.concurrent.CancellationException v2_0 = androidx.concurrent.futures.i.getUninterruptibly(p5);
                } catch (androidx.concurrent.futures.b v5_5) {
                    return new androidx.concurrent.futures.c(v5_5.getCause());
                } catch (java.util.concurrent.CancellationException v2_1) {
                    if (v0_7 != null) {
                        return new androidx.concurrent.futures.b(0, v2_1);
                    } else {
                        StringBuilder v3_1 = new StringBuilder("get() threw CancellationException, despite reporting isCancelled() == false: ");
                        v3_1.append(p5);
                        return new androidx.concurrent.futures.c(new IllegalArgumentException(v3_1.toString(), v2_1));
                    }
                } catch (androidx.concurrent.futures.b v5_1) {
                    return new androidx.concurrent.futures.c(v5_1);
                }
                if (v2_0 != null) {
                    return v2_0;
                } else {
                    return androidx.concurrent.futures.i.NULL;
                }
            } else {
                return androidx.concurrent.futures.b.d;
            }
        } else {
            androidx.concurrent.futures.b v5_10 = ((androidx.concurrent.futures.i) p5).value;
            if ((v5_10 instanceof androidx.concurrent.futures.b)) {
                androidx.concurrent.futures.c v0_10 = ((androidx.concurrent.futures.b) v5_10);
                if (v0_10.a) {
                    if (v0_10.b == null) {
                        v5_10 = androidx.concurrent.futures.b.d;
                    } else {
                        return new androidx.concurrent.futures.b(0, v0_10.b);
                    }
                }
            }
            return v5_10;
        }
    }

    public static Object getUninterruptibly(java.util.concurrent.Future p1)
    {
        Thread v0_0 = 0;
        try {
            while(true) {
                p1 = p1.get();
                v0_0 = 1;
            }
        } catch (InterruptedException) {
        } catch (Throwable v1_1) {
            if (v0_0 != null) {
                Thread.currentThread().interrupt();
            }
            throw v1_1;
        }
        if (v0_0 != null) {
            Thread.currentThread().interrupt();
        }
        return p1;
    }

    public final void a(StringBuilder p4)
    {
        try {
            String v1_4;
            String v1_2 = androidx.concurrent.futures.i.getUninterruptibly(this);
            p4.append("SUCCESS, result=[");
        } catch (String v1_1) {
            p4.append("FAILURE, cause=[");
            p4.append(v1_1.getCause());
            p4.append("]");
            return;
        } catch (java.util.concurrent.ExecutionException) {
            p4.append("CANCELLED");
            return;
        } catch (String v0_4) {
            p4.append("UNKNOWN, cause=[");
            p4.append(v0_4.getClass());
            p4.append(" thrown from get()]");
            return;
        }
        if (v1_2 != this) {
            v1_4 = String.valueOf(v1_2);
        } else {
            v1_4 = "this future";
        }
        p4.append(v1_4);
        p4.append("]");
        return;
    }

    public final void addListener(Runnable p5, java.util.concurrent.Executor p6)
    {
        androidx.concurrent.futures.i.checkNotNull(p5);
        androidx.concurrent.futures.i.checkNotNull(p6);
        androidx.concurrent.futures.d v0_1 = this.listeners;
        androidx.concurrent.futures.d v1 = androidx.concurrent.futures.d.d;
        if (v0_1 != v1) {
            androidx.concurrent.futures.d v2_1 = new androidx.concurrent.futures.d(p5, p6);
            do {
                v2_1.c = v0_1;
                if (!androidx.concurrent.futures.i.ATOMIC_HELPER.a(this, v0_1, v2_1)) {
                    v0_1 = this.listeners;
                } else {
                    return;
                }
            } while(v0_1 != v1);
        }
        androidx.concurrent.futures.i.b(p5, p6);
        return;
    }

    public void afterDone()
    {
        return;
    }

    public final boolean cancel(boolean p8)
    {
        androidx.concurrent.futures.b v3_3;
        Object v0_0 = this.value;
        if (v0_0 != null) {
            v3_3 = 0;
        } else {
            v3_3 = 1;
        }
        if ((v3_3 | (v0_0 instanceof androidx.concurrent.futures.f)) == 0) {
            return 0;
        } else {
            androidx.concurrent.futures.b v3_1;
            if (!androidx.concurrent.futures.i.GENERATE_CANCELLATION_CAUSES) {
                if (!p8) {
                    v3_1 = androidx.concurrent.futures.b.d;
                } else {
                    v3_1 = androidx.concurrent.futures.b.c;
                }
            } else {
                v3_1 = new androidx.concurrent.futures.b(p8, new java.util.concurrent.CancellationException("Future.cancel() was called."));
            }
            androidx.concurrent.futures.i v4_2 = this;
            int v5_1 = 0;
            do {
                if (!androidx.concurrent.futures.i.ATOMIC_HELPER.b(v4_2, v0_0, v3_1)) {
                    v0_0 = v4_2.value;
                } else {
                    if (p8) {
                        v4_2.interruptTask();
                    }
                    androidx.concurrent.futures.i.complete(v4_2);
                    if ((v0_0 instanceof androidx.concurrent.futures.f)) {
                        Object v0_2 = ((androidx.concurrent.futures.f) v0_0).h;
                        if (!(v0_2 instanceof androidx.concurrent.futures.i)) {
                            v0_2.cancel(p8);
                        } else {
                            int v5_2;
                            v4_2 = ((androidx.concurrent.futures.i) v0_2);
                            v0_0 = v4_2.value;
                            if (v0_0 != null) {
                                v5_2 = 0;
                            } else {
                                v5_2 = 1;
                            }
                            if ((v5_2 | (v0_0 instanceof androidx.concurrent.futures.f)) != 0) {
                                v5_1 = 1;
                            }
                        }
                    }
                    return 1;
                }
            } while((v0_0 instanceof androidx.concurrent.futures.f));
            return v5_1;
        }
    }

    public final void d(androidx.concurrent.futures.h p5)
    {
        p5.a = 0;
        do {
            boolean v5_3 = this.waiters;
            if (v5_3 != androidx.concurrent.futures.h.c) {
                androidx.concurrent.futures.h v1_0 = 0;
                while (v5_3) {
                    androidx.concurrent.futures.h v2 = v5_3.b;
                    if (v5_3.a == null) {
                        if (v1_0 == null) {
                        } else {
                            v1_0.b = v2;
                            if (v1_0.a == null) {
                            }
                        }
                    } else {
                        v1_0 = v5_3;
                    }
                    v5_3 = v2;
                }
            }
            return;
        } while(androidx.concurrent.futures.i.ATOMIC_HELPER.c(this, v5_3, v2));
    }

    public final Object get()
    {
        Object v0_0 = androidx.concurrent.futures.h.c;
        if (Thread.interrupted()) {
            throw new InterruptedException();
        } else {
            androidx.concurrent.futures.h v4_0;
            int v1_5 = this.value;
            if (v1_5 == 0) {
                v4_0 = 0;
            } else {
                v4_0 = 1;
            }
            if ((v4_0 & ((v1_5 instanceof androidx.concurrent.futures.f) ^ 1)) == 0) {
                int v1_0 = this.waiters;
                if (v1_0 != v0_0) {
                    androidx.concurrent.futures.h v4_3 = new androidx.concurrent.futures.h();
                    do {
                        int v5_2 = androidx.concurrent.futures.i.ATOMIC_HELPER;
                        v5_2.d(v4_3, v1_0);
                        if (!v5_2.c(this, v1_0, v4_3)) {
                            v1_0 = this.waiters;
                        }
                        do {
                            java.util.concurrent.locks.LockSupport.park(this);
                            if (Thread.interrupted()) {
                                this.d(v4_3);
                                throw new InterruptedException();
                            } else {
                                int v1_3;
                                Object v0_7 = this.value;
                                if (v0_7 == null) {
                                    v1_3 = 0;
                                } else {
                                    v1_3 = 1;
                                }
                            }
                        } while((v1_3 & ((v0_7 instanceof androidx.concurrent.futures.f) ^ 1)) == 0);
                        return androidx.concurrent.futures.i.c(v0_7);
                    } while(v1_0 != v0_0);
                }
                return androidx.concurrent.futures.i.c(this.value);
            } else {
                return androidx.concurrent.futures.i.c(v1_5);
            }
        }
    }

    public final Object get(long p19, java.util.concurrent.TimeUnit p21)
    {
        long v4_3 = androidx.concurrent.futures.h.c;
        long v5_3 = p21.toNanos(p19);
        if (Thread.interrupted()) {
            throw new InterruptedException();
        } else {
            long v10_1;
            androidx.concurrent.futures.h v7_0 = this.value;
            if (v7_0 == null) {
                v10_1 = 0;
            } else {
                v10_1 = 1;
            }
            if ((v10_1 & ((v7_0 instanceof androidx.concurrent.futures.f) ^ 1)) == 0) {
                long v12_1;
                if (v5_3 <= 0) {
                    v12_1 = 0;
                } else {
                    v12_1 = (System.nanoTime() + v5_3);
                }
                int v17;
                if (v5_3 < 1000) {
                    v17 = 1;
                } else {
                    androidx.concurrent.futures.h v7_3 = this.waiters;
                    if (v7_3 != v4_3) {
                        long v8_2 = new androidx.concurrent.futures.h();
                        v17 = 1;
                        do {
                            StringBuilder v9_1 = androidx.concurrent.futures.i.ATOMIC_HELPER;
                            v9_1.d(v8_2, v7_3);
                            if (!v9_1.c(this, v7_3, v8_2)) {
                                v7_3 = this.waiters;
                            }
                            do {
                                java.util.concurrent.locks.LockSupport.parkNanos(this, v5_3);
                                if (Thread.interrupted()) {
                                    this.d(v8_2);
                                    throw new InterruptedException();
                                } else {
                                    long v5_4;
                                    long v4_5 = this.value;
                                    if (v4_5 == 0) {
                                        v5_4 = 0;
                                    } else {
                                        v5_4 = 1;
                                    }
                                    if ((v5_4 & ((v4_5 instanceof androidx.concurrent.futures.f) ^ 1)) == 0) {
                                        v5_3 = (v12_1 - System.nanoTime());
                                    } else {
                                        return androidx.concurrent.futures.i.c(v4_5);
                                    }
                                }
                                while (v5_3 > 0) {
                                    long v5_1;
                                    long v4_0 = this.value;
                                    if (v4_0 == 0) {
                                        v5_1 = 0;
                                    } else {
                                        v5_1 = v17;
                                    }
                                    if ((v5_1 & ((v4_0 instanceof androidx.concurrent.futures.f) ^ 1)) == 0) {
                                        if (Thread.interrupted()) {
                                            throw new InterruptedException();
                                        } else {
                                            v5_3 = (v12_1 - System.nanoTime());
                                        }
                                    } else {
                                        return androidx.concurrent.futures.i.c(v4_0);
                                    }
                                }
                                long v4_9 = this.toString();
                                long v8_3 = java.util.Locale.ROOT;
                                androidx.concurrent.futures.h v7_7 = p21.toString().toLowerCase(v8_3);
                                StringBuilder v9_3 = new StringBuilder("Waited ");
                                v9_3.append(p19);
                                v9_3.append(" ");
                                v9_3.append(p21.toString().toLowerCase(v8_3));
                                String v2_3 = v9_3.toString();
                                if ((v5_3 + 1000) < 0) {
                                    int v16;
                                    String v2_1 = v2_3.concat(" (plus ");
                                    long v5_6 = (- v5_3);
                                    long v8_0 = p21.convert(v5_6, java.util.concurrent.TimeUnit.NANOSECONDS);
                                    long v5_0 = (v5_6 - p21.toNanos(v8_0));
                                    String v3_0 = v8_0 cmp 0;
                                    if ((v3_0 != null) && (v5_0 <= 1000)) {
                                        v16 = 0;
                                    } else {
                                        v16 = v17;
                                    }
                                    if (v3_0 > null) {
                                        String v3_2 = new StringBuilder();
                                        v3_2.append(v2_1);
                                        v3_2.append(v8_0);
                                        v3_2.append(" ");
                                        v3_2.append(v7_7);
                                        String v2_0 = v3_2.toString();
                                        if (v16 != 0) {
                                            v2_0 = v2_0.concat(",");
                                        }
                                        v2_1 = v2_0.concat(" ");
                                    }
                                    if (v16 != 0) {
                                        String v1_3 = new StringBuilder();
                                        v1_3.append(v2_1);
                                        v1_3.append(v5_0);
                                        v1_3.append(" nanoseconds ");
                                        v2_1 = v1_3.toString();
                                    }
                                    v2_3 = v2_1.concat("delay)");
                                }
                                if (this.isDone()) {
                                    throw new java.util.concurrent.TimeoutException(v2_3.concat(" but future completed as timeout expired"));
                                } else {
                                    androidx.fragment.app.a.f(v2_3, v4_9);
                                    return 0;
                                }
                            } while(v5_3 >= 1000);
                            this.d(v8_2);
                        } while(v7_3 != v4_3);
                    }
                    return androidx.concurrent.futures.i.c(this.value);
                }
            } else {
                return androidx.concurrent.futures.i.c(v7_0);
            }
        }
    }

    public void interruptTask()
    {
        return;
    }

    public final boolean isCancelled()
    {
        return (this.value instanceof androidx.concurrent.futures.b);
    }

    public final boolean isDone()
    {
        int v2;
        int v0_0 = this.value;
        if (v0_0 == 0) {
            v2 = 0;
        } else {
            v2 = 1;
        }
        return (((v0_0 instanceof androidx.concurrent.futures.f) ^ 1) & v2);
    }

    public final void maybePropagateCancellationTo(java.util.concurrent.Future p3)
    {
        boolean v0_0;
        if (p3 == null) {
            v0_0 = 0;
        } else {
            v0_0 = 1;
        }
        if ((v0_0 & this.isCancelled()) != 0) {
            p3.cancel(this.wasInterrupted());
        }
        return;
    }

    public String pendingToString()
    {
        String v0_0 = this.value;
        if (!(v0_0 instanceof androidx.concurrent.futures.f)) {
            if (!(this instanceof java.util.concurrent.ScheduledFuture)) {
                return 0;
            } else {
                String v0_9 = new StringBuilder("remaining delay=[");
                v0_9.append(((java.util.concurrent.ScheduledFuture) this).getDelay(java.util.concurrent.TimeUnit.MILLISECONDS));
                v0_9.append(" ms]");
                return v0_9.toString();
            }
        } else {
            String v0_4;
            String v1_6 = new StringBuilder("setFuture=[");
            String v0_3 = ((androidx.concurrent.futures.f) v0_0).h;
            if (v0_3 != this) {
                v0_4 = String.valueOf(v0_3);
            } else {
                v0_4 = "this future";
            }
            return r1.a.n(v0_4, "]", v1_6);
        }
    }

    public boolean set(Object p3)
    {
        if (p3 == 0) {
            p3 = androidx.concurrent.futures.i.NULL;
        }
        if (!androidx.concurrent.futures.i.ATOMIC_HELPER.b(this, 0, p3)) {
            return 0;
        } else {
            androidx.concurrent.futures.i.complete(this);
            return 1;
        }
    }

    public boolean setException(Throwable p3)
    {
        if (!androidx.concurrent.futures.i.ATOMIC_HELPER.b(this, 0, new androidx.concurrent.futures.c(((Throwable) androidx.concurrent.futures.i.checkNotNull(p3))))) {
            return 0;
        } else {
            androidx.concurrent.futures.i.complete(this);
            return 1;
        }
    }

    public boolean setFuture(com.google.common.util.concurrent.ListenableFuture p6)
    {
        androidx.concurrent.futures.i.checkNotNull(p6);
        Object v0_0 = this.value;
        if (v0_0 != null) {
            if ((v0_0 instanceof androidx.concurrent.futures.b)) {
                p6.cancel(((androidx.concurrent.futures.b) v0_0).a);
            }
        } else {
            if (!p6.isDone()) {
                Object v0_1 = new androidx.concurrent.futures.f(this, p6);
                if (!androidx.concurrent.futures.i.ATOMIC_HELPER.b(this, 0, v0_1)) {
                    v0_0 = this.value;
                } else {
                    try {
                        p6.addListener(v0_1, androidx.concurrent.futures.DirectExecutor.g);
                        return 1;
                    } catch (androidx.concurrent.futures.a v6_1) {
                        try {
                            androidx.concurrent.futures.c v1_3 = new androidx.concurrent.futures.c(v6_1);
                        } catch (Throwable) {
                            v1_3 = androidx.concurrent.futures.c.b;
                        }
                        androidx.concurrent.futures.i.ATOMIC_HELPER.b(this, v0_1, v1_3);
                        return 1;
                    }
                }
            } else {
                if (androidx.concurrent.futures.i.ATOMIC_HELPER.b(this, 0, androidx.concurrent.futures.i.getFutureValue(p6))) {
                    androidx.concurrent.futures.i.complete(this);
                    return 1;
                }
            }
        }
        return 0;
    }

    public String toString()
    {
        String v0_1 = new StringBuilder();
        v0_1.append(super.toString());
        v0_1.append("[status=");
        if (!this.isCancelled()) {
            if (!this.isDone()) {
                try {
                    String v1_1 = this.pendingToString();
                } catch (String v1_2) {
                    String v3_1 = new StringBuilder("Exception thrown from implementation: ");
                    v3_1.append(v1_2.getClass());
                    v1_1 = v3_1.toString();
                }
                if ((v1_1 == null) || (v1_1.isEmpty())) {
                    if (!this.isDone()) {
                        v0_1.append("PENDING");
                    } else {
                        this.a(v0_1);
                    }
                } else {
                    v0_1.append("PENDING, info=[");
                    v0_1.append(v1_1);
                    v0_1.append("]");
                }
            } else {
                this.a(v0_1);
            }
        } else {
            v0_1.append("CANCELLED");
        }
        v0_1.append("]");
        return v0_1.toString();
    }

    public final boolean wasInterrupted()
    {
        int v0_0 = this.value;
        if ((!(v0_0 instanceof androidx.concurrent.futures.b)) || (!((androidx.concurrent.futures.b) v0_0).a)) {
            return 0;
        } else {
            return 1;
        }
    }
}
