// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
public final enum class DirectExecutor extends java.lang.Enum implements java.util.concurrent.Executor {
    public static final enum androidx.concurrent.futures.DirectExecutor g;
    public static final synthetic androidx.concurrent.futures.DirectExecutor[] h;

    static DirectExecutor()
    {
        androidx.concurrent.futures.DirectExecutor[] v0_1 = new androidx.concurrent.futures.DirectExecutor("INSTANCE", 0);
        androidx.concurrent.futures.DirectExecutor.g = v0_1;
        androidx.concurrent.futures.DirectExecutor.h = new androidx.concurrent.futures.DirectExecutor[] {v0_1});
        return;
    }

    public static androidx.concurrent.futures.DirectExecutor valueOf(String p1)
    {
        return ((androidx.concurrent.futures.DirectExecutor) Enum.valueOf(androidx.concurrent.futures.DirectExecutor, p1));
    }

    public static androidx.concurrent.futures.DirectExecutor[] values()
    {
        return ((androidx.concurrent.futures.DirectExecutor[]) androidx.concurrent.futures.DirectExecutor.h.clone());
    }

    public final void execute(Runnable p1)
    {
        p1.run();
        return;
    }

    public final String toString()
    {
        return "DirectExecutor";
    }
}
