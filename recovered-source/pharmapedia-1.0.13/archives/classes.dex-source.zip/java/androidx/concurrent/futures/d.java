// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
public final class d {
    public static final androidx.concurrent.futures.d d;
    public final Runnable a;
    public final java.util.concurrent.Executor b;
    public androidx.concurrent.futures.d c;

    static d()
    {
        androidx.concurrent.futures.d.d = new androidx.concurrent.futures.d(0, 0);
        return;
    }

    public d(Runnable p1, java.util.concurrent.Executor p2)
    {
        this.a = p1;
        this.b = p2;
        return;
    }
}
