// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
final class CallbackToFutureAdapter$FutureGarbageCollectedException extends java.lang.Throwable {

    public final declared_synchronized Throwable fillInStackTrace()
    {
        return this;
    }
}
