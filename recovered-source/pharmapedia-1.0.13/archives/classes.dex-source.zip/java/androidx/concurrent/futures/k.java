// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
public final class k extends androidx.concurrent.futures.i {
    public final synthetic androidx.concurrent.futures.l g;

    public k(androidx.concurrent.futures.l p1)
    {
        this.g = p1;
        return;
    }

    public final String pendingToString()
    {
        String v0_6 = ((androidx.concurrent.futures.j) this.g.g.get());
        if (v0_6 != null) {
            StringBuilder v1_1 = new StringBuilder("tag=[");
            v1_1.append(v0_6.a);
            v1_1.append("]");
            return v1_1.toString();
        } else {
            return "Completer object has been garbage collected, future will fail soon";
        }
    }
}
