// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
public final class e extends androidx.concurrent.futures.a {
    public final java.util.concurrent.atomic.AtomicReferenceFieldUpdater a;
    public final java.util.concurrent.atomic.AtomicReferenceFieldUpdater b;
    public final java.util.concurrent.atomic.AtomicReferenceFieldUpdater c;
    public final java.util.concurrent.atomic.AtomicReferenceFieldUpdater d;
    public final java.util.concurrent.atomic.AtomicReferenceFieldUpdater e;

    public e(java.util.concurrent.atomic.AtomicReferenceFieldUpdater p1, java.util.concurrent.atomic.AtomicReferenceFieldUpdater p2, java.util.concurrent.atomic.AtomicReferenceFieldUpdater p3, java.util.concurrent.atomic.AtomicReferenceFieldUpdater p4, java.util.concurrent.atomic.AtomicReferenceFieldUpdater p5)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        this.d = p4;
        this.e = p5;
        return;
    }

    public final boolean a(androidx.concurrent.futures.i p3, androidx.concurrent.futures.d p4, androidx.concurrent.futures.d p5)
    {
        do {
            Object v0_0 = this.d;
            if (!v0_0.compareAndSet(p3, p4, p5)) {
            } else {
                return 1;
            }
        } while(v0_0.get(p3) == p4);
        return 0;
    }

    public final boolean b(androidx.concurrent.futures.i p3, Object p4, Object p5)
    {
        do {
            Object v0_0 = this.e;
            if (!v0_0.compareAndSet(p3, p4, p5)) {
            } else {
                return 1;
            }
        } while(v0_0.get(p3) == p4);
        return 0;
    }

    public final boolean c(androidx.concurrent.futures.i p3, androidx.concurrent.futures.h p4, androidx.concurrent.futures.h p5)
    {
        do {
            Object v0_0 = this.c;
            if (!v0_0.compareAndSet(p3, p4, p5)) {
            } else {
                return 1;
            }
        } while(v0_0.get(p3) == p4);
        return 0;
    }

    public final void d(androidx.concurrent.futures.h p2, androidx.concurrent.futures.h p3)
    {
        this.b.lazySet(p2, p3);
        return;
    }

    public final void e(androidx.concurrent.futures.h p2, Thread p3)
    {
        this.a.lazySet(p2, p3);
        return;
    }
}
