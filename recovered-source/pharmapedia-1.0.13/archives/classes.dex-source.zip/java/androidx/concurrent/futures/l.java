// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
public final class l implements com.google.common.util.concurrent.ListenableFuture {
    public final ref.WeakReference g;
    public final androidx.concurrent.futures.k h;

    public l(androidx.concurrent.futures.j p2)
    {
        this.h = new androidx.concurrent.futures.k(this);
        this.g = new ref.WeakReference(p2);
        return;
    }

    public final void addListener(Runnable p2, java.util.concurrent.Executor p3)
    {
        this.h.addListener(p2, p3);
        return;
    }

    public final boolean cancel(boolean p3)
    {
        androidx.concurrent.futures.m v0_3 = ((androidx.concurrent.futures.j) this.g.get());
        boolean v3_1 = this.h.cancel(p3);
        if ((v3_1) && (v0_3 != null)) {
            v0_3.a = 0;
            v0_3.b = 0;
            v0_3.c.set(0);
        }
        return v3_1;
    }

    public final Object get()
    {
        return this.h.get();
    }

    public final Object get(long p2, java.util.concurrent.TimeUnit p4)
    {
        return this.h.get(p2, p4);
    }

    public final boolean isCancelled()
    {
        return this.h.isCancelled();
    }

    public final boolean isDone()
    {
        return this.h.isDone();
    }

    public final String toString()
    {
        return this.h.toString();
    }
}
