// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
public final class b {
    public static final androidx.concurrent.futures.b c;
    public static final androidx.concurrent.futures.b d;
    public final boolean a;
    public final Throwable b;

    static b()
    {
        if (!androidx.concurrent.futures.i.GENERATE_CANCELLATION_CAUSES) {
            androidx.concurrent.futures.b.d = new androidx.concurrent.futures.b(0, 0);
            androidx.concurrent.futures.b.c = new androidx.concurrent.futures.b(1, 0);
            return;
        } else {
            androidx.concurrent.futures.b.d = 0;
            androidx.concurrent.futures.b.c = 0;
            return;
        }
    }

    public b(boolean p1, Throwable p2)
    {
        this.a = p1;
        this.b = p2;
        return;
    }
}
