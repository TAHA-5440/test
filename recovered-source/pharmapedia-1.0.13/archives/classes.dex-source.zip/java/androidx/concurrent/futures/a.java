// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
public abstract class a {

    public abstract boolean a(androidx.concurrent.futures.i p0, androidx.concurrent.futures.d p1, androidx.concurrent.futures.d p2);

    public abstract boolean b(androidx.concurrent.futures.i p0, Object p1, Object p2);

    public abstract boolean c(androidx.concurrent.futures.i p0, androidx.concurrent.futures.h p1, androidx.concurrent.futures.h p2);

    public abstract void d(androidx.concurrent.futures.h p0, androidx.concurrent.futures.h p1);

    public abstract void e(androidx.concurrent.futures.h p0, Thread p1);
}
