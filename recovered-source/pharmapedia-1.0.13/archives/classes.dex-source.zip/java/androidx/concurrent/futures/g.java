// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
public final class g extends androidx.concurrent.futures.a {

    public final boolean a(androidx.concurrent.futures.i p2, androidx.concurrent.futures.d p3, androidx.concurrent.futures.d p4)
    {
        if (p2.listeners != p3) {
            return 0;
        } else {
            p2.listeners = p4;
            return 1;
        }
    }

    public final boolean b(androidx.concurrent.futures.i p2, Object p3, Object p4)
    {
        if (p2.value != p3) {
            return 0;
        } else {
            p2.value = p4;
            return 1;
        }
    }

    public final boolean c(androidx.concurrent.futures.i p2, androidx.concurrent.futures.h p3, androidx.concurrent.futures.h p4)
    {
        if (p2.waiters != p3) {
            return 0;
        } else {
            p2.waiters = p4;
            return 1;
        }
    }

    public final void d(androidx.concurrent.futures.h p1, androidx.concurrent.futures.h p2)
    {
        p1.b = p2;
        return;
    }

    public final void e(androidx.concurrent.futures.h p1, Thread p2)
    {
        p1.a = p2;
        return;
    }
}
