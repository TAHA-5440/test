// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
public final class m extends androidx.concurrent.futures.i {
}
