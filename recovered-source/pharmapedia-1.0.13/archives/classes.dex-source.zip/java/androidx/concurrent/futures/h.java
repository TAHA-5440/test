// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.concurrent.futures;
public final class h {
    public static final androidx.concurrent.futures.h c;
    public volatile Thread a;
    public volatile androidx.concurrent.futures.h b;

    static h()
    {
        androidx.concurrent.futures.h.c = new androidx.concurrent.futures.h();
        return;
    }

    public h()
    {
        androidx.concurrent.futures.i.ATOMIC_HELPER.e(this, Thread.currentThread());
        return;
    }
}
