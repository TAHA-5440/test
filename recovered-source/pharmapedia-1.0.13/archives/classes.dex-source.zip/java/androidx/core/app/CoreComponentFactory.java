// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.core.app;
public class CoreComponentFactory extends android.app.AppComponentFactory {

    public CoreComponentFactory()
    {
        return;
    }
}
