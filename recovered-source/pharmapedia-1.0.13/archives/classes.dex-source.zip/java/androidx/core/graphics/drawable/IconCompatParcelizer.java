// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.core.graphics.drawable;
public class IconCompatParcelizer {

    public IconCompatParcelizer()
    {
        return;
    }

    public static androidx.core.graphics.drawable.IconCompat read(n2.a p7)
    {
        java.nio.charset.Charset v4_8;
        androidx.core.graphics.drawable.IconCompat v0_1 = new androidx.core.graphics.drawable.IconCompat();
        v0_1.a = -1;
        String v2_4 = 0;
        v0_1.c = 0;
        v0_1.d = 0;
        v0_1.e = 0;
        v0_1.f = 0;
        v0_1.g = 0;
        v0_1.h = androidx.core.graphics.drawable.IconCompat.k;
        v0_1.i = 0;
        if (p7.e(1)) {
            v4_8 = ((n2.b) p7).e.readInt();
        } else {
            v4_8 = -1;
        }
        v0_1.a = v4_8;
        if (p7.e(2)) {
            java.nio.charset.Charset v4_12 = ((n2.b) p7).e;
            boolean v6_1 = v4_12.readInt();
            if (v6_1) {
                v2_4 = new byte[v6_1];
                v4_12.readByteArray(v2_4);
            }
        } else {
            v2_4 = v0_1.c;
        }
        v0_1.c = v2_4;
        v0_1.d = p7.f(v0_1.d, 3);
        String v2_7 = v0_1.e;
        if (p7.e(4)) {
            v2_7 = ((n2.b) p7).e.readInt();
        }
        v0_1.e = v2_7;
        String v2_11 = v0_1.f;
        if (p7.e(5)) {
            v2_11 = ((n2.b) p7).e.readInt();
        }
        v0_1.f = v2_11;
        v0_1.g = ((android.content.res.ColorStateList) p7.f(v0_1.g, 6));
        String v2_18 = v0_1.i;
        if (p7.e(7)) {
            v2_18 = ((n2.b) p7).e.readString();
        }
        v0_1.i = v2_18;
        String v2_22 = v0_1.j;
        if (p7.e(8)) {
            v2_22 = ((n2.b) p7).e.readString();
        }
        v0_1.j = v2_22;
        v0_1.h = android.graphics.PorterDuff$Mode.valueOf(v0_1.i);
        switch (v0_1.a) {
            case -1:
                String v7_9 = v0_1.d;
                if (v7_9 == null) {
                    com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("Invalid icon");
                    return 0;
                } else {
                    v0_1.b = v7_9;
                    return v0_1;
                }
            case 0:
            default:
                break;
            case 1:
            case 5:
                String v7_6 = v0_1.d;
                if (v7_6 == null) {
                    String v7_7 = v0_1.c;
                    v0_1.b = v7_7;
                    v0_1.a = 3;
                    v0_1.e = 0;
                    v0_1.f = v7_7.length;
                    return v0_1;
                } else {
                    v0_1.b = v7_6;
                    return v0_1;
                }
            case 2:
            case 4:
            case 6:
                String v7_3 = new String(v0_1.c, java.nio.charset.Charset.forName("UTF-16"));
                v0_1.b = v7_3;
                if ((v0_1.a != 2) || (v0_1.j != null)) {
                } else {
                    v0_1.j = v7_3.split(":", -1)[0];
                }
                break;
            case 3:
                v0_1.b = v0_1.c;
                return v0_1;
        }
        return v0_1;
    }

    public static void write(androidx.core.graphics.drawable.IconCompat p3, n2.a p4)
    {
        p4.getClass();
        p3.i = p3.h.name();
        switch (p3.a) {
            case -1:
                p3.d = ((android.os.Parcelable) p3.b);
                break;
            case 0:
            default:
                break;
            case 1:
            case 5:
                p3.d = ((android.os.Parcelable) p3.b);
                break;
            case 2:
                p3.c = ((String) p3.b).getBytes(java.nio.charset.Charset.forName("UTF-16"));
                break;
            case 3:
                p3.c = ((byte[]) p3.b);
                break;
            case 4:
            case 6:
                p3.c = p3.b.toString().getBytes(java.nio.charset.Charset.forName("UTF-16"));
                break;
        }
        int v0_13 = p3.a;
        if (-1 != v0_13) {
            p4.h(1);
            ((n2.b) p4).e.writeInt(v0_13);
        }
        int v0_14 = p3.c;
        if (v0_14 != 0) {
            p4.h(2);
            android.os.Parcel v1_10 = ((n2.b) p4).e;
            v1_10.writeInt(v0_14.length);
            v1_10.writeByteArray(v0_14);
        }
        int v0_16 = p3.d;
        if (v0_16 != 0) {
            p4.h(3);
            ((n2.b) p4).e.writeParcelable(v0_16, 0);
        }
        int v0_17 = p3.e;
        if (v0_17 != 0) {
            p4.h(4);
            ((n2.b) p4).e.writeInt(v0_17);
        }
        int v0_18 = p3.f;
        if (v0_18 != 0) {
            p4.h(5);
            ((n2.b) p4).e.writeInt(v0_18);
        }
        int v0_19 = p3.g;
        if (v0_19 != 0) {
            p4.h(6);
            ((n2.b) p4).e.writeParcelable(v0_19, 0);
        }
        int v0_21 = p3.i;
        if (v0_21 != 0) {
            p4.h(7);
            ((n2.b) p4).e.writeString(v0_21);
        }
        String v3_1 = p3.j;
        if (v3_1 != null) {
            p4.h(8);
            ((n2.b) p4).e.writeString(v3_1);
        }
        return;
    }
}
