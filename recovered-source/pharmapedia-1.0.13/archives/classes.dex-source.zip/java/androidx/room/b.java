// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.room;
public interface b {

    public abstract f2.e d();
}
