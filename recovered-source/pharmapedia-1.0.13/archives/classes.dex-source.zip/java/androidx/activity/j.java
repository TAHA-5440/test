// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class j implements androidx.lifecycle.t {
    public final synthetic int g;
    public final synthetic androidx.activity.p h;

    public synthetic j(androidx.activity.p p1, int p2)
    {
        this.g = p2;
        this.h = p1;
        return;
    }

    public final void d(androidx.lifecycle.v p2, androidx.lifecycle.Lifecycle$Event p3)
    {
        switch (this.g) {
            case 0:
                if (p3 == androidx.lifecycle.Lifecycle$Event.ON_DESTROY) {
                    this.h.mContextAwareHelper.b = 0;
                    if (!this.h.isChangingConfigurations()) {
                        this.h.getViewModelStore().a();
                    }
                    int v2_14 = ((androidx.activity.o) this.h.mReportFullyDrawnExecutor);
                    android.view.ViewTreeObserver v3_2 = v2_14.j;
                    v3_2.getWindow().getDecorView().removeCallbacks(v2_14);
                    v3_2.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(v2_14);
                }
                return;
            case 1:
                if (p3 == androidx.lifecycle.Lifecycle$Event.ON_STOP) {
                    int v2_3;
                    int v2_2 = this.h.getWindow();
                    if (v2_2 == 0) {
                        v2_3 = 0;
                    } else {
                        v2_3 = v2_2.peekDecorView();
                    }
                    if (v2_3 != 0) {
                        v2_3.cancelPendingInputEvents();
                    }
                }
                return;
            case 2:
                int v2_4 = this.h;
                v2_4.ensureViewModelStore();
                v2_4.getLifecycle().b(this);
                return;
            default:
                if (p3 != androidx.lifecycle.Lifecycle$Event.ON_CREATE) {
                    return;
                } else {
                    if (android.os.Build$VERSION.SDK_INT < 33) {
                        return;
                    } else {
                        android.view.ViewTreeObserver v3_8 = androidx.activity.p.access$100(this.h);
                        int v2_17 = androidx.activity.l.a(((androidx.activity.p) p2));
                        v3_8.getClass();
                        v2_17.getClass();
                        v3_8.e = v2_17;
                        v3_8.c(v3_8.g);
                        return;
                    }
                }
        }
    }
}
