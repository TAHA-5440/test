// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class i0 {
    public final int a;
    public final int b;
    public final int c;
    public final ua.l d;

    public i0(int p1, int p2, int p3, ua.l p4)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        this.d = p4;
        return;
    }
}
