// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class w implements androidx.activity.x {

    public void a(androidx.activity.i0 p3, androidx.activity.i0 p4, android.view.Window p5, android.view.View p6, boolean p7, boolean p8)
    {
        int v3_1;
        p3.getClass();
        p4.getClass();
        int v0 = p4.c;
        p5.getClass();
        p6.getClass();
        int v6_1 = 0;
        com.bumptech.glide.j.T(p5, 0);
        if (p3.c != 0) {
            if (!p7) {
                v3_1 = p3.a;
            } else {
                v3_1 = p3.b;
            }
        } else {
            v3_1 = 0;
        }
        int v3_2;
        p5.setStatusBarColor(v3_1);
        if (v0 != 0) {
            if (!p8) {
                v3_2 = p4.a;
            } else {
                v3_2 = p4.b;
            }
        } else {
            v3_2 = 0;
        }
        p5.setNavigationBarColor(v3_2);
        androidx.activity.v.m(p5);
        if (v0 == 0) {
            v6_1 = 1;
        }
        q0.p1 v4_3;
        androidx.activity.v.n(p5, v6_1);
        q0.p1 v4_1 = android.os.Build$VERSION.SDK_INT;
        if (v4_1 < 35) {
            if (v4_1 < 30) {
                if (v4_1 < 26) {
                    v4_3 = new q0.p1(p5);
                } else {
                    v4_3 = new q0.q1(p5);
                }
            } else {
                v4_3 = new q0.r1(p5);
            }
        } else {
            v4_3 = new q0.s1(p5);
        }
        v4_3.r((p7 ^ 1));
        v4_3.q((1 ^ p8));
        return;
    }
}
