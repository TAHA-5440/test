// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public abstract class p extends e0.g implements androidx.lifecycle.j1, androidx.lifecycle.l, c2.g, androidx.activity.g0, f.i, f0.d, f0.e, e0.d0, e0.e0, q0.j {
    private static final String ACTIVITY_RESULT_TAG = "android:support:activity-result";
    private final f.h mActivityResultRegistry;
    private int mContentLayoutId;
    final e.a mContextAwareHelper;
    private androidx.lifecycle.f1 mDefaultFactory;
    private boolean mDispatchingOnMultiWindowModeChanged;
    private boolean mDispatchingOnPictureInPictureModeChanged;
    final androidx.activity.y mFullyDrawnReporter;
    private final androidx.lifecycle.z mLifecycleRegistry;
    private final q0.n mMenuHostHelper;
    private final java.util.concurrent.atomic.AtomicInteger mNextLocalRequestCode;
    private androidx.activity.f0 mOnBackPressedDispatcher;
    private final java.util.concurrent.CopyOnWriteArrayList mOnConfigurationChangedListeners;
    private final java.util.concurrent.CopyOnWriteArrayList mOnMultiWindowModeChangedListeners;
    private final java.util.concurrent.CopyOnWriteArrayList mOnNewIntentListeners;
    private final java.util.concurrent.CopyOnWriteArrayList mOnPictureInPictureModeChangedListeners;
    private final java.util.concurrent.CopyOnWriteArrayList mOnTrimMemoryListeners;
    final androidx.activity.n mReportFullyDrawnExecutor;
    final c2.f mSavedStateRegistryController;
    private androidx.lifecycle.i1 mViewModelStore;

    public p()
    {
        this.mContextAwareHelper = new e.a();
        this.mMenuHostHelper = new q0.n(new androidx.activity.d(this, 0));
        this.mLifecycleRegistry = new androidx.lifecycle.z(this);
        int v0_4 = new d2.b(this, new androidx.activity.e(this, 2));
        this.mSavedStateRegistryController = new c2.f(v0_4);
        this.mOnBackPressedDispatcher = 0;
        androidx.activity.f v1_6 = new androidx.activity.o(this);
        this.mReportFullyDrawnExecutor = v1_6;
        this.mFullyDrawnReporter = new androidx.activity.y(v1_6, new androidx.activity.e(this, 0));
        this.mNextLocalRequestCode = new java.util.concurrent.atomic.AtomicInteger();
        this.mActivityResultRegistry = new androidx.activity.i(this);
        this.mOnConfigurationChangedListeners = new java.util.concurrent.CopyOnWriteArrayList();
        this.mOnTrimMemoryListeners = new java.util.concurrent.CopyOnWriteArrayList();
        this.mOnNewIntentListeners = new java.util.concurrent.CopyOnWriteArrayList();
        this.mOnMultiWindowModeChangedListeners = new java.util.concurrent.CopyOnWriteArrayList();
        this.mOnPictureInPictureModeChangedListeners = new java.util.concurrent.CopyOnWriteArrayList();
        this.mDispatchingOnMultiWindowModeChanged = 0;
        this.mDispatchingOnPictureInPictureModeChanged = 0;
        if (this.getLifecycle() == null) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.w("getLifecycle() returned null in ComponentActivity\'s constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
            throw 0;
        } else {
            this.getLifecycle().a(new androidx.activity.j(this, 1));
            this.getLifecycle().a(new androidx.activity.j(this, 0));
            this.getLifecycle().a(new androidx.activity.j(this, 2));
            v0_4.a();
            androidx.lifecycle.w.d(this);
            this.getSavedStateRegistry().c("android:support:activity-result", new androidx.activity.f(this, 0));
            this.addOnContextAvailableListener(new androidx.activity.g(this));
            return;
        }
    }

    public static synthetic void access$001(androidx.activity.p p0)
    {
        super.onBackPressed();
        return;
    }

    public static synthetic androidx.activity.f0 access$100(androidx.activity.p p0)
    {
        return p0.mOnBackPressedDispatcher;
    }

    public static void b(androidx.activity.p p9)
    {
        int v0_3 = p9.getSavedStateRegistry().a("android:support:activity-result");
        if (v0_3 != 0) {
            f.h v9_1 = p9.mActivityResultRegistry;
            java.util.HashMap v1_1 = v9_1.b;
            java.util.HashMap v2 = v9_1.a;
            android.os.Bundle v3 = v9_1.g;
            java.util.ArrayList v4_1 = v0_3.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
            java.util.ArrayList v5_1 = v0_3.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
            if ((v5_1 != null) && (v4_1 != null)) {
                v9_1.d = v0_3.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                v3.putAll(v0_3.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
                int v0_2 = 0;
                while (v0_2 < v5_1.size()) {
                    Integer v6_5 = ((String) v5_1.get(v0_2));
                    if ((v1_1.containsKey(v6_5)) && (!v3.containsKey(v6_5))) {
                        v2.remove(((Integer) v1_1.remove(v6_5)));
                    }
                    Integer v6_8 = ((Integer) v4_1.get(v0_2));
                    v6_8.intValue();
                    String v7_4 = ((String) v5_1.get(v0_2));
                    v2.put(v6_8, v7_4);
                    v9_1.b.put(v7_4, v6_8);
                    v0_2++;
                }
            }
        }
        return;
    }

    public static android.os.Bundle c(androidx.activity.p p4)
    {
        android.os.Bundle v0_1 = new android.os.Bundle();
        android.os.Bundle v4_1 = p4.mActivityResultRegistry;
        v4_1.getClass();
        String v2_4 = v4_1.b;
        v0_1.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new java.util.ArrayList(v2_4.values()));
        v0_1.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new java.util.ArrayList(v2_4.keySet()));
        v0_1.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new java.util.ArrayList(v4_1.d));
        v0_1.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", ((android.os.Bundle) v4_1.g.clone()));
        return v0_1;
    }

    public void addContentView(android.view.View p3, android.view.ViewGroup$LayoutParams p4)
    {
        this.initializeViewTreeOwners();
        ((androidx.activity.o) this.mReportFullyDrawnExecutor).a(this.getWindow().getDecorView());
        super.addContentView(p3, p4);
        return;
    }

    public void addMenuProvider(q0.o p3)
    {
        q0.n v0 = this.mMenuHostHelper;
        v0.b.add(p3);
        v0.a.run();
        return;
    }

    public void addMenuProvider(q0.o p6, androidx.lifecycle.v p7)
    {
        q0.m v0_0 = this.mMenuHostHelper;
        v0_0.b.add(p6);
        v0_0.a.run();
        androidx.lifecycle.p v7_1 = p7.getLifecycle();
        java.util.HashMap v1_2 = v0_0.c;
        q0.l v2_0 = ((q0.m) v1_2.remove(p6));
        if (v2_0 != null) {
            v2_0.a.b(v2_0.b);
            v2_0.b = 0;
        }
        v1_2.put(p6, new q0.m(v7_1, new q0.l(v0_0, p6)));
        return;
    }

    public void addMenuProvider(q0.o p6, androidx.lifecycle.v p7, androidx.lifecycle.Lifecycle$State p8)
    {
        q0.n v0 = this.mMenuHostHelper;
        v0.getClass();
        androidx.lifecycle.p v7_1 = p7.getLifecycle();
        java.util.HashMap v1 = v0.c;
        q0.k v2_3 = ((q0.m) v1.remove(p6));
        if (v2_3 != null) {
            v2_3.a.b(v2_3.b);
            v2_3.b = 0;
        }
        v1.put(p6, new q0.m(v7_1, new q0.k(v0, p8, p6)));
        return;
    }

    public final void addOnConfigurationChangedListener(p0.a p2)
    {
        this.mOnConfigurationChangedListeners.add(p2);
        return;
    }

    public final void addOnContextAvailableListener(e.b p3)
    {
        java.util.concurrent.CopyOnWriteArraySet v0_0 = this.mContextAwareHelper;
        v0_0.getClass();
        p3.getClass();
        androidx.activity.p v1 = v0_0.b;
        if (v1 != null) {
            p3.a(v1);
        }
        v0_0.a.add(p3);
        return;
    }

    public final void addOnMultiWindowModeChangedListener(p0.a p2)
    {
        this.mOnMultiWindowModeChangedListeners.add(p2);
        return;
    }

    public final void addOnNewIntentListener(p0.a p2)
    {
        this.mOnNewIntentListeners.add(p2);
        return;
    }

    public final void addOnPictureInPictureModeChangedListener(p0.a p2)
    {
        this.mOnPictureInPictureModeChangedListeners.add(p2);
        return;
    }

    public final void addOnTrimMemoryListener(p0.a p2)
    {
        this.mOnTrimMemoryListeners.add(p2);
        return;
    }

    public void ensureViewModelStore()
    {
        if (this.mViewModelStore == null) {
            androidx.lifecycle.i1 v0_4 = ((androidx.activity.m) this.getLastNonConfigurationInstance());
            if (v0_4 != null) {
                this.mViewModelStore = v0_4.b;
            }
            if (this.mViewModelStore == null) {
                this.mViewModelStore = new androidx.lifecycle.i1();
            }
        }
        return;
    }

    public final f.h getActivityResultRegistry()
    {
        return this.mActivityResultRegistry;
    }

    public n1.b getDefaultViewModelCreationExtras()
    {
        n1.c v0_1 = new n1.c();
        java.util.LinkedHashMap v2 = v0_1.a;
        if (this.getApplication() != null) {
            v2.put(androidx.lifecycle.e1.d, this.getApplication());
        }
        v2.put(androidx.lifecycle.w.a, this);
        v2.put(androidx.lifecycle.w.b, this);
        if ((this.getIntent() != null) && (this.getIntent().getExtras() != null)) {
            v2.put(androidx.lifecycle.w.c, this.getIntent().getExtras());
        }
        return v0_1;
    }

    public androidx.lifecycle.f1 getDefaultViewModelProviderFactory()
    {
        if (this.mDefaultFactory == null) {
            int v2_1;
            android.app.Application v1 = this.getApplication();
            if (this.getIntent() == null) {
                v2_1 = 0;
            } else {
                v2_1 = this.getIntent().getExtras();
            }
            this.mDefaultFactory = new androidx.lifecycle.x0(v1, this, v2_1);
        }
        return this.mDefaultFactory;
    }

    public androidx.activity.y getFullyDrawnReporter()
    {
        return this.mFullyDrawnReporter;
    }

    public Object getLastCustomNonConfigurationInstance()
    {
        int v0_1 = ((androidx.activity.m) this.getLastNonConfigurationInstance());
        if (v0_1 == 0) {
            return 0;
        } else {
            return v0_1.a;
        }
    }

    public androidx.lifecycle.p getLifecycle()
    {
        return this.mLifecycleRegistry;
    }

    public final androidx.activity.f0 getOnBackPressedDispatcher()
    {
        if (this.mOnBackPressedDispatcher == null) {
            this.mOnBackPressedDispatcher = new androidx.activity.f0(new androidx.activity.k(this));
            this.getLifecycle().a(new androidx.activity.j(this, 3));
        }
        return this.mOnBackPressedDispatcher;
    }

    public final c2.e getSavedStateRegistry()
    {
        return this.mSavedStateRegistryController.b;
    }

    public androidx.lifecycle.i1 getViewModelStore()
    {
        if (this.getApplication() == null) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.w("Your activity is not yet attached to the Application instance. You can\'t request ViewModel before onCreate call.");
            return 0;
        } else {
            this.ensureViewModelStore();
            return this.mViewModelStore;
        }
    }

    public void initializeViewTreeOwners()
    {
        android.view.View v0_7 = this.getWindow().getDecorView();
        v0_7.getClass();
        v0_7.setTag(2131362466, this);
        android.view.View v0_1 = this.getWindow().getDecorView();
        v0_1.getClass();
        v0_1.setTag(2131362469, this);
        android.view.View v0_3 = this.getWindow().getDecorView();
        v0_3.getClass();
        v0_3.setTag(2131362468, this);
        android.view.View v0_5 = this.getWindow().getDecorView();
        v0_5.getClass();
        v0_5.setTag(2131362467, this);
        android.view.View v0_8 = this.getWindow().getDecorView();
        v0_8.getClass();
        v0_8.setTag(2131362297, this);
        return;
    }

    public void invalidateMenu()
    {
        this.invalidateOptionsMenu();
        return;
    }

    public void onActivityResult(int p2, int p3, android.content.Intent p4)
    {
        if (!this.mActivityResultRegistry.a(p2, p3, p4)) {
            super.onActivityResult(p2, p3, p4);
        }
        return;
    }

    public void onBackPressed()
    {
        this.getOnBackPressedDispatcher().b();
        return;
    }

    public void onConfigurationChanged(android.content.res.Configuration p3)
    {
        super.onConfigurationChanged(p3);
        java.util.Iterator v0_1 = this.mOnConfigurationChangedListeners.iterator();
        while (v0_1.hasNext()) {
            ((p0.a) v0_1.next()).accept(p3);
        }
        return;
    }

    public void onCreate(android.os.Bundle p3)
    {
        this.mSavedStateRegistryController.a(p3);
        java.util.Iterator v0_1 = this.mContextAwareHelper;
        v0_1.getClass();
        v0_1.b = this;
        java.util.Iterator v0_3 = v0_1.a.iterator();
        while (v0_3.hasNext()) {
            ((e.b) v0_3.next()).a(this);
        }
        super.onCreate(p3);
        androidx.lifecycle.p0.b(this);
        int v3_1 = this.mContentLayoutId;
        if (v3_1 != 0) {
            this.setContentView(v3_1);
        }
        return;
    }

    public boolean onCreatePanelMenu(int p3, android.view.Menu p4)
    {
        if (p3 == 0) {
            super.onCreatePanelMenu(p3, p4);
            int v3_2 = this.mMenuHostHelper;
            android.view.MenuInflater v0 = this.getMenuInflater();
            int v3_4 = v3_2.b.iterator();
            while (v3_4.hasNext()) {
                ((androidx.fragment.app.z0) ((q0.o) v3_4.next())).a.j(p4, v0);
            }
        }
        return 1;
    }

    public boolean onMenuItemSelected(int p2, android.view.MenuItem p3)
    {
        if (!super.onMenuItemSelected(p2, p3)) {
            if (p2 != 0) {
                return 0;
            } else {
                return this.mMenuHostHelper.a(p3);
            }
        } else {
            return 1;
        }
    }

    public void onMultiWindowModeChanged(boolean p4)
    {
        if (!this.mDispatchingOnMultiWindowModeChanged) {
            java.util.Iterator v0_2 = this.mOnMultiWindowModeChangedListeners.iterator();
            while (v0_2.hasNext()) {
                ((p0.a) v0_2.next()).accept(new e0.k(p4));
            }
        }
        return;
    }

    public void onMultiWindowModeChanged(boolean p4, android.content.res.Configuration p5)
    {
        this.mDispatchingOnMultiWindowModeChanged = 1;
        try {
            super.onMultiWindowModeChanged(p4, p5);
            this.mDispatchingOnMultiWindowModeChanged = 0;
            java.util.Iterator v0_3 = this.mOnMultiWindowModeChangedListeners.iterator();
        } catch (Throwable v4_1) {
            this.mDispatchingOnMultiWindowModeChanged = v0_3;
            throw v4_1;
        }
        while (v0_3.hasNext()) {
            p0.a v1_2 = ((p0.a) v0_3.next());
            p5.getClass();
            v1_2.accept(new e0.k(p4));
        }
        return;
    }

    public void onNewIntent(android.content.Intent p3)
    {
        super.onNewIntent(p3);
        java.util.Iterator v0_1 = this.mOnNewIntentListeners.iterator();
        while (v0_1.hasNext()) {
            ((p0.a) v0_1.next()).accept(p3);
        }
        return;
    }

    public void onPanelClosed(int p3, android.view.Menu p4)
    {
        java.util.Iterator v0_2 = this.mMenuHostHelper.b.iterator();
        while (v0_2.hasNext()) {
            ((androidx.fragment.app.z0) ((q0.o) v0_2.next())).a.p(p4);
        }
        super.onPanelClosed(p3, p4);
        return;
    }

    public void onPictureInPictureModeChanged(boolean p4)
    {
        if (!this.mDispatchingOnPictureInPictureModeChanged) {
            java.util.Iterator v0_2 = this.mOnPictureInPictureModeChangedListeners.iterator();
            while (v0_2.hasNext()) {
                ((p0.a) v0_2.next()).accept(new e0.f0(p4));
            }
        }
        return;
    }

    public void onPictureInPictureModeChanged(boolean p4, android.content.res.Configuration p5)
    {
        this.mDispatchingOnPictureInPictureModeChanged = 1;
        try {
            super.onPictureInPictureModeChanged(p4, p5);
            this.mDispatchingOnPictureInPictureModeChanged = 0;
            java.util.Iterator v0_3 = this.mOnPictureInPictureModeChangedListeners.iterator();
        } catch (Throwable v4_1) {
            this.mDispatchingOnPictureInPictureModeChanged = v0_3;
            throw v4_1;
        }
        while (v0_3.hasNext()) {
            p0.a v1_2 = ((p0.a) v0_3.next());
            p5.getClass();
            v1_2.accept(new e0.f0(p4));
        }
        return;
    }

    public boolean onPreparePanel(int p1, android.view.View p2, android.view.Menu p3)
    {
        if (p1 == 0) {
            super.onPreparePanel(p1, p2, p3);
            int v1_3 = this.mMenuHostHelper.b.iterator();
            while (v1_3.hasNext()) {
                ((androidx.fragment.app.z0) ((q0.o) v1_3.next())).a.s(p3);
            }
        }
        return 1;
    }

    public void onRequestPermissionsResult(int p4, String[] p5, int[] p6)
    {
        if (!this.mActivityResultRegistry.a(p4, -1, new android.content.Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", p5).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", p6))) {
            super.onRequestPermissionsResult(p4, p5, p6);
        }
        return;
    }

    public Object onRetainCustomNonConfigurationInstance()
    {
        return 0;
    }

    public final Object onRetainNonConfigurationInstance()
    {
        int v0_0 = this.onRetainCustomNonConfigurationInstance();
        androidx.lifecycle.i1 v1 = this.mViewModelStore;
        if (v1 == null) {
            androidx.activity.m v2_3 = ((androidx.activity.m) this.getLastNonConfigurationInstance());
            if (v2_3 != null) {
                v1 = v2_3.b;
            }
        }
        if ((v1 != null) || (v0_0 != 0)) {
            androidx.activity.m v2_1 = new androidx.activity.m();
            v2_1.a = v0_0;
            v2_1.b = v1;
            return v2_1;
        } else {
            return 0;
        }
    }

    public void onSaveInstanceState(android.os.Bundle p4)
    {
        c2.f v0_0 = this.getLifecycle();
        if ((v0_0 instanceof androidx.lifecycle.z)) {
            c2.f v0_2 = ((androidx.lifecycle.z) v0_0);
            v0_2.d("setCurrentState");
            v0_2.f(androidx.lifecycle.Lifecycle$State.i);
        }
        super.onSaveInstanceState(p4);
        this.mSavedStateRegistryController.b(p4);
        return;
    }

    public void onTrimMemory(int p4)
    {
        super.onTrimMemory(p4);
        java.util.Iterator v0_1 = this.mOnTrimMemoryListeners.iterator();
        while (v0_1.hasNext()) {
            ((p0.a) v0_1.next()).accept(Integer.valueOf(p4));
        }
        return;
    }

    public android.content.Context peekAvailableContext()
    {
        return this.mContextAwareHelper.b;
    }

    public final f.c registerForActivityResult(g.a p2, f.b p3)
    {
        return this.registerForActivityResult(p2, this.mActivityResultRegistry, p3);
    }

    public final f.c registerForActivityResult(g.a p3, f.h p4, f.b p5)
    {
        String v0_1 = new StringBuilder("activity_rq#");
        v0_1.append(this.mNextLocalRequestCode.getAndIncrement());
        return p4.c(v0_1.toString(), this, p3, p5);
    }

    public void removeMenuProvider(q0.o p2)
    {
        this.mMenuHostHelper.b(p2);
        return;
    }

    public final void removeOnConfigurationChangedListener(p0.a p2)
    {
        this.mOnConfigurationChangedListeners.remove(p2);
        return;
    }

    public final void removeOnContextAvailableListener(e.b p2)
    {
        java.util.concurrent.CopyOnWriteArraySet v0_0 = this.mContextAwareHelper;
        v0_0.getClass();
        p2.getClass();
        v0_0.a.remove(p2);
        return;
    }

    public final void removeOnMultiWindowModeChangedListener(p0.a p2)
    {
        this.mOnMultiWindowModeChangedListeners.remove(p2);
        return;
    }

    public final void removeOnNewIntentListener(p0.a p2)
    {
        this.mOnNewIntentListeners.remove(p2);
        return;
    }

    public final void removeOnPictureInPictureModeChangedListener(p0.a p2)
    {
        this.mOnPictureInPictureModeChangedListeners.remove(p2);
        return;
    }

    public final void removeOnTrimMemoryListener(p0.a p2)
    {
        this.mOnTrimMemoryListeners.remove(p2);
        return;
    }

    public void reportFullyDrawn()
    {
        if (com.bumptech.glide.e.j()) {
            com.bumptech.glide.e.a("reportFullyDrawn() for ComponentActivity");
        }
        super.reportFullyDrawn();
        java.util.ArrayList v0_5 = this.mFullyDrawnReporter;
        v0_5.b = 1;
        java.util.ArrayList v2_0 = v0_5.c;
        int v3 = v2_0.size();
        int v4 = 0;
        while (v4 < v3) {
            ua.a v5_0 = v2_0.get(v4);
            v4++;
            ((ua.a) v5_0).invoke();
        }
        v0_5.c.clear();
        android.os.Trace.endSection();
        return;
    }

    public void setContentView(int p3)
    {
        this.initializeViewTreeOwners();
        ((androidx.activity.o) this.mReportFullyDrawnExecutor).a(this.getWindow().getDecorView());
        super.setContentView(p3);
        return;
    }

    public void setContentView(android.view.View p3)
    {
        this.initializeViewTreeOwners();
        ((androidx.activity.o) this.mReportFullyDrawnExecutor).a(this.getWindow().getDecorView());
        super.setContentView(p3);
        return;
    }

    public void setContentView(android.view.View p3, android.view.ViewGroup$LayoutParams p4)
    {
        this.initializeViewTreeOwners();
        ((androidx.activity.o) this.mReportFullyDrawnExecutor).a(this.getWindow().getDecorView());
        super.setContentView(p3, p4);
        return;
    }

    public void startActivityForResult(android.content.Intent p1, int p2)
    {
        super.startActivityForResult(p1, p2);
        return;
    }

    public void startActivityForResult(android.content.Intent p1, int p2, android.os.Bundle p3)
    {
        super.startActivityForResult(p1, p2, p3);
        return;
    }

    public void startIntentSenderForResult(android.content.IntentSender p1, int p2, android.content.Intent p3, int p4, int p5, int p6)
    {
        super.startIntentSenderForResult(p1, p2, p3, p4, p5, p6);
        return;
    }

    public void startIntentSenderForResult(android.content.IntentSender p1, int p2, android.content.Intent p3, int p4, int p5, int p6, android.os.Bundle p7)
    {
        super.startIntentSenderForResult(p1, p2, p3, p4, p5, p6, p7);
        return;
    }
}
