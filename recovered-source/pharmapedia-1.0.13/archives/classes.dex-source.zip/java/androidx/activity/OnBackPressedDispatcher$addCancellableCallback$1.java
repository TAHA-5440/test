// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
final synthetic class OnBackPressedDispatcher$addCancellableCallback$1 extends kotlin.jvm.internal.FunctionReferenceImpl implements ua.a {

    public final Object invoke()
    {
        ((androidx.activity.f0) this.receiver).d();
        return ga.p.a;
    }
}
