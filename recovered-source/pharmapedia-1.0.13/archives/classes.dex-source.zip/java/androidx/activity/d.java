// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final synthetic class d implements java.lang.Runnable {
    public final synthetic int g;
    public final synthetic Object h;

    public synthetic d(Object p1, int p2)
    {
        this.g = p2;
        this.h = p1;
        return;
    }

    public final void run()
    {
        switch (this.g) {
            case 0:
                ((androidx.activity.p) this.h).invalidateMenu();
                return;
            case 1:
                ClassCastException v0_56 = ((androidx.activity.o) this.h);
                java.util.ArrayList v2_24 = v0_56.h;
                if (v2_24 != null) {
                    v2_24.run();
                    v0_56.h = 0;
                }
                return;
            case 2:
                androidx.activity.r.a(((androidx.activity.r) this.h));
                return;
            case 3:
                Object v5_16;
                ClassCastException v0_52 = ((androidx.lifecycle.o0) this.h);
                java.util.ArrayList v2_22 = v0_52.l;
                if (v0_52.h != 0) {
                    v5_16 = 1;
                } else {
                    v5_16 = 1;
                    v0_52.i = 1;
                    v2_22.e(androidx.lifecycle.Lifecycle$Event.ON_PAUSE);
                }
                if ((v0_52.g == 0) && (v0_52.i)) {
                    v2_22.e(androidx.lifecycle.Lifecycle$Event.ON_STOP);
                    v0_52.j = v5_16;
                }
                return;
            case 4:
                androidx.work.CoroutineWorker.a(((androidx.work.CoroutineWorker) this.h));
                return;
            case 5:
                com.google.firebase.appcheck.internal.DefaultTokenRefresher.b(((com.google.firebase.appcheck.internal.DefaultTokenRefresher) this.h));
                return;
            case 6:
                ((com.google.firebase.firestore.ListenerRegistration) this.h).remove();
                return;
            case 7:
                com.google.firebase.firestore.core.TransactionRunner.b(((com.google.firebase.firestore.core.TransactionRunner) this.h));
                return;
            case 8:
                com.google.firebase.installations.FirebaseInstallations.d(((com.google.firebase.installations.FirebaseInstallations) this.h));
                return;
            case 9:
                com.onesignal.core.internal.application.impl.ApplicationService.a(((com.onesignal.common.threading.Waiter) this.h));
                return;
            case 10:
                com.onesignal.core.internal.purchases.impl.TrackGooglePurchase.a(((com.onesignal.core.internal.purchases.impl.TrackGooglePurchase) this.h));
                return;
            case 11:
                ClassCastException v0_24 = ((d1.c) ((d1.c) this.h).c.h);
                com.bumptech.glide.j v6_3 = android.os.SystemClock.uptimeMillis();
                Object v3_8 = v0_24.b;
                long v8 = android.os.SystemClock.uptimeMillis();
                int v10 = 0;
                while (v10 < v3_8.size()) {
                    d1.f v11_2 = ((d1.f) v3_8.get(v10));
                    if (v11_2 != null) {
                        int v12_0 = v0_24.a;
                        int v13_2 = ((Long) v12_0.get(v11_2));
                        if (v13_2 != 0) {
                            if (v13_2.longValue() >= v8) {
                                v10++;
                                Object v5 = 0;
                            } else {
                                v12_0.remove(v11_2);
                            }
                        }
                        int v12_1 = v11_2.f;
                        if (v12_1 != 0) {
                            int v12_5;
                            int v12_2 = (v6_3 - v12_1);
                            v11_2.f = v6_3;
                            double v14_2 = d1.f.a().g;
                            if (v14_2 != 0) {
                                v12_5 = ((long) (((float) v12_2) / v14_2));
                            } else {
                                v12_5 = 2147483647;
                            }
                            int v4_30;
                            long v22 = v12_5;
                            int v13_5 = v11_2.k;
                            if (!v11_2.l) {
                                Object v5_0 = v11_2.j;
                                int v12_7 = v11_2.b;
                                int v13_6 = v11_2.a;
                                if (v13_5 == 2139095039) {
                                    int v4_16 = v5_0.a(((double) v12_7), ((double) v13_6), v22);
                                    v11_2.b = v4_16.a;
                                    v11_2.a = v4_16.b;
                                } else {
                                    long v30 = (v22 / 2);
                                    Object v5_2 = v5_0.a(((double) v12_7), ((double) v13_6), v30);
                                    int v12_10 = v11_2.j;
                                    v12_10.i = ((double) v11_2.k);
                                    v11_2.k = 2139095039;
                                    int v4_20 = v12_10.a(((double) v5_2.a), ((double) v5_2.b), v30);
                                    v11_2.b = v4_20.a;
                                    v11_2.a = v4_20.b;
                                }
                                Object v5_5 = Math.max(v11_2.b, -8388609);
                                v11_2.b = v5_5;
                                Object v5_6 = Math.min(v5_5, 2139095039);
                                v11_2.b = v5_6;
                                int v12_11 = v11_2.a;
                                int v13_11 = v11_2.j;
                                v13_11.getClass();
                                if ((((double) Math.abs(v12_11)) >= v13_11.e) || (((double) Math.abs((v5_6 - ((float) v13_11.i)))) >= v13_11.d)) {
                                    v4_30 = 0;
                                } else {
                                    v11_2.b = ((float) v11_2.j.i);
                                    v11_2.a = 0;
                                    v4_30 = 1;
                                }
                            } else {
                                if (v13_5 != 2139095039) {
                                    v11_2.j.i = ((double) v13_5);
                                    v11_2.k = 2139095039;
                                }
                                v11_2.b = ((float) v11_2.j.i);
                                v11_2.a = 0;
                                v11_2.l = 0;
                            }
                            java.util.ArrayList v2_17 = Math.min(v11_2.b, 2139095039);
                            v11_2.b = v2_17;
                            java.util.ArrayList v2_18 = Math.max(v2_17, -8388609);
                            v11_2.b = v2_18;
                            v11_2.b(v2_18);
                            if (v4_30 != 0) {
                                java.util.ArrayList v2_20 = v11_2.h;
                                v11_2.e = 0;
                                int v4_41 = d1.f.a();
                                v4_41.a.remove(v11_2);
                                Object v5_10 = v4_41.b;
                                int v12_15 = v5_10.indexOf(v11_2);
                                if (v12_15 >= 0) {
                                    v5_10.set(v12_15, 0);
                                    v4_41.f = 1;
                                }
                                v11_2.f = 0;
                                int v4_43 = 0;
                                while (v4_43 < v2_20.size()) {
                                    if (v2_20.get(v4_43) != null) {
                                        throw f0.a.a(v4_43, v2_20);
                                    } else {
                                        v4_43++;
                                    }
                                }
                                int v4_45 = (v2_20.size() - 1);
                                while (v4_45 >= 0) {
                                    if (v2_20.get(v4_45) == null) {
                                        v2_20.remove(v4_45);
                                    }
                                    v4_45--;
                                }
                            }
                        } else {
                            v11_2.f = v6_3;
                            v11_2.b(v11_2.b);
                        }
                    }
                }
                if (v0_24.f) {
                    java.util.ArrayList v2_8 = (v3_8.size() - 1);
                    while (v2_8 >= null) {
                        if (v3_8.get(v2_8) == null) {
                            v3_8.remove(v2_8);
                        }
                        v2_8--;
                    }
                    if ((v3_8.size() == 0) && (android.os.Build$VERSION.SDK_INT >= 33)) {
                        java.util.ArrayList v2_11 = v0_24.h;
                        androidx.activity.q.n(((d1.a) v2_11.h));
                        v2_11.h = 0;
                    }
                    v0_24.f = 0;
                }
                if (v3_8.size() > 0) {
                    ((android.view.Choreographer) v0_24.e.h).postFrameCallback(new d1.b(v0_24.d));
                }
                return;
            case 12:
                java.util.ArrayList v2_1 = ((e1.q) this.h);
                if (v2_1.n != null) {
                    try {
                        int v4_1 = v2_1.c();
                        com.bumptech.glide.j v6_0 = v4_1.e;
                    } catch (ClassCastException v0_16) {
                        int v4_8 = v2_1.n;
                        if (v4_8 != 0) {
                            v4_8.p(v0_16);
                        }
                        v2_1.b();
                    }
                    if (v6_0 == 2) {
                    }
                    if (v6_0 != null) {
                        int v4_3 = new StringBuilder("fetchFonts result is not OK. (");
                        v4_3.append(v6_0);
                        v4_3.append(")");
                        throw new RuntimeException(v4_3.toString());
                    } else {
                        android.os.Trace.beginSection("EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface");
                        Object v3_2 = v2_1.g;
                        v2_1.i.getClass();
                        ClassCastException v0_7 = new n0.h[] {v4_1});
                        com.bumptech.glide.e.a("TypefaceCompat.createFromFontInfo");
                        ClassCastException v0_8 = i0.f.a.J(v3_2, v0_7, 0);
                        android.os.Trace.endSection();
                        Object v3_5 = com.bumptech.glide.k.m(v2_1.g, v4_1.a);
                        if ((v3_5 == null) || (v0_8 == null)) {
                            throw new RuntimeException("Unable to open file.");
                        } else {
                            try {
                                android.os.Trace.beginSection("EmojiCompat.MetadataRepo.create");
                                int v4_7 = new c0.g(v0_8, com.bumptech.glide.k.o(v3_5));
                            } catch (ClassCastException v0_12) {
                                android.os.Trace.endSection();
                                throw v0_12;
                            }
                            android.os.Trace.endSection();
                            android.os.Trace.endSection();
                            ClassCastException v0_14 = v2_1.n;
                            if (v0_14 != null) {
                                v0_14.q(v4_7);
                            }
                            v2_1.b();
                        }
                    }
                } else {
                }
                return;
            case 13:
                ClassCastException v0_74 = ((g7.h) this.h);
                java.util.ArrayList v2_31 = v0_74.d;
                if (v2_31 != null) {
                    Object v3_23 = ((e7.j1) v2_31.h);
                    if ((!v3_23.i) && (!v3_23.h)) {
                        v2_31.f();
                    }
                }
                v0_74.c = 0;
                return;
            case 14:
                ((g7.z2) this.h).e();
                return;
            case 15:
                ClassCastException v0_70 = ((g7.g4) this.h).e;
                v0_70.c.a(new bc.c(v0_70, 12));
                return;
            case 16:
                ClassCastException v0_66 = ((c0.g) this.h);
                ((k4.g) v0_66.k).M(new androidx.work.impl.b(v0_66, 17));
                return;
            case 17:
                ((java.util.concurrent.CountDownLatch) this.h).countDown();
                return;
            case 18:
                ClassCastException v0_48 = ((o5.e) this.h);
                v0_48.b = 0;
                java.util.ArrayList v2_25 = ((com.google.android.material.sidesheet.SideSheetBehavior) v0_48.e);
                int v4_46 = v2_25.i;
                if ((v4_46 == 0) || (!v4_46.f())) {
                    if (v2_25.h == 2) {
                        v2_25.w(v0_48.c);
                    }
                } else {
                    v0_48.a(v0_48.c);
                }
                return;
            case 19:
                ClassCastException v0_33 = ((t0.d) this.h).a;
                java.util.ArrayList v2_19 = v0_33.getParent();
                if ((v2_19 instanceof android.view.ViewGroup)) {
                    ((android.view.ViewGroup) v2_19).removeView(v0_33);
                }
                return;
            case 20:
                androidx.work.impl.workers.ConstraintTrackingWorker.a(((androidx.work.impl.workers.ConstraintTrackingWorker) this.h));
                return;
            case 21:
                com.google.android.material.button.MaterialButton.b(((com.google.android.material.button.MaterialButton) this.h));
                return;
            case 22:
                ClassCastException v0_67 = ((wc.l) this.h);
                if ((v0_67.y != null) && (((android.content.SharedPreferences) v0_67.j().h).getBoolean("IS_DATA_FETCHED_KEY", 0))) {
                    ClassCastException v0_17 = v0_67.x;
                    if (v0_17 == null) {
                        kotlin.jvm.internal.f.i("progressDialog");
                        throw 0;
                    } else {
                        v0_17.dismiss();
                    }
                }
                return;
            default:
                ((com.google.android.material.carousel.CarouselLayoutManager) this.h).o0();
                return;
        }
    }
}
