// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class b {
    public final float a;
    public final float b;
    public final float c;
    public final int d;

    public b(android.window.BackEvent p5)
    {
        p5.getClass();
        androidx.activity.a v0 = androidx.activity.a.a;
        float v1 = v0.d(p5);
        float v2 = v0.e(p5);
        float v3 = v0.b(p5);
        int v5_1 = v0.c(p5);
        this.a = v1;
        this.b = v2;
        this.c = v3;
        this.d = v5_1;
        return;
    }

    public final String toString()
    {
        String v0_1 = new StringBuilder("BackEventCompat{touchX=");
        v0_1.append(this.a);
        v0_1.append(", touchY=");
        v0_1.append(this.b);
        v0_1.append(", progress=");
        v0_1.append(this.c);
        v0_1.append(", swipeEdge=");
        v0_1.append(this.d);
        v0_1.append(125);
        return v0_1.toString();
    }
}
