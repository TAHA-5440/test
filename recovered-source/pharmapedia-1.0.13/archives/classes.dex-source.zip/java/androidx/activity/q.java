// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public abstract synthetic class q {

    public static bridge synthetic double a(double p0, double p2, double p4)
    {
        return Math.fma(p0, p2, p4);
    }

    public static bridge synthetic float b()
    {
        return android.animation.ValueAnimator.getDurationScale();
    }

    public static bridge synthetic android.view.accessibility.AccessibilityNodeInfo$AccessibilityAction c()
    {
        return android.view.accessibility.AccessibilityNodeInfo$AccessibilityAction.ACTION_SHOW_TEXT_SUGGESTIONS;
    }

    public static bridge synthetic android.window.OnBackInvokedCallback d(Object p0)
    {
        return ((android.window.OnBackInvokedCallback) p0);
    }

    public static bridge synthetic android.window.OnBackInvokedDispatcher e(android.app.Activity p0)
    {
        return p0.getOnBackInvokedDispatcher();
    }

    public static bridge synthetic android.window.OnBackInvokedDispatcher f(android.view.View p0)
    {
        return p0.findOnBackInvokedDispatcher();
    }

    public static bridge synthetic android.window.OnBackInvokedDispatcher g(androidx.activity.r p0)
    {
        return p0.getOnBackInvokedDispatcher();
    }

    public static bridge synthetic android.window.OnBackInvokedDispatcher h(Object p0)
    {
        return ((android.window.OnBackInvokedDispatcher) p0);
    }

    public static bridge synthetic java.io.Serializable i(android.os.Bundle p2)
    {
        return p2.getSerializable("MedicinesModel", vet.pharmapedia.vetpharmapediapakistan.database.models.MedicinesRoomDBModel);
    }

    public static bridge synthetic String j()
    {
        return android.os.Process.myProcessName();
    }

    public static bridge synthetic void k(android.window.OnBackInvokedDispatcher p0, int p1, android.window.OnBackInvokedCallback p2)
    {
        p0.registerOnBackInvokedCallback(p1, p2);
        return;
    }

    public static bridge synthetic void l(android.window.OnBackInvokedDispatcher p0, android.window.OnBackInvokedCallback p1)
    {
        p0.unregisterOnBackInvokedCallback(p1);
        return;
    }

    public static bridge synthetic void m(android.window.OnBackInvokedDispatcher p1, androidx.activity.z p2)
    {
        p1.registerOnBackInvokedCallback(1000000, p2);
        return;
    }

    public static bridge synthetic boolean n(d1.a p0)
    {
        return android.animation.ValueAnimator.unregisterDurationScaleChangeListener(p0);
    }

    public static bridge synthetic boolean o(d1.a p0)
    {
        return android.animation.ValueAnimator.registerDurationScaleChangeListener(p0);
    }
}
