// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class a {
    public static final androidx.activity.a a;

    static a()
    {
        androidx.activity.a.a = new androidx.activity.a();
        return;
    }

    public final android.window.BackEvent a(float p2, float p3, float p4, int p5)
    {
        return new android.window.BackEvent(p2, p3, p4, p5);
    }

    public final float b(android.window.BackEvent p1)
    {
        p1.getClass();
        return p1.getProgress();
    }

    public final int c(android.window.BackEvent p1)
    {
        p1.getClass();
        return p1.getSwipeEdge();
    }

    public final float d(android.window.BackEvent p1)
    {
        p1.getClass();
        return p1.getTouchX();
    }

    public final float e(android.window.BackEvent p1)
    {
        p1.getClass();
        return p1.getTouchY();
    }
}
