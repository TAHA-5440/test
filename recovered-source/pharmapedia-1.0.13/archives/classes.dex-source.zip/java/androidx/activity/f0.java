// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class f0 {
    public final Runnable a;
    public final ha.h b;
    public androidx.fragment.app.y0 c;
    public final android.window.OnBackInvokedCallback d;
    public android.window.OnBackInvokedDispatcher e;
    public boolean f;
    public boolean g;

    public f0(Runnable p5)
    {
        this.a = p5;
        this.b = new ha.h();
        android.window.OnBackInvokedCallback v5_8 = android.os.Build$VERSION.SDK_INT;
        if (v5_8 >= 33) {
            android.window.OnBackInvokedCallback v5_3;
            if (v5_8 < 34) {
                v5_3 = androidx.activity.a0.a.a(new androidx.activity.OnBackPressedDispatcher$5(this));
            } else {
                v5_3 = androidx.activity.c0.a.a(new androidx.activity.OnBackPressedDispatcher$1(this), new androidx.activity.OnBackPressedDispatcher$2(this), new androidx.activity.OnBackPressedDispatcher$3(this), new androidx.activity.OnBackPressedDispatcher$4(this));
            }
            this.d = v5_3;
        }
        return;
    }

    public final void a(androidx.lifecycle.v p9, androidx.fragment.app.y0 p10)
    {
        p10.getClass();
        java.util.concurrent.CopyOnWriteArrayList v9_2 = p9.getLifecycle();
        if (((androidx.lifecycle.z) v9_2).i != androidx.lifecycle.Lifecycle$State.g) {
            p10.b.add(new androidx.activity.d0(this, v9_2, p10));
            this.d();
            p10.c = new androidx.activity.OnBackPressedDispatcher$addCallback$1(0, this, androidx.activity.f0, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0);
            return;
        } else {
            return;
        }
    }

    public final void b()
    {
        androidx.activity.f0 v0_0 = this.b;
        androidx.activity.f0 v0_8 = v0_0.listIterator(v0_0.a());
        while (v0_8.hasPrevious()) {
            boolean v1_0 = v0_8.previous();
            if (((androidx.fragment.app.y0) v1_0).a) {
            }
            boolean v1_1 = ((androidx.fragment.app.y0) v1_0);
            this.c = 0;
            if (!v1_1) {
                this.a.run();
                return;
            } else {
                switch (v1_1.d) {
                    case 0:
                        androidx.activity.f0 v0_4 = ((androidx.fragment.app.h1) v1_1.e);
                        v0_4.x(1);
                        if (!v0_4.h.a) {
                            v0_4.g.b();
                        } else {
                            v0_4.O();
                        }
                    default:
                        ((qc.b) v1_1.e).m();
                }
                return;
            }
        }
        v1_0 = 0;
    }

    public final void c(boolean p6)
    {
        android.window.OnBackInvokedDispatcher v0 = this.e;
        if (v0 != null) {
            android.window.OnBackInvokedCallback v1 = this.d;
            if (v1 != null) {
                androidx.activity.a0 v3 = androidx.activity.a0.a;
                if ((!p6) || (this.f)) {
                    if ((!p6) && (this.f)) {
                        v3.c(v0, v1);
                        this.f = 0;
                    }
                } else {
                    v3.b(v0, 0, v1);
                    this.f = 1;
                    return;
                }
            }
        }
        return;
    }

    public final void d()
    {
        int v0_0 = this.g;
        int v1 = 0;
        int v2_0 = this.b;
        if ((v2_0 == 0) || (!v2_0.isEmpty())) {
            int v2_2 = v2_0.iterator();
            while (v2_2.hasNext()) {
                if (((androidx.fragment.app.y0) v2_2.next()).a) {
                    v1 = 1;
                    break;
                }
            }
        }
        this.g = v1;
        if ((v1 != v0_0) && (android.os.Build$VERSION.SDK_INT >= 33)) {
            this.c(v1);
        }
        return;
    }
}
