// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
final class SystemBarStyle$Companion$auto$1 extends kotlin.jvm.internal.Lambda implements ua.l {
    public static final androidx.activity.SystemBarStyle$Companion$auto$1 g;

    static SystemBarStyle$Companion$auto$1()
    {
        androidx.activity.SystemBarStyle$Companion$auto$1.g = new androidx.activity.SystemBarStyle$Companion$auto$1(1);
        return;
    }

    public final Object invoke(Object p2)
    {
        Boolean v2_6;
        ((android.content.res.Resources) p2).getClass();
        if ((((android.content.res.Resources) p2).getConfiguration().uiMode & 48) != 32) {
            v2_6 = 0;
        } else {
            v2_6 = 1;
        }
        return Boolean.valueOf(v2_6);
    }
}
