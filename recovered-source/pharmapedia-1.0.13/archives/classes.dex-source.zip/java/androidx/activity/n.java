// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public interface n implements java.util.concurrent.Executor {
}
