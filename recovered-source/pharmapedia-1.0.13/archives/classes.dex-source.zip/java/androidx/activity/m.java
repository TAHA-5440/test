// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class m {
    public Object a;
    public androidx.lifecycle.i1 b;
}
