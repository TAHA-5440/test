// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class i extends f.h {
    public final synthetic androidx.activity.p h;

    public i(androidx.activity.p p1)
    {
        this.h = p1;
        return;
    }

    public final void b(int p9, g.a p10, Object p11)
    {
        int v0_0 = this.h;
        android.content.IntentSender v1_1 = p10.b(v0_0, p11);
        if (v1_1 == null) {
            android.os.Handler v10_3 = p10.a(v0_0, p11);
            if ((v10_3.getExtras() != null) && (v10_3.getExtras().getClassLoader() == null)) {
                v10_3.setExtrasClassLoader(v0_0.getClassLoader());
            }
            android.content.IntentSender v1_2;
            if (!v10_3.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
                v1_2 = 0;
            } else {
                v1_2 = v10_3.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                v10_3.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
            }
            int v7 = v1_2;
            if (!"androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(v10_3.getAction())) {
                if (!"androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(v10_3.getAction())) {
                    v0_0.startActivityForResult(v10_3, p9, v7);
                    return;
                } else {
                    android.os.Handler v10_2 = ((f.j) v10_3.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST"));
                    try {
                        int v2_1 = p9;
                        try {
                            v0_0.startIntentSenderForResult(v10_2.g, p9, v10_2.h, v10_2.i, v10_2.j, 0, v7);
                            return;
                        } catch (int v0_1) {
                            new android.os.Handler(android.os.Looper.getMainLooper()).post(new androidx.activity.h(this, v2_1, v0_1, 1));
                            return;
                        }
                    } catch (int v0_1) {
                        v2_1 = p9;
                        new android.os.Handler(android.os.Looper.getMainLooper()).post(new androidx.activity.h(this, v2_1, v0_1, 1));
                        return;
                    }
                    v0_0.startIntentSenderForResult(v10_2.g, p9, v10_2.h, v10_2.i, v10_2.j, 0, v7);
                    return;
                }
            } else {
                android.os.Handler v10_6 = v10_3.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
                if (v10_6 == null) {
                    v10_6 = new String[0];
                }
                e0.d.h(v0_0, v10_6, p9);
                return;
            }
        } else {
            new android.os.Handler(android.os.Looper.getMainLooper()).post(new androidx.activity.h(this, p9, v1_1, 0));
            return;
        }
    }
}
