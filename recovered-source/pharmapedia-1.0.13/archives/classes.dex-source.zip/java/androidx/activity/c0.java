// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class c0 {
    public static final androidx.activity.c0 a;

    static c0()
    {
        androidx.activity.c0.a = new androidx.activity.c0();
        return;
    }

    public final android.window.OnBackInvokedCallback a(ua.l p2, ua.l p3, ua.a p4, ua.a p5)
    {
        p2.getClass();
        p3.getClass();
        p4.getClass();
        p5.getClass();
        return new androidx.activity.b0(p2, p3, p4, p5);
    }
}
