// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public abstract class s {

    static s()
    {
        android.graphics.Color.argb(230, 255, 255, 255);
        android.graphics.Color.argb(128, 27, 27, 27);
        return;
    }

    public static void a(qc.b p7, androidx.activity.i0 p8)
    {
        androidx.activity.t v0_9;
        androidx.activity.i0 v2_1 = androidx.activity.SystemBarStyle$Companion$auto$1.g;
        androidx.activity.i0 v1_1 = new androidx.activity.i0(0, 0, 0, v2_1);
        android.view.View v4 = p7.getWindow().getDecorView();
        v4.getClass();
        androidx.activity.t v0_1 = v4.getResources();
        v0_1.getClass();
        boolean v5 = ((Boolean) v2_1.invoke(v0_1)).booleanValue();
        androidx.activity.t v0_4 = p8.d;
        androidx.activity.i0 v2_0 = v4.getResources();
        v2_0.getClass();
        boolean v6 = ((Boolean) v0_4.invoke(v2_0)).booleanValue();
        androidx.activity.t v0_7 = android.os.Build$VERSION.SDK_INT;
        if (v0_7 < 29) {
            if (v0_7 < 26) {
                v0_9 = new androidx.activity.t();
            } else {
                v0_9 = new androidx.activity.u();
            }
        } else {
            v0_9 = new androidx.activity.w();
        }
        android.view.Window v3 = p7.getWindow();
        v3.getClass();
        v0_9.a(v1_1, p8, v3, v4, v5, v6);
        return;
    }
}
