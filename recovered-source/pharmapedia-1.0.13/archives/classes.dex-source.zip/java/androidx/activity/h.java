// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class h implements java.lang.Runnable {
    public final synthetic int g;
    public final synthetic int h;
    public final synthetic Object i;
    public final synthetic Object j;

    public h(android.widget.TextView p2, android.graphics.Typeface p3, int p4)
    {
        this.g = 2;
        this.j = p2;
        this.i = p3;
        this.h = p4;
        return;
    }

    public synthetic h(androidx.activity.i p1, int p2, Object p3, int p4)
    {
        this.g = p4;
        this.i = p1;
        this.h = p2;
        this.j = p3;
        return;
    }

    public h(com.google.android.material.bottomsheet.BottomSheetBehavior p2, android.view.View p3, int p4)
    {
        this.g = 3;
        this.i = p2;
        this.j = p3;
        this.h = p4;
        return;
    }

    public final void run()
    {
        switch (this.g) {
            case 0:
                boolean v0_4 = ((androidx.activity.i) this.i);
                android.graphics.Typeface v1_6 = ((a3.f) this.j).h;
                int v2_6 = ((String) v0_4.a.get(Integer.valueOf(this.h)));
                if (v2_6 != 0) {
                    android.os.Bundle v3_6 = ((f.f) v0_4.e.get(v2_6));
                    if (v3_6 != null) {
                        android.os.Bundle v3_7 = v3_6.a;
                        if (v3_7 != null) {
                            if (!v0_4.d.remove(v2_6)) {
                                return;
                            } else {
                                v3_7.a(v1_6);
                                return;
                            }
                        }
                    }
                    v0_4.g.remove(v2_6);
                    v0_4.f.put(v2_6, v1_6);
                }
                return;
            case 1:
                ((androidx.activity.i) this.i).a(this.h, 0, new android.content.Intent().setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", ((android.content.IntentSender$SendIntentException) this.j)));
                return;
            case 2:
                m.s0.d(((android.widget.TextView) this.j), ((android.graphics.Typeface) this.i), this.h);
                return;
            default:
                ((com.google.android.material.bottomsheet.BottomSheetBehavior) this.i).N(((android.view.View) this.j), this.h, 0);
                return;
        }
    }
}
