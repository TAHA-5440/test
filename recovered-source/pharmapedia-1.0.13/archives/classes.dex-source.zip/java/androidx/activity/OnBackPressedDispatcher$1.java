// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
final class OnBackPressedDispatcher$1 extends kotlin.jvm.internal.Lambda implements ua.l {
    public final synthetic androidx.activity.f0 g;

    public OnBackPressedDispatcher$1(androidx.activity.f0 p1)
    {
        this.g = p1;
        super(1);
        return;
    }

    public final Object invoke(Object p4)
    {
        ((androidx.activity.b) p4).getClass();
        ga.p v4_2 = this.g;
        java.util.ListIterator v0_0 = v4_2.b;
        java.util.ListIterator v0_1 = v0_0.listIterator(v0_0.a());
        while (v0_1.hasPrevious()) {
            androidx.fragment.app.y0 v1_0 = v0_1.previous();
            if (((androidx.fragment.app.y0) v1_0).a) {
            }
            v4_2.c = ((androidx.fragment.app.y0) v1_0);
            return ga.p.a;
        }
        v1_0 = 0;
        v4_2.c = ((androidx.fragment.app.y0) v1_0);
        return ga.p.a;
    }
}
