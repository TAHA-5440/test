// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class k implements java.lang.Runnable {
    public final synthetic androidx.activity.p g;

    public k(androidx.activity.p p1)
    {
        this.g = p1;
        return;
    }

    public final void run()
    {
        try {
            androidx.activity.p.access$001(this.g);
            return;
        } catch (NullPointerException v0_1) {
            if (!android.text.TextUtils.equals(v0_1.getMessage(), "Can not perform this action after onSaveInstanceState")) {
                throw v0_1;
            } else {
                return;
            }
        } catch (NullPointerException v0_2) {
            if (!android.text.TextUtils.equals(v0_2.getMessage(), "Attempt to invoke virtual method \'android.os.Handler android.app.FragmentHostCallback.getHandler()\' on a null object reference")) {
                throw v0_2;
            } else {
                return;
            }
        }
    }
}
