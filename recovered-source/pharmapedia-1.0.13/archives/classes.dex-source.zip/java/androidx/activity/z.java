// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final synthetic class z implements android.window.OnBackInvokedCallback {
    public final synthetic int a;
    public final synthetic Object b;

    public synthetic z(Object p1, int p2)
    {
        this.a = p2;
        this.b = p1;
        return;
    }

    public final void onBackInvoked()
    {
        switch (this.a) {
            case 0:
                ((ua.a) this.b).invoke();
                return;
            case 1:
                ((h5.b) this.b).c();
                return;
            case 2:
                ((i.w) this.b).C();
                return;
            default:
                ((m.c2) this.b).run();
                return;
        }
    }
}
