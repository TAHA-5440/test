// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class e0 implements androidx.activity.c {
    public final androidx.fragment.app.y0 g;
    public final synthetic androidx.activity.f0 h;

    public e0(androidx.activity.f0 p1, androidx.fragment.app.y0 p2)
    {
        p2.getClass();
        this.h = p1;
        this.g = p2;
        return;
    }

    public final void cancel()
    {
        kotlin.jvm.internal.FunctionReferenceImpl v0_0 = this.h;
        androidx.fragment.app.y0 v2 = this.g;
        v0_0.b.remove(v2);
        if (kotlin.jvm.internal.f.a(v0_0.c, v2)) {
            v2.getClass();
            v0_0.c = 0;
        }
        v2.getClass();
        v2.b.remove(this);
        kotlin.jvm.internal.FunctionReferenceImpl v0_2 = v2.c;
        if (v0_2 != null) {
            v0_2.invoke();
        }
        v2.c = 0;
        return;
    }
}
