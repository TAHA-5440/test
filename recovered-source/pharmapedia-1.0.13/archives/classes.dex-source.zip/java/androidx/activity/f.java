// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final synthetic class f implements c2.d {
    public final synthetic int a;
    public final synthetic Object b;

    public synthetic f(Object p1, int p2)
    {
        this.a = p2;
        this.b = p1;
        return;
    }

    public final android.os.Bundle a()
    {
        switch (this.a) {
            case 0:
                return androidx.activity.p.c(((androidx.activity.p) this.b));
            default:
                kotlin.Pair[] v0_15 = ((androidx.lifecycle.d1) this.b);
                int v1_3 = kotlin.collections.a.N(((java.util.LinkedHashMap) v0_15.j)).entrySet().iterator();
                while (v1_3.hasNext()) {
                    int v2_9 = ((java.util.Map$Entry) v1_3.next());
                    v0_15.c(((kotlinx.coroutines.flow.f) ((jb.i) v2_9.getValue())).e(), ((String) v2_9.getKey()));
                }
                int v1_8 = kotlin.collections.a.N(((java.util.LinkedHashMap) v0_15.h)).entrySet().iterator();
                while (v1_8.hasNext()) {
                    int v2_4 = ((java.util.Map$Entry) v1_8.next());
                    v0_15.c(((c2.d) v2_4.getValue()).a(), ((String) v2_4.getKey()));
                }
                kotlin.Pair[] v0_10;
                kotlin.Pair[] v0_4 = ((java.util.LinkedHashMap) v0_15.g);
                if (!v0_4.isEmpty()) {
                    int v1_11 = new java.util.ArrayList(v0_4.size());
                    kotlin.Pair[] v0_6 = v0_4.entrySet().iterator();
                    while (v0_6.hasNext()) {
                        Object v3_3 = ((java.util.Map$Entry) v0_6.next());
                        v1_11.add(new kotlin.Pair(((String) v3_3.getKey()), v3_3.getValue()));
                    }
                    kotlin.Pair[] v0_7 = new kotlin.Pair[0];
                    v0_10 = ((kotlin.Pair[]) v1_11.toArray(v0_7));
                } else {
                    v0_10 = new kotlin.Pair[0];
                }
                return com.bumptech.glide.f.b(((kotlin.Pair[]) java.util.Arrays.copyOf(v0_10, v0_10.length)));
        }
    }
}
