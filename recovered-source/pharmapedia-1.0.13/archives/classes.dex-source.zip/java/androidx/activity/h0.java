// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public abstract class h0 {

    public static androidx.activity.i0 a()
    {
        return new androidx.activity.i0(-3355444, -3355444, 1, androidx.activity.SystemBarStyle$Companion$light$1.g);
    }
}
