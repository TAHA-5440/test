// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public class r extends android.app.Dialog implements androidx.lifecycle.v, androidx.activity.g0, c2.g {
    public androidx.lifecycle.z g;
    public final c2.f h;
    public final androidx.activity.f0 i;

    public r(android.content.Context p2, int p3)
    {
        p2.getClass();
        super(p2, p3);
        super.h = new c2.f(new d2.b(super, new androidx.activity.e(super, 2)));
        super.i = new androidx.activity.f0(new androidx.activity.d(super, 2));
        return;
    }

    public static void a(androidx.activity.r p0)
    {
        super.onBackPressed();
        return;
    }

    public void addContentView(android.view.View p1, android.view.ViewGroup$LayoutParams p2)
    {
        p1.getClass();
        this.b();
        super.addContentView(p1, p2);
        return;
    }

    public final void b()
    {
        android.view.View v0_0 = this.getWindow();
        v0_0.getClass();
        android.view.View v0_4 = v0_0.getDecorView();
        v0_4.getClass();
        v0_4.setTag(2131362466, this);
        android.view.View v0_5 = this.getWindow();
        v0_5.getClass();
        android.view.View v0_1 = v0_5.getDecorView();
        v0_1.getClass();
        v0_1.setTag(2131362467, this);
        android.view.View v0_2 = this.getWindow();
        v0_2.getClass();
        android.view.View v0_3 = v0_2.getDecorView();
        v0_3.getClass();
        v0_3.setTag(2131362468, this);
        return;
    }

    public final androidx.lifecycle.p getLifecycle()
    {
        androidx.lifecycle.z v0_0 = this.g;
        if (v0_0 == null) {
            v0_0 = new androidx.lifecycle.z(this);
            this.g = v0_0;
        }
        return v0_0;
    }

    public final androidx.activity.f0 getOnBackPressedDispatcher()
    {
        return this.i;
    }

    public final c2.e getSavedStateRegistry()
    {
        return this.h.b;
    }

    public final void onBackPressed()
    {
        this.i.b();
        return;
    }

    public void onCreate(android.os.Bundle p3)
    {
        super.onCreate(p3);
        if (android.os.Build$VERSION.SDK_INT >= 33) {
            androidx.lifecycle.Lifecycle$Event v0_4 = androidx.activity.q.g(this);
            v0_4.getClass();
            androidx.activity.f0 v1_1 = this.i;
            v1_1.getClass();
            v1_1.e = v0_4;
            v1_1.c(v1_1.g);
        }
        this.h.a(p3);
        androidx.lifecycle.z v3_1 = this.g;
        if (v3_1 == null) {
            v3_1 = new androidx.lifecycle.z(this);
            this.g = v3_1;
        }
        v3_1.e(androidx.lifecycle.Lifecycle$Event.ON_CREATE);
        return;
    }

    public final android.os.Bundle onSaveInstanceState()
    {
        android.os.Bundle v0 = super.onSaveInstanceState();
        v0.getClass();
        this.h.b(v0);
        return v0;
    }

    public void onStart()
    {
        super.onStart();
        androidx.lifecycle.z v0_0 = this.g;
        if (v0_0 == null) {
            v0_0 = new androidx.lifecycle.z(this);
            this.g = v0_0;
        }
        v0_0.e(androidx.lifecycle.Lifecycle$Event.ON_RESUME);
        return;
    }

    public void onStop()
    {
        int v0_0 = this.g;
        if (v0_0 == 0) {
            v0_0 = new androidx.lifecycle.z(this);
            this.g = v0_0;
        }
        v0_0.e(androidx.lifecycle.Lifecycle$Event.ON_DESTROY);
        this.g = 0;
        super.onStop();
        return;
    }

    public void setContentView(int p1)
    {
        this.b();
        super.setContentView(p1);
        return;
    }

    public void setContentView(android.view.View p1)
    {
        p1.getClass();
        this.b();
        super.setContentView(p1);
        return;
    }

    public void setContentView(android.view.View p1, android.view.ViewGroup$LayoutParams p2)
    {
        p1.getClass();
        this.b();
        super.setContentView(p1, p2);
        return;
    }
}
