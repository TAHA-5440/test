// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final synthetic class g implements e.b {
    public final synthetic androidx.activity.p a;

    public synthetic g(androidx.activity.p p1)
    {
        this.a = p1;
        return;
    }

    public final void a(androidx.activity.p p1)
    {
        androidx.activity.p.b(this.a);
        return;
    }
}
