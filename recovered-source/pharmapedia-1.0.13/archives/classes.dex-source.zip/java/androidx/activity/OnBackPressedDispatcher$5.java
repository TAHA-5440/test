// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
final class OnBackPressedDispatcher$5 extends kotlin.jvm.internal.Lambda implements ua.a {
    public final synthetic androidx.activity.f0 g;

    public OnBackPressedDispatcher$5(androidx.activity.f0 p1)
    {
        this.g = p1;
        super(0);
        return;
    }

    public final Object invoke()
    {
        this.g.b();
        return ga.p.a;
    }
}
