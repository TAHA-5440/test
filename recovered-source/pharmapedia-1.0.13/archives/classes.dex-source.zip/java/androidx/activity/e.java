// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final synthetic class e implements ua.a {
    public final synthetic int g;
    public final synthetic Object h;

    public synthetic e(Object p1, int p2)
    {
        this.g = p2;
        this.h = p1;
        return;
    }

    public final Object invoke()
    {
        StringBuilder v2_3 = ga.p.a;
        oc.y v4_5 = 0;
        java.util.ArrayList v5_8 = this.h;
        switch (this.g) {
            case 0:
                ((androidx.activity.p) v5_8).reportFullyDrawn();
                return 0;
            case 1:
                return androidx.lifecycle.w.f(((androidx.lifecycle.j1) v5_8));
            case 2:
                java.util.ArrayList v5_12 = ((c2.g) v5_8);
                v5_12.getLifecycle().a(new c2.b(v5_12, 0));
                return v2_3;
            case 3:
                return com.google.firebase.firestore.pipeline.DocumentsSource.a(((com.google.firebase.firestore.pipeline.DocumentsSource) v5_8));
            case 4:
                java.util.ArrayList v5_10 = ((fc.p) v5_8);
                v5_10.getClass();
                try {
                    v5_10.C.M(2, 0, 0);
                } catch (Throwable v0_60) {
                    v5_10.d(okhttp3.internal.http2.ErrorCode.j, okhttp3.internal.http2.ErrorCode.j, v0_60);
                }
                return v2_3;
            case 5:
                androidx.sqlite.db.framework.a v6_0;
                java.util.ArrayList v5_7 = ((g2.e) v5_8);
                Throwable v0_55 = v5_7.h;
                if ((v0_55 == null) || (!v5_7.j)) {
                    v6_0 = new androidx.sqlite.db.framework.a(v5_7.g, v5_7.h, new a3.f(16), v5_7.i, v5_7.k);
                } else {
                    kotlin.Pair v3_27 = v5_7.g;
                    v3_27.getClass();
                    kotlin.Pair v3_28 = v3_27.getNoBackupFilesDir();
                    v3_28.getClass();
                    v6_0 = new androidx.sqlite.db.framework.a(v5_7.g, new java.io.File(v3_28, v0_55).getAbsolutePath(), new a3.f(16), v5_7.i, v5_7.k);
                }
                v6_0.setWriteAheadLoggingEnabled(v5_7.m);
                return v6_0;
            case 6:
                java.util.ArrayList v5_6 = ((Object[]) v5_8);
                v5_6.getClass();
                return new ga.g(v5_6);
            case 7:
                java.util.ArrayList v5_9 = ((pc.i) v5_8);
                Throwable v0_58 = v5_9.h;
                StringBuilder v2_10 = v5_9.i;
                java.util.ArrayList v5_17 = v0_58.getResources("");
                v5_17.getClass();
                java.util.ArrayList v5_18 = java.util.Collections.list(v5_17);
                v5_18.getClass();
                androidx.sqlite.db.framework.a v6_3 = new java.util.ArrayList();
                java.util.ArrayList v7_3 = v5_18.size();
                int v8_0 = 0;
                while (v8_0 < v7_3) {
                    int v10_5;
                    oc.w v9_1 = v5_18.get(v8_0);
                    v8_0++;
                    oc.w v9_2 = ((java.net.URL) v9_1);
                    v9_2.getClass();
                    if (kotlin.jvm.internal.f.a(v9_2.getProtocol(), "file")) {
                        v10_5 = new kotlin.Pair(v2_10, ea.c.v(new java.io.File(v9_2.toURI())));
                    } else {
                        v10_5 = 0;
                    }
                    if (v10_5 != 0) {
                        v6_3.add(v10_5);
                    }
                }
                Throwable v0_64 = v0_58.getResources("META-INF/MANIFEST.MF");
                v0_64.getClass();
                java.util.ArrayList v5_1 = java.util.Collections.list(v0_64);
                v5_1.getClass();
                java.util.ArrayList v7_5 = new java.util.ArrayList();
                int v8_3 = v5_1.size();
                Throwable v0_52 = 0;
                while (v0_52 < v8_3) {
                    pc.f v19_4;
                    int v10_9 = (v0_52 + 1);
                    oc.w v9_9 = ((java.net.URL) v5_1.get(v0_52));
                    v9_9.getClass();
                    Throwable v0_67 = v9_9.toString();
                    v0_67.getClass();
                    if (db.p.Q(v0_67, "jar:file:", v4_5)) {
                        oc.w v9_13 = db.i.b0(6, v0_67, "!");
                        if (v9_13 != -1) {
                            oc.w v9_0 = ea.c.v(new java.io.File(java.net.URI.create(v0_67.substring(4, v9_13))));
                            oc.g v11_0 = v2_10.c0(v9_0);
                            oc.y v12_1 = (v11_0.size() - ((long) 22));
                            long v14_2 = 0;
                            if (v12_1 < 0) {
                                StringBuilder v2_1 = new StringBuilder("not a zip: size=");
                                v2_1.append(v11_0.size());
                                throw new java.io.IOException(v2_1.toString());
                            } else {
                                kotlin.Pair v3_2 = Math.max((v12_1 - 65536), 0);
                                while(true) {
                                    long v16_2 = v14_2;
                                    long v14_4 = new oc.y(v11_0.d(v12_1));
                                    if (v14_4.B() == 101010256) {
                                        break;
                                    }
                                    pc.f v19_0 = v5_1;
                                    v14_4.close();
                                    v12_1 += -1;
                                    if (v12_1 < v3_2) {
                                        throw new java.io.IOException("not a zip: end of central directory signature not found");
                                    } else {
                                        v14_2 = v16_2;
                                        v5_1 = v19_0;
                                    }
                                }
                                Throwable v0_12 = (v14_4.M() & 65535);
                                kotlin.Pair v3_4 = ((long) (v14_4.M() & 65535));
                                if ((v3_4 != ((long) (v14_4.M() & 65535))) || ((v0_12 != null) || ((v14_4.M() & 65535) != 0))) {
                                    throw new java.io.IOException("unsupported zip: spanned");
                                } else {
                                    oc.y v20_1 = v3_4;
                                    v14_4.skip(4);
                                    long v23 = (((long) v14_4.B()) & 4294967295);
                                    int v22_1 = (v14_4.M() & 65535);
                                    pc.f v19_3 = new pc.f(v20_1, v22_1, v23);
                                    Throwable v0_20 = v22_1;
                                    v14_4.Z(((long) v0_20));
                                    v14_4.close();
                                    oc.y v12_2 = (v12_1 - ((long) 20));
                                    if (v12_2 > v16_2) {
                                        oc.y v4_3 = new oc.y(v11_0.d(v12_2));
                                        if (v4_3.B() != 117853008) {
                                            try {
                                                v4_3.close();
                                                Throwable v0_38 = 0;
                                            } catch (Throwable v0_38) {
                                            }
                                        } else {
                                            kotlin.Pair v3_13 = v4_3.B();
                                            oc.y v12_4 = v4_3.L();
                                            if ((v4_3.B() != 1) || (v3_13 != null)) {
                                                throw new java.io.IOException("unsupported zip: spanned");
                                            } else {
                                                oc.y v12_6 = new oc.y(v11_0.d(v12_4));
                                                kotlin.Pair v3_15 = v12_6.B();
                                                if (v3_15 != 101075792) {
                                                    oc.g0 v1_6 = new StringBuilder();
                                                    v1_6.append("bad zip: expected ");
                                                    v1_6.append(pc.b.c(101075792));
                                                    v1_6.append(" but was ");
                                                    v1_6.append(pc.b.c(v3_15));
                                                    throw new java.io.IOException(v1_6.toString());
                                                } else {
                                                    v12_6.skip(12);
                                                    kotlin.Pair v3_17 = v12_6.B();
                                                    long v13_4 = v12_6.B();
                                                    long v26 = v12_6.L();
                                                    if ((v26 != v12_6.L()) || ((v3_17 != null) || (v13_4 != 0))) {
                                                        throw new java.io.IOException("unsupported zip: spanned");
                                                    } else {
                                                        v12_6.skip(8);
                                                        pc.f v25_1 = new pc.f(v26, v0_20, v12_6.L());
                                                        try {
                                                            v12_6.close();
                                                            Throwable v0_34 = 0;
                                                        } catch (Throwable v0_34) {
                                                        }
                                                        v19_3 = v25_1;
                                                        if (v0_34 != null) {
                                                            throw v0_34;
                                                        } else {
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        if (v0_38 != null) {
                                            throw v0_38;
                                        }
                                    }
                                    Throwable v0_39 = v19_3;
                                    oc.g0 v1_11 = new java.util.ArrayList();
                                    oc.y v4_6 = new oc.y(v11_0.d(v0_39.b));
                                    try {
                                        oc.y v12_7 = v0_39.a;
                                        long v14_9 = v16_2;
                                    } catch (Throwable v0_41) {
                                        oc.y v20_2 = v4_6;
                                        v19_4 = v5_1;
                                        kotlin.Pair v3_24 = v0_41;
                                        try {
                                            v20_2.close();
                                        } catch (Throwable v0_46) {
                                            com.bumptech.glide.i.d(v3_24, v0_46);
                                        }
                                        Throwable v0_42 = v3_24;
                                        if (v0_42 != null) {
                                            throw v0_42;
                                        } else {
                                            oc.g0 v1_13 = new oc.g0(v9_0, v2_10, pc.b.b(v1_11));
                                            try {
                                                v11_0.close();
                                            } catch (Throwable) {
                                            }
                                            kotlin.Pair v3_26 = new kotlin.Pair(v1_13, pc.i.k);
                                        }
                                    }
                                    while (v14_9 < v12_7) {
                                        kotlin.Pair v3_21 = pc.b.d(v4_6);
                                        v20_2 = v4_6;
                                        v19_4 = v5_1;
                                        if (v3_21.h >= v0_39.b) {
                                            throw new java.io.IOException("bad zip: local file header offset >= central directory offset");
                                        } else {
                                            if (pc.h.c(v3_21.a)) {
                                                v1_11.add(v3_21);
                                            }
                                            v14_9++;
                                            v5_1 = v19_4;
                                            v4_6 = v20_2;
                                        }
                                    }
                                    v19_4 = v5_1;
                                    try {
                                        v4_6.close();
                                        v0_42 = 0;
                                    } catch (Throwable v0_42) {
                                    }
                                }
                            }
                        } else {
                            v19_4 = v5_1;
                            v3_26 = 0;
                        }
                    }
                    if (v3_26 != null) {
                        v7_5.add(v3_26);
                    }
                    v0_52 = v10_9;
                    v5_1 = v19_4;
                    v4_5 = 0;
                }
                return ha.j.K(v7_5, v6_3);
            case 8:
                return new l.o(((oc.i) ((s6.h) v5_8).f.getValue()));
            case 9:
                java.util.ArrayList v5_4 = ((sb.e) v5_8);
                return Integer.valueOf(ub.m0.d(v5_4, v5_4.j));
            case 10:
                return new tc.e(((vet.pharmapedia.vetpharmapediapakistan.database.roomDB.MedicinesDBClass_Impl) v5_8));
            case 11:
                return ((a0.i) v5_8).b(":memory:");
            case 12:
                java.util.ArrayList v5_0 = ((androidx.room.coroutines.c) v5_8);
                return v5_0.g.b(v5_0.h);
            case 13:
                try {
                    Throwable v0_1 = ((java.util.List) ((ua.a) v5_8).invoke());
                } catch (javax.net.ssl.SSLPeerUnverifiedException) {
                    v0_1 = kotlin.collections.EmptyList.g;
                }
                return v0_1;
            default:
                return ((java.util.List) v5_8);
        }
    }
}
