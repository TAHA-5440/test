// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
final class OnBackPressedDispatcher$2 extends kotlin.jvm.internal.Lambda implements ua.l {
    public final synthetic androidx.activity.f0 g;

    public OnBackPressedDispatcher$2(androidx.activity.f0 p1)
    {
        this.g = p1;
        super(1);
        return;
    }

    public final Object invoke(Object p3)
    {
        ((androidx.activity.b) p3).getClass();
        ga.p v3_4 = this.g.b;
        ga.p v3_5 = v3_4.listIterator(v3_4.a());
        while (v3_5.hasPrevious()) {
            if (((androidx.fragment.app.y0) v3_5.previous()).a) {
                break;
            }
        }
        return ga.p.a;
    }
}
