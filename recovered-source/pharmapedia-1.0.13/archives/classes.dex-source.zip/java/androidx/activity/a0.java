// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class a0 {
    public static final androidx.activity.a0 a;

    static a0()
    {
        androidx.activity.a0.a = new androidx.activity.a0();
        return;
    }

    public final android.window.OnBackInvokedCallback a(ua.a p3)
    {
        p3.getClass();
        return new androidx.activity.z(p3, 0);
    }

    public final void b(Object p1, int p2, Object p3)
    {
        p1.getClass();
        p3.getClass();
        ((android.window.OnBackInvokedDispatcher) p1).registerOnBackInvokedCallback(p2, ((android.window.OnBackInvokedCallback) p3));
        return;
    }

    public final void c(Object p1, Object p2)
    {
        p1.getClass();
        p2.getClass();
        ((android.window.OnBackInvokedDispatcher) p1).unregisterOnBackInvokedCallback(((android.window.OnBackInvokedCallback) p2));
        return;
    }
}
