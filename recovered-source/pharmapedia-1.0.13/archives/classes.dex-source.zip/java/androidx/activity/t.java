// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class t implements androidx.activity.x {

    public void a(androidx.activity.i0 p1, androidx.activity.i0 p2, android.view.Window p3, android.view.View p4, boolean p5, boolean p6)
    {
        q0.p1 v1_8;
        p1.getClass();
        p2.getClass();
        p3.getClass();
        p4.getClass();
        com.bumptech.glide.j.T(p3, 0);
        if (!p5) {
            v1_8 = p1.a;
        } else {
            v1_8 = p1.b;
        }
        q0.p1 v1_4;
        p3.setStatusBarColor(v1_8);
        p3.setNavigationBarColor(p2.b);
        q0.p1 v1_2 = android.os.Build$VERSION.SDK_INT;
        if (v1_2 < 35) {
            if (v1_2 < 30) {
                if (v1_2 < 26) {
                    v1_4 = new q0.p1(p3);
                } else {
                    v1_4 = new q0.q1(p3);
                }
            } else {
                v1_4 = new q0.r1(p3);
            }
        } else {
            v1_4 = new q0.s1(p3);
        }
        v1_4.r((p5 ^ 1));
        return;
    }
}
