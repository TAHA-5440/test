// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public abstract class l {

    public static android.window.OnBackInvokedDispatcher a(android.app.Activity p0)
    {
        return p0.getOnBackInvokedDispatcher();
    }
}
