// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public interface x {

    public abstract void a(androidx.activity.i0 p0, androidx.activity.i0 p1, android.view.Window p2, android.view.View p3, boolean p4, boolean p5);
}
