// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class y {
    public final Object a;
    public boolean b;
    public final java.util.ArrayList c;

    public y(androidx.activity.o p1, androidx.activity.e p2)
    {
        this.a = new Object();
        this.c = new java.util.ArrayList();
        return;
    }
}
