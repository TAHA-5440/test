// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public interface g0 implements androidx.lifecycle.v {

    public abstract androidx.activity.f0 getOnBackPressedDispatcher();
}
