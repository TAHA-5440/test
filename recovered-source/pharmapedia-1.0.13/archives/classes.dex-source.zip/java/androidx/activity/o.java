// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class o implements androidx.activity.n, android.view.ViewTreeObserver$OnDrawListener, java.lang.Runnable {
    public final long g;
    public Runnable h;
    public boolean i;
    public final synthetic androidx.activity.p j;

    public o(androidx.activity.p p5)
    {
        this.j = p5;
        this.g = (android.os.SystemClock.uptimeMillis() + 10000);
        this.i = 0;
        return;
    }

    public final void a(android.view.View p2)
    {
        if (!this.i) {
            this.i = 1;
            p2.getViewTreeObserver().addOnDrawListener(this);
        }
        return;
    }

    public final void execute(Runnable p3)
    {
        this.h = p3;
        android.view.View v3_3 = this.j.getWindow().getDecorView();
        if (!this.i) {
            v3_3.postOnAnimation(new androidx.activity.d(this, 1));
            return;
        } else {
            if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
                v3_3.postInvalidate();
                return;
            } else {
                v3_3.invalidate();
                return;
            }
        }
    }

    public final void onDraw()
    {
        android.view.View v0_0 = this.h;
        if (v0_0 == null) {
            if (android.os.SystemClock.uptimeMillis() > this.g) {
                this.i = 0;
                this.j.getWindow().getDecorView().post(this);
            }
        } else {
            v0_0.run();
            this.h = 0;
            try {
                if (this.j.mFullyDrawnReporter.b) {
                    this.i = 0;
                    this.j.getWindow().getDecorView().post(this);
                    return;
                }
            } catch (android.view.View v0_7) {
                throw v0_7;
            }
        }
        return;
    }

    public final void run()
    {
        this.j.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
        return;
    }
}
