// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
final class OnBackPressedDispatcher$4 extends kotlin.jvm.internal.Lambda implements ua.a {
    public final synthetic androidx.activity.f0 g;

    public OnBackPressedDispatcher$4(androidx.activity.f0 p1)
    {
        this.g = p1;
        super(0);
        return;
    }

    public final Object invoke()
    {
        ga.p v0_0 = this.g;
        java.util.ListIterator v1_0 = v0_0.b;
        java.util.ListIterator v1_1 = v1_0.listIterator(v1_0.a());
        while (v1_1.hasPrevious()) {
            if (((androidx.fragment.app.y0) v1_1.previous()).a) {
                break;
            }
        }
        v0_0.c = 0;
        return ga.p.a;
    }
}
