// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public abstract synthetic class v {

    public static bridge synthetic boolean A(android.graphics.drawable.Drawable p0)
    {
        return p0.isProjected();
    }

    public static bridge synthetic int B(android.graphics.Insets p0)
    {
        return p0.right;
    }

    public static bridge synthetic void C(android.view.View p0, android.graphics.Matrix p1)
    {
        p0.transformMatrixToLocal(p1);
        return;
    }

    public static bridge synthetic int D(android.graphics.Insets p0)
    {
        return p0.bottom;
    }

    public static bridge synthetic float a(android.view.View p0)
    {
        return p0.getTransitionAlpha();
    }

    public static bridge synthetic int b(android.graphics.Insets p0)
    {
        return p0.left;
    }

    public static bridge synthetic android.content.res.ColorStateList c(android.graphics.drawable.ColorStateListDrawable p0)
    {
        return p0.getColorStateList();
    }

    public static bridge synthetic android.graphics.drawable.ColorStateListDrawable d(android.graphics.drawable.Drawable p0)
    {
        return ((android.graphics.drawable.ColorStateListDrawable) p0);
    }

    public static bridge synthetic android.net.Uri e(android.net.Uri p0)
    {
        return android.provider.MediaStore.setRequireOriginal(p0);
    }

    public static bridge synthetic android.view.DisplayCutout f(android.view.Display p0)
    {
        return p0.getCutout();
    }

    public static bridge synthetic String g(android.app.NotificationManager p0)
    {
        return p0.getNotificationDelegate();
    }

    public static bridge synthetic String h(javax.net.ssl.SSLSocket p0)
    {
        return p0.getApplicationProtocol();
    }

    public static bridge synthetic void i(android.app.Activity p0, androidx.lifecycle.r0$a p1)
    {
        p0.registerActivityLifecycleCallbacks(p1);
        return;
    }

    public static bridge synthetic void j(android.app.NotificationManager p1)
    {
        p1.setNotificationDelegate("com.google.android.gms");
        return;
    }

    public static bridge synthetic void k(android.view.View p0, float p1)
    {
        p0.setTransitionAlpha(p1);
        return;
    }

    public static bridge synthetic void l(android.view.View p0, android.graphics.Matrix p1)
    {
        p0.setAnimationMatrix(p1);
        return;
    }

    public static bridge synthetic void m(android.view.Window p1)
    {
        p1.setStatusBarContrastEnforced(0);
        return;
    }

    public static bridge synthetic void n(android.view.Window p0, boolean p1)
    {
        p0.setNavigationBarContrastEnforced(p1);
        return;
    }

    public static bridge synthetic void o(androidx.coordinatorlayout.widget.CoordinatorLayout p7, android.content.Context p8, int[] p9, android.util.AttributeSet p10, android.content.res.TypedArray p11)
    {
        p7.saveAttributeDataForStyleable(p8, p9, p10, p11, 0, 2132018701);
        return;
    }

    public static bridge synthetic void p(androidx.coordinatorlayout.widget.CoordinatorLayout p7, android.content.Context p8, int[] p9, android.util.AttributeSet p10, android.content.res.TypedArray p11, int p12)
    {
        p7.saveAttributeDataForStyleable(p8, p9, p10, p11, p12, 0);
        return;
    }

    public static bridge synthetic void q(javax.net.ssl.SSLParameters p0, String[] p1)
    {
        p0.setApplicationProtocols(p1);
        return;
    }

    public static bridge synthetic void r(javax.net.ssl.SSLSocket p1)
    {
        android.net.ssl.SSLSockets.setUseSessionTickets(p1, 1);
        return;
    }

    public static bridge synthetic boolean s()
    {
        return android.os.Trace.isEnabled();
    }

    public static bridge synthetic boolean t(android.content.Context p0, android.content.Intent p1, android.content.ServiceConnection p2, int p3, java.util.concurrent.Executor p4)
    {
        return p0.bindService(p1, p3, p4, p2);
    }

    public static bridge synthetic boolean u(android.graphics.drawable.Drawable p0)
    {
        return (p0 instanceof android.graphics.drawable.ColorStateListDrawable);
    }

    public static bridge synthetic boolean v(javax.net.ssl.SSLSocket p0)
    {
        return android.net.ssl.SSLSockets.isSupportedSocket(p0);
    }

    public static bridge synthetic int w(android.graphics.Insets p0)
    {
        return p0.top;
    }

    public static bridge synthetic void x(android.app.NotificationManager p1)
    {
        p1.setNotificationDelegate(0);
        return;
    }

    public static bridge synthetic void y(android.view.View p0, android.graphics.Matrix p1)
    {
        p0.transformMatrixToGlobal(p1);
        return;
    }

    public static bridge synthetic boolean z()
    {
        return android.os.Environment.isExternalStorageLegacy();
    }
}
