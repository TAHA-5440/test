// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class b0 implements android.window.OnBackAnimationCallback {
    public final synthetic ua.l a;
    public final synthetic ua.l b;
    public final synthetic ua.a c;
    public final synthetic ua.a d;

    public b0(ua.l p1, ua.l p2, ua.a p3, ua.a p4)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        this.d = p4;
        return;
    }

    public final void onBackCancelled()
    {
        this.d.invoke();
        return;
    }

    public final void onBackInvoked()
    {
        this.c.invoke();
        return;
    }

    public final void onBackProgressed(android.window.BackEvent p2)
    {
        p2.getClass();
        this.b.invoke(new androidx.activity.b(p2));
        return;
    }

    public final void onBackStarted(android.window.BackEvent p2)
    {
        p2.getClass();
        this.a.invoke(new androidx.activity.b(p2));
        return;
    }
}
