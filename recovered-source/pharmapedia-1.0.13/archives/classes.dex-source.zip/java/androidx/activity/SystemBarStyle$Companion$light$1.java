// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
final class SystemBarStyle$Companion$light$1 extends kotlin.jvm.internal.Lambda implements ua.l {
    public static final androidx.activity.SystemBarStyle$Companion$light$1 g;

    static SystemBarStyle$Companion$light$1()
    {
        androidx.activity.SystemBarStyle$Companion$light$1.g = new androidx.activity.SystemBarStyle$Companion$light$1(1);
        return;
    }

    public final Object invoke(Object p1)
    {
        ((android.content.res.Resources) p1).getClass();
        return Boolean.FALSE;
    }
}
