// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public interface c {

    public abstract void cancel();
}
