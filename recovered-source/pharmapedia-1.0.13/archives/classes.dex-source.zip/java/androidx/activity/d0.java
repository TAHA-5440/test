// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.activity;
public final class d0 implements androidx.lifecycle.t, androidx.activity.c {
    public final androidx.lifecycle.p g;
    public final androidx.fragment.app.y0 h;
    public androidx.activity.e0 i;
    public final synthetic androidx.activity.f0 j;

    public d0(androidx.activity.f0 p1, androidx.lifecycle.p p2, androidx.fragment.app.y0 p3)
    {
        p3.getClass();
        this.j = p1;
        this.g = p2;
        this.h = p3;
        p2.a(this);
        return;
    }

    public final void cancel()
    {
        this.g.b(this);
        int v0_1 = this.h;
        v0_1.getClass();
        v0_1.b.remove(this);
        int v0_3 = this.i;
        if (v0_3 != 0) {
            v0_3.cancel();
        }
        this.i = 0;
        return;
    }

    public final void d(androidx.lifecycle.v p8, androidx.lifecycle.Lifecycle$Event p9)
    {
        if (p9 != androidx.lifecycle.Lifecycle$Event.ON_START) {
            if (p9 != androidx.lifecycle.Lifecycle$Event.ON_STOP) {
                if (p9 == androidx.lifecycle.Lifecycle$Event.ON_DESTROY) {
                    this.cancel();
                }
            } else {
                androidx.lifecycle.Lifecycle$Event v8_4 = this.i;
                if (v8_4 != null) {
                    v8_4.cancel();
                    return;
                }
            }
            return;
        } else {
            androidx.activity.f0 v2 = this.j;
            v2.getClass();
            androidx.lifecycle.Lifecycle$Event v8_1 = this.h;
            v8_1.getClass();
            v2.b.addLast(v8_1);
            androidx.activity.e0 v9_3 = new androidx.activity.e0(v2, v8_1);
            v8_1.b.add(v9_3);
            v2.d();
            v8_1.c = new androidx.activity.OnBackPressedDispatcher$addCancellableCallback$1(0, v2, androidx.activity.f0, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0);
            this.i = v9_3;
            return;
        }
    }
}
