// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.lifecycle;
public interface u {
}
