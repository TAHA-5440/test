// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.lifecycle;
public interface f1 {

    public androidx.lifecycle.c1 a(Class p2)
    {
        throw new UnsupportedOperationException("`Factory.create(String, CreationExtras)` is not implemented. You may need to override the method and provide a custom implementation. Note that using `Factory.create(String)` is not supported and considered an error.");
    }

    public androidx.lifecycle.c1 b(kotlin.jvm.internal.b p1, n1.c p2)
    {
        androidx.lifecycle.c1 v1_1 = p1.a();
        v1_1.getClass();
        return this.c(v1_1, p2);
    }

    public androidx.lifecycle.c1 c(Class p1, n1.c p2)
    {
        return this.a(p1);
    }
}
