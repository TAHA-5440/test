// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.lifecycle;
public interface t implements androidx.lifecycle.u {

    public abstract void d(androidx.lifecycle.v p0, androidx.lifecycle.Lifecycle$Event p1);
}
