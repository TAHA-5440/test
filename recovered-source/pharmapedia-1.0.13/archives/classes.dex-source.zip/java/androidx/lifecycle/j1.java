// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.lifecycle;
public interface j1 {

    public abstract androidx.lifecycle.i1 getViewModelStore();
}
