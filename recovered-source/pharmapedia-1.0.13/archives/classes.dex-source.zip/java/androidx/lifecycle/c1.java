// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.lifecycle;
public abstract class c1 {
    private final o1.b impl;

    public c1()
    {
        this.impl = new o1.b();
        return;
    }

    public void addCloseable(java.io.Closeable p3)
    {
        p3.getClass();
        java.util.LinkedHashSet v0_0 = this.impl;
        if (v0_0 == null) {
            return;
        } else {
            if (!v0_0.d) {
                try {
                    v0_0.c.add(p3);
                    return;
                } catch (Throwable v3_1) {
                    throw v3_1;
                }
            } else {
                o1.b.a(p3);
                return;
            }
        }
    }

    public void addCloseable(AutoCloseable p3)
    {
        p3.getClass();
        java.util.LinkedHashSet v0_0 = this.impl;
        if (v0_0 == null) {
            return;
        } else {
            if (!v0_0.d) {
                try {
                    v0_0.c.add(p3);
                    return;
                } catch (Throwable v3_1) {
                    throw v3_1;
                }
            } else {
                o1.b.a(p3);
                return;
            }
        }
    }

    public final void addCloseable(String p3, AutoCloseable p4)
    {
        p3.getClass();
        p4.getClass();
        java.util.LinkedHashMap v0_0 = this.impl;
        if (v0_0 == null) {
            return;
        } else {
            if (!v0_0.d) {
                try {
                    o1.b.a(((AutoCloseable) v0_0.b.put(p3, p4)));
                    return;
                } catch (Throwable v3_3) {
                    throw v3_3;
                }
            } else {
                o1.b.a(p4);
                return;
            }
        }
    }

    public final void clear$lifecycle_viewmodel()
    {
        java.util.LinkedHashSet v0_0 = this.impl;
        if ((v0_0 != null) && (!v0_0.d)) {
            v0_0.d = 1;
            java.util.Iterator v2_0 = v0_0.b.values().iterator();
            while (v2_0.hasNext()) {
                o1.b.a(((AutoCloseable) v2_0.next()));
            }
            java.util.Iterator v2_2 = v0_0.c.iterator();
            while (v2_2.hasNext()) {
                o1.b.a(((AutoCloseable) v2_2.next()));
            }
            v0_0.c.clear();
        }
        this.onCleared();
        return;
    }

    public final AutoCloseable getCloseable(String p3)
    {
        p3.getClass();
        java.util.LinkedHashMap v0_0 = this.impl;
        if (v0_0 == null) {
            return 0;
        } else {
            try {
                return ((AutoCloseable) v0_0.b.get(p3));
            } catch (Throwable v3_1) {
                throw v3_1;
            }
        }
    }

    public void onCleared()
    {
        return;
    }
}
