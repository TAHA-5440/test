// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.appcompat.view.menu;
public final class ExpandedMenuView extends android.widget.ListView implements l.l, l.b0, android.widget.AdapterView$OnItemClickListener {
    public static final int[] h;
    public l.m g;

    static ExpandedMenuView()
    {
        androidx.appcompat.view.menu.ExpandedMenuView.h = new int[] {16842964, 16843049});
        return;
    }

    public ExpandedMenuView(android.content.Context p2, android.util.AttributeSet p3)
    {
        this(p2, p3, 16842868);
        return;
    }

    public ExpandedMenuView(android.content.Context p3, android.util.AttributeSet p4, int p5)
    {
        super(p3, p4);
        super.setOnItemClickListener(super);
        androidx.lifecycle.j v3_1 = androidx.lifecycle.j.N(p5, 0, p3, p4, androidx.appcompat.view.menu.ExpandedMenuView.h);
        android.graphics.drawable.Drawable v4_4 = ((android.content.res.TypedArray) v3_1.i);
        if (v4_4.hasValue(0)) {
            super.setBackgroundDrawable(v3_1.x(0));
        }
        if (v4_4.hasValue(1)) {
            super.setDivider(v3_1.x(1));
        }
        v3_1.P();
        return;
    }

    public final boolean a(l.p p4)
    {
        return this.g.q(p4, 0, 0);
    }

    public final void b(l.m p1)
    {
        this.g = p1;
        return;
    }

    public int getWindowAnimations()
    {
        return 0;
    }

    public final void onDetachedFromWindow()
    {
        super.onDetachedFromWindow();
        this.setChildrenDrawingCacheEnabled(0);
        return;
    }

    public final void onItemClick(android.widget.AdapterView p1, android.view.View p2, int p3, long p4)
    {
        this.a(((l.p) this.getAdapter().getItem(p3)));
        return;
    }
}
