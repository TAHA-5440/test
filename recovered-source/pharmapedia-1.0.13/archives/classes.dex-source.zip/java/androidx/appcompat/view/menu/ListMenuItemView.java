// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.appcompat.view.menu;
public class ListMenuItemView extends android.widget.LinearLayout implements l.a0, android.widget.AbsListView$SelectionBoundsAdjuster {
    public l.p g;
    public android.widget.ImageView h;
    public android.widget.RadioButton i;
    public android.widget.TextView j;
    public android.widget.CheckBox k;
    public android.widget.TextView l;
    public android.widget.ImageView m;
    public android.widget.ImageView n;
    public android.widget.LinearLayout o;
    public final android.graphics.drawable.Drawable p;
    public final int q;
    public final android.content.Context r;
    public boolean s;
    public final android.graphics.drawable.Drawable t;
    public final boolean u;
    public android.view.LayoutInflater v;
    public boolean w;

    public ListMenuItemView(android.content.Context p2, android.util.AttributeSet p3)
    {
        this(p2, p3, 2130969408);
        return;
    }

    public ListMenuItemView(android.content.Context p4, android.util.AttributeSet p5, int p6)
    {
        super(p4, p5);
        androidx.lifecycle.j v5_1 = androidx.lifecycle.j.N(p6, 0, super.getContext(), p5, h.a.r);
        super.p = v5_1.x(5);
        boolean v6_2 = ((android.content.res.TypedArray) v5_1.i);
        super.q = v6_2.getResourceId(1, -1);
        super.s = v6_2.getBoolean(7, 0);
        super.r = p4;
        super.t = v5_1.x(8);
        android.content.res.TypedArray v4_2 = p4.getTheme().obtainStyledAttributes(0, new int[] {16843049}), 2130969022, 0);
        super.u = v4_2.hasValue(0);
        v5_1.P();
        v4_2.recycle();
        return;
    }

    private android.view.LayoutInflater getInflater()
    {
        if (this.v == null) {
            this.v = android.view.LayoutInflater.from(this.getContext());
        }
        return this.v;
    }

    private void setSubMenuArrowVisible(boolean p2)
    {
        android.widget.ImageView v0 = this.m;
        if (v0 != null) {
            int v2_1;
            if (p2 == 0) {
                v2_1 = 8;
            } else {
                v2_1 = 0;
            }
            v0.setVisibility(v2_1);
        }
        return;
    }

    public final void adjustListItemSelectionBounds(android.graphics.Rect p5)
    {
        int v0_0 = this.n;
        if ((v0_0 != 0) && (v0_0.getVisibility() == 0)) {
            int v0_5 = ((android.widget.LinearLayout$LayoutParams) this.n.getLayoutParams());
            p5.top = (((this.n.getHeight() + v0_5.topMargin) + v0_5.bottomMargin) + p5.top);
        }
        return;
    }

    public final void b(l.p p11)
    {
        int v0_17;
        this.g = p11;
        String v1_9 = p11.t;
        int v3 = 0;
        if (!p11.isVisible()) {
            v0_17 = 8;
        } else {
            v0_17 = 0;
        }
        int v0_12;
        this.setVisibility(v0_17);
        this.setTitle(p11.k);
        this.setCheckable(p11.isCheckable());
        if (!v1_9.o()) {
            v0_12 = 0;
        } else {
            int v0_11;
            if (!v1_9.n()) {
                v0_11 = p11.n;
            } else {
                v0_11 = p11.p;
            }
            if (v0_11 == 0) {
            } else {
                v0_12 = 1;
            }
        }
        v1_9.n();
        if (v0_12 == 0) {
            v3 = 8;
        } else {
            int v0_15;
            int v0_13 = this.g;
            String v1_10 = v0_13.t;
            if (!v1_10.o()) {
                v0_15 = 0;
            } else {
                int v0_14;
                if (!v1_10.n()) {
                    v0_14 = v0_13.n;
                } else {
                    v0_14 = v0_13.p;
                }
                if (v0_14 == 0) {
                } else {
                    v0_15 = 1;
                }
            }
            if (v0_15 == 0) {
            }
        }
        if (v3 == 0) {
            char v7_1;
            int v0_16 = this.l;
            String v1_12 = this.g;
            int v5_1 = v1_12.t;
            int v6_0 = v5_1.g;
            if (!v5_1.n()) {
                v7_1 = v1_12.n;
            } else {
                v7_1 = v1_12.p;
            }
            String v1_8;
            if (v7_1 != 0) {
                android.content.res.Resources v8 = v6_0.getResources();
                StringBuilder v9_1 = new StringBuilder();
                if (android.view.ViewConfiguration.get(v6_0).hasPermanentMenuKey()) {
                    v9_1.append(v8.getString(2131951637));
                }
                String v1_13;
                if (!v5_1.n()) {
                    v1_13 = v1_12.o;
                } else {
                    v1_13 = v1_12.q;
                }
                l.p.c(v9_1, v8.getString(2131951633), v1_13, 65536);
                l.p.c(v9_1, v8.getString(2131951629), v1_13, 4096);
                l.p.c(v9_1, v8.getString(2131951628), v1_13, 2);
                l.p.c(v9_1, v8.getString(2131951634), v1_13, 1);
                l.p.c(v9_1, v8.getString(2131951636), v1_13, 4);
                l.p.c(v9_1, v8.getString(2131951632), v1_13, 8);
                if (v7_1 == 8) {
                    v9_1.append(v8.getString(2131951630));
                } else {
                    if (v7_1 == 10) {
                        v9_1.append(v8.getString(2131951631));
                    } else {
                        if (v7_1 == 32) {
                            v9_1.append(v8.getString(2131951635));
                        } else {
                            v9_1.append(v7_1);
                        }
                    }
                }
                v1_8 = v9_1.toString();
            } else {
                v1_8 = "";
            }
            v0_16.setText(v1_8);
        }
        if (this.l.getVisibility() != v3) {
            this.l.setVisibility(v3);
        }
        this.setIcon(p11.getIcon());
        this.setEnabled(p11.isEnabled());
        this.setSubMenuArrowVisible(p11.hasSubMenu());
        this.setContentDescription(p11.w);
        return;
    }

    public l.p getItemData()
    {
        return this.g;
    }

    public final void onFinishInflate()
    {
        super.onFinishInflate();
        this.setBackground(this.p);
        android.widget.LinearLayout v0_15 = ((android.widget.TextView) this.findViewById(2131362419));
        this.j = v0_15;
        int v2 = this.q;
        if (v2 != -1) {
            v0_15.setTextAppearance(this.r, v2);
        }
        this.l = ((android.widget.TextView) this.findViewById(2131362344));
        android.widget.LinearLayout v0_6 = ((android.widget.ImageView) this.findViewById(2131362381));
        this.m = v0_6;
        if (v0_6 != null) {
            v0_6.setImageDrawable(this.t);
        }
        this.n = ((android.widget.ImageView) this.findViewById(2131362070));
        this.o = ((android.widget.LinearLayout) this.findViewById(2131361961));
        return;
    }

    public final void onMeasure(int p4, int p5)
    {
        if ((this.h != null) && (this.s)) {
            android.widget.LinearLayout$LayoutParams v1_2 = ((android.widget.LinearLayout$LayoutParams) this.h.getLayoutParams());
            int v0_1 = this.getLayoutParams().height;
            if ((v0_1 > 0) && (v1_2.width <= 0)) {
                v1_2.width = v0_1;
            }
        }
        super.onMeasure(p4, p5);
        return;
    }

    public void setCheckable(boolean p5)
    {
        if ((p5 != 0) || ((this.i != null) || (this.k != null))) {
            android.widget.RadioButton v1_0;
            android.widget.CheckBox v0_5;
            if ((this.g.D & 4) == 0) {
                if (this.k == null) {
                    android.widget.CheckBox v0_4 = ((android.widget.CheckBox) this.getInflater().inflate(2131558414, this, 0));
                    this.k = v0_4;
                    int v3_1 = this.o;
                    if (v3_1 == 0) {
                        this.addView(v0_4, -1);
                    } else {
                        v3_1.addView(v0_4, -1);
                    }
                }
                v0_5 = this.k;
                v1_0 = this.i;
            } else {
                if (this.i == null) {
                    android.widget.CheckBox v0_10 = ((android.widget.RadioButton) this.getInflater().inflate(2131558417, this, 0));
                    this.i = v0_10;
                    int v3_3 = this.o;
                    if (v3_3 == 0) {
                        this.addView(v0_10, -1);
                    } else {
                        v3_3.addView(v0_10, -1);
                    }
                }
                v0_5 = this.i;
                v1_0 = this.k;
            }
            if (p5 == 0) {
                int v5_1 = this.k;
                if (v5_1 != 0) {
                    v5_1.setVisibility(8);
                }
                int v5_2 = this.i;
                if (v5_2 != 0) {
                    v5_2.setVisibility(8);
                }
            } else {
                v0_5.setChecked(this.g.isChecked());
                if (v0_5.getVisibility() != 0) {
                    v0_5.setVisibility(0);
                }
                if ((v1_0 != null) && (v1_0.getVisibility() != 8)) {
                    v1_0.setVisibility(8);
                    return;
                }
            }
        }
        return;
    }

    public void setChecked(boolean p5)
    {
        android.widget.CheckBox v0_4;
        if ((this.g.D & 4) == 0) {
            if (this.k == null) {
                android.widget.CheckBox v0_3 = ((android.widget.CheckBox) this.getInflater().inflate(2131558414, this, 0));
                this.k = v0_3;
                android.widget.LinearLayout v2_0 = this.o;
                if (v2_0 == null) {
                    this.addView(v0_3, -1);
                } else {
                    v2_0.addView(v0_3, -1);
                }
            }
            v0_4 = this.k;
        } else {
            if (this.i == null) {
                android.widget.CheckBox v0_9 = ((android.widget.RadioButton) this.getInflater().inflate(2131558417, this, 0));
                this.i = v0_9;
                android.widget.LinearLayout v2_1 = this.o;
                if (v2_1 == null) {
                    this.addView(v0_9, -1);
                } else {
                    v2_1.addView(v0_9, -1);
                }
            }
            v0_4 = this.i;
        }
        v0_4.setChecked(p5);
        return;
    }

    public void setForceShowIcon(boolean p1)
    {
        this.w = p1;
        this.s = p1;
        return;
    }

    public void setGroupDividerEnabled(boolean p3)
    {
        android.widget.ImageView v0 = this.n;
        if (v0 != null) {
            if ((this.u) || (p3 == 0)) {
                int v3_1 = 8;
            } else {
                v3_1 = 0;
            }
            v0.setVisibility(v3_1);
        }
        return;
    }

    public void setIcon(android.graphics.drawable.Drawable p5)
    {
        int v0_1 = this.w;
        if ((v0_1 != 0) || (this.s)) {
            android.widget.ImageView v1_6 = this.h;
            if ((v1_6 != null) || ((p5 != null) || (this.s))) {
                if (v1_6 == null) {
                    android.widget.ImageView v1_2 = ((android.widget.ImageView) this.getInflater().inflate(2131558415, this, 0));
                    this.h = v1_2;
                    android.widget.LinearLayout v3_1 = this.o;
                    if (v3_1 == null) {
                        this.addView(v1_2, 0);
                    } else {
                        v3_1.addView(v1_2, 0);
                    }
                }
                if ((p5 == null) && (!this.s)) {
                    this.h.setVisibility(8);
                    return;
                } else {
                    if (v0_1 == 0) {
                        p5 = 0;
                    }
                    this.h.setImageDrawable(p5);
                    if (this.h.getVisibility() != 0) {
                        this.h.setVisibility(0);
                    }
                }
            }
        }
        return;
    }

    public void setTitle(CharSequence p2)
    {
        int v0_0 = this.j;
        if (p2 == null) {
            if (v0_0.getVisibility() != 8) {
                this.j.setVisibility(8);
            }
        } else {
            v0_0.setText(p2);
            if (this.j.getVisibility() != 0) {
                this.j.setVisibility(0);
                return;
            }
        }
        return;
    }
}
