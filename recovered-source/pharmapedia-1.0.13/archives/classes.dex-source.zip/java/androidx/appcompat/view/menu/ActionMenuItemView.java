// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.appcompat.view.menu;
public class ActionMenuItemView extends androidx.appcompat.widget.AppCompatTextView implements l.a0, android.view.View$OnClickListener, m.l {
    public l.p o;
    public CharSequence p;
    public android.graphics.drawable.Drawable q;
    public l.l r;
    public l.b s;
    public l.c t;
    public boolean u;
    public boolean v;
    public final int w;
    public int x;
    public final int y;

    public ActionMenuItemView(android.content.Context p2)
    {
        this(p2, 0);
        return;
    }

    public ActionMenuItemView(android.content.Context p2, android.util.AttributeSet p3)
    {
        this(p2, p3, 0);
        return;
    }

    public ActionMenuItemView(android.content.Context p4, android.util.AttributeSet p5, int p6)
    {
        super(p4, p5, p6);
        android.content.res.Resources v0 = p4.getResources();
        super.u = super.h();
        int v4_7 = p4.obtainStyledAttributes(p5, h.a.c, p6, 0);
        super.w = v4_7.getDimensionPixelSize(0, 0);
        v4_7.recycle();
        super.y = ((int) ((v0.getDisplayMetrics().density * 1107296256) + 1056964608));
        super.setOnClickListener(super);
        super.x = -1;
        super.setSaveEnabled(0);
        return;
    }

    public final boolean a()
    {
        return (android.text.TextUtils.isEmpty(this.getText()) ^ 1);
    }

    public final void b(l.p p2)
    {
        boolean v0_1;
        this.o = p2;
        this.setIcon(p2.getIcon());
        this.setTitle(p2.getTitleCondensed());
        this.setId(p2.g);
        if (!p2.isVisible()) {
            v0_1 = 8;
        } else {
            v0_1 = 0;
        }
        this.setVisibility(v0_1);
        this.setEnabled(p2.isEnabled());
        if ((p2.hasSubMenu()) && (this.s == null)) {
            this.s = new l.b(this);
        }
        return;
    }

    public final boolean c()
    {
        if ((android.text.TextUtils.isEmpty(this.getText())) || (this.o.getIcon() != null)) {
            return 0;
        } else {
            return 1;
        }
    }

    public CharSequence getAccessibilityClassName()
    {
        return android.widget.Button.getName();
    }

    public l.p getItemData()
    {
        return this.o;
    }

    public final boolean h()
    {
        int v0_5 = this.getContext().getResources().getConfiguration();
        int v1_1 = v0_5.screenWidthDp;
        if (((v1_1 < 480) && ((v1_1 < 640) || (v0_5.screenHeightDp < 480))) && (v0_5.orientation != 2)) {
            return 0;
        } else {
            return 1;
        }
    }

    public final void i()
    {
        boolean vtmp1 = android.text.TextUtils.isEmpty(this.p);
        CharSequence v1_0 = 1;
        if ((this.q != null) && (((this.o.E & 4) != 4) || ((!this.u) && (!this.v)))) {
            v1_0 = 0;
        }
        CharSequence v2_3;
        l.p v0_1 = ((vtmp1 ^ 1) & v1_0);
        CharSequence v1_1 = 0;
        if (v0_1 == null) {
            v2_3 = 0;
        } else {
            v2_3 = this.p;
        }
        this.setText(v2_3);
        CharSequence v2_5 = this.o.w;
        if (!android.text.TextUtils.isEmpty(v2_5)) {
            this.setContentDescription(v2_5);
        } else {
            CharSequence v2_7;
            if (v0_1 == null) {
                v2_7 = this.o.k;
            } else {
                v2_7 = 0;
            }
            this.setContentDescription(v2_7);
        }
        CharSequence v2_9 = this.o.x;
        if (!android.text.TextUtils.isEmpty(v2_9)) {
            com.bumptech.glide.e.p(this, v2_9);
            return;
        } else {
            if (v0_1 == null) {
                v1_1 = this.o.k;
            }
            com.bumptech.glide.e.p(this, v1_1);
            return;
        }
    }

    public final void onClick(android.view.View p2)
    {
        p2 = this.r;
        if (p2 != null) {
            p2.a(this.o);
        }
        return;
    }

    public final void onConfigurationChanged(android.content.res.Configuration p1)
    {
        super.onConfigurationChanged(p1);
        this.u = this.h();
        this.i();
        return;
    }

    public final void onMeasure(int p6, int p7)
    {
        int v0_1 = android.text.TextUtils.isEmpty(this.getText());
        if (v0_1 == 0) {
            int v1_1 = this.x;
            if (v1_1 >= 0) {
                super.setPadding(v1_1, this.getPaddingTop(), this.getPaddingRight(), this.getPaddingBottom());
            }
        }
        int v6_2;
        super.onMeasure(p6, p7);
        int v1_0 = android.view.View$MeasureSpec.getMode(p6);
        int v6_1 = android.view.View$MeasureSpec.getSize(p6);
        int v2_0 = this.getMeasuredWidth();
        int v4_1 = this.w;
        if (v1_0 != -2147483648) {
            v6_2 = v4_1;
        } else {
            v6_2 = Math.min(v6_1, v4_1);
        }
        if ((v1_0 != 1073741824) && ((v4_1 > 0) && (v2_0 < v6_2))) {
            super.onMeasure(android.view.View$MeasureSpec.makeMeasureSpec(v6_2, 1073741824), p7);
        }
        if ((v0_1 != 0) && (this.q != null)) {
            super.setPadding(((this.getMeasuredWidth() - this.q.getBounds().width()) / 2), this.getPaddingTop(), this.getPaddingRight(), this.getPaddingBottom());
        }
        return;
    }

    public final void onRestoreInstanceState(android.os.Parcelable p1)
    {
        super.onRestoreInstanceState(0);
        return;
    }

    public final boolean onTouchEvent(android.view.MotionEvent p2)
    {
        if (this.o.hasSubMenu()) {
            boolean v0_2 = this.s;
            if ((v0_2) && (v0_2.onTouch(this, p2))) {
                return 1;
            }
        }
        return super.onTouchEvent(p2);
    }

    public void setCheckable(boolean p1)
    {
        return;
    }

    public void setChecked(boolean p1)
    {
        return;
    }

    public void setExpandedFormat(boolean p2)
    {
        if (this.v != p2) {
            this.v = p2;
            l.m v2_1 = this.o;
            if (v2_1 != null) {
                l.m v2_2 = v2_1.t;
                v2_2.q = 1;
                v2_2.p(1);
            }
        }
        return;
    }

    public void setIcon(android.graphics.drawable.Drawable p5)
    {
        this.q = p5;
        if (p5 != null) {
            int v0_2 = p5.getIntrinsicWidth();
            int v1_0 = p5.getIntrinsicHeight();
            float v2 = this.y;
            if (v0_2 > v2) {
                v1_0 = ((int) (((float) v1_0) * (((float) v2) / ((float) v0_2))));
                v0_2 = v2;
            }
            if (v1_0 <= v2) {
                v2 = v1_0;
            } else {
                v0_2 = ((int) (((float) v0_2) * (((float) v2) / ((float) v1_0))));
            }
            p5.setBounds(0, 0, v0_2, v2);
        }
        this.setCompoundDrawables(p5, 0, 0, 0);
        this.i();
        return;
    }

    public void setItemInvoker(l.l p1)
    {
        this.r = p1;
        return;
    }

    public final void setPadding(int p1, int p2, int p3, int p4)
    {
        this.x = p1;
        super.setPadding(p1, p2, p3, p4);
        return;
    }

    public void setPopupCallback(l.c p1)
    {
        this.t = p1;
        return;
    }

    public void setTitle(CharSequence p1)
    {
        this.p = p1;
        this.i();
        return;
    }
}
