// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.appcompat.widget;
public class AppCompatTextView extends android.widget.TextView {
    public final m.p g;
    public final m.s0 h;
    public final m.a0 i;
    public m.w j;
    public boolean k;
    public l.o l;
    public java.util.concurrent.Future m;
    public m.r0 n;

    public AppCompatTextView(android.content.Context p2)
    {
        this(p2, 0);
        return;
    }

    public AppCompatTextView(android.content.Context p2, android.util.AttributeSet p3)
    {
        this(p2, p3, 16842884);
        return;
    }

    public AppCompatTextView(android.content.Context p1, android.util.AttributeSet p2, int p3)
    {
        super(p1, p2, p3);
        super.k = 0;
        super.l = 0;
        m.b2.a(super, super.getContext());
        m.w v1_10 = new m.p(super);
        super.g = v1_10;
        v1_10.k(p2, p3);
        m.w v1_3 = new m.s0(super);
        super.h = v1_3;
        v1_3.h(p2, p3);
        v1_3.b();
        m.w v1_5 = new m.a0();
        v1_5.b = super;
        super.i = v1_5;
        super.getEmojiTextViewHelper().a(p2, p3);
        return;
    }

    public static synthetic void d(androidx.appcompat.widget.AppCompatTextView p0, android.graphics.Typeface p1)
    {
        super.setTypeface(p1);
        return;
    }

    public static synthetic void e(androidx.appcompat.widget.AppCompatTextView p0, int p1)
    {
        super.setFirstBaselineToTopHeight(p1);
        return;
    }

    public static synthetic void f(androidx.appcompat.widget.AppCompatTextView p0, int p1)
    {
        super.setLastBaselineToBottomHeight(p1);
        return;
    }

    public static synthetic void g(androidx.appcompat.widget.AppCompatTextView p0, int p1, float p2)
    {
        super.setLineHeight(p1, p2);
        return;
    }

    private m.w getEmojiTextViewHelper()
    {
        if (this.j == null) {
            this.j = new m.w(this);
        }
        return this.j;
    }

    public final void drawableStateChanged()
    {
        super.drawableStateChanged();
        m.s0 v0_0 = this.g;
        if (v0_0 != null) {
            v0_0.a();
        }
        m.s0 v0_1 = this.h;
        if (v0_1 != null) {
            v0_1.b();
        }
        return;
    }

    public int getAutoSizeMaxTextSize()
    {
        if (!m.o2.c) {
            int v0_5 = this.h;
            if (v0_5 == 0) {
                return -1;
            } else {
                return Math.round(v0_5.i.e);
            }
        } else {
            this.getSuperCaller();
            return super.getAutoSizeMaxTextSize();
        }
    }

    public int getAutoSizeMinTextSize()
    {
        if (!m.o2.c) {
            int v0_5 = this.h;
            if (v0_5 == 0) {
                return -1;
            } else {
                return Math.round(v0_5.i.d);
            }
        } else {
            this.getSuperCaller();
            return super.getAutoSizeMinTextSize();
        }
    }

    public int getAutoSizeStepGranularity()
    {
        if (!m.o2.c) {
            int v0_5 = this.h;
            if (v0_5 == 0) {
                return -1;
            } else {
                return Math.round(v0_5.i.c);
            }
        } else {
            this.getSuperCaller();
            return super.getAutoSizeStepGranularity();
        }
    }

    public int[] getAutoSizeTextAvailableSizes()
    {
        if (!m.o2.c) {
            int[] v0_5 = this.h;
            if (v0_5 == null) {
                int[] v0_7 = new int[0];
                return v0_7;
            } else {
                return v0_5.i.f;
            }
        } else {
            this.getSuperCaller();
            return super.getAutoSizeTextAvailableSizes();
        }
    }

    public int getAutoSizeTextType()
    {
        if (!m.o2.c) {
            int v0_4 = this.h;
            if (v0_4 != 0) {
                return v0_4.i.a;
            }
        } else {
            this.getSuperCaller();
            if (super.getAutoSizeTextType() == 1) {
                return 1;
            }
        }
        return 0;
    }

    public android.view.ActionMode$Callback getCustomSelectionActionModeCallback()
    {
        return g6.f0.x(super.getCustomSelectionActionModeCallback());
    }

    public int getFirstBaselineToTopHeight()
    {
        return (this.getPaddingTop() - this.getPaint().getFontMetricsInt().top);
    }

    public String getFontVariationSettings()
    {
        return this.getFontVariationSettingsManager().e;
    }

    public m.r0 getFontVariationSettingsManager()
    {
        if (this.n == null) {
            this.n = new m.r0(this, new androidx.work.a(this, 3));
        }
        return this.n;
    }

    public int getLastBaselineToBottomHeight()
    {
        return (this.getPaddingBottom() + this.getPaint().getFontMetricsInt().bottom);
    }

    public m.t0 getSuperCaller()
    {
        if (this.l == null) {
            l.o v0_7 = android.os.Build$VERSION.SDK_INT;
            if (v0_7 < 34) {
                if (v0_7 < 28) {
                    if (v0_7 >= 26) {
                        this.l = new l.o(this, 3);
                    }
                } else {
                    this.l = new m.u0(this);
                }
            } else {
                this.l = new m.v0(this);
            }
        }
        return this.l;
    }

    public android.content.res.ColorStateList getSupportBackgroundTintList()
    {
        int v0_0 = this.g;
        if (v0_0 == 0) {
            return 0;
        } else {
            return v0_0.h();
        }
    }

    public android.graphics.PorterDuff$Mode getSupportBackgroundTintMode()
    {
        int v0_0 = this.g;
        if (v0_0 == 0) {
            return 0;
        } else {
            return v0_0.i();
        }
    }

    public android.content.res.ColorStateList getSupportCompoundDrawablesTintList()
    {
        return this.h.f();
    }

    public android.graphics.PorterDuff$Mode getSupportCompoundDrawablesTintMode()
    {
        return this.h.g();
    }

    public CharSequence getText()
    {
        ClassCastException v0_0 = this.m;
        try {
            if (v0_0 != null) {
                this.m = 0;
                if (v0_0.get() != null) {
                    throw new ClassCastException();
                } else {
                    if (android.os.Build$VERSION.SDK_INT < 29) {
                        g6.f0.k(this);
                        throw 0;
                    } else {
                        throw 0;
                    }
                }
            } else {
                return super.getText();
            }
        } catch (java.util.concurrent.ExecutionException) {
            return super.getText();
        }
    }

    public android.view.textclassifier.TextClassifier getTextClassifier()
    {
        if (android.os.Build$VERSION.SDK_INT < 28) {
            android.view.textclassifier.TextClassifier v0_7 = this.i;
            if (v0_7 != null) {
                android.view.textclassifier.TextClassifier v1_2 = ((android.view.textclassifier.TextClassifier) v0_7.c);
                if (v1_2 != null) {
                    return v1_2;
                } else {
                    return f0.b.d(((android.widget.TextView) v0_7.b));
                }
            }
        }
        this.getSuperCaller();
        return super.getTextClassifier();
    }

    public o0.a getTextMetricsParamsCompat()
    {
        return g6.f0.k(this);
    }

    public android.graphics.Typeface getTypeface()
    {
        if (android.os.Build$VERSION.SDK_INT < 26) {
            return super.getTypeface();
        } else {
            return this.getFontVariationSettingsManager().c;
        }
    }

    public final android.view.inputmethod.InputConnection onCreateInputConnection(android.view.inputmethod.EditorInfo p3)
    {
        android.view.inputmethod.InputConnection v0 = super.onCreateInputConnection(p3);
        this.h.getClass();
        m.s0.j(p3, v0, this);
        com.bumptech.glide.d.w(p3, v0, this);
        return v0;
    }

    public final void onDetachedFromWindow()
    {
        super.onDetachedFromWindow();
        android.view.inputmethod.InputMethodManager v0_0 = android.os.Build$VERSION.SDK_INT;
        if ((v0_0 >= 30) && ((v0_0 < 33) && (this.onCheckIsTextEditor()))) {
            ((android.view.inputmethod.InputMethodManager) this.getContext().getSystemService("input_method")).isActive(this);
        }
        return;
    }

    public final void onLayout(boolean p1, int p2, int p3, int p4, int p5)
    {
        m.y0 v2_1 = super.onLayout(p1, p2, p3, p4, p5).h;
        if ((v2_1 != null) && (!m.o2.c)) {
            v2_1.i.a();
        }
        return;
    }

    public void onMeasure(int p4, int p5)
    {
        ClassCastException v0_0 = this.m;
        try {
            if (v0_0 != null) {
                this.m = 0;
                if (v0_0.get() != null) {
                    throw new ClassCastException();
                } else {
                    if (android.os.Build$VERSION.SDK_INT < 29) {
                        g6.f0.k(this);
                        throw 0;
                    } else {
                        throw 0;
                    }
                }
            } else {
                super.onMeasure(p4, p5);
                return;
            }
        } catch (java.util.concurrent.ExecutionException) {
            super.onMeasure(p4, p5);
            return;
        }
    }

    public final void onTextChanged(CharSequence p1, int p2, int p3, int p4)
    {
        super.onTextChanged(p1, p2, p3, p4);
        m.y0 v1_1 = this.h;
        if (v1_1 != null) {
            m.y0 v1_2 = v1_1.i;
            if ((!m.o2.c) && (v1_2.f())) {
                v1_2.a();
            }
        }
        return;
    }

    public void setAllCaps(boolean p2)
    {
        super.setAllCaps(p2);
        this.getEmojiTextViewHelper().b(p2);
        return;
    }

    public final void setAutoSizeTextTypeUniformWithConfiguration(int p2, int p3, int p4, int p5)
    {
        if (!m.o2.c) {
            m.s0 v0_1 = this.h;
            if (v0_1 != null) {
                v0_1.k(p2, p3, p4, p5);
            }
            return;
        } else {
            this.getSuperCaller();
            super.setAutoSizeTextTypeUniformWithConfiguration(p2, p3, p4, p5);
            return;
        }
    }

    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] p2, int p3)
    {
        if (!m.o2.c) {
            m.s0 v0_1 = this.h;
            if (v0_1 != null) {
                v0_1.l(p2, p3);
            }
            return;
        } else {
            this.getSuperCaller();
            super.setAutoSizeTextTypeUniformWithPresetSizes(p2, p3);
            return;
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int p2)
    {
        if (!m.o2.c) {
            m.s0 v0_1 = this.h;
            if (v0_1 != null) {
                v0_1.m(p2);
            }
            return;
        } else {
            this.getSuperCaller();
            super.setAutoSizeTextTypeWithDefaults(p2);
            return;
        }
    }

    public void setBackgroundDrawable(android.graphics.drawable.Drawable p1)
    {
        super.setBackgroundDrawable(p1);
        m.p v1_1 = this.g;
        if (v1_1 != null) {
            v1_1.m();
        }
        return;
    }

    public void setBackgroundResource(int p2)
    {
        super.setBackgroundResource(p2);
        m.p v0 = this.g;
        if (v0 != null) {
            v0.n(p2);
        }
        return;
    }

    public final void setCompoundDrawables(android.graphics.drawable.Drawable p1, android.graphics.drawable.Drawable p2, android.graphics.drawable.Drawable p3, android.graphics.drawable.Drawable p4)
    {
        super.setCompoundDrawables(p1, p2, p3, p4);
        m.s0 v1_1 = this.h;
        if (v1_1 != null) {
            v1_1.b();
        }
        return;
    }

    public final void setCompoundDrawablesRelative(android.graphics.drawable.Drawable p1, android.graphics.drawable.Drawable p2, android.graphics.drawable.Drawable p3, android.graphics.drawable.Drawable p4)
    {
        super.setCompoundDrawablesRelative(p1, p2, p3, p4);
        m.s0 v1_1 = this.h;
        if (v1_1 != null) {
            v1_1.b();
        }
        return;
    }

    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(int p3, int p4, int p5, int p6)
    {
        m.s0 v3_2;
        android.content.Context v0 = this.getContext();
        android.graphics.drawable.Drawable v1 = 0;
        if (p3 == null) {
            v3_2 = 0;
        } else {
            v3_2 = t6.a.h(v0, p3);
        }
        int v4_1;
        if (p4 == 0) {
            v4_1 = 0;
        } else {
            v4_1 = t6.a.h(v0, p4);
        }
        int v5_1;
        if (p5 == 0) {
            v5_1 = 0;
        } else {
            v5_1 = t6.a.h(v0, p5);
        }
        if (p6 != 0) {
            v1 = t6.a.h(v0, p6);
        }
        this.setCompoundDrawablesRelativeWithIntrinsicBounds(v3_2, v4_1, v5_1, v1);
        m.s0 v3_1 = this.h;
        if (v3_1 != null) {
            v3_1.b();
        }
        return;
    }

    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(android.graphics.drawable.Drawable p1, android.graphics.drawable.Drawable p2, android.graphics.drawable.Drawable p3, android.graphics.drawable.Drawable p4)
    {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(p1, p2, p3, p4);
        m.s0 v1_1 = this.h;
        if (v1_1 != null) {
            v1_1.b();
        }
        return;
    }

    public final void setCompoundDrawablesWithIntrinsicBounds(int p3, int p4, int p5, int p6)
    {
        m.s0 v3_2;
        android.content.Context v0 = this.getContext();
        android.graphics.drawable.Drawable v1 = 0;
        if (p3 == null) {
            v3_2 = 0;
        } else {
            v3_2 = t6.a.h(v0, p3);
        }
        int v4_1;
        if (p4 == 0) {
            v4_1 = 0;
        } else {
            v4_1 = t6.a.h(v0, p4);
        }
        int v5_1;
        if (p5 == 0) {
            v5_1 = 0;
        } else {
            v5_1 = t6.a.h(v0, p5);
        }
        if (p6 != 0) {
            v1 = t6.a.h(v0, p6);
        }
        this.setCompoundDrawablesWithIntrinsicBounds(v3_2, v4_1, v5_1, v1);
        m.s0 v3_1 = this.h;
        if (v3_1 != null) {
            v3_1.b();
        }
        return;
    }

    public final void setCompoundDrawablesWithIntrinsicBounds(android.graphics.drawable.Drawable p1, android.graphics.drawable.Drawable p2, android.graphics.drawable.Drawable p3, android.graphics.drawable.Drawable p4)
    {
        super.setCompoundDrawablesWithIntrinsicBounds(p1, p2, p3, p4);
        m.s0 v1_1 = this.h;
        if (v1_1 != null) {
            v1_1.b();
        }
        return;
    }

    public void setCustomSelectionActionModeCallback(android.view.ActionMode$Callback p1)
    {
        super.setCustomSelectionActionModeCallback(g6.f0.z(p1, this));
        return;
    }

    public void setEmojiCompatEnabled(boolean p2)
    {
        this.getEmojiTextViewHelper().c(p2);
        return;
    }

    public void setFilters(android.text.InputFilter[] p2)
    {
        super.setFilters(((com.bumptech.glide.f) this.getEmojiTextViewHelper().b.h).s(p2));
        return;
    }

    public void setFirstBaselineToTopHeight(int p3)
    {
        if (android.os.Build$VERSION.SDK_INT < 28) {
            g6.f0.s(this, p3);
            return;
        } else {
            this.getSuperCaller().t(p3);
            return;
        }
    }

    public final boolean setFontVariationSettings(String p2)
    {
        return this.getFontVariationSettingsManager().a(p2);
    }

    public void setLastBaselineToBottomHeight(int p3)
    {
        if (android.os.Build$VERSION.SDK_INT < 28) {
            g6.f0.t(this, p3);
            return;
        } else {
            this.getSuperCaller().o(p3);
            return;
        }
    }

    public void setLineHeight(int p1)
    {
        g6.f0.u(this, p1);
        return;
    }

    public final void setLineHeight(int p3, float p4)
    {
        android.util.DisplayMetrics v0_0 = android.os.Build$VERSION.SDK_INT;
        if (v0_0 < 34) {
            if (v0_0 < 34) {
                g6.f0.u(this, Math.round(android.util.TypedValue.applyDimension(p3, p4, this.getResources().getDisplayMetrics())));
                return;
            } else {
                q0.y.h(this, p3, p4);
                return;
            }
        } else {
            this.getSuperCaller().u(p3, p4);
            return;
        }
    }

    public void setPrecomputedText(o0.b p3)
    {
        if (android.os.Build$VERSION.SDK_INT < 29) {
            g6.f0.k(this);
            throw 0;
        } else {
            throw 0;
        }
    }

    public void setSupportBackgroundTintList(android.content.res.ColorStateList p2)
    {
        m.p v0 = this.g;
        if (v0 != null) {
            v0.s(p2);
        }
        return;
    }

    public void setSupportBackgroundTintMode(android.graphics.PorterDuff$Mode p2)
    {
        m.p v0 = this.g;
        if (v0 != null) {
            v0.t(p2);
        }
        return;
    }

    public void setSupportCompoundDrawablesTintList(android.content.res.ColorStateList p2)
    {
        m.s0 v0 = this.h;
        v0.n(p2);
        v0.b();
        return;
    }

    public void setSupportCompoundDrawablesTintMode(android.graphics.PorterDuff$Mode p2)
    {
        m.s0 v0 = this.h;
        v0.o(p2);
        v0.b();
        return;
    }

    public void setTextAppearance(android.content.Context p2, int p3)
    {
        super.setTextAppearance(p2, p3);
        m.s0 v0 = this.h;
        if (v0 != null) {
            v0.i(p2, p3);
        }
        return;
    }

    public void setTextClassifier(android.view.textclassifier.TextClassifier p3)
    {
        if (android.os.Build$VERSION.SDK_INT < 28) {
            androidx.appcompat.widget.AppCompatTextView v0_2 = this.i;
            if (v0_2 != null) {
                v0_2.c = p3;
                return;
            }
        }
        this.getSuperCaller();
        super.setTextClassifier(p3);
        return;
    }

    public void setTextFuture(java.util.concurrent.Future p1)
    {
        this.m = p1;
        if (p1 != null) {
            this.requestLayout();
        }
        return;
    }

    public void setTextMetricsParamsCompat(o0.a p6)
    {
        int v0_0 = p6.b;
        android.text.TextPaint v1_0 = android.text.TextDirectionHeuristics.FIRSTSTRONG_RTL;
        int v2 = 1;
        if (v0_0 != v1_0) {
            android.text.TextDirectionHeuristic v3 = android.text.TextDirectionHeuristics.FIRSTSTRONG_LTR;
            if (v0_0 != v3) {
                if (v0_0 != android.text.TextDirectionHeuristics.ANYRTL_LTR) {
                    if (v0_0 != android.text.TextDirectionHeuristics.LTR) {
                        if (v0_0 != android.text.TextDirectionHeuristics.RTL) {
                            if (v0_0 != android.text.TextDirectionHeuristics.LOCALE) {
                                if (v0_0 != v3) {
                                    if (v0_0 == v1_0) {
                                        v2 = 7;
                                    }
                                } else {
                                    v2 = 6;
                                }
                            } else {
                                v2 = 5;
                            }
                        } else {
                            v2 = 4;
                        }
                    } else {
                        v2 = 3;
                    }
                } else {
                    v2 = 2;
                }
            }
        }
        this.setTextDirection(v2);
        this.getPaint().set(p6.a);
        this.setBreakStrategy(p6.c);
        this.setHyphenationFrequency(p6.d);
        return;
    }

    public final void setTextSize(int p3, float p4)
    {
        boolean v0_0 = m.o2.c;
        if (!v0_0) {
            m.y0 v1_0 = this.h;
            if (v1_0 != null) {
                m.y0 v1_1 = v1_0.i;
                if ((!v0_0) && (!v1_1.f())) {
                    v1_1.g(p3, p4);
                }
            }
            return;
        } else {
            super.setTextSize(p3, p4);
            return;
        }
    }

    public void setTypeface(android.graphics.Typeface p3)
    {
        if (android.os.Build$VERSION.SDK_INT < 26) {
            super.setTypeface(p3);
            return;
        } else {
            p0.a v0_1 = this.getFontVariationSettingsManager();
            v0_1.c = p3;
            v0_1.d = p3;
            v0_1.b.accept(p3);
            return;
        }
    }

    public final void setTypeface(android.graphics.Typeface p3, int p4)
    {
        if (!this.k) {
            if ((p3 != null) && (p4 > 0)) {
                if (this.getContext() == null) {
                    com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("Context cannot be null");
                    return;
                } else {
                    p3 = android.graphics.Typeface.create(p3, p4);
                }
            }
            this.k = 1;
            try {
                super.setTypeface(p3, p4);
                this.k = 0;
                return;
            } catch (Throwable v3_1) {
                this.k = 0;
                throw v3_1;
            }
        } else {
            return;
        }
    }
}
