// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.appcompat.widget;
public class AppCompatEditText extends android.widget.EditText {
    public final m.p g;
    public final m.s0 h;
    public final m.a0 i;
    public final u0.j j;
    public final m.a0 k;
    public m.v l;
    public m.r0 m;

    public AppCompatEditText(android.content.Context p2)
    {
        this(p2, 0);
        return;
    }

    public AppCompatEditText(android.content.Context p2, android.util.AttributeSet p3)
    {
        this(p2, p3, 2130969028);
        return;
    }

    public AppCompatEditText(android.content.Context p4, android.util.AttributeSet p5, int p6)
    {
        super(p4, p5, p6);
        m.b2.a(super, super.getContext());
        android.text.method.KeyListener v4_10 = new m.p(super);
        super.g = v4_10;
        v4_10.k(p5, p6);
        android.text.method.KeyListener v4_12 = new m.s0(super);
        super.h = v4_12;
        v4_12.h(p5, p6);
        v4_12.b();
        android.text.method.KeyListener v4_2 = new m.a0();
        v4_2.b = super;
        super.i = v4_2;
        super.j = new u0.j();
        android.text.method.KeyListener v4_7 = new m.a0(super);
        super.k = v4_7;
        v4_7.b(p5, p6);
        android.text.method.KeyListener v5_1 = super.getKeyListener();
        if (!(v5_1 instanceof android.text.method.NumberKeyListener)) {
            boolean v6_2 = super.isFocusable();
            boolean v0 = super.isClickable();
            boolean v1 = super.isLongClickable();
            int v2 = super.getInputType();
            android.text.method.KeyListener v4_8 = v4_7.a(v5_1);
            if (v4_8 != v5_1) {
                super.setKeyListener(v4_8);
                super.setRawInputType(v2);
                super.setFocusable(v6_2);
                super.setClickable(v0);
                super.setLongClickable(v1);
            }
        }
        return;
    }

    public static synthetic void a(androidx.appcompat.widget.AppCompatEditText p0, android.graphics.Typeface p1)
    {
        super.setTypeface(p1);
        return;
    }

    private m.v getSuperCaller()
    {
        if (this.l == null) {
            this.l = new m.v(this);
        }
        return this.l;
    }

    public final q0.f b(q0.f p2)
    {
        this.j.getClass();
        return u0.j.a(this, p2);
    }

    public final void drawableStateChanged()
    {
        super.drawableStateChanged();
        m.s0 v0_0 = this.g;
        if (v0_0 != null) {
            v0_0.a();
        }
        m.s0 v0_1 = this.h;
        if (v0_1 != null) {
            v0_1.b();
        }
        return;
    }

    public android.view.ActionMode$Callback getCustomSelectionActionModeCallback()
    {
        return g6.f0.x(super.getCustomSelectionActionModeCallback());
    }

    public String getFontVariationSettings()
    {
        return this.getFontVariationSettingsManager().e;
    }

    public m.r0 getFontVariationSettingsManager()
    {
        if (this.m == null) {
            this.m = new m.r0(this, new androidx.work.a(this, 2));
        }
        return this.m;
    }

    public android.content.res.ColorStateList getSupportBackgroundTintList()
    {
        int v0_0 = this.g;
        if (v0_0 == 0) {
            return 0;
        } else {
            return v0_0.h();
        }
    }

    public android.graphics.PorterDuff$Mode getSupportBackgroundTintMode()
    {
        int v0_0 = this.g;
        if (v0_0 == 0) {
            return 0;
        } else {
            return v0_0.i();
        }
    }

    public android.content.res.ColorStateList getSupportCompoundDrawablesTintList()
    {
        return this.h.f();
    }

    public android.graphics.PorterDuff$Mode getSupportCompoundDrawablesTintMode()
    {
        return this.h.g();
    }

    public android.text.Editable getText()
    {
        if (android.os.Build$VERSION.SDK_INT < 28) {
            return super.getEditableText();
        } else {
            return super.getText();
        }
    }

    public bridge synthetic CharSequence getText()
    {
        return this.getText();
    }

    public android.view.textclassifier.TextClassifier getTextClassifier()
    {
        if (android.os.Build$VERSION.SDK_INT < 28) {
            android.view.textclassifier.TextClassifier v0_5 = this.i;
            if (v0_5 != null) {
                android.view.textclassifier.TextClassifier v1_2 = ((android.view.textclassifier.TextClassifier) v0_5.c);
                if (v1_2 != null) {
                    return v1_2;
                } else {
                    return f0.b.d(((android.widget.TextView) v0_5.b));
                }
            }
        }
        this.getSuperCaller();
        return super.getTextClassifier();
    }

    public android.graphics.Typeface getTypeface()
    {
        if (android.os.Build$VERSION.SDK_INT < 26) {
            return super.getTypeface();
        } else {
            return this.getFontVariationSettingsManager().c;
        }
    }

    public android.view.inputmethod.InputConnection onCreateInputConnection(android.view.inputmethod.EditorInfo p8)
    {
        s0.d v0 = super.onCreateInputConnection(p8);
        this.h.getClass();
        m.s0.j(p8, v0, this);
        com.bumptech.glide.d.w(p8, v0, this);
        if (v0 != null) {
            String[] v1_9 = android.os.Build$VERSION.SDK_INT;
            if (v1_9 <= 30) {
                androidx.work.impl.b v2_0 = q0.n0.g(this);
                if (v2_0 != null) {
                    if (v1_9 < 25) {
                        if (p8.extras == null) {
                            p8.extras = new android.os.Bundle();
                        }
                        p8.extras.putStringArray("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES", v2_0);
                        p8.extras.putStringArray("android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES", v2_0);
                    } else {
                        s0.a.a(p8, v2_0);
                    }
                    String[] v1_6;
                    androidx.work.impl.b v2_2 = new androidx.work.impl.b(this, 18);
                    if (v1_9 < 25) {
                        String[] v1_2;
                        android.os.Bundle v6_6 = s0.c.a;
                        if (v1_9 < 25) {
                            String[] v1_1 = p8.extras;
                            if (v1_1 != null) {
                                v1_2 = v1_1.getStringArray("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES");
                                if (v1_2 == null) {
                                    v1_2 = p8.extras.getStringArray("android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES");
                                }
                                if (v1_2 != null) {
                                    v6_6 = v1_2;
                                }
                            }
                        } else {
                            v1_2 = s0.a.b(p8);
                            if (v1_2 != null) {
                            }
                        }
                        if (v6_6.length != 0) {
                            v1_6 = new s0.e(v0, v2_2);
                        } else {
                            return this.k.c(v0, p8);
                        }
                    } else {
                        v1_6 = new s0.d(v0, v2_2);
                    }
                    v0 = v1_6;
                }
            }
        }
        return this.k.c(v0, p8);
    }

    public final void onDetachedFromWindow()
    {
        super.onDetachedFromWindow();
        android.view.inputmethod.InputMethodManager v0_0 = android.os.Build$VERSION.SDK_INT;
        if ((v0_0 >= 30) && (v0_0 < 33)) {
            ((android.view.inputmethod.InputMethodManager) this.getContext().getSystemService("input_method")).isActive(this);
        }
        return;
    }

    public final boolean onDragEvent(android.view.DragEvent p6)
    {
        if ((android.os.Build$VERSION.SDK_INT < 31) && ((p6.getLocalState() == null) && (q0.n0.g(this) != null))) {
            q0.d v0_1 = this.getContext();
            while ((v0_1 instanceof android.content.ContextWrapper)) {
                if (!(v0_1 instanceof android.app.Activity)) {
                    v0_1 = ((android.content.ContextWrapper) v0_1).getBaseContext();
                } else {
                    q0.d v0_2 = ((android.app.Activity) v0_1);
                }
                if (v0_2 != null) {
                    if ((p6.getAction() != 1) && (p6.getAction() == 3)) {
                        v0_2.requestDragAndDropPermissions(p6);
                        q0.d v0_5 = this.getOffsetForPosition(p6.getX(), p6.getY());
                        this.beginBatchEdit();
                        try {
                            q0.d v0_9;
                            android.text.Selection.setSelection(((android.text.Spannable) this.getText()), v0_5);
                            q0.f v6_1 = p6.getClipData();
                        } catch (q0.f v6_2) {
                            this.endBatchEdit();
                            throw v6_2;
                        }
                        if (android.os.Build$VERSION.SDK_INT < 31) {
                            v0_9 = new q0.d();
                            v0_9.h = v6_1;
                            v0_9.i = 3;
                        } else {
                            v0_9 = new l.o(v6_1, 3);
                        }
                        q0.n0.j(this, v0_9.build());
                        this.endBatchEdit();
                        return 1;
                    }
                } else {
                    q0.d v0_12 = new StringBuilder("Can\'t handle drop: no activity: view=");
                    v0_12.append(this);
                    android.util.Log.i("ReceiveContent", v0_12.toString());
                }
            }
            v0_2 = 0;
        }
        return super.onDragEvent(p6);
    }

    public final boolean onTextContextMenuItem(int p7)
    {
        q0.d v0_0 = android.os.Build$VERSION.SDK_INT;
        if ((v0_0 < 31) && ((q0.n0.g(this) != null) && ((p7 == 16908322) || (p7 == 16908337)))) {
            android.content.ClipData v3_3;
            android.content.ClipData v3_2 = ((android.content.ClipboardManager) this.getContext().getSystemService("clipboard"));
            if (v3_2 != null) {
                v3_3 = v3_2.getPrimaryClip();
            } else {
                v3_3 = 0;
            }
            if ((v3_3 != null) && (v3_3.getItemCount() > 0)) {
                q0.d v0_2;
                if (v0_0 < 31) {
                    v0_2 = new q0.d();
                    v0_2.h = v3_3;
                    v0_2.i = 1;
                } else {
                    v0_2 = new l.o(v3_3, 1);
                }
                q0.f v7_1;
                if (p7 != 16908322) {
                    v7_1 = 1;
                } else {
                    v7_1 = 0;
                }
                v0_2.l(v7_1);
                q0.n0.j(this, v0_2.build());
            }
            return 1;
        } else {
            return super.onTextContextMenuItem(p7);
        }
    }

    public void setBackgroundDrawable(android.graphics.drawable.Drawable p1)
    {
        super.setBackgroundDrawable(p1);
        m.p v1_1 = this.g;
        if (v1_1 != null) {
            v1_1.m();
        }
        return;
    }

    public void setBackgroundResource(int p2)
    {
        super.setBackgroundResource(p2);
        m.p v0 = this.g;
        if (v0 != null) {
            v0.n(p2);
        }
        return;
    }

    public final void setCompoundDrawables(android.graphics.drawable.Drawable p1, android.graphics.drawable.Drawable p2, android.graphics.drawable.Drawable p3, android.graphics.drawable.Drawable p4)
    {
        super.setCompoundDrawables(p1, p2, p3, p4);
        m.s0 v1_1 = this.h;
        if (v1_1 != null) {
            v1_1.b();
        }
        return;
    }

    public final void setCompoundDrawablesRelative(android.graphics.drawable.Drawable p1, android.graphics.drawable.Drawable p2, android.graphics.drawable.Drawable p3, android.graphics.drawable.Drawable p4)
    {
        super.setCompoundDrawablesRelative(p1, p2, p3, p4);
        m.s0 v1_1 = this.h;
        if (v1_1 != null) {
            v1_1.b();
        }
        return;
    }

    public void setCustomSelectionActionModeCallback(android.view.ActionMode$Callback p1)
    {
        super.setCustomSelectionActionModeCallback(g6.f0.z(p1, this));
        return;
    }

    public void setEmojiCompatEnabled(boolean p2)
    {
        this.k.d(p2);
        return;
    }

    public final boolean setFontVariationSettings(String p2)
    {
        return this.getFontVariationSettingsManager().a(p2);
    }

    public void setKeyListener(android.text.method.KeyListener p2)
    {
        super.setKeyListener(this.k.a(p2));
        return;
    }

    public void setSupportBackgroundTintList(android.content.res.ColorStateList p2)
    {
        m.p v0 = this.g;
        if (v0 != null) {
            v0.s(p2);
        }
        return;
    }

    public void setSupportBackgroundTintMode(android.graphics.PorterDuff$Mode p2)
    {
        m.p v0 = this.g;
        if (v0 != null) {
            v0.t(p2);
        }
        return;
    }

    public void setSupportCompoundDrawablesTintList(android.content.res.ColorStateList p2)
    {
        m.s0 v0 = this.h;
        v0.n(p2);
        v0.b();
        return;
    }

    public void setSupportCompoundDrawablesTintMode(android.graphics.PorterDuff$Mode p2)
    {
        m.s0 v0 = this.h;
        v0.o(p2);
        v0.b();
        return;
    }

    public final void setTextAppearance(android.content.Context p2, int p3)
    {
        super.setTextAppearance(p2, p3);
        m.s0 v0 = this.h;
        if (v0 != null) {
            v0.i(p2, p3);
        }
        return;
    }

    public void setTextClassifier(android.view.textclassifier.TextClassifier p3)
    {
        if (android.os.Build$VERSION.SDK_INT < 28) {
            androidx.appcompat.widget.AppCompatEditText v0_1 = this.i;
            if (v0_1 != null) {
                v0_1.c = p3;
                return;
            }
        }
        this.getSuperCaller();
        super.setTextClassifier(p3);
        return;
    }

    public void setTypeface(android.graphics.Typeface p3)
    {
        if (android.os.Build$VERSION.SDK_INT < 26) {
            super.setTypeface(p3);
            return;
        } else {
            p0.a v0_1 = this.getFontVariationSettingsManager();
            v0_1.c = p3;
            v0_1.d = p3;
            v0_1.b.accept(p3);
            return;
        }
    }
}
