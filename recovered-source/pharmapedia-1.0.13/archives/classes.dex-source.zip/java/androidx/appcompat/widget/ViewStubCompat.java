// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.appcompat.widget;
public final class ViewStubCompat extends android.view.View {
    public int g;
    public int h;
    public ref.WeakReference i;
    public android.view.LayoutInflater j;

    public ViewStubCompat(android.content.Context p2, android.util.AttributeSet p3)
    {
        this(p2, p3, 0);
        return;
    }

    public ViewStubCompat(android.content.Context p3, android.util.AttributeSet p4, int p5)
    {
        super(p3, p4, p5);
        super.g = 0;
        int v3_2 = p3.obtainStyledAttributes(p4, h.a.z, p5, 0);
        super.h = v3_2.getResourceId(2, -1);
        super.g = v3_2.getResourceId(1, 0);
        super.setId(v3_2.getResourceId(0, -1));
        v3_2.recycle();
        super.setVisibility(8);
        super.setWillNotDraw(1);
        return;
    }

    public final android.view.View a()
    {
        ref.WeakReference v0_0 = this.getParent();
        if (!(v0_0 instanceof android.view.ViewGroup)) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.w("ViewStub must have a non-null ViewGroup viewParent");
        } else {
            if (this.g == 0) {
                com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.u("ViewStub must have a valid layoutResource");
            } else {
                ref.WeakReference v0_2 = ((android.view.ViewGroup) v0_0);
                android.view.View v1_0 = this.j;
                if (v1_0 == null) {
                    v1_0 = android.view.LayoutInflater.from(this.getContext());
                }
                android.view.View v1_3 = v1_0.inflate(this.g, v0_2, 0);
                int v2_1 = this.h;
                if (v2_1 != -1) {
                    v1_3.setId(v2_1);
                }
                int v2_2 = v0_2.indexOfChild(this);
                v0_2.removeViewInLayout(this);
                android.view.ViewGroup$LayoutParams v3_2 = this.getLayoutParams();
                if (v3_2 == null) {
                    v0_2.addView(v1_3, v2_2);
                } else {
                    v0_2.addView(v1_3, v2_2, v3_2);
                }
                this.i = new ref.WeakReference(v1_3);
                return v1_3;
            }
        }
        return 0;
    }

    public final void dispatchDraw(android.graphics.Canvas p1)
    {
        return;
    }

    public final void draw(android.graphics.Canvas p1)
    {
        return;
    }

    public int getInflatedId()
    {
        return this.h;
    }

    public android.view.LayoutInflater getLayoutInflater()
    {
        return this.j;
    }

    public int getLayoutResource()
    {
        return this.g;
    }

    public final void onMeasure(int p1, int p2)
    {
        this.setMeasuredDimension(0, 0);
        return;
    }

    public void setInflatedId(int p1)
    {
        this.h = p1;
        return;
    }

    public void setLayoutInflater(android.view.LayoutInflater p1)
    {
        this.j = p1;
        return;
    }

    public void setLayoutResource(int p1)
    {
        this.g = p1;
        return;
    }

    public void setOnInflateListener(m.n2 p1)
    {
        return;
    }

    public void setVisibility(int p2)
    {
        int v0_0 = this.i;
        if (v0_0 == 0) {
            super.setVisibility(p2);
            if ((p2 != null) && (p2 != 4)) {
                return;
            } else {
                this.a();
                return;
            }
        } else {
            int v0_2 = ((android.view.View) v0_0.get());
            if (v0_2 == 0) {
                com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.w("setVisibility called on un-referenced view");
                return;
            } else {
                v0_2.setVisibility(p2);
                return;
            }
        }
    }
}
