// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.appcompat.widget;
public class AppCompatImageView extends android.widget.ImageView {
    public final m.p g;
    public final dc.i h;
    public boolean i;

    public AppCompatImageView(android.content.Context p2)
    {
        this(p2, 0);
        return;
    }

    public AppCompatImageView(android.content.Context p2, android.util.AttributeSet p3)
    {
        this(p2, p3, 0);
        return;
    }

    public AppCompatImageView(android.content.Context p1, android.util.AttributeSet p2, int p3)
    {
        super(p1, p2, p3);
        super.i = 0;
        m.b2.a(super, super.getContext());
        dc.i v1_6 = new m.p(super);
        super.g = v1_6;
        v1_6.k(p2, p3);
        dc.i v1_3 = new dc.i(super);
        super.h = v1_3;
        v1_3.e(p2, p3);
        return;
    }

    public final void drawableStateChanged()
    {
        super.drawableStateChanged();
        dc.i v0_0 = this.g;
        if (v0_0 != null) {
            v0_0.a();
        }
        dc.i v0_1 = this.h;
        if (v0_1 != null) {
            v0_1.a();
        }
        return;
    }

    public android.content.res.ColorStateList getSupportBackgroundTintList()
    {
        int v0_0 = this.g;
        if (v0_0 == 0) {
            return 0;
        } else {
            return v0_0.h();
        }
    }

    public android.graphics.PorterDuff$Mode getSupportBackgroundTintMode()
    {
        int v0_0 = this.g;
        if (v0_0 == 0) {
            return 0;
        } else {
            return v0_0.i();
        }
    }

    public android.content.res.ColorStateList getSupportImageTintList()
    {
        android.content.res.ColorStateList v0_0 = 0;
        i7.a v1_0 = this.h;
        if (v1_0 != null) {
            i7.a v1_2 = ((i7.a) v1_0.d);
            if (v1_2 != null) {
                v0_0 = ((android.content.res.ColorStateList) v1_2.b);
            }
        }
        return v0_0;
    }

    public android.graphics.PorterDuff$Mode getSupportImageTintMode()
    {
        android.graphics.PorterDuff$Mode v0_0 = 0;
        i7.a v1_0 = this.h;
        if (v1_0 != null) {
            i7.a v1_2 = ((i7.a) v1_0.d);
            if (v1_2 != null) {
                v0_0 = ((android.graphics.PorterDuff$Mode) v1_2.c);
            }
        }
        return v0_0;
    }

    public final boolean hasOverlappingRendering()
    {
        if (((((android.widget.ImageView) this.h.c).getBackground() instanceof android.graphics.drawable.RippleDrawable)) || (!super.hasOverlappingRendering())) {
            return 0;
        } else {
            return 1;
        }
    }

    public void setBackgroundDrawable(android.graphics.drawable.Drawable p1)
    {
        super.setBackgroundDrawable(p1);
        m.p v1_1 = this.g;
        if (v1_1 != null) {
            v1_1.m();
        }
        return;
    }

    public void setBackgroundResource(int p2)
    {
        super.setBackgroundResource(p2);
        m.p v0 = this.g;
        if (v0 != null) {
            v0.n(p2);
        }
        return;
    }

    public void setImageBitmap(android.graphics.Bitmap p1)
    {
        super.setImageBitmap(p1);
        dc.i v1_1 = this.h;
        if (v1_1 != null) {
            v1_1.a();
        }
        return;
    }

    public void setImageDrawable(android.graphics.drawable.Drawable p3)
    {
        int v0_0 = this.h;
        if ((v0_0 != 0) && ((p3 != null) && (!this.i))) {
            v0_0.b = p3.getLevel();
        }
        super.setImageDrawable(p3);
        if (v0_0 != 0) {
            v0_0.a();
            if (!this.i) {
                android.graphics.drawable.Drawable v3_3 = ((android.widget.ImageView) v0_0.c);
                if (v3_3.getDrawable() != null) {
                    v3_3.getDrawable().setLevel(v0_0.b);
                }
            }
        }
        return;
    }

    public void setImageLevel(int p1)
    {
        super.setImageLevel(p1);
        this.i = 1;
        return;
    }

    public void setImageResource(int p4)
    {
        dc.i v0 = this.h;
        if (v0 != null) {
            android.widget.ImageView v1_1 = ((android.widget.ImageView) v0.c);
            if (p4 == 0) {
                v1_1.setImageDrawable(0);
            } else {
                int v4_1 = t6.a.h(v1_1.getContext(), p4);
                if (v4_1 != 0) {
                    m.c1.a(v4_1);
                }
                v1_1.setImageDrawable(v4_1);
            }
            v0.a();
        }
        return;
    }

    public void setImageURI(android.net.Uri p1)
    {
        super.setImageURI(p1);
        dc.i v1_1 = this.h;
        if (v1_1 != null) {
            v1_1.a();
        }
        return;
    }

    public void setSupportBackgroundTintList(android.content.res.ColorStateList p2)
    {
        m.p v0 = this.g;
        if (v0 != null) {
            v0.s(p2);
        }
        return;
    }

    public void setSupportBackgroundTintMode(android.graphics.PorterDuff$Mode p2)
    {
        m.p v0 = this.g;
        if (v0 != null) {
            v0.t(p2);
        }
        return;
    }

    public void setSupportImageTintList(android.content.res.ColorStateList p3)
    {
        dc.i v0 = this.h;
        if (v0 != null) {
            if (((i7.a) v0.d) == null) {
                v0.d = new i7.a();
            }
            i7.a v1_5 = ((i7.a) v0.d);
            v1_5.b = p3;
            v1_5.d = 1;
            v0.a();
        }
        return;
    }

    public void setSupportImageTintMode(android.graphics.PorterDuff$Mode p3)
    {
        dc.i v0 = this.h;
        if (v0 != null) {
            if (((i7.a) v0.d) == null) {
                v0.d = new i7.a();
            }
            i7.a v1_5 = ((i7.a) v0.d);
            v1_5.c = p3;
            v1_5.a = 1;
            v0.a();
        }
        return;
    }
}
