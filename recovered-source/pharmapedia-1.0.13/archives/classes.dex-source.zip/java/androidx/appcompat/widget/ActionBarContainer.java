// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.appcompat.widget;
public class ActionBarContainer extends android.widget.FrameLayout {
    public boolean g;
    public android.view.View h;
    public android.view.View i;
    public android.graphics.drawable.Drawable j;
    public android.graphics.drawable.Drawable k;
    public android.graphics.drawable.Drawable l;
    public final boolean m;
    public boolean n;
    public final int o;

    public ActionBarContainer(android.content.Context p2)
    {
        this(p2, 0);
        return;
    }

    public ActionBarContainer(android.content.Context p4, android.util.AttributeSet p5)
    {
        super(p4, p5);
        super.setBackground(new m.a(super));
        android.graphics.drawable.Drawable v4_5 = p4.obtainStyledAttributes(p5, h.a.a);
        int v5_1 = 0;
        super.j = v4_5.getDrawable(0);
        super.k = v4_5.getDrawable(2);
        super.o = v4_5.getDimensionPixelSize(13, -1);
        if (super.getId() == 2131362363) {
            super.m = 1;
            super.l = v4_5.getDrawable(1);
        }
        v4_5.recycle();
        if (!super.m) {
            if ((super.j == null) && (super.k == null)) {
                v5_1 = 1;
            }
        } else {
            if (super.l == null) {
            }
        }
        super.setWillNotDraw(v5_1);
        return;
    }

    public final void drawableStateChanged()
    {
        super.drawableStateChanged();
        android.graphics.drawable.Drawable v0_0 = this.j;
        if ((v0_0 != null) && (v0_0.isStateful())) {
            this.j.setState(this.getDrawableState());
        }
        android.graphics.drawable.Drawable v0_1 = this.k;
        if ((v0_1 != null) && (v0_1.isStateful())) {
            this.k.setState(this.getDrawableState());
        }
        android.graphics.drawable.Drawable v0_4 = this.l;
        if ((v0_4 != null) && (v0_4.isStateful())) {
            this.l.setState(this.getDrawableState());
        }
        return;
    }

    public android.view.View getTabContainer()
    {
        return 0;
    }

    public final void jumpDrawablesToCurrentState()
    {
        super.jumpDrawablesToCurrentState();
        android.graphics.drawable.Drawable v0_0 = this.j;
        if (v0_0 != null) {
            v0_0.jumpToCurrentState();
        }
        android.graphics.drawable.Drawable v0_1 = this.k;
        if (v0_1 != null) {
            v0_1.jumpToCurrentState();
        }
        android.graphics.drawable.Drawable v0_2 = this.l;
        if (v0_2 != null) {
            v0_2.jumpToCurrentState();
        }
        return;
    }

    public final void onFinishInflate()
    {
        super.onFinishInflate();
        this.h = this.findViewById(2131361850);
        this.i = this.findViewById(2131361858);
        return;
    }

    public final boolean onHoverEvent(android.view.MotionEvent p1)
    {
        super.onHoverEvent(p1);
        return 1;
    }

    public final boolean onInterceptTouchEvent(android.view.MotionEvent p2)
    {
        if ((!this.g) && (!super.onInterceptTouchEvent(p2))) {
            return 0;
        } else {
            return 1;
        }
    }

    public final void onLayout(boolean p2, int p3, int p4, int p5, int p6)
    {
        this = super.onLayout(p2, p3, p4, p5, p6);
        int v4_1 = 1;
        if (!this.m) {
            if (this.j == null) {
                v4_1 = 0;
            } else {
                if (this.h.getVisibility() != 0) {
                    android.graphics.drawable.Drawable v3_2 = this.i;
                    if ((v3_2 == null) || (v3_2.getVisibility() != 0)) {
                        this.j.setBounds(0, 0, 0, 0);
                        this.n = 0;
                        if (v4_1 != 0) {
                            this.invalidate();
                        }
                        return;
                    }
                }
                this.j.setBounds(0, 0, this.getMeasuredWidth(), this.getMeasuredHeight());
            }
        } else {
            android.graphics.drawable.Drawable v3_7 = this.l;
            if (v3_7 == null) {
                v4_1 = 0;
            } else {
                v3_7.setBounds(0, 0, this.getMeasuredWidth(), this.getMeasuredHeight());
            }
        }
    }

    public final void onMeasure(int p3, int p4)
    {
        if ((this.h == null) && (android.view.View$MeasureSpec.getMode(p4) == -2147483648)) {
            int v0_2 = this.o;
            if (v0_2 >= 0) {
                p4 = android.view.View$MeasureSpec.makeMeasureSpec(Math.min(v0_2, android.view.View$MeasureSpec.getSize(p4)), -2147483648);
            }
        }
        super.onMeasure(p3, p4);
        if (this.h != null) {
            android.view.View$MeasureSpec.getMode(p4);
            return;
        } else {
            return;
        }
    }

    public final boolean onTouchEvent(android.view.MotionEvent p1)
    {
        super.onTouchEvent(p1);
        return 1;
    }

    public void setPrimaryBackground(android.graphics.drawable.Drawable p4)
    {
        int v0_0 = this.j;
        if (v0_0 != 0) {
            v0_0.setCallback(0);
            this.unscheduleDrawable(this.j);
        }
        this.j = p4;
        int v0_1 = 0;
        if (p4 != null) {
            p4.setCallback(this);
            if (this.h != null) {
                p4.setBounds(0, 0, this.getMeasuredWidth(), this.getMeasuredHeight());
            }
        }
        if (!this.m) {
            if ((this.j == null) && (this.k == null)) {
                v0_1 = 1;
            }
        } else {
            if (this.l == null) {
            }
        }
        this.setWillNotDraw(v0_1);
        this.invalidate();
        this.invalidateOutline();
        return;
    }

    public void setSplitBackground(android.graphics.drawable.Drawable p5)
    {
        android.graphics.drawable.Drawable v0_0 = this.l;
        if (v0_0 != null) {
            v0_0.setCallback(0);
            this.unscheduleDrawable(this.l);
        }
        this.l = p5;
        android.graphics.drawable.Drawable v0_5 = this.m;
        android.graphics.drawable.Drawable v1_1 = 0;
        if (p5 != null) {
            p5.setCallback(this);
            if (v0_5 != null) {
                android.graphics.drawable.Drawable v5_1 = this.l;
                if (v5_1 != null) {
                    v5_1.setBounds(0, 0, this.getMeasuredWidth(), this.getMeasuredHeight());
                }
            }
        }
        if (v0_5 == null) {
            if ((this.j == null) && (this.k == null)) {
                v1_1 = 1;
            }
        } else {
            if (this.l == null) {
            }
        }
        this.setWillNotDraw(v1_1);
        this.invalidate();
        this.invalidateOutline();
        return;
    }

    public void setStackedBackground(android.graphics.drawable.Drawable p3)
    {
        int v0_0 = this.k;
        if (v0_0 != 0) {
            v0_0.setCallback(0);
            this.unscheduleDrawable(this.k);
        }
        this.k = p3;
        if (p3 != null) {
            p3.setCallback(this);
            if ((this.n) && (this.k != null)) {
                throw 0;
            }
        }
        int v0_1 = 0;
        if (!this.m) {
            if ((this.j == null) && (this.k == null)) {
                v0_1 = 1;
            }
        } else {
            if (this.l == null) {
            }
        }
        this.setWillNotDraw(v0_1);
        this.invalidate();
        this.invalidateOutline();
        return;
    }

    public void setTabContainer(m.z1 p1)
    {
        return;
    }

    public void setTransitioning(boolean p1)
    {
        int v1_1;
        this.g = p1;
        if (p1 == 0) {
            v1_1 = 262144;
        } else {
            v1_1 = 393216;
        }
        this.setDescendantFocusability(v1_1);
        return;
    }

    public void setVisibility(int p3)
    {
        int v3_1;
        super.setVisibility(p3);
        if (p3 != 0) {
            v3_1 = 0;
        } else {
            v3_1 = 1;
        }
        android.graphics.drawable.Drawable v1_1 = this.j;
        if (v1_1 != null) {
            v1_1.setVisible(v3_1, 0);
        }
        android.graphics.drawable.Drawable v1_2 = this.k;
        if (v1_2 != null) {
            v1_2.setVisible(v3_1, 0);
        }
        android.graphics.drawable.Drawable v1_0 = this.l;
        if (v1_0 != null) {
            v1_0.setVisible(v3_1, 0);
        }
        return;
    }

    public final android.view.ActionMode startActionModeForChild(android.view.View p1, android.view.ActionMode$Callback p2)
    {
        return 0;
    }

    public final android.view.ActionMode startActionModeForChild(android.view.View p1, android.view.ActionMode$Callback p2, int p3)
    {
        if (p3 == 0) {
            return 0;
        } else {
            return super.startActionModeForChild(p1, p2, p3);
        }
    }

    public final boolean verifyDrawable(android.graphics.drawable.Drawable p3)
    {
        boolean v1 = this.m;
        if (((p3 != this.j) || (v1)) && (((p3 != this.k) || (!this.n)) && (((p3 != this.l) || (!v1)) && (!super.verifyDrawable(p3))))) {
            return 0;
        } else {
            return 1;
        }
    }
}
