// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.appcompat.widget;
public class FitWindowsLinearLayout extends android.widget.LinearLayout {

    public FitWindowsLinearLayout(android.content.Context p1)
    {
        super(p1);
        return;
    }

    public FitWindowsLinearLayout(android.content.Context p1, android.util.AttributeSet p2)
    {
        super(p1, p2);
        return;
    }

    public final boolean fitSystemWindows(android.graphics.Rect p1)
    {
        return super.fitSystemWindows(p1);
    }

    public void setOnFitSystemWindowsListener(m.h1 p1)
    {
        return;
    }
}
