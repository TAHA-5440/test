// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.appcompat.widget;
public class ActionBarContextView extends android.view.ViewGroup {
    public int A;
    public int B;
    public int C;
    public int D;
    public int E;
    public int F;
    public int G;
    public final e7.m g;
    public final android.content.Context h;
    public androidx.appcompat.widget.ActionMenuView i;
    public m.k j;
    public int k;
    public q0.q0 l;
    public boolean m;
    public boolean n;
    public CharSequence o;
    public CharSequence p;
    public android.view.View q;
    public android.view.View r;
    public android.view.View s;
    public android.widget.LinearLayout t;
    public android.widget.TextView u;
    public android.widget.TextView v;
    public final int w;
    public final int x;
    public boolean y;
    public final int z;

    public ActionBarContextView(android.content.Context p2)
    {
        this(p2, 0);
        return;
    }

    public ActionBarContextView(android.content.Context p2, android.util.AttributeSet p3)
    {
        this(p2, p3, 2130968606);
        return;
    }

    public ActionBarContextView(android.content.Context p5, android.util.AttributeSet p6, int p7)
    {
        super(p5, p6, p7);
        super.g = new e7.m(super);
        int[] v0_5 = new android.util.TypedValue();
        if ((!p5.getTheme().resolveAttribute(2130968580, v0_5, 1)) || (v0_5.resourceId == 0)) {
            super.h = p5;
        } else {
            super.h = new android.view.ContextThemeWrapper(p5, v0_5.resourceId);
        }
        int v5_1;
        android.content.res.TypedArray v6_1 = p5.obtainStyledAttributes(p6, h.a.d, p7, 0);
        if (!v6_1.hasValue(0)) {
            v5_1 = v6_1.getDrawable(0);
        } else {
            int v7_2 = v6_1.getResourceId(0, 0);
            if (v7_2 == 0) {
            } else {
                v5_1 = t6.a.h(p5, v7_2);
            }
        }
        super.setBackground(v5_1);
        super.w = v6_1.getResourceId(5, 0);
        super.x = v6_1.getResourceId(4, 0);
        super.k = v6_1.getLayoutDimension(3, 0);
        super.z = v6_1.getResourceId(2, 2131558405);
        v6_1.recycle();
        super.D = super.getPaddingLeft();
        super.E = super.getPaddingTop();
        super.F = super.getPaddingRight();
        super.G = super.getPaddingBottom();
        return;
    }

    public static synthetic void a(androidx.appcompat.widget.ActionBarContextView p1)
    {
        super.setVisibility(0);
        return;
    }

    public static synthetic void b(androidx.appcompat.widget.ActionBarContextView p0, int p1)
    {
        super.setVisibility(p1);
        return;
    }

    public static int f(android.view.View p1, int p2, int p3)
    {
        p1.measure(android.view.View$MeasureSpec.makeMeasureSpec(p2, -2147483648), p3);
        return Math.max(0, (p2 - p1.getMeasuredWidth()));
    }

    public static int h(int p2, int p3, int p4, android.view.View p5, boolean p6)
    {
        int v0 = p5.getMeasuredWidth();
        int v1_1 = p5.getMeasuredHeight();
        int v4_3 = (((p4 - v1_1) / 2) + p3);
        if (!p6) {
            p5.layout(p2, v4_3, (p2 + v0), (v1_1 + v4_3));
        } else {
            p5.layout((p2 - v0), v4_3, p2, (v1_1 + v4_3));
        }
        if (!p6) {
            return v0;
        } else {
            return (- v0);
        }
    }

    public final void c(k.a p7)
    {
        l.v v0_0 = this.q;
        if (v0_0 != null) {
            if (v0_0.getParent() == null) {
                this.addView(this.q);
            }
        } else {
            l.v v0_2 = android.view.LayoutInflater.from(this.getContext()).inflate(this.z, this, 0);
            this.q = v0_2;
            this.addView(v0_2);
        }
        l.v v0_4 = this.q.findViewById(2131361865);
        this.r = v0_4;
        v0_4.setOnClickListener(new i.a(p7, 2));
        androidx.appcompat.widget.ActionMenuView v7_1 = p7.c();
        l.v v0_5 = this.j;
        if (v0_5 != null) {
            v0_5.f();
            l.v v0_6 = v0_5.A;
            if ((v0_6 != null) && (v0_6.b())) {
                v0_6.j.dismiss();
            }
        }
        l.v v0_10 = new m.k(this.getContext());
        this.j = v0_10;
        v0_10.s = 1;
        v0_10.t = 1;
        l.v v0_12 = new android.view.ViewGroup$LayoutParams(-2, -1);
        v7_1.b(this.j, this.h);
        androidx.appcompat.widget.ActionMenuView v7_2 = this.j;
        l.b0 v3_3 = v7_2.n;
        if (v3_3 == null) {
            androidx.appcompat.widget.ActionMenuView v1_2 = ((l.b0) v7_2.j.inflate(v7_2.l, this, 0));
            v7_2.n = v1_2;
            v1_2.b(v7_2.i);
            v7_2.d(1);
        }
        androidx.appcompat.widget.ActionMenuView v1_3 = v7_2.n;
        if (v3_3 != v1_3) {
            ((androidx.appcompat.widget.ActionMenuView) v1_3).setPresenter(v7_2);
        }
        androidx.appcompat.widget.ActionMenuView v1_4 = ((androidx.appcompat.widget.ActionMenuView) v1_3);
        this.i = v1_4;
        v1_4.setBackground(0);
        this.addView(this.i, v0_12);
        return;
    }

    public final void d()
    {
        if (this.t == null) {
            android.view.LayoutInflater.from(this.getContext()).inflate(2131558400, this);
            android.widget.LinearLayout v0_3 = ((android.widget.LinearLayout) this.getChildAt((this.getChildCount() - 1)));
            this.t = v0_3;
            this.u = ((android.widget.TextView) v0_3.findViewById(2131361856));
            this.v = ((android.widget.TextView) this.t.findViewById(2131361855));
            android.widget.LinearLayout v0_9 = this.w;
            if (v0_9 != null) {
                this.u.setTextAppearance(this.getContext(), v0_9);
            }
            android.widget.LinearLayout v0_11 = this.x;
            if (v0_11 != null) {
                this.v.setTextAppearance(this.getContext(), v0_11);
            }
        }
        int v5;
        this.u.setText(this.o);
        this.v.setText(this.p);
        android.widget.LinearLayout v0_15 = android.text.TextUtils.isEmpty(this.o);
        android.widget.TextView v1_7 = android.text.TextUtils.isEmpty(this.p);
        int v3 = 8;
        if (v1_7 != null) {
            v5 = 8;
        } else {
            v5 = 0;
        }
        this.v.setVisibility(v5);
        if ((v0_15 == null) || (v1_7 == null)) {
            v3 = 0;
        }
        this.t.setVisibility(v3);
        if (this.t.getParent() == null) {
            this.addView(this.t);
        }
        return;
    }

    public final void e()
    {
        this.removeAllViews();
        this.s = 0;
        this.i = 0;
        this.j = 0;
        android.view.View v1 = this.r;
        if (v1 != null) {
            v1.setOnClickListener(0);
        }
        return;
    }

    public final void g(android.content.res.Configuration p5)
    {
        super.onConfigurationChanged(p5);
        l.m v5_4 = this.getContext().obtainStyledAttributes(0, h.a.a, 2130968583, 0);
        this.setContentHeight(v5_4.getLayoutDimension(13, 0));
        v5_4.recycle();
        l.m v5_1 = this.j;
        if (v5_1 != null) {
            int v0_10;
            int v0_3 = v5_1.h.getResources().getConfiguration();
            int v1_0 = v0_3.screenWidthDp;
            int v2_0 = v0_3.screenHeightDp;
            if (((v0_3.smallestScreenWidthDp <= 600) && ((v1_0 <= 600) && ((v1_0 <= 960) || (v2_0 <= 720)))) && ((v1_0 <= 720) || (v2_0 <= 960))) {
                if (((v1_0 < 500) && ((v1_0 <= 640) || (v2_0 <= 480))) && ((v1_0 <= 480) || (v2_0 <= 640))) {
                    if (v1_0 < 360) {
                        v0_10 = 2;
                    } else {
                        v0_10 = 3;
                    }
                } else {
                    v0_10 = 4;
                }
            } else {
                v0_10 = 5;
            }
            v5_1.w = v0_10;
            l.m v5_3 = v5_1.i;
            if (v5_3 != null) {
                v5_3.p(1);
            }
        }
        return;
    }

    public final android.view.ViewGroup$LayoutParams generateDefaultLayoutParams()
    {
        return new android.view.ViewGroup$MarginLayoutParams(-1, -2);
    }

    public final android.view.ViewGroup$LayoutParams generateLayoutParams(android.util.AttributeSet p3)
    {
        return new android.view.ViewGroup$MarginLayoutParams(this.getContext(), p3);
    }

    public int getAnimatedVisibility()
    {
        if (this.l == null) {
            return this.getVisibility();
        } else {
            return this.g.i;
        }
    }

    public int getContentHeight()
    {
        return this.k;
    }

    public CharSequence getSubtitle()
    {
        return this.p;
    }

    public CharSequence getTitle()
    {
        return this.o;
    }

    public final void i(int p2)
    {
        if (p2 != this.getVisibility()) {
            q0.q0 v0_1 = this.l;
            if (v0_1 != null) {
                v0_1.b();
            }
            super.setVisibility(p2);
        }
        return;
    }

    public final q0.q0 j(int p4, long p5)
    {
        e7.m v0_0 = this.l;
        if (v0_0 != null) {
            v0_0.b();
        }
        e7.m v0_1 = this.g;
        if (p4 != 0) {
            int v2_2 = q0.n0.a(this);
            v2_2.a(0);
            v2_2.c(p5);
            ((androidx.appcompat.widget.ActionBarContextView) v0_1.j).l = v2_2;
            v0_1.i = p4;
            v2_2.d(v0_1);
            return v2_2;
        } else {
            if (this.getVisibility() != 0) {
                this.setAlpha(0);
            }
            q0.q0 v1_0 = q0.n0.a(this);
            v1_0.a(1065353216);
            v1_0.c(p5);
            ((androidx.appcompat.widget.ActionBarContextView) v0_1.j).l = v1_0;
            v0_1.i = p4;
            v1_0.d(v0_1);
            return v1_0;
        }
    }

    public final void k()
    {
        super.setPadding((this.A + this.D), (this.B + this.E), (this.C + this.F), this.G);
        return;
    }

    public final void onConfigurationChanged(android.content.res.Configuration p5)
    {
        this.g(p5);
        android.content.res.TypedArray v5_2 = this.getContext().obtainStyledAttributes(0, h.a.d, 2130968606, 0);
        this.setContentHeight(v5_2.getLayoutDimension(3, 0));
        v5_2.recycle();
        return;
    }

    public final void onDetachedFromWindow()
    {
        super.onDetachedFromWindow();
        l.v v0_0 = this.j;
        if (v0_0 != null) {
            v0_0.f();
            l.v v0_3 = this.j.A;
            if ((v0_3 != null) && (v0_3.b())) {
                v0_3.j.dismiss();
            }
        }
        return;
    }

    public final boolean onHoverEvent(android.view.MotionEvent p6)
    {
        int v0 = p6.getActionMasked();
        if (v0 == 9) {
            this.n = 0;
        }
        if (!this.n) {
            int v6_1 = super.onHoverEvent(p6);
            if ((v0 == 9) && (v6_1 == 0)) {
                this.n = 1;
            }
        }
        if ((v0 != 10) && (v0 != 3)) {
            return 1;
        } else {
            this.n = 0;
            return 1;
        }
    }

    public final void onLayout(boolean p6, int p7, int p8, int p9, int p10)
    {
        int v6_1;
        if (this.getLayoutDirection() != 1) {
            v6_1 = 0;
        } else {
            v6_1 = 1;
        }
        int v1_1;
        if (v6_1 == 0) {
            v1_1 = this.getPaddingLeft();
        } else {
            v1_1 = ((p9 - p7) - this.getPaddingRight());
        }
        int v2_1 = this.getPaddingTop();
        int v10_3 = (((p10 - p8) - this.getPaddingTop()) - this.getPaddingBottom());
        androidx.appcompat.widget.ActionMenuView v8_3 = this.q;
        if ((v8_3 != null) && (v8_3.getVisibility() != 8)) {
            int v4_0;
            androidx.appcompat.widget.ActionMenuView v8_7 = ((android.view.ViewGroup$MarginLayoutParams) this.q.getLayoutParams());
            if (v6_1 == 0) {
                v4_0 = v8_7.leftMargin;
            } else {
                v4_0 = v8_7.rightMargin;
            }
            androidx.appcompat.widget.ActionMenuView v8_8;
            if (v6_1 == 0) {
                v8_8 = v8_7.rightMargin;
            } else {
                v8_8 = v8_7.leftMargin;
            }
            int v1_2;
            if (v6_1 == 0) {
                v1_2 = (v1_1 + v4_0);
            } else {
                v1_2 = (v1_1 - v4_0);
            }
            int v4_4;
            int v4_3 = (androidx.appcompat.widget.ActionBarContextView.h(v1_2, v2_1, v10_3, this.q, v6_1) + v1_2);
            if (v6_1 == 0) {
                v4_4 = (v4_3 + v8_8);
            } else {
                v4_4 = (v4_3 - v8_8);
            }
            v1_1 = v4_4;
        }
        androidx.appcompat.widget.ActionMenuView v8_9 = this.t;
        if ((v8_9 != null) && ((this.s == null) && (v8_9.getVisibility() != 8))) {
            v1_1 += androidx.appcompat.widget.ActionBarContextView.h(v1_1, v2_1, v10_3, this.t, v6_1);
        }
        androidx.appcompat.widget.ActionMenuView v8_13 = this.s;
        if (v8_13 != null) {
            androidx.appcompat.widget.ActionBarContextView.h(v1_1, v2_1, v10_3, v8_13, v6_1);
        }
        int v7_2;
        if (v6_1 == 0) {
            v7_2 = ((p9 - p7) - this.getPaddingRight());
        } else {
            v7_2 = this.getPaddingLeft();
        }
        androidx.appcompat.widget.ActionMenuView v8_14 = this.i;
        if (v8_14 != null) {
            androidx.appcompat.widget.ActionBarContextView.h(v7_2, v2_1, v10_3, v8_14, (v6_1 ^ 1));
        }
        return;
    }

    public final void onMeasure(int p11, int p12)
    {
        int v1_0 = 1073741824;
        if (android.view.View$MeasureSpec.getMode(p11) != 1073741824) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.w(this.getClass().getSimpleName().concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
            return;
        } else {
            if (android.view.View$MeasureSpec.getMode(p12) == 0) {
                com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.w(this.getClass().getSimpleName().concat(" can only be used with android:layout_height=\"wrap_content\""));
                return;
            } else {
                int v2_3;
                String v11_5 = android.view.View$MeasureSpec.getSize(p11);
                int v0_1 = ((v11_5 - this.getPaddingLeft()) - this.getPaddingRight());
                int v3_1 = (this.getPaddingBottom() + this.getPaddingTop());
                int v2_2 = this.k;
                if (v2_2 <= 0) {
                    v2_3 = android.view.View$MeasureSpec.getSize(p12);
                } else {
                    v2_3 = (v2_2 + this.B);
                }
                int v12_1 = (v2_3 - v3_1);
                android.widget.LinearLayout v5_1 = android.view.View$MeasureSpec.makeMeasureSpec(v12_1, -2147483648);
                int v6_0 = this.q;
                if (v6_0 != 0) {
                    int v6_3 = ((android.view.ViewGroup$MarginLayoutParams) this.q.getLayoutParams());
                    v0_1 = (androidx.appcompat.widget.ActionBarContextView.f(v6_0, v0_1, v5_1) - (v6_3.leftMargin + v6_3.rightMargin));
                }
                int v6_5 = this.i;
                if ((v6_5 != 0) && (v6_5.getParent() == this)) {
                    v0_1 = androidx.appcompat.widget.ActionBarContextView.f(this.i, v0_1, v5_1);
                }
                int v6_8 = this.t;
                int v7_0 = 0;
                if ((v6_8 != 0) && (this.s == null)) {
                    if (!this.y) {
                        v0_1 = androidx.appcompat.widget.ActionBarContextView.f(v6_8, v0_1, v5_1);
                    } else {
                        int v6_10;
                        this.t.measure(android.view.View$MeasureSpec.makeMeasureSpec(0, 0), v5_1);
                        android.widget.LinearLayout v5_3 = this.t.getMeasuredWidth();
                        if (v5_3 > v0_1) {
                            v6_10 = 0;
                        } else {
                            v6_10 = 1;
                        }
                        if (v6_10 != 0) {
                            v0_1 -= v5_3;
                        }
                        int v6_11;
                        if (v6_10 == 0) {
                            v6_11 = 8;
                        } else {
                            v6_11 = 0;
                        }
                        this.t.setVisibility(v6_11);
                    }
                }
                android.widget.LinearLayout v5_5 = this.s;
                if (v5_5 != null) {
                    int v9;
                    android.widget.LinearLayout v5_6 = v5_5.getLayoutParams();
                    int v6_12 = v5_6.width;
                    if (v6_12 == -2) {
                        v9 = -2147483648;
                    } else {
                        v9 = 1073741824;
                    }
                    if (v6_12 >= 0) {
                        v0_1 = Math.min(v6_12, v0_1);
                    }
                    android.widget.LinearLayout v5_0 = v5_6.height;
                    if (v5_0 == -2) {
                        v1_0 = -2147483648;
                    }
                    if (v5_0 >= null) {
                        v12_1 = Math.min(v5_0, v12_1);
                    }
                    this.s.measure(android.view.View$MeasureSpec.makeMeasureSpec(v0_1, v9), android.view.View$MeasureSpec.makeMeasureSpec(v12_1, v1_0));
                }
                if (this.k > 0) {
                    this.setMeasuredDimension(v11_5, v2_3);
                    return;
                } else {
                    int v12_4 = this.getChildCount();
                    int v0_3 = 0;
                    while (v7_0 < v12_4) {
                        int v1_3 = (this.getChildAt(v7_0).getMeasuredHeight() + v3_1);
                        if (v1_3 > v0_3) {
                            v0_3 = v1_3;
                        }
                        v7_0++;
                    }
                    this.setMeasuredDimension(v11_5, v0_3);
                    return;
                }
            }
        }
    }

    public final boolean onTouchEvent(android.view.MotionEvent p5)
    {
        int v0 = p5.getActionMasked();
        if (v0 == 0) {
            this.m = 0;
        }
        if (!this.m) {
            int v5_2 = super.onTouchEvent(p5);
            if ((v0 == 0) && (v5_2 == 0)) {
                this.m = 1;
            }
        }
        if ((v0 != 1) && (v0 != 3)) {
            return 1;
        } else {
            this.m = 0;
            return 1;
        }
    }

    public void setContentHeight(int p1)
    {
        this.k = p1;
        return;
    }

    public void setCustomView(android.view.View p2)
    {
        int v0_0 = this.s;
        if (v0_0 != 0) {
            this.removeView(v0_0);
        }
        this.s = p2;
        if (p2 != null) {
            int v0_1 = this.t;
            if (v0_1 != 0) {
                this.removeView(v0_1);
                this.t = 0;
            }
        }
        if (p2 != null) {
            this.addView(p2);
        }
        this.requestLayout();
        return;
    }

    public final void setPadding(int p1, int p2, int p3, int p4)
    {
        this.D = p1;
        this.E = p2;
        this.F = p3;
        this.G = p4;
        this.k();
        return;
    }

    public final void setPaddingRelative(int p3, int p4, int p5, int p6)
    {
        if (this.getLayoutDirection() == 1) {
            this.D = p5;
            this.F = p3;
        } else {
            this.D = p3;
            this.F = p5;
        }
        this.E = p4;
        this.G = p6;
        this.k();
        return;
    }

    public void setSubtitle(CharSequence p1)
    {
        this.p = p1;
        this.d();
        return;
    }

    public void setTitle(CharSequence p1)
    {
        this.o = p1;
        this.d();
        q0.n0.o(this, p1);
        return;
    }

    public void setTitleOptional(boolean p2)
    {
        if (p2 != this.y) {
            this.requestLayout();
        }
        this.y = p2;
        return;
    }

    public bridge synthetic void setVisibility(int p1)
    {
        this.i(p1);
        return;
    }

    public final boolean shouldDelayChildPressedState()
    {
        return 0;
    }
}
