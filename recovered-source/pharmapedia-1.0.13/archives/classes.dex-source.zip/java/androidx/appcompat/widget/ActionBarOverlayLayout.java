// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.appcompat.widget;
public class ActionBarOverlayLayout extends android.view.ViewGroup implements q0.q, q0.r {
    public static final int[] L;
    public static final q0.o1 M;
    public static final android.graphics.Rect N;
    public q0.o1 A;
    public q0.o1 B;
    public q0.o1 C;
    public m.c D;
    public android.widget.OverScroller E;
    public android.view.ViewPropertyAnimator F;
    public final e5.b G;
    public final m.b H;
    public final m.b I;
    public final m6.b J;
    public final m.e K;
    public int g;
    public int h;
    public androidx.appcompat.widget.ContentFrameLayout i;
    public androidx.appcompat.widget.ActionBarContainer j;
    public m.b1 k;
    public android.graphics.drawable.Drawable l;
    public boolean m;
    public boolean n;
    public boolean o;
    public boolean p;
    public int q;
    public int r;
    public final android.graphics.Rect s;
    public final android.graphics.Rect t;
    public final android.graphics.Rect u;
    public final android.graphics.Rect v;
    public final android.graphics.Rect w;
    public boolean x;
    public boolean y;
    public q0.o1 z;

    static ActionBarOverlayLayout()
    {
        q0.a1 v0_2;
        androidx.appcompat.widget.ActionBarOverlayLayout.L = new int[] {2130968581, 16842841});
        q0.a1 v0_10 = android.os.Build$VERSION.SDK_INT;
        if (v0_10 < 34) {
            if (v0_10 < 30) {
                if (v0_10 < 29) {
                    v0_2 = new q0.a1();
                } else {
                    v0_2 = new q0.b1();
                }
            } else {
                v0_2 = new q0.c1();
            }
        } else {
            v0_2 = new q0.d1();
        }
        v0_2.g(i0.c.c(0, 1, 0, 1));
        androidx.appcompat.widget.ActionBarOverlayLayout.M = v0_2.b();
        androidx.appcompat.widget.ActionBarOverlayLayout.N = new android.graphics.Rect();
        return;
    }

    public ActionBarOverlayLayout(android.content.Context p2)
    {
        this(p2, 0);
        return;
    }

    public ActionBarOverlayLayout(android.content.Context p3, android.util.AttributeSet p4)
    {
        super(p3, p4);
        super.h = 0;
        super.s = new android.graphics.Rect();
        super.t = new android.graphics.Rect();
        super.u = new android.graphics.Rect();
        super.v = new android.graphics.Rect();
        super.w = new android.graphics.Rect();
        super.x = 1;
        super.y = 0;
        m.e v4_2 = q0.o1.b;
        super.z = v4_2;
        super.A = v4_2;
        super.B = v4_2;
        super.C = v4_2;
        super.G = new e5.b(super, 3);
        super.H = new m.b(super, 0);
        super.I = new m.b(super, 1);
        super.h(p3);
        super.J = new m6.b();
        m.e v4_12 = new m.e(p3);
        v4_12.setWillNotDraw(1);
        super.K = v4_12;
        super.addView(v4_12);
        return;
    }

    public static boolean k(android.view.View p2, int p3, int p4, int p5, int p6)
    {
        int v3_1;
        m.d v2_2 = ((m.d) p2.getLayoutParams());
        if (v2_2.leftMargin == p3) {
            v3_1 = 0;
        } else {
            v2_2.leftMargin = p3;
            v3_1 = 1;
        }
        if (v2_2.topMargin != p4) {
            v2_2.topMargin = p4;
            v3_1 = 1;
        }
        if (v2_2.rightMargin != p5) {
            v2_2.rightMargin = p5;
            v3_1 = 1;
        }
        if (v2_2.bottomMargin == p6) {
            return v3_1;
        } else {
            v2_2.bottomMargin = p6;
            return 1;
        }
    }

    public final void a(android.view.View p1, int p2, int p3, int p4, int p5, int p6, int[] p7)
    {
        this.b(p1, p2, p3, p4, p5, p6);
        return;
    }

    public final void b(android.view.View p1, int p2, int p3, int p4, int p5, int p6)
    {
        if (p6 == 0) {
            this.onNestedScroll(p1, p2, p3, p4, p5);
        }
        return;
    }

    public final boolean c(android.view.View p1, android.view.View p2, int p3, int p4)
    {
        if ((p4 != 0) || (!this.onStartNestedScroll(p1, p2, p3))) {
            return 0;
        } else {
            return 1;
        }
    }

    public final boolean checkLayoutParams(android.view.ViewGroup$LayoutParams p1)
    {
        return (p1 instanceof m.d);
    }

    public final void d(android.view.View p1, android.view.View p2, int p3, int p4)
    {
        if (p4 == 0) {
            this.onNestedScrollAccepted(p1, p2, p3);
        }
        return;
    }

    public final void draw(android.graphics.Canvas p6)
    {
        super.draw(p6);
        if (this.l != null) {
            android.graphics.drawable.Drawable v0_4;
            if (this.j.getVisibility() != 0) {
                v0_4 = 0;
            } else {
                v0_4 = ((int) ((this.j.getTranslationY() + ((float) this.j.getBottom())) + 1056964608));
            }
            this.l.setBounds(0, v0_4, this.getWidth(), (this.l.getIntrinsicHeight() + v0_4));
            this.l.draw(p6);
        }
        return;
    }

    public final void e(android.view.View p1, int p2)
    {
        if (p2 == 0) {
            this.onStopNestedScroll(p1);
        }
        return;
    }

    public final void f(android.view.View p1, int p2, int p3, int[] p4, int p5)
    {
        return;
    }

    public final void g()
    {
        this.removeCallbacks(this.H);
        this.removeCallbacks(this.I);
        android.view.ViewPropertyAnimator v0_2 = this.F;
        if (v0_2 != null) {
            v0_2.cancel();
        }
        return;
    }

    public final android.view.ViewGroup$LayoutParams generateDefaultLayoutParams()
    {
        return new m.d(-1, -1);
    }

    public final android.view.ViewGroup$LayoutParams generateLayoutParams(android.util.AttributeSet p3)
    {
        return new m.d(this.getContext(), p3);
    }

    public final android.view.ViewGroup$LayoutParams generateLayoutParams(android.view.ViewGroup$LayoutParams p2)
    {
        return new m.d(p2);
    }

    public int getActionBarHideOffset()
    {
        int v0_0 = this.j;
        if (v0_0 == 0) {
            return 0;
        } else {
            return (- ((int) v0_0.getTranslationY()));
        }
    }

    public int getNestedScrollAxes()
    {
        int v0_0 = this.J;
        return (v0_0.b | v0_0.a);
    }

    public CharSequence getTitle()
    {
        this.j();
        return ((m.j2) this.k).a.getTitle();
    }

    public final void h(android.content.Context p5)
    {
        android.widget.OverScroller v0_4 = this.getContext().getTheme().obtainStyledAttributes(androidx.appcompat.widget.ActionBarOverlayLayout.L);
        int v1_0 = 0;
        this.g = v0_4.getDimensionPixelSize(0, 0);
        android.graphics.drawable.Drawable v3 = v0_4.getDrawable(1);
        this.l = v3;
        if (v3 == null) {
            v1_0 = 1;
        }
        this.setWillNotDraw(v1_0);
        v0_4.recycle();
        this.E = new android.widget.OverScroller(p5);
        return;
    }

    public final void i(int p4)
    {
        this.j();
        if (p4 == 2) {
            ((m.j2) this.k).getClass();
            android.util.Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
            return;
        } else {
            if (p4 == 5) {
                ((m.j2) this.k).getClass();
                android.util.Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
                return;
            } else {
                if (p4 == 109) {
                    this.setOverlayMode(1);
                    return;
                } else {
                    return;
                }
            }
        }
    }

    public final void j()
    {
        if (this.i == null) {
            String v0_9;
            this.i = ((androidx.appcompat.widget.ContentFrameLayout) this.findViewById(2131361851));
            this.j = ((androidx.appcompat.widget.ActionBarContainer) this.findViewById(2131361852));
            String v0_3 = this.findViewById(2131361850);
            if (!(v0_3 instanceof m.b1)) {
                if (!(v0_3 instanceof androidx.appcompat.widget.Toolbar)) {
                    com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.w("Can\'t make a decor toolbar out of ".concat(v0_3.getClass().getSimpleName()));
                    return;
                } else {
                    v0_9 = ((androidx.appcompat.widget.Toolbar) v0_3).getWrapper();
                }
            } else {
                v0_9 = ((m.b1) v0_3);
            }
            this.k = v0_9;
            return;
        }
        return;
    }

    public final void l(android.view.Menu p5, l.y p6)
    {
        this.j();
        m.k v0_2 = ((m.j2) this.k);
        androidx.appcompat.widget.Toolbar v1 = v0_2.a;
        if (v0_2.m == null) {
            m.e2 v2_7 = new m.k(v1.getContext());
            v0_2.m = v2_7;
            v2_7.o = 2131361862;
        }
        m.k v0_1 = v0_2.m;
        v0_1.k = p6;
        if ((((l.m) p5) != null) || (v1.g != null)) {
            v1.f();
            int v6_3 = v1.g.v;
            if (v6_3 != ((l.m) p5)) {
                if (v6_3 != 0) {
                    v6_3.r(v1.Q);
                    v6_3.r(v1.R);
                }
                if (v1.R == null) {
                    v1.R = new m.e2(v1);
                }
                v0_1.x = 1;
                m.e2 v2_2 = v1.p;
                if (((l.m) p5) == null) {
                    v0_1.j(v2_2, 0);
                    v1.R.j(v1.p, 0);
                    v0_1.d(1);
                    v1.R.d(1);
                } else {
                    ((l.m) p5).b(v0_1, v2_2);
                    ((l.m) p5).b(v1.R, v1.p);
                }
                v1.g.setPopupTheme(v1.q);
                v1.g.setPresenter(v0_1);
                v1.Q = v0_1;
                v1.t();
                return;
            }
        }
        return;
    }

    public final android.view.WindowInsets onApplyWindowInsets(android.view.WindowInsets p10)
    {
        int v1_10;
        this.j();
        int v0_1 = this.getWindowSystemUiVisibility();
        int v2 = 1;
        if ((v0_1 & 256) == 0) {
            v1_10 = 0;
        } else {
            v1_10 = 1;
        }
        int v0_0;
        if ((v0_1 & 1536) == 0) {
            v0_0 = 0;
        } else {
            v0_0 = 1;
        }
        int v0_2;
        int v6_0 = this.w;
        q0.f0.b(this.K, androidx.appcompat.widget.ActionBarOverlayLayout.M, v6_0);
        boolean v4_2 = v6_0.equals(androidx.appcompat.widget.ActionBarOverlayLayout.N);
        this.x = (v4_2 ^ 1);
        if ((!v4_2) && ((v1_10 == 0) || (v0_0 == 0))) {
            v0_2 = 0;
        } else {
            v0_2 = 1;
        }
        this.y = v0_2;
        boolean v4_3 = this.D;
        if (v4_3) {
            if ((v1_10 != 0) || (v0_2 != 0)) {
                int v0_3 = 0;
            } else {
                v0_3 = 1;
            }
            ((i.e0) v4_3).o = v0_3;
        }
        int v1_6;
        android.view.WindowInsets v10_3 = q0.o1.h(p10, this);
        int v0_4 = v10_3.a;
        int v1_1 = v0_4.k();
        int v5_2 = v1_1.a;
        int v6_1 = v1_1.b;
        int v7_0 = v1_1.c;
        this.v.set(v1_1.a, v6_1, v7_0, v1_1.d);
        if (!this.y) {
            this.j.setPadding(0, 0, 0, 0);
            v1_6 = androidx.appcompat.widget.ActionBarOverlayLayout.k(this.j, v5_2, v6_1, v7_0, 0);
        } else {
            int v1_8 = v0_4.f(2);
            int v8_1 = v1_8.c;
            this.j.setPadding((v5_2 - v1_8.a), v6_1, (v7_0 - v8_1), 0);
            v1_6 = androidx.appcompat.widget.ActionBarOverlayLayout.k(this.j, v1_8.a, 0, v8_1, 0);
        }
        android.graphics.Rect v3_1 = this.s;
        q0.f0.b(this, v10_3, v3_1);
        android.view.WindowInsets v10_5 = v0_4.m(v3_1.left, v3_1.top, v3_1.right, v3_1.bottom);
        this.z = v10_5;
        if (!this.A.equals(v10_5)) {
            this.A = this.z;
            v1_6 = 1;
        }
        android.view.WindowInsets v10_8 = this.t;
        if (v10_8.equals(v3_1)) {
            v2 = v1_6;
        } else {
            v10_8.set(v3_1);
        }
        if (v2 != 0) {
            this.requestLayout();
        }
        return v0_4.a().a.c().a.b().g();
    }

    public final void onConfigurationChanged(android.content.res.Configuration p1)
    {
        super.onConfigurationChanged(p1);
        this.h(this.getContext());
        q0.d0.c(this);
        return;
    }

    public final void onDetachedFromWindow()
    {
        super.onDetachedFromWindow();
        this.g();
        return;
    }

    public final void onLayout(boolean p5, int p6, int p7, int p8, int p9)
    {
        p5 = this.getChildCount();
        p6 = this.getPaddingLeft();
        p7 = this.getPaddingTop();
        p8 = 0;
        while (p8 < p5) {
            p9 = this.getChildAt(p8);
            if (p9.getVisibility() != 8) {
                int v0_2 = ((m.d) p9.getLayoutParams());
                int v3_1 = (v0_2.leftMargin + p6);
                int v0_4 = (v0_2.topMargin + p7);
                p9.layout(v3_1, v0_4, (p9.getMeasuredWidth() + v3_1), (p9.getMeasuredHeight() + v0_4));
            }
            p8++;
        }
        return;
    }

    public final void onMeasure(int p13, int p14)
    {
        int v5_26;
        this.j();
        this.measureChildWithMargins(this.j, p13, 0, p14, 0);
        int v13_2 = ((m.d) this.j.getLayoutParams());
        int v14_7 = Math.max(0, ((this.j.getMeasuredWidth() + v13_2.leftMargin) + v13_2.rightMargin));
        int v13_8 = Math.max(0, ((this.j.getMeasuredHeight() + v13_2.topMargin) + v13_2.bottomMargin));
        int v3_11 = android.view.View.combineMeasuredStates(0, this.j.getMeasuredState());
        if ((this.getWindowSystemUiVisibility() & 256) == 0) {
            v5_26 = 0;
        } else {
            v5_26 = 1;
        }
        int v6_13;
        if (v5_26 == 0) {
            if (this.j.getVisibility() == 8) {
                v6_13 = 0;
            } else {
                v6_13 = this.j.getMeasuredHeight();
            }
        } else {
            v6_13 = this.g;
            if (this.y) {
                v6_13 += this.v.top;
            }
            if ((this.n) && (this.j.getTabContainer() != null)) {
                v6_13 += this.g;
            }
        }
        int v8_2 = this.u;
        v8_2.set(this.s);
        androidx.appcompat.widget.ContentFrameLayout v7_18 = this.z;
        this.B = v7_18;
        if ((this.m) || ((v5_26 != 0) || (!this.x))) {
            int v1_2;
            if (!this.y) {
                v1_2 = i0.c.c(v7_18.b(), (this.B.d() + v6_13), this.B.c(), this.B.a());
            } else {
                v1_2 = i0.c.c(v7_18.b(), Math.max(this.B.d(), v6_13), this.B.c(), Math.max(this.B.a(), 0));
            }
            int v6_2;
            int v5_0 = this.B;
            int v6_0 = android.os.Build$VERSION.SDK_INT;
            if (v6_0 < 34) {
                if (v6_0 < 30) {
                    if (v6_0 < 29) {
                        v6_2 = new q0.a1(v5_0);
                    } else {
                        v6_2 = new q0.b1(v5_0);
                    }
                } else {
                    v6_2 = new q0.c1(v5_0);
                }
            } else {
                v6_2 = new q0.d1(v5_0);
            }
            v6_2.g(v1_2);
            this.B = v6_2.b();
        } else {
            androidx.appcompat.widget.ContentFrameLayout v7_5 = v8_2.top;
            if (!this.y) {
                v8_2.top = (v7_5 + v6_13);
                v8_2.bottom = v8_2.bottom;
            } else {
                v8_2.top = Math.max(v7_5, v6_13);
                v8_2.bottom = Math.max(v8_2.bottom, 0);
            }
            this.B = this.B.a.m(0, v6_13, 0, 0);
        }
        androidx.appcompat.widget.ActionBarOverlayLayout.k(this.i, v8_2.left, v8_2.top, v8_2.right, v8_2.bottom);
        if (!this.C.equals(this.B)) {
            int v1_9 = this.B;
            this.C = v1_9;
            q0.n0.b(this.i, v1_9);
        }
        this.measureChildWithMargins(this.i, p13, 0, p14, 0);
        int v1_13 = ((m.d) this.i.getLayoutParams());
        int v14_5 = Math.max(v14_7, ((this.i.getMeasuredWidth() + v1_13.leftMargin) + v1_13.rightMargin));
        int v13_3 = Math.max(v13_8, ((this.i.getMeasuredHeight() + v1_13.topMargin) + v1_13.bottomMargin));
        int v1_18 = android.view.View.combineMeasuredStates(v3_11, this.i.getMeasuredState());
        this.setMeasuredDimension(android.view.View.resolveSizeAndState(Math.max(((this.getPaddingRight() + this.getPaddingLeft()) + v14_5), this.getSuggestedMinimumWidth()), p13, v1_18), android.view.View.resolveSizeAndState(Math.max(((this.getPaddingBottom() + this.getPaddingTop()) + v13_3), this.getSuggestedMinimumHeight()), p14, (v1_18 << 16)));
        return;
    }

    public final boolean onNestedFling(android.view.View p10, float p11, float p12, boolean p13)
    {
        if ((this.o) && (p13)) {
            this.E.fling(0, 0, 0, ((int) p12), 0, 0, -2147483648, 2147483647);
            if (this.E.getFinalY() <= this.j.getHeight()) {
                this.g();
                this.H.run();
            } else {
                this.g();
                this.I.run();
            }
            this.p = 1;
            return 1;
        } else {
            return 0;
        }
    }

    public final boolean onNestedPreFling(android.view.View p1, float p2, float p3)
    {
        return 0;
    }

    public final void onNestedPreScroll(android.view.View p1, int p2, int p3, int[] p4)
    {
        return;
    }

    public final void onNestedScroll(android.view.View p1, int p2, int p3, int p4, int p5)
    {
        int v1_1 = (this.q + p3);
        this.q = v1_1;
        this.setActionBarHideOffset(v1_1);
        return;
    }

    public final void onNestedScrollAccepted(android.view.View p1, android.view.View p2, int p3)
    {
        this.J.a = p3;
        this.q = this.getActionBarHideOffset();
        this.g();
        i.e0 v1_2 = this.D;
        if (v1_2 != null) {
            i.e0 v1_3 = ((i.e0) v1_2);
            int v2_1 = v1_3.s;
            if (v2_1 != 0) {
                v2_1.a();
                v1_3.s = 0;
            }
        }
        return;
    }

    public final boolean onStartNestedScroll(android.view.View p1, android.view.View p2, int p3)
    {
        if (((p3 & 2) != 0) && (this.j.getVisibility() == 0)) {
            return this.o;
        } else {
            return 0;
        }
    }

    public final void onStopNestedScroll(android.view.View p4)
    {
        if ((this.o) && (!this.p)) {
            if (this.q > this.j.getHeight()) {
                this.g();
                this.postDelayed(this.I, 600);
            } else {
                this.g();
                this.postDelayed(this.H, 600);
            }
        }
        return;
    }

    public final void onWindowSystemUiVisibilityChanged(int p7)
    {
        int v1_0;
        super.onWindowSystemUiVisibilityChanged(p7);
        this.j();
        int v0_1 = (this.r ^ p7);
        this.r = p7;
        if ((p7 & 4) != 0) {
            v1_0 = 0;
        } else {
            v1_0 = 1;
        }
        boolean v7_2;
        if ((p7 & 256) == 0) {
            v7_2 = 0;
        } else {
            v7_2 = 1;
        }
        i.e0 v4_0 = this.D;
        if (v4_0 != null) {
            if ((v7_2) || (this.y)) {
                int v5_1 = 0;
            } else {
                v5_1 = 1;
            }
            i.e0 v4_1 = ((i.e0) v4_0);
            v4_1.o = v5_1;
            if ((v1_0 == 0) && (v7_2)) {
                if (!v4_1.p) {
                    v4_1.p = 1;
                    v4_1.f(1);
                }
            } else {
                if (v4_1.p) {
                    v4_1.p = 0;
                    v4_1.f(1);
                }
            }
        }
        if (((v0_1 & 256) != 0) && (this.D != null)) {
            q0.d0.c(this);
        }
        return;
    }

    public final void onWindowVisibilityChanged(int p2)
    {
        super.onWindowVisibilityChanged(p2);
        this.h = p2;
        i.e0 v0_0 = this.D;
        if (v0_0 != null) {
            ((i.e0) v0_0).n = p2;
        }
        return;
    }

    public void setActionBarHideOffset(int p3)
    {
        this.g();
        this.j.setTranslationY(((float) (- Math.max(0, Math.min(p3, this.j.getHeight())))));
        return;
    }

    public void setActionBarVisibilityCallback(m.c p2)
    {
        this.D = p2;
        if (this.getWindowToken() != null) {
            ((i.e0) this.D).n = this.h;
            java.util.WeakHashMap v2_4 = this.r;
            if (v2_4 != null) {
                this.onWindowSystemUiVisibilityChanged(v2_4);
                q0.d0.c(this);
            }
        }
        return;
    }

    public void setHasNonEmbeddedTabs(boolean p1)
    {
        this.n = p1;
        return;
    }

    public void setHideOnContentScrollEnabled(boolean p2)
    {
        if (p2 != this.o) {
            this.o = p2;
            if (p2 == 0) {
                this.g();
                this.setActionBarHideOffset(0);
            }
        }
        return;
    }

    public void setIcon(int p3)
    {
        int v3_1;
        this.j();
        m.j2 v0_1 = ((m.j2) this.k);
        if (p3 == 0) {
            v3_1 = 0;
        } else {
            v3_1 = t6.a.h(v0_1.a.getContext(), p3);
        }
        v0_1.d = v3_1;
        v0_1.c();
        return;
    }

    public void setIcon(android.graphics.drawable.Drawable p2)
    {
        this.j();
        m.j2 v0_1 = ((m.j2) this.k);
        v0_1.d = p2;
        v0_1.c();
        return;
    }

    public void setLogo(int p3)
    {
        int v3_1;
        this.j();
        m.j2 v0_1 = ((m.j2) this.k);
        if (p3 == 0) {
            v3_1 = 0;
        } else {
            v3_1 = t6.a.h(v0_1.a.getContext(), p3);
        }
        v0_1.e = v3_1;
        v0_1.c();
        return;
    }

    public void setOverlayMode(boolean p1)
    {
        this.m = p1;
        return;
    }

    public void setShowingForActionMode(boolean p1)
    {
        return;
    }

    public void setUiOptions(int p1)
    {
        return;
    }

    public void setWindowCallback(android.view.Window$Callback p2)
    {
        this.j();
        ((m.j2) this.k).k = p2;
        return;
    }

    public void setWindowTitle(CharSequence p4)
    {
        this.j();
        android.view.View v0_3 = ((m.j2) this.k);
        if (!v0_3.g) {
            androidx.appcompat.widget.Toolbar v1_1 = v0_3.a;
            v0_3.h = p4;
            if ((v0_3.b & 8) != 0) {
                v1_1.setTitle(p4);
                if (v0_3.g) {
                    q0.n0.o(v1_1.getRootView(), p4);
                }
            }
        }
        return;
    }

    public final boolean shouldDelayChildPressedState()
    {
        return 0;
    }
}
