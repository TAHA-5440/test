// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.appcompat.app;
public class AlertController$RecycleListView extends android.widget.ListView {
    public final int g;
    public final int h;

    public AlertController$RecycleListView(android.content.Context p2)
    {
        this(p2, 0);
        return;
    }

    public AlertController$RecycleListView(android.content.Context p2, android.util.AttributeSet p3)
    {
        super(p2, p3);
        int v2_2 = p2.obtainStyledAttributes(p3, h.a.t);
        super.h = v2_2.getDimensionPixelOffset(0, -1);
        super.g = v2_2.getDimensionPixelOffset(1, -1);
        return;
    }
}
