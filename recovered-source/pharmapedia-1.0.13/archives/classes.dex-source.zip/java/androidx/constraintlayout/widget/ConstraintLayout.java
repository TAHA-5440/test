// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.constraintlayout.widget;
public class ConstraintLayout extends android.view.ViewGroup {
    public static a0.u v;
    public final android.util.SparseArray g;
    public final java.util.ArrayList h;
    public final x.e i;
    public int j;
    public int k;
    public int l;
    public int m;
    public boolean n;
    public int o;
    public a0.p p;
    public a0.i q;
    public int r;
    public java.util.HashMap s;
    public final android.util.SparseArray t;
    public final a0.f u;

    public ConstraintLayout(android.content.Context p3)
    {
        super(p3);
        super.g = new android.util.SparseArray();
        super.h = new java.util.ArrayList(4);
        super.i = new x.e();
        super.j = 0;
        super.k = 0;
        super.l = 2147483647;
        super.m = 2147483647;
        super.n = 1;
        super.o = 257;
        super.p = 0;
        super.q = 0;
        super.r = -1;
        super.s = new java.util.HashMap();
        super.t = new android.util.SparseArray();
        super.u = new a0.f(super, super);
        super.i(0, 0, 0);
        return;
    }

    public ConstraintLayout(android.content.Context p2, android.util.AttributeSet p3)
    {
        super(p2, p3);
        super.g = new android.util.SparseArray();
        super.h = new java.util.ArrayList(4);
        super.i = new x.e();
        super.j = 0;
        super.k = 0;
        super.l = 2147483647;
        super.m = 2147483647;
        super.n = 1;
        super.o = 257;
        super.p = 0;
        super.q = 0;
        super.r = -1;
        super.s = new java.util.HashMap();
        super.t = new android.util.SparseArray();
        super.u = new a0.f(super, super);
        super.i(p3, 0, 0);
        return;
    }

    public ConstraintLayout(android.content.Context p2, android.util.AttributeSet p3, int p4)
    {
        super(p2, p3, p4);
        super.g = new android.util.SparseArray();
        super.h = new java.util.ArrayList(4);
        super.i = new x.e();
        super.j = 0;
        super.k = 0;
        super.l = 2147483647;
        super.m = 2147483647;
        super.n = 1;
        super.o = 257;
        super.p = 0;
        super.q = 0;
        super.r = -1;
        super.s = new java.util.HashMap();
        super.t = new android.util.SparseArray();
        super.u = new a0.f(super, super);
        super.i(p3, p4, 0);
        return;
    }

    public ConstraintLayout(android.content.Context p2, android.util.AttributeSet p3, int p4, int p5)
    {
        super(p2, p3, p4, p5);
        super.g = new android.util.SparseArray();
        super.h = new java.util.ArrayList(4);
        super.i = new x.e();
        super.j = 0;
        super.k = 0;
        super.l = 2147483647;
        super.m = 2147483647;
        super.n = 1;
        super.o = 257;
        super.p = 0;
        super.q = 0;
        super.r = -1;
        super.s = new java.util.HashMap();
        super.t = new android.util.SparseArray();
        super.u = new a0.f(super, super);
        super.i(p3, p4, p5);
        return;
    }

    public static a0.e g()
    {
        a0.e v0_1 = new a0.e(-2, -2);
        v0_1.a = -1;
        v0_1.b = -1;
        v0_1.c = -1082130432;
        v0_1.d = 1;
        v0_1.e = -1;
        v0_1.f = -1;
        v0_1.g = -1;
        v0_1.h = -1;
        v0_1.i = -1;
        v0_1.j = -1;
        v0_1.k = -1;
        v0_1.l = -1;
        v0_1.m = -1;
        v0_1.n = -1;
        v0_1.o = -1;
        v0_1.p = -1;
        v0_1.q = 0;
        v0_1.r = 0;
        v0_1.s = -1;
        v0_1.t = -1;
        v0_1.u = -1;
        v0_1.v = -1;
        v0_1.w = -2147483648;
        v0_1.x = -2147483648;
        v0_1.y = -2147483648;
        v0_1.z = -2147483648;
        v0_1.A = -2147483648;
        v0_1.B = -2147483648;
        v0_1.C = -2147483648;
        v0_1.D = 0;
        v0_1.E = 1056964608;
        v0_1.F = 1056964608;
        v0_1.G = 0;
        v0_1.H = -1082130432;
        v0_1.I = -1082130432;
        v0_1.J = 0;
        v0_1.K = 0;
        v0_1.L = 0;
        v0_1.M = 0;
        v0_1.N = 0;
        v0_1.O = 0;
        v0_1.P = 0;
        v0_1.Q = 0;
        v0_1.R = 1065353216;
        v0_1.S = 1065353216;
        v0_1.T = -1;
        v0_1.U = -1;
        v0_1.V = -1;
        v0_1.W = 0;
        v0_1.X = 0;
        v0_1.Y = 0;
        v0_1.Z = 0;
        v0_1.a0 = 1;
        v0_1.b0 = 1;
        v0_1.c0 = 0;
        v0_1.d0 = 0;
        v0_1.e0 = 0;
        v0_1.f0 = -1;
        v0_1.g0 = -1;
        v0_1.h0 = -1;
        v0_1.i0 = -1;
        v0_1.j0 = -2147483648;
        v0_1.k0 = -2147483648;
        v0_1.l0 = 1056964608;
        v0_1.p0 = new x.d();
        return v0_1;
    }

    private int getPaddingWidth()
    {
        int v2_2 = (Math.max(0, this.getPaddingRight()) + Math.max(0, this.getPaddingLeft()));
        int v1_1 = (Math.max(0, this.getPaddingEnd()) + Math.max(0, this.getPaddingStart()));
        if (v1_1 <= 0) {
            return v2_2;
        } else {
            return v1_1;
        }
    }

    public static a0.u getSharedValues()
    {
        if (androidx.constraintlayout.widget.ConstraintLayout.v == null) {
            a0.u v0_2 = new a0.u();
            new android.util.SparseIntArray();
            new java.util.HashMap();
            androidx.constraintlayout.widget.ConstraintLayout.v = v0_2;
        }
        return androidx.constraintlayout.widget.ConstraintLayout.v;
    }

    public final boolean checkLayoutParams(android.view.ViewGroup$LayoutParams p1)
    {
        return (p1 instanceof a0.e);
    }

    public final void dispatchDraw(android.graphics.Canvas p18)
    {
        float v2_3 = this.h;
        if (v2_3 != 0) {
            float v3_2 = v2_3.size();
            if (v3_2 > 0) {
                int v4_0 = 0;
                while (v4_0 < v3_2) {
                    ((a0.c) v2_3.get(v4_0)).getClass();
                    v4_0++;
                }
            }
        }
        super.dispatchDraw(p18);
        if (this.isInEditMode()) {
            float v2_2 = ((float) this.getWidth());
            float v3_1 = ((float) this.getHeight());
            int v4_1 = this.getChildCount();
            int v5_0 = 0;
            while (v5_0 < v4_1) {
                int v6_1 = this.getChildAt(v5_0);
                if (v6_1.getVisibility() != 8) {
                    int v6_2 = v6_1.getTag();
                    if ((v6_2 != 0) && ((v6_2 instanceof String))) {
                        int v6_4 = ((String) v6_2).split(",");
                        if (v6_4.length == 4) {
                            float v7_9 = ((int) ((((float) Integer.parseInt(v6_4[0])) / 1149698048) * v2_2));
                            int v8_8 = ((int) ((((float) Integer.parseInt(v6_4[1])) / 1156579328) * v3_1));
                            int v9_6 = ((int) ((((float) Integer.parseInt(v6_4[2])) / 1149698048) * v2_2));
                            int v6_10 = ((int) ((((float) Integer.parseInt(v6_4[3])) / 1156579328) * v3_1));
                            android.graphics.Paint v15_1 = new android.graphics.Paint();
                            v15_1.setColor(-65536);
                            float v11_1 = ((float) v7_9);
                            float v12_2 = ((float) v8_8);
                            float v13_1 = ((float) (v7_9 + v9_6));
                            p18.drawLine(v11_1, v12_2, v13_1, v12_2, v15_1);
                            float v7_11 = v11_1;
                            float v14_3 = ((float) (v8_8 + v6_10));
                            float v11_2 = v13_1;
                            p18.drawLine(v11_2, v12_2, v13_1, v14_3, v15_1);
                            int v6_11 = v12_2;
                            float v12_3 = v14_3;
                            float v13_2 = v7_11;
                            p18.drawLine(v11_2, v12_3, v13_2, v14_3, v15_1);
                            float v7_12 = v11_2;
                            float v11_3 = v13_2;
                            float v14_4 = v6_11;
                            p18.drawLine(v11_3, v12_3, v13_2, v14_4, v15_1);
                            float v14_0 = v12_3;
                            float v12_0 = v14_4;
                            v15_1.setColor(-16711936);
                            float v13_0 = v7_12;
                            p18.drawLine(v11_3, v12_0, v13_0, v14_0, v15_1);
                            p18.drawLine(v11_3, v14_0, v13_0, v12_0, v15_1);
                        }
                    }
                }
                v5_0++;
            }
        }
        return;
    }

    public final void forceLayout()
    {
        this.n = 1;
        super.forceLayout();
        return;
    }

    public final bridge synthetic android.view.ViewGroup$LayoutParams generateDefaultLayoutParams()
    {
        return androidx.constraintlayout.widget.ConstraintLayout.g();
    }

    public final android.view.ViewGroup$LayoutParams generateLayoutParams(android.util.AttributeSet p13)
    {
        int v1_0 = this.getContext();
        a0.e v0_1 = new a0.e(v1_0, p13);
        v0_1.a = -1;
        v0_1.b = -1;
        v0_1.c = -1082130432;
        v0_1.d = 1;
        v0_1.e = -1;
        v0_1.f = -1;
        v0_1.g = -1;
        v0_1.h = -1;
        v0_1.i = -1;
        v0_1.j = -1;
        v0_1.k = -1;
        v0_1.l = -1;
        v0_1.m = -1;
        v0_1.n = -1;
        v0_1.o = -1;
        v0_1.p = -1;
        v0_1.q = 0;
        v0_1.r = 0;
        v0_1.s = -1;
        v0_1.t = -1;
        v0_1.u = -1;
        v0_1.v = -1;
        v0_1.w = -2147483648;
        v0_1.x = -2147483648;
        v0_1.y = -2147483648;
        v0_1.z = -2147483648;
        v0_1.A = -2147483648;
        v0_1.B = -2147483648;
        v0_1.C = -2147483648;
        v0_1.D = 0;
        v0_1.E = 1056964608;
        v0_1.F = 1056964608;
        v0_1.G = 0;
        v0_1.H = -1082130432;
        v0_1.I = -1082130432;
        v0_1.J = 0;
        v0_1.K = 0;
        v0_1.L = 0;
        v0_1.M = 0;
        v0_1.N = 0;
        v0_1.O = 0;
        v0_1.P = 0;
        v0_1.Q = 0;
        v0_1.R = 1065353216;
        v0_1.S = 1065353216;
        v0_1.T = -1;
        v0_1.U = -1;
        v0_1.V = -1;
        v0_1.W = 0;
        v0_1.X = 0;
        v0_1.Y = 0;
        v0_1.Z = 0;
        v0_1.a0 = 1;
        v0_1.b0 = 1;
        v0_1.c0 = 0;
        v0_1.d0 = 0;
        v0_1.e0 = 0;
        v0_1.f0 = -1;
        v0_1.g0 = -1;
        v0_1.h0 = -1;
        v0_1.i0 = -1;
        v0_1.j0 = -2147483648;
        v0_1.k0 = -2147483648;
        v0_1.l0 = 1056964608;
        v0_1.p0 = new x.d();
        android.content.res.TypedArray v13_1 = v1_0.obtainStyledAttributes(p13, a0.t.b);
        int v1_1 = v13_1.getIndexCount();
        int v3_0 = 0;
        while (v3_0 < v1_1) {
            int v7_60 = v13_1.getIndex(v3_0);
            boolean v8_72 = a0.d.a.get(v7_60);
            switch (v8_72) {
                case 1:
                    v0_1.V = v13_1.getInt(v7_60, v0_1.V);
                    break;
                case 2:
                    boolean v8_56 = v13_1.getResourceId(v7_60, v0_1.p);
                    v0_1.p = v8_56;
                    if (v8_56 != -1) {
                    } else {
                        v0_1.p = v13_1.getInt(v7_60, -1);
                    }
                    break;
                case 3:
                    v0_1.q = v13_1.getDimensionPixelSize(v7_60, v0_1.q);
                    break;
                case 4:
                    int v7_40 = (v13_1.getFloat(v7_60, v0_1.r) % 1135869952);
                    v0_1.r = v7_40;
                    if (v7_40 >= 0) {
                    } else {
                        v0_1.r = ((1135869952 - v7_40) % 1135869952);
                    }
                    break;
                case 5:
                    v0_1.a = v13_1.getDimensionPixelOffset(v7_60, v0_1.a);
                    break;
                case 6:
                    v0_1.b = v13_1.getDimensionPixelOffset(v7_60, v0_1.b);
                    break;
                case 7:
                    v0_1.c = v13_1.getFloat(v7_60, v0_1.c);
                    break;
                case 8:
                    boolean v8_48 = v13_1.getResourceId(v7_60, v0_1.e);
                    v0_1.e = v8_48;
                    if (v8_48 != -1) {
                    } else {
                        v0_1.e = v13_1.getInt(v7_60, -1);
                    }
                    break;
                case 9:
                    boolean v8_46 = v13_1.getResourceId(v7_60, v0_1.f);
                    v0_1.f = v8_46;
                    if (v8_46 != -1) {
                    } else {
                        v0_1.f = v13_1.getInt(v7_60, -1);
                    }
                    break;
                case 10:
                    boolean v8_44 = v13_1.getResourceId(v7_60, v0_1.g);
                    v0_1.g = v8_44;
                    if (v8_44 != -1) {
                    } else {
                        v0_1.g = v13_1.getInt(v7_60, -1);
                    }
                    break;
                case 11:
                    boolean v8_42 = v13_1.getResourceId(v7_60, v0_1.h);
                    v0_1.h = v8_42;
                    if (v8_42 != -1) {
                    } else {
                        v0_1.h = v13_1.getInt(v7_60, -1);
                    }
                    break;
                case 12:
                    boolean v8_40 = v13_1.getResourceId(v7_60, v0_1.i);
                    v0_1.i = v8_40;
                    if (v8_40 != -1) {
                    } else {
                        v0_1.i = v13_1.getInt(v7_60, -1);
                    }
                    break;
                case 13:
                    boolean v8_38 = v13_1.getResourceId(v7_60, v0_1.j);
                    v0_1.j = v8_38;
                    if (v8_38 != -1) {
                    } else {
                        v0_1.j = v13_1.getInt(v7_60, -1);
                    }
                    break;
                case 14:
                    boolean v8_36 = v13_1.getResourceId(v7_60, v0_1.k);
                    v0_1.k = v8_36;
                    if (v8_36 != -1) {
                    } else {
                        v0_1.k = v13_1.getInt(v7_60, -1);
                    }
                    break;
                case 15:
                    boolean v8_34 = v13_1.getResourceId(v7_60, v0_1.l);
                    v0_1.l = v8_34;
                    if (v8_34 != -1) {
                    } else {
                        v0_1.l = v13_1.getInt(v7_60, -1);
                    }
                    break;
                case 16:
                    boolean v8_32 = v13_1.getResourceId(v7_60, v0_1.m);
                    v0_1.m = v8_32;
                    if (v8_32 != -1) {
                    } else {
                        v0_1.m = v13_1.getInt(v7_60, -1);
                    }
                    break;
                case 17:
                    boolean v8_30 = v13_1.getResourceId(v7_60, v0_1.s);
                    v0_1.s = v8_30;
                    if (v8_30 != -1) {
                    } else {
                        v0_1.s = v13_1.getInt(v7_60, -1);
                    }
                    break;
                case 18:
                    boolean v8_28 = v13_1.getResourceId(v7_60, v0_1.t);
                    v0_1.t = v8_28;
                    if (v8_28 != -1) {
                    } else {
                        v0_1.t = v13_1.getInt(v7_60, -1);
                    }
                    break;
                case 19:
                    boolean v8_26 = v13_1.getResourceId(v7_60, v0_1.u);
                    v0_1.u = v8_26;
                    if (v8_26 != -1) {
                    } else {
                        v0_1.u = v13_1.getInt(v7_60, -1);
                    }
                    break;
                case 20:
                    boolean v8_24 = v13_1.getResourceId(v7_60, v0_1.v);
                    v0_1.v = v8_24;
                    if (v8_24 != -1) {
                    } else {
                        v0_1.v = v13_1.getInt(v7_60, -1);
                    }
                    break;
                case 21:
                    v0_1.w = v13_1.getDimensionPixelSize(v7_60, v0_1.w);
                    break;
                case 22:
                    v0_1.x = v13_1.getDimensionPixelSize(v7_60, v0_1.x);
                    break;
                case 23:
                    v0_1.y = v13_1.getDimensionPixelSize(v7_60, v0_1.y);
                    break;
                case 24:
                    v0_1.z = v13_1.getDimensionPixelSize(v7_60, v0_1.z);
                    break;
                case 25:
                    v0_1.A = v13_1.getDimensionPixelSize(v7_60, v0_1.A);
                    break;
                case 26:
                    v0_1.B = v13_1.getDimensionPixelSize(v7_60, v0_1.B);
                    break;
                case 27:
                    v0_1.W = v13_1.getBoolean(v7_60, v0_1.W);
                    break;
                case 28:
                    v0_1.X = v13_1.getBoolean(v7_60, v0_1.X);
                    break;
                case 29:
                    v0_1.E = v13_1.getFloat(v7_60, v0_1.E);
                    break;
                case 30:
                    v0_1.F = v13_1.getFloat(v7_60, v0_1.F);
                    break;
                case 31:
                    int v7_10 = v13_1.getInt(v7_60, 0);
                    v0_1.L = v7_10;
                    if (v7_10 != 1) {
                    } else {
                        android.util.Log.e("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                    }
                    break;
                case 32:
                    int v7_8 = v13_1.getInt(v7_60, 0);
                    v0_1.M = v7_8;
                    if (v7_8 != 1) {
                    } else {
                        android.util.Log.e("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                    }
                    break;
                case 33:
                    try {
                        v0_1.N = v13_1.getDimensionPixelSize(v7_60, v0_1.N);
                    } catch (Exception) {
                        if (v13_1.getInt(v7_60, v0_1.N) != -2) {
                        } else {
                            v0_1.N = -2;
                        }
                    }
                    break;
                case 34:
                    try {
                        v0_1.P = v13_1.getDimensionPixelSize(v7_60, v0_1.P);
                    } catch (Exception) {
                        if (v13_1.getInt(v7_60, v0_1.P) != -2) {
                        } else {
                            v0_1.P = -2;
                        }
                    }
                    break;
                case 35:
                    v0_1.R = Math.max(0, v13_1.getFloat(v7_60, v0_1.R));
                    v0_1.L = 2;
                    break;
                case 36:
                    try {
                        v0_1.O = v13_1.getDimensionPixelSize(v7_60, v0_1.O);
                    } catch (Exception) {
                        if (v13_1.getInt(v7_60, v0_1.O) != -2) {
                        } else {
                            v0_1.O = -2;
                        }
                    }
                    break;
                case 37:
                    try {
                        v0_1.Q = v13_1.getDimensionPixelSize(v7_60, v0_1.Q);
                    } catch (Exception) {
                        if (v13_1.getInt(v7_60, v0_1.Q) != -2) {
                        } else {
                            v0_1.Q = -2;
                        }
                    }
                    break;
                case 38:
                    v0_1.S = Math.max(0, v13_1.getFloat(v7_60, v0_1.S));
                    v0_1.M = 2;
                    break;
                default:
                    switch (v8_72) {
                        case 44:
                            a0.p.g(v0_1, v13_1.getString(v7_60));
                            break;
                        case 45:
                            v0_1.H = v13_1.getFloat(v7_60, v0_1.H);
                            break;
                        case 46:
                            v0_1.I = v13_1.getFloat(v7_60, v0_1.I);
                            break;
                        case 47:
                            v0_1.J = v13_1.getInt(v7_60, 0);
                            break;
                        case 48:
                            v0_1.K = v13_1.getInt(v7_60, 0);
                            break;
                        case 49:
                            v0_1.T = v13_1.getDimensionPixelOffset(v7_60, v0_1.T);
                            break;
                        case 50:
                            v0_1.U = v13_1.getDimensionPixelOffset(v7_60, v0_1.U);
                            break;
                        case 51:
                            v0_1.Y = v13_1.getString(v7_60);
                            break;
                        case 52:
                            boolean v8_63 = v13_1.getResourceId(v7_60, v0_1.n);
                            v0_1.n = v8_63;
                            if (v8_63 != -1) {
                            } else {
                                v0_1.n = v13_1.getInt(v7_60, -1);
                            }
                            break;
                        case 53:
                            boolean v8_61 = v13_1.getResourceId(v7_60, v0_1.o);
                            v0_1.o = v8_61;
                            if (v8_61 != -1) {
                            } else {
                                v0_1.o = v13_1.getInt(v7_60, -1);
                            }
                            break;
                        case 54:
                            v0_1.D = v13_1.getDimensionPixelSize(v7_60, v0_1.D);
                            break;
                        case 55:
                            v0_1.C = v13_1.getDimensionPixelSize(v7_60, v0_1.C);
                            break;
                        default:
                            switch (v8_72) {
                                case 64:
                                    a0.p.f(v0_1, v13_1, v7_60, 0);
                                    break;
                                case 65:
                                    a0.p.f(v0_1, v13_1, v7_60, 1);
                                    break;
                                case 66:
                                    v0_1.Z = v13_1.getInt(v7_60, v0_1.Z);
                                    break;
                                case 67:
                                    v0_1.d = v13_1.getBoolean(v7_60, v0_1.d);
                                    break;
                                default:
                            }
                    }
            }
            v3_0++;
        }
        v13_1.recycle();
        v0_1.a();
        return v0_1;
    }

    public final android.view.ViewGroup$LayoutParams generateLayoutParams(android.view.ViewGroup$LayoutParams p9)
    {
        a0.e v0_1 = new a0.e(p9);
        v0_1.a = -1;
        v0_1.b = -1;
        v0_1.c = -1082130432;
        v0_1.d = 1;
        v0_1.e = -1;
        v0_1.f = -1;
        v0_1.g = -1;
        v0_1.h = -1;
        v0_1.i = -1;
        v0_1.j = -1;
        v0_1.k = -1;
        v0_1.l = -1;
        v0_1.m = -1;
        v0_1.n = -1;
        v0_1.o = -1;
        v0_1.p = -1;
        v0_1.q = 0;
        v0_1.r = 0;
        v0_1.s = -1;
        v0_1.t = -1;
        v0_1.u = -1;
        v0_1.v = -1;
        v0_1.w = -2147483648;
        v0_1.x = -2147483648;
        v0_1.y = -2147483648;
        v0_1.z = -2147483648;
        v0_1.A = -2147483648;
        v0_1.B = -2147483648;
        v0_1.C = -2147483648;
        v0_1.D = 0;
        v0_1.E = 1056964608;
        v0_1.F = 1056964608;
        v0_1.G = 0;
        v0_1.H = -1082130432;
        v0_1.I = -1082130432;
        v0_1.J = 0;
        v0_1.K = 0;
        v0_1.L = 0;
        v0_1.M = 0;
        v0_1.N = 0;
        v0_1.O = 0;
        v0_1.P = 0;
        v0_1.Q = 0;
        v0_1.R = 1065353216;
        v0_1.S = 1065353216;
        v0_1.T = -1;
        v0_1.U = -1;
        v0_1.V = -1;
        v0_1.W = 0;
        v0_1.X = 0;
        v0_1.Y = 0;
        v0_1.Z = 0;
        v0_1.a0 = 1;
        v0_1.b0 = 1;
        v0_1.c0 = 0;
        v0_1.d0 = 0;
        v0_1.e0 = 0;
        v0_1.f0 = -1;
        v0_1.g0 = -1;
        v0_1.h0 = -1;
        v0_1.i0 = -1;
        v0_1.j0 = -2147483648;
        v0_1.k0 = -2147483648;
        v0_1.l0 = 1056964608;
        v0_1.p0 = new x.d();
        if ((p9 instanceof android.view.ViewGroup$MarginLayoutParams)) {
            v0_1.leftMargin = ((android.view.ViewGroup$MarginLayoutParams) p9).leftMargin;
            v0_1.rightMargin = ((android.view.ViewGroup$MarginLayoutParams) p9).rightMargin;
            v0_1.topMargin = ((android.view.ViewGroup$MarginLayoutParams) p9).topMargin;
            v0_1.bottomMargin = ((android.view.ViewGroup$MarginLayoutParams) p9).bottomMargin;
            v0_1.setMarginStart(((android.view.ViewGroup$MarginLayoutParams) p9).getMarginStart());
            v0_1.setMarginEnd(((android.view.ViewGroup$MarginLayoutParams) p9).getMarginEnd());
        }
        if ((p9 instanceof a0.e)) {
            v0_1.a = ((a0.e) p9).a;
            v0_1.b = ((a0.e) p9).b;
            v0_1.c = ((a0.e) p9).c;
            v0_1.d = ((a0.e) p9).d;
            v0_1.e = ((a0.e) p9).e;
            v0_1.f = ((a0.e) p9).f;
            v0_1.g = ((a0.e) p9).g;
            v0_1.h = ((a0.e) p9).h;
            v0_1.i = ((a0.e) p9).i;
            v0_1.j = ((a0.e) p9).j;
            v0_1.k = ((a0.e) p9).k;
            v0_1.l = ((a0.e) p9).l;
            v0_1.m = ((a0.e) p9).m;
            v0_1.n = ((a0.e) p9).n;
            v0_1.o = ((a0.e) p9).o;
            v0_1.p = ((a0.e) p9).p;
            v0_1.q = ((a0.e) p9).q;
            v0_1.r = ((a0.e) p9).r;
            v0_1.s = ((a0.e) p9).s;
            v0_1.t = ((a0.e) p9).t;
            v0_1.u = ((a0.e) p9).u;
            v0_1.v = ((a0.e) p9).v;
            v0_1.w = ((a0.e) p9).w;
            v0_1.x = ((a0.e) p9).x;
            v0_1.y = ((a0.e) p9).y;
            v0_1.z = ((a0.e) p9).z;
            v0_1.A = ((a0.e) p9).A;
            v0_1.B = ((a0.e) p9).B;
            v0_1.C = ((a0.e) p9).C;
            v0_1.D = ((a0.e) p9).D;
            v0_1.E = ((a0.e) p9).E;
            v0_1.F = ((a0.e) p9).F;
            v0_1.G = ((a0.e) p9).G;
            v0_1.H = ((a0.e) p9).H;
            v0_1.I = ((a0.e) p9).I;
            v0_1.J = ((a0.e) p9).J;
            v0_1.K = ((a0.e) p9).K;
            v0_1.W = ((a0.e) p9).W;
            v0_1.X = ((a0.e) p9).X;
            v0_1.L = ((a0.e) p9).L;
            v0_1.M = ((a0.e) p9).M;
            v0_1.N = ((a0.e) p9).N;
            v0_1.P = ((a0.e) p9).P;
            v0_1.O = ((a0.e) p9).O;
            v0_1.Q = ((a0.e) p9).Q;
            v0_1.R = ((a0.e) p9).R;
            v0_1.S = ((a0.e) p9).S;
            v0_1.T = ((a0.e) p9).T;
            v0_1.U = ((a0.e) p9).U;
            v0_1.V = ((a0.e) p9).V;
            v0_1.a0 = ((a0.e) p9).a0;
            v0_1.b0 = ((a0.e) p9).b0;
            v0_1.c0 = ((a0.e) p9).c0;
            v0_1.d0 = ((a0.e) p9).d0;
            v0_1.f0 = ((a0.e) p9).f0;
            v0_1.g0 = ((a0.e) p9).g0;
            v0_1.h0 = ((a0.e) p9).h0;
            v0_1.i0 = ((a0.e) p9).i0;
            v0_1.j0 = ((a0.e) p9).j0;
            v0_1.k0 = ((a0.e) p9).k0;
            v0_1.l0 = ((a0.e) p9).l0;
            v0_1.Y = ((a0.e) p9).Y;
            v0_1.Z = ((a0.e) p9).Z;
            v0_1.p0 = ((a0.e) p9).p0;
            return v0_1;
        } else {
            return v0_1;
        }
    }

    public int getMaxHeight()
    {
        return this.m;
    }

    public int getMaxWidth()
    {
        return this.l;
    }

    public int getMinHeight()
    {
        return this.k;
    }

    public int getMinWidth()
    {
        return this.j;
    }

    public int getOptimizationLevel()
    {
        return this.i.C0;
    }

    public String getSceneString()
    {
        String v0_1 = new StringBuilder();
        x.e v1 = this.i;
        if (v1.j == null) {
            java.util.ArrayList v2_8 = this.getId();
            if (v2_8 == -1) {
                v1.j = "parent";
            } else {
                v1.j = this.getContext().getResources().getResourceEntryName(v2_8);
            }
        }
        if (v1.h0 == null) {
            v1.h0 = v1.j;
            java.util.ArrayList v2_4 = new StringBuilder(" setDebugName ");
            v2_4.append(v1.h0);
            android.util.Log.v("ConstraintLayout", v2_4.toString());
        }
        java.util.ArrayList v2_7 = v1.p0;
        int v6_1 = v2_7.size();
        int v7 = 0;
        while (v7 < v6_1) {
            String v8_0 = v2_7.get(v7);
            v7++;
            String v8_1 = ((x.d) v8_0);
            StringBuilder v9_0 = v8_1.f0;
            if (v9_0 != null) {
                if (v8_1.j == null) {
                    StringBuilder v9_1 = v9_0.getId();
                    if (v9_1 != -1) {
                        v8_1.j = this.getContext().getResources().getResourceEntryName(v9_1);
                    }
                }
                if (v8_1.h0 == null) {
                    v8_1.h0 = v8_1.j;
                    StringBuilder v9_6 = new StringBuilder(" setDebugName ");
                    v9_6.append(v8_1.h0);
                    android.util.Log.v("ConstraintLayout", v9_6.toString());
                }
            }
        }
        v1.l(v0_1);
        return v0_1.toString();
    }

    public final x.d h(android.view.View p2)
    {
        if (p2 != this) {
            if (p2 != null) {
                if (!(p2.getLayoutParams() instanceof a0.e)) {
                    p2.setLayoutParams(this.generateLayoutParams(p2.getLayoutParams()));
                    if ((p2.getLayoutParams() instanceof a0.e)) {
                        return ((a0.e) p2.getLayoutParams()).p0;
                    }
                } else {
                    return ((a0.e) p2.getLayoutParams()).p0;
                }
            }
            return 0;
        } else {
            return this.i;
        }
    }

    public final void i(android.util.AttributeSet p7, int p8, int p9)
    {
        x.e v0 = this.i;
        v0.f0 = this;
        int v1_1 = this.u;
        v0.t0 = v1_1;
        v0.r0.g = v1_1;
        this.g.put(this.getId(), this);
        this.p = 0;
        if (p7) {
            boolean v7_1 = this.getContext().obtainStyledAttributes(p7, a0.t.b, p8, p9);
            int v8_1 = v7_1.getIndexCount();
            int v2_1 = 0;
            while (v2_1 < v8_1) {
                int v3_1 = v7_1.getIndex(v2_1);
                if (v3_1 != 16) {
                    if (v3_1 != 17) {
                        if (v3_1 != 14) {
                            if (v3_1 != 15) {
                                if (v3_1 != 113) {
                                    if (v3_1 != 56) {
                                        if (v3_1 == 34) {
                                            int v3_2 = v7_1.getResourceId(v3_1, 0);
                                            try {
                                                a0.p v4_8 = new a0.p();
                                                this.p = v4_8;
                                                v4_8.d(this.getContext(), v3_2);
                                            } catch (android.content.res.Resources$NotFoundException) {
                                                this.p = 0;
                                            }
                                            this.r = v3_2;
                                        }
                                    } else {
                                        int v3_3 = v7_1.getResourceId(v3_1, 0);
                                        if (v3_3 != 0) {
                                            try {
                                                this.j(v3_3);
                                            } catch (android.content.res.Resources$NotFoundException) {
                                                this.q = 0;
                                            }
                                        }
                                    }
                                } else {
                                    this.o = v7_1.getInt(v3_1, this.o);
                                }
                            } else {
                                this.m = v7_1.getDimensionPixelOffset(v3_1, this.m);
                            }
                        } else {
                            this.l = v7_1.getDimensionPixelOffset(v3_1, this.l);
                        }
                    } else {
                        this.k = v7_1.getDimensionPixelOffset(v3_1, this.k);
                    }
                } else {
                    this.j = v7_1.getDimensionPixelOffset(v3_1, this.j);
                }
                v2_1++;
            }
            v7_1.recycle();
        }
        v0.C0 = this.o;
        v.c.q = v0.S(512);
        return;
    }

    public final void j(int p9)
    {
        java.io.IOException v1_0 = this.getContext();
        a0.i v0_1 = new a0.i(0, 0);
        v0_1.h = new android.util.SparseArray();
        v0_1.i = new android.util.SparseArray();
        StringBuilder v4_1 = v1_0.getResources().getXml(p9);
        a0.h v5_0 = v4_1.getEventType();
        a0.g v6_0 = 0;
        while (v5_0 != 1) {
            if (v5_0 == 2) {
                java.util.ArrayList v7_5;
                a0.h v5_1 = v4_1.getName();
                switch (v5_1.hashCode()) {
                    case -1349929691:
                        if (v5_1.equals("ConstraintSet")) {
                            v0_1.v(v1_0, v4_1);
                        }
                        break;
                    case 80204913:
                        if (v5_1.equals("State")) {
                            a0.h v5_7 = new a0.g(v1_0, v4_1);
                            ((android.util.SparseArray) v0_1.h).put(v5_7.b, v5_7);
                            v6_0 = v5_7;
                        }
                        break;
                    case 1382829617:
                        v7_5 = "StateSet";
                        break;
                    case 1657696882:
                        v7_5 = "layoutDescription";
                        break;
                    case 1901439077:
                        if (v5_1.equals("Variant")) {
                            a0.h v5_4 = new a0.h(v1_0, v4_1);
                            if (v6_0 != null) {
                                v6_0.a.add(v5_4);
                            }
                        }
                        break;
                    default:
                }
                v5_1.equals(v7_5);
            } else {
            }
            v5_0 = v4_1.next();
        }
        this.q = v0_1;
        return;
    }

    public final void k(x.e p29, int p30, int p31, int p32)
    {
        int v3_0 = android.view.View$MeasureSpec.getMode(p31);
        int v4_21 = android.view.View$MeasureSpec.getSize(p31);
        int v5_7 = android.view.View$MeasureSpec.getMode(p32);
        int v6_0 = android.view.View$MeasureSpec.getSize(p32);
        androidx.lifecycle.j v7_1 = Math.max(0, this.getPaddingTop());
        int v9_3 = Math.max(0, this.getPaddingBottom());
        int v10_8 = (v7_1 + v9_3);
        boolean v11_14 = this.getPaddingWidth();
        int v12_4 = this.u;
        v12_4.b = v7_1;
        v12_4.c = v9_3;
        v12_4.d = v11_14;
        v12_4.e = v10_8;
        v12_4.f = p31;
        v12_4.g = p32;
        int v9_9 = Math.max(0, this.getPaddingStart());
        boolean v13_2 = Math.max(0, this.getPaddingEnd());
        if ((v9_9 <= 0) && (v13_2)) {
            v9_9 = Math.max(0, this.getPaddingLeft());
        } else {
            if (((this.getContext().getApplicationInfo().flags & 4194304) != 0) && (1 == this.getLayoutDirection())) {
                v9_9 = v13_2;
            }
        }
        int v10_23;
        androidx.constraintlayout.core.widgets.analyzer.a v17_2;
        int v8_41;
        int v15_7;
        int v4_20 = (v4_21 - v11_14);
        int v6_10 = (v6_0 - v10_8);
        int v10_13 = v12_4.e;
        boolean v11_43 = v12_4.d;
        int v12_5 = this.getChildCount();
        boolean v13_13 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.g;
        int v14_6 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.h;
        if (v3_0 == -2147483648) {
            if (v12_5 != 0) {
                v15_7 = v4_20;
                v17_2 = v10_13;
                v8_41 = v14_6;
                v10_23 = -2147483648;
            } else {
                v15_7 = Math.max(0, this.j);
            }
        } else {
            if (v3_0 == 0) {
                if (v12_5 != 0) {
                    v15_7 = 0;
                } else {
                    v17_2 = v10_13;
                    v8_41 = v14_6;
                    v15_7 = Math.max(0, this.j);
                }
            } else {
                if (v3_0 == 1073741824) {
                    v15_7 = Math.min((this.l - v11_43), v4_20);
                    v17_2 = v10_13;
                } else {
                    v17_2 = v10_13;
                    v15_7 = 0;
                }
                v10_23 = -2147483648;
                v8_41 = v13_13;
            }
        }
        int v10_1;
        int v12_0;
        androidx.constraintlayout.core.widgets.analyzer.e v18_0;
        if (v5_7 == v10_23) {
            if (v12_5 != 0) {
                v12_0 = v6_10;
                v18_0 = v11_43;
                v10_1 = v14_6;
            } else {
                v12_0 = Math.max(0, this.k);
            }
        } else {
            if (v5_7 == 0) {
                if (v12_5 != 0) {
                    v12_0 = 0;
                } else {
                    v18_0 = v11_43;
                    v10_1 = v14_6;
                    v12_0 = Math.max(0, this.k);
                }
            } else {
                if (v5_7 == 1073741824) {
                    v12_0 = Math.min((this.m - v17_2), v6_10);
                    v18_0 = v11_43;
                    v10_1 = v13_13;
                } else {
                    v18_0 = v11_43;
                    v10_1 = v13_13;
                    v12_0 = 0;
                }
            }
        }
        int v31_1;
        int v19_0 = v13_13;
        boolean v13_0 = p29.r0;
        int v20_0 = v14_6;
        int v14_0 = p29.C;
        if ((v15_7 == p29.o()) && (v12_0 == p29.i())) {
            v31_1 = 1;
        } else {
            v13_0.c = 1;
            v31_1 = 1;
        }
        p29.Y = 0;
        p29.Z = 0;
        v14_0[0] = (this.l - v18_0);
        v14_0[v31_1] = (this.m - v17_2);
        p29.b0 = 0;
        p29.c0 = 0;
        p29.I(v8_41);
        p29.K(v15_7);
        p29.J(v10_1);
        p29.H(v12_0);
        int v8_2 = (this.j - v18_0);
        if (v8_2 >= 0) {
            p29.b0 = v8_2;
        } else {
            p29.b0 = 0;
        }
        int v8_4 = (this.k - v17_2);
        if (v8_4 >= 0) {
            p29.c0 = v8_4;
        } else {
            p29.c0 = 0;
        }
        int v2_1;
        p29.w0 = v9_9;
        p29.x0 = v7_1;
        androidx.lifecycle.j v7_2 = p29.q0;
        int v8_6 = ((x.e) v7_2.j);
        int v9_2 = ((java.util.ArrayList) v7_2.h);
        int v10_7 = p29.t0;
        boolean v11_10 = p29.p0.size();
        int v12_3 = p29.o();
        int v15_0 = p29.i();
        int v0_2 = x.g.c(p30, 128);
        androidx.constraintlayout.core.widgets.analyzer.a v17_0 = v14_0;
        if ((v0_2 == 0) && (!x.g.c(p30, 64))) {
            v2_1 = 0;
        } else {
            v2_1 = 1;
        }
        int v21;
        int v2_4;
        int v14_2 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.i;
        if (v2_1 == 0) {
            v21 = v11_10;
            v2_4 = v2_1;
        } else {
            int v2_3 = 0;
            while(true) {
                v21 = v11_10;
                if (v2_3 >= v11_10) {
                } else {
                    int v25_0;
                    boolean v11_13 = ((x.d) p29.p0.get(v2_3));
                    int v23_0 = v11_13.S;
                    if (v23_0[0] != v14_2) {
                        v25_0 = 0;
                    } else {
                        v25_0 = 1;
                    }
                    int v2_8;
                    if (v23_0[1] != v14_2) {
                        v2_8 = 0;
                    } else {
                        v2_8 = 1;
                    }
                    if ((v25_0 == 0) || ((v2_8 == 0) || (v11_13.W <= 0))) {
                        int v2_11 = 0;
                    } else {
                        v2_11 = 1;
                    }
                    if (((v11_13.v()) && (v2_11 != 0)) || (((v11_13.w()) && (v2_11 != 0)) || ((v11_13.v()) || (v11_13.w())))) {
                        break;
                    }
                    v2_3++;
                    v11_10 = v21;
                }
            }
            v2_4 = 0;
        }
        if (((v3_0 != 1073741824) || (v5_7 != 1073741824)) && (v0_2 == 0)) {
            boolean v11_16 = 0;
        } else {
            v11_16 = 1;
        }
        androidx.constraintlayout.core.widgets.analyzer.e v24_1;
        androidx.constraintlayout.core.widgets.analyzer.a v17_1;
        int v22_1;
        int v0_3;
        int v6_1;
        int v19_1;
        int v25_1;
        int v2_14 = (v2_4 & v11_16);
        if (v2_14 == 0) {
            v17_1 = v2_14;
            v25_1 = v8_6;
            v24_1 = v9_2;
            v22_1 = v10_7;
            v19_1 = v20_0;
            v0_3 = 0;
            v6_1 = 0;
        } else {
            boolean v11_21;
            int v4_0 = Math.min(v17_0[0], v4_20);
            int v6_2 = Math.min(v17_0[1], v6_10);
            if ((v3_0 != 1073741824) || (p29.o() == v4_0)) {
                v11_21 = 1;
            } else {
                p29.K(v4_0);
                v11_21 = 1;
                v13_0.b = 1;
            }
            boolean v11_22;
            if (v5_7 != 1073741824) {
                v11_22 = 1073741824;
            } else {
                if (p29.i() != v6_2) {
                    p29.H(v6_2);
                    v13_0.b = v11_21;
                }
                v11_22 = 1073741824;
            }
            if ((v3_0 != v11_22) || (v5_7 != v11_22)) {
                boolean v11_23;
                v17_1 = v2_14;
                v25_1 = v8_6;
                v24_1 = v9_2;
                v22_1 = v10_7;
                v19_1 = v20_0;
                int v2_16 = ((x.e) v13_0.d);
                if (!v13_0.b) {
                    v11_23 = 0;
                } else {
                    int v4_4 = v2_16.p0;
                    int v6_3 = v4_4.size();
                    int v8_7 = 0;
                    while (v8_7 < v6_3) {
                        int v9_7 = v4_4.get(v8_7);
                        v8_7++;
                        int v9_8 = ((x.d) v9_7);
                        v9_8.f();
                        v9_8.a = 0;
                        int v10_9 = v9_8.d;
                        Object v16_4 = v4_4;
                        v10_9.e.j = 0;
                        v10_9.g = 0;
                        v10_9.n();
                        int v4_13 = v9_8.e;
                        v4_13.e.j = 0;
                        v4_13.g = 0;
                        v4_13.m();
                        v4_4 = v16_4;
                    }
                    v11_23 = 0;
                    v2_16.f();
                    v2_16.a = 0;
                    int v4_5 = v2_16.d;
                    v4_5.e.j = 0;
                    v4_5.g = 0;
                    v4_5.n();
                    int v4_6 = v2_16.e;
                    v4_6.e.j = 0;
                    v4_6.g = 0;
                    v4_6.m();
                    v13_0.c();
                }
                int v2_19;
                v13_0.b(((x.e) v13_0.e));
                v2_16.Y = v11_23;
                v2_16.Z = v11_23;
                v2_16.d.h.d(v11_23);
                v2_16.e.h.d(v11_23);
                int v4_11 = 1073741824;
                if (v3_0 != 1073741824) {
                    v2_19 = 1;
                    v6_1 = 0;
                } else {
                    v2_19 = p29.P(v11_23, v0_2);
                    v6_1 = 1;
                }
                if (v5_7 != 1073741824) {
                    v0_3 = v2_19;
                } else {
                    v0_3 = (p29.P(1, v0_2) & v2_19);
                    v6_1++;
                }
            } else {
                boolean v11_28;
                int v4_15 = ((java.util.ArrayList) v13_0.f);
                int v6_7 = ((x.e) v13_0.d);
                if ((!v13_0.b) && (!v13_0.c)) {
                    v17_1 = v2_14;
                    v22_1 = v10_7;
                    v11_28 = 0;
                } else {
                    boolean v11_29 = v6_7.p0;
                    v17_1 = v2_14;
                    int v2_20 = v11_29.size();
                    v22_1 = v10_7;
                    int v10_10 = 0;
                    while (v10_10 < v2_20) {
                        int v10_20 = (v10_10 + 1);
                        androidx.constraintlayout.core.widgets.analyzer.e v24_2 = v2_20;
                        int v2_52 = ((x.d) v11_29.get(v10_10));
                        v2_52.f();
                        int v23_5 = v10_20;
                        v2_52.a = 0;
                        v2_52.d.n();
                        v2_52.e.m();
                        v10_10 = v23_5;
                        v2_20 = v24_2;
                    }
                    v6_7.f();
                    v11_28 = 0;
                    v6_7.a = 0;
                    v6_7.d.n();
                    v6_7.e.m();
                    v13_0.c = 0;
                }
                v13_0.b(((x.e) v13_0.e));
                v6_7.Y = v11_28;
                int v2_25 = v6_7.S;
                v6_7.Z = v11_28;
                int v10_11 = v6_7.h(v11_28);
                int v23_3 = v2_25;
                int v2_26 = v6_7.h(1);
                if (v13_0.b) {
                    v13_0.c();
                }
                int v20_1;
                int v26;
                int v9_12;
                boolean v11_32 = v6_7.p();
                v24_1 = v9_2;
                int v9_11 = v6_7.q();
                v25_1 = v8_6;
                v6_7.d.h.d(v11_32);
                v6_7.e.h.d(v9_11);
                v13_0.g();
                int v8_12 = v20_0;
                if ((v10_11 != v8_12) && (v2_26 != v8_12)) {
                    v20_1 = v9_11;
                    v26 = v11_32;
                    v9_12 = v19_0;
                } else {
                    v20_1 = v9_11;
                    if (v0_2 == 0) {
                        v26 = v11_32;
                    } else {
                        int v9_13 = v4_15.size();
                        v26 = v11_32;
                        boolean v11_33 = 0;
                        while (v11_33 < v9_13) {
                            boolean v27_0 = v4_15.get(v11_33);
                            v11_33++;
                            if (!((androidx.constraintlayout.core.widgets.analyzer.f) v27_0).k()) {
                                v0_2 = 0;
                                break;
                            }
                        }
                    }
                    if ((v0_2 == 0) || (v10_11 != v8_12)) {
                        v9_12 = v19_0;
                        int v19_2 = v0_2;
                    } else {
                        v9_12 = v19_0;
                        v6_7.I(v9_12);
                        v19_2 = v0_2;
                        v6_7.K(v13_0.d(v6_7, 0));
                        v6_7.d.e.d(v6_7.o());
                    }
                    if ((v19_2 != 0) && (v2_26 == v8_12)) {
                        v6_7.J(v9_12);
                        v6_7.H(v13_0.d(v6_7, 1));
                        v6_7.e.e.d(v6_7.i());
                    }
                }
                int v0_12;
                int v0_11 = v23_3[0];
                boolean v11_38 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.j;
                if ((v0_11 != v9_12) && (v0_11 != v11_38)) {
                    v19_1 = v8_12;
                    v0_12 = 0;
                } else {
                    int v0_14 = (v6_7.o() + v26);
                    v19_1 = v8_12;
                    v6_7.d.i.d(v0_14);
                    v6_7.d.e.d((v0_14 - v26));
                    v13_0.g();
                    int v8_17 = v23_3[1];
                    if ((v8_17 == v9_12) || (v8_17 == v11_38)) {
                        int v0_18 = (v6_7.i() + v20_1);
                        v6_7.e.i.d(v0_18);
                        v6_7.e.e.d((v0_18 - v20_1));
                    }
                    v13_0.g();
                    v0_12 = 1;
                }
                int v8_22 = v4_15.size();
                int v9_15 = 0;
                while (v9_15 < v8_22) {
                    boolean v11_56 = v4_15.get(v9_15);
                    v9_15++;
                    boolean v11_57 = ((androidx.constraintlayout.core.widgets.analyzer.f) v11_56);
                    if ((v11_57.b != v6_7) || (v11_57.g)) {
                        v11_57.e();
                    }
                }
                int v8_23 = v4_15.size();
                int v9_16 = 0;
                while (v9_16 < v8_23) {
                    boolean v11_39 = v4_15.get(v9_16);
                    v9_16++;
                    boolean v11_40 = ((androidx.constraintlayout.core.widgets.analyzer.f) v11_39);
                    if (((v0_12 != 0) || (v11_40.b != v6_7)) && (((!v11_40.h.j) || ((!v11_40.i.j) && (!(v11_40 instanceof y.f)))) || ((!v11_40.e.j) && ((!(v11_40 instanceof y.c)) && (!(v11_40 instanceof y.f)))))) {
                        v0_3 = 0;
                    }
                    v6_7.I(v10_11);
                    v6_7.J(v2_26);
                    v4_11 = 1073741824;
                    v6_1 = 2;
                }
                v0_3 = 1;
            }
            if (v0_3 != 0) {
                int v2_27;
                if (v3_0 != v4_11) {
                    v2_27 = 0;
                } else {
                    v2_27 = 1;
                }
                int v3_1;
                if (v5_7 != v4_11) {
                    v3_1 = 0;
                } else {
                    v3_1 = 1;
                }
                p29.L(v2_27, v3_1);
            }
        }
        if ((v0_3 != 0) && (v6_1 == 2)) {
            return;
        } else {
            int v0_21 = p29.C0;
            if (v21 > 0) {
                int v2_29 = p29.p0.size();
                int v3_3 = p29.S(64);
                int v4_16 = p29.t0;
                int v8_24 = 0;
                while (v8_24 < v2_29) {
                    int v5_6 = ((x.d) p29.p0.get(v8_24));
                    if ((!(v5_6 instanceof x.f)) && (!(v5_6 instanceof x.a))) {
                        v5_6.getClass();
                        if (v3_3 != 0) {
                            int v6_23 = v5_6.d;
                            if (v6_23 != 0) {
                                int v9_19 = v5_6.e;
                                if ((v9_19 != 0) && ((v6_23.e.j) && (v9_19.e.j))) {
                                    v8_24++;
                                }
                            }
                        }
                        int v10_19;
                        int v6_28 = v5_6.h(0);
                        int v9_20 = v5_6.h(1);
                        if ((v6_28 != v14_2) || ((v5_6.r == 1) || ((v9_20 != v14_2) || (v5_6.s == 1)))) {
                            v10_19 = 0;
                        } else {
                            v10_19 = 1;
                        }
                        if ((v10_19 == 0) && (p29.S(1))) {
                            if ((v6_28 == v14_2) && ((v5_6.r == 0) && ((v9_20 != v14_2) && (!v5_6.v())))) {
                                v10_19 = 1;
                            }
                            if ((v9_20 == v14_2) && ((v5_6.s == 0) && ((v6_28 != v14_2) && (!v5_6.v())))) {
                                v10_19 = 1;
                            }
                            if (((v6_28 == v14_2) || (v9_20 == v14_2)) && (v5_6.W > 0)) {
                                v10_19 = 1;
                            }
                        }
                        if (v10_19 == 0) {
                            v7_2.M(0, v4_16, v5_6);
                        }
                    }
                }
                int v2_30 = v4_16.a;
                int v3_4 = v2_30.getChildCount();
                int v4_17 = v2_30.h;
                int v8_25 = 0;
                while (v8_25 < v3_4) {
                    v2_30.getChildAt(v8_25);
                    v8_25++;
                }
                int v2_31 = v4_17.size();
                if (v2_31 > 0) {
                    int v8_26 = 0;
                    while (v8_26 < v2_31) {
                        ((a0.c) v4_17.get(v8_26)).getClass();
                        v8_26++;
                    }
                }
            }
            v7_2.W(p29);
            int v2_32 = v24_1.size();
            boolean v11_42 = 0;
            if (v21 > 0) {
                v7_2.S(p29, 0, v12_3, v15_0);
            }
            if (v2_32 > 0) {
                int v4_19;
                int v3_5 = p29.S;
                int v8_27 = v19_1;
                if (v3_5[0] != v8_27) {
                    v4_19 = 0;
                } else {
                    v4_19 = 1;
                }
                int v8_28;
                if (v3_5[1] != v8_27) {
                    v8_28 = 0;
                } else {
                    v8_28 = 1;
                }
                int v5_1 = v25_1;
                int v3_8 = Math.max(p29.o(), v5_1.b0);
                int v5_3 = Math.max(p29.i(), v5_1.c0);
                int v6_11 = 0;
                while (v6_11 < v2_32) {
                    v24_1.get(v6_11);
                    v6_11++;
                }
                int v9_17 = v24_1;
                int v6_12 = 0;
                while (v6_12 < 2) {
                    boolean v13_12 = v11_42;
                    int v14_4 = v13_12;
                    while (v13_12 < v2_32) {
                        int v32_2;
                        int v20_3;
                        androidx.constraintlayout.core.widgets.analyzer.e v18_3;
                        int v19_4;
                        int v10_15 = ((x.d) v9_17.get(v13_12));
                        if ((!(v10_15 instanceof x.a)) && (!(v10_15 instanceof x.f))) {
                            v32_2 = v2_32;
                            if ((v10_15.g0 != 8) && ((v17_1 == null) || ((!v10_15.d.e.j) || (!v10_15.e.e.j)))) {
                                int v2_40 = v10_15.o();
                                boolean v11_47 = v10_15.i();
                                v18_3 = v4_19;
                                int v4_22 = v10_15.a0;
                                v19_4 = v8_28;
                                int v8_29 = 1;
                                if (v6_12 == 1) {
                                    v8_29 = 2;
                                }
                                v20_3 = v6_12;
                                int v6_13 = v22_1;
                                int v8_31 = (v7_2.M(v8_29, v6_13, v10_15) | v14_4);
                                int v14_5 = v10_15.o();
                                v22_1 = v6_13;
                                int v6_14 = v10_15.i();
                                if (v14_5 != v2_40) {
                                    v10_15.K(v14_5);
                                    if ((v18_3 != null) && ((v10_15.p() + v10_15.U) > v3_8)) {
                                        v3_8 = Math.max(v3_8, (v10_15.g(androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.i).d() + (v10_15.p() + v10_15.U)));
                                    }
                                    v8_31 = 1;
                                }
                                boolean v11_48;
                                if (v6_14 == v11_47) {
                                    v11_48 = v8_31;
                                } else {
                                    v10_15.H(v6_14);
                                    if ((v19_4 != 0) && ((v10_15.q() + v10_15.V) > v5_3)) {
                                        v5_3 = Math.max(v5_3, (v10_15.g(androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.j).d() + (v10_15.q() + v10_15.V)));
                                    }
                                    v11_48 = 1;
                                }
                                if ((!v10_15.E) || (v4_22 == v10_15.a0)) {
                                    v14_4 = v11_48;
                                } else {
                                    v14_4 = 1;
                                }
                            } else {
                                v18_3 = v4_19;
                                v20_3 = v6_12;
                                v19_4 = v8_28;
                            }
                        } else {
                            v32_2 = v2_32;
                        }
                        v13_12++;
                        v2_32 = v32_2;
                        v4_19 = v18_3;
                        v8_28 = v19_4;
                        v6_12 = v20_3;
                        boolean v11 = 0;
                    }
                    int v32_1 = v2_32;
                    androidx.constraintlayout.core.widgets.analyzer.e v18_2 = v4_19;
                    int v19_3 = v8_28;
                    if (v14_4 == 0) {
                        break;
                    }
                    v6_12++;
                    v7_2.S(p29, v6_12, v12_3, v15_0);
                    v2_32 = v32_1;
                    v4_19 = v18_2;
                    v8_28 = v19_3;
                    v11_42 = 0;
                }
            }
            p29.C0 = v0_21;
            v.c.q = p29.S(512);
            return;
        }
    }

    public final void l(x.d p3, a0.e p4, android.util.SparseArray p5, int p6, androidx.constraintlayout.core.widgets.ConstraintAnchor$Type p7)
    {
        x.c v0_6 = ((android.view.View) this.g.get(p6));
        x.c v5_3 = ((x.d) p5.get(p6));
        if ((v5_3 != null) && ((v0_6 != null) && ((v0_6.getLayoutParams() instanceof a0.e)))) {
            p4.c0 = 1;
            androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v1 = androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.k;
            if (p7 == v1) {
                x.c v0_2 = ((a0.e) v0_6.getLayoutParams());
                v0_2.c0 = 1;
                v0_2.p0.E = 1;
            }
            p3.g(v1).a(v5_3.g(p7), p4.D, p4.C);
            p3.E = 1;
            p3.g(androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.h).g();
            p3.g(androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.j).g();
        }
        return;
    }

    public final void onLayout(boolean p5, int p6, int p7, int p8, int p9)
    {
        java.util.ArrayList v5_0 = this.getChildCount();
        int v6_0 = this.isInEditMode();
        p7 = 0;
        a0.c v8_2 = 0;
        while (v8_2 < v5_0) {
            p9 = this.getChildAt(v8_2);
            boolean v0_1 = ((a0.e) p9.getLayoutParams());
            int v1_0 = v0_1.p0;
            if ((p9.getVisibility() != 8) || ((v0_1.d0) || ((v0_1.e0) || (v6_0 != 0)))) {
                boolean v0_3 = v1_0.p();
                int v2_2 = v1_0.q();
                p9.layout(v0_3, v2_2, (v1_0.o() + v0_3), (v1_0.i() + v2_2));
            }
            v8_2++;
        }
        java.util.ArrayList v5_1 = this.h;
        int v6_1 = v5_1.size();
        if (v6_1 > 0) {
            while (p7 < v6_1) {
                ((a0.c) v5_1.get(p7)).i();
                p7++;
            }
        }
        return;
    }

    public final void onMeasure(int p34, int p35)
    {
        androidx.constraintlayout.widget.ConstraintLayout v1 = this;
        float v0_0 = this.n;
        this.n = v0_0;
        if (v0_0 == 0) {
            float v0_43 = this.getChildCount();
            float v2_24 = 0;
            while (v2_24 < v0_43) {
                if (!this.getChildAt(v2_24).isLayoutRequested()) {
                    v2_24++;
                } else {
                    this.n = 1;
                    break;
                }
            }
        }
        if (((this.getContext().getApplicationInfo().flags & 4194304) == 0) || (1 != this.getLayoutDirection())) {
            float v0_39 = 0;
        } else {
            v0_39 = 1;
        }
        int v7_1;
        int v11_4 = this.i;
        v11_4.u0 = v0_39;
        if (!this.n) {
            v7_1 = v11_4;
        } else {
            this.n = 0;
            float v0_41 = this.getChildCount();
            float v2_45 = 0;
            while (v2_45 < v0_41) {
                if (!this.getChildAt(v2_45).isLayoutRequested()) {
                    v2_45++;
                } else {
                    int v12_0 = 1;
                }
                int v23_1;
                if (v12_0 == 0) {
                    v7_1 = v11_4;
                    v23_1 = v12_0;
                } else {
                    x.a v13_0 = this.isInEditMode();
                    androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v14_0 = this.getChildCount();
                    float v0_25 = 0;
                    while (v0_25 < v14_0) {
                        float v2_20 = this.h(this.getChildAt(v0_25));
                        if (v2_20 != 0) {
                            v2_20.A();
                        }
                        v0_25++;
                    }
                    float v2_17 = this.g;
                    if (v13_0 != null) {
                        float v0_24 = 0;
                        while (v0_24 < v14_0) {
                            float v4_1 = this.getChildAt(v0_24);
                            try {
                                float v5_2 = this.getResources().getResourceName(v4_1.getId());
                                int v6_2 = Integer.valueOf(v4_1.getId());
                            } catch (android.content.res.Resources$NotFoundException) {
                                v0_24++;
                            }
                            if (v5_2 != 0) {
                                if (this.s == null) {
                                    this.s = new java.util.HashMap();
                                }
                                float v3_9;
                                float v3_8 = v5_2.indexOf("/");
                                if (v3_8 == -1) {
                                    v3_9 = v5_2;
                                } else {
                                    v3_9 = v5_2.substring((v3_8 + 1));
                                }
                                this.s.put(v3_9, v6_2);
                            }
                            float v3_12 = v5_2.indexOf(47);
                            if (v3_12 != -1) {
                                v5_2 = v5_2.substring((v3_12 + 1));
                            }
                            float v3_18;
                            float v3_14 = v4_1.getId();
                            if (v3_14 != 0) {
                                float v4_3 = ((android.view.View) v2_17.get(v3_14));
                                if (v4_3 == 0) {
                                    v4_3 = this.findViewById(v3_14);
                                    if ((v4_3 != 0) && ((v4_3 != this) && (v4_3.getParent() == this))) {
                                        this.onViewAdded(v4_3);
                                    }
                                }
                                if (v4_3 != this) {
                                    if (v4_3 != 0) {
                                        v3_18 = ((a0.e) v4_3.getLayoutParams()).p0;
                                    } else {
                                        v3_18 = 0;
                                    }
                                } else {
                                    v3_18 = v11_4;
                                }
                            }
                            v3_18.h0 = v5_2;
                        }
                    }
                    if (this.r != -1) {
                        float v0_20 = 0;
                        while (v0_20 < v14_0) {
                            this.getChildAt(v0_20).getId();
                            v0_20++;
                        }
                    }
                    int v26_4;
                    int v28_1;
                    boolean v24_1;
                    float v3_2 = this.p;
                    if (v3_2 == 0) {
                        v28_1 = v2_17;
                        v23_1 = v12_0;
                        v24_1 = v13_0;
                        v26_4 = v14_0;
                        v7_1 = v11_4;
                    } else {
                        float v4_28 = this.getChildCount();
                        int v6_30 = v3_2.c;
                        float v5_0 = new java.util.HashSet(v6_30.keySet());
                        x.a v10_3 = 0;
                        while (v10_3 < v4_28) {
                            int v21;
                            int v23_0;
                            androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v22_0;
                            int v26_0;
                            boolean v24_0;
                            int v28_0;
                            androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v31_1;
                            int v9_6 = this.getChildAt(v10_3);
                            float v0_45 = v9_6.getId();
                            int v20_2 = v10_3;
                            if (v6_30.containsKey(Integer.valueOf(v0_45))) {
                                int v15_21;
                                if (!v3_2.b) {
                                    v15_21 = -1;
                                } else {
                                    v15_21 = -1;
                                    if (v0_45 == -1) {
                                        com.google.firebase.firestore.v.f("All children of ConstraintLayout must have ids to use ConstraintSet");
                                        return;
                                    }
                                }
                                if (v0_45 != v15_21) {
                                    if (!v6_30.containsKey(Integer.valueOf(v0_45))) {
                                        v28_0 = v2_17;
                                        v21 = v3_2;
                                        v22_0 = v5_0;
                                        v31_1 = v11_4;
                                        v23_0 = v12_0;
                                        v24_0 = v13_0;
                                        v26_0 = v14_0;
                                        float v2_88 = new StringBuilder("WARNING NO CONSTRAINTS for view ");
                                        v2_88.append(v0_45);
                                        android.util.Log.v("ConstraintSet", v2_88.toString());
                                    } else {
                                        v5_0.remove(Integer.valueOf(v0_45));
                                        x.a v10_20 = ((a0.k) v6_30.get(Integer.valueOf(v0_45)));
                                        if (v10_20 != null) {
                                            int v15_24 = v10_20.b;
                                            v21 = v3_2;
                                            float v3_38 = v10_20.d;
                                            v22_0 = v5_0;
                                            float v5_40 = v10_20.e;
                                            v23_0 = v12_0;
                                            if ((v9_6 instanceof a0.a)) {
                                                v3_38.h0 = 1;
                                                int v12_34 = ((a0.a) v9_6);
                                                v12_34.setId(v0_45);
                                                v12_34.setType(v3_38.f0);
                                                v12_34.setMargin(v3_38.g0);
                                                v12_34.setAllowsGoneWidget(v3_38.n0);
                                                float v0_52 = v3_38.i0;
                                                if (v0_52 == 0) {
                                                    float v0_53 = v3_38.j0;
                                                    if (v0_53 != 0) {
                                                        float v0_54 = a0.p.b(v12_34, v0_53);
                                                        v3_38.i0 = v0_54;
                                                        v12_34.setReferencedIds(v0_54);
                                                    }
                                                } else {
                                                    v12_34.setReferencedIds(v0_52);
                                                }
                                            }
                                            float v3_40 = ((a0.e) v9_6.getLayoutParams());
                                            v3_40.a();
                                            v10_20.a(v3_40);
                                            x.a v10_2 = v10_20.f;
                                            v24_0 = v13_0;
                                            androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v8_20 = v9_6.getClass();
                                            androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v25_1 = v10_2.keySet().iterator();
                                            while (v25_1.hasNext()) {
                                                x.a v10_22;
                                                int v26_5 = v14_0;
                                                androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v14_16 = ((String) v25_1.next());
                                                float v0_89 = ((a0.b) v10_2.get(v14_16));
                                                x.a v27 = v10_2;
                                                if (v0_89.a) {
                                                    v10_22 = v14_16;
                                                } else {
                                                    v10_22 = r1.a.j("set", v14_16);
                                                }
                                                int v28_2 = v2_17;
                                                androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v31_0;
                                                Class v29 = Float.TYPE;
                                                Class v30 = Integer.TYPE;
                                                switch (v0_89.b.ordinal()) {
                                                    case 0:
                                                        v31_0 = v11_4;
                                                        v8_20.getMethod(v10_22, new Class[] {v30, v30})).invoke(v9_6, new Object[] {Integer.valueOf(v0_89.c)}));
                                                    case 1:
                                                        v31_0 = v11_4;
                                                        v8_20.getMethod(v10_22, new Class[] {v29, v29})).invoke(v9_6, new Object[] {Float.valueOf(v0_89.d)}));
                                                        break;
                                                    case 2:
                                                        v31_0 = v11_4;
                                                        v8_20.getMethod(v10_22, new Class[] {v30, v30})).invoke(v9_6, new Object[] {Integer.valueOf(v0_89.g)}));
                                                        break;
                                                    case 3:
                                                        float v2_3 = v8_20.getMethod(v10_22, new Class[] {android.graphics.drawable.Drawable}));
                                                        v31_0 = v11_4;
                                                        int v11_1 = new android.graphics.drawable.ColorDrawable();
                                                        v11_1.setColor(v0_89.g);
                                                        v2_3.invoke(v9_6, new Object[] {v11_1}));
                                                        break;
                                                    case 4:
                                                        v8_20.getMethod(v10_22, new Class[] {CharSequence})).invoke(v9_6, new Object[] {v0_89.e}));
                                                        v31_0 = v11_4;
                                                        break;
                                                    case 5:
                                                        v8_20.getMethod(v10_22, new Class[] {Boolean.TYPE})).invoke(v9_6, new Object[] {Boolean.valueOf(v0_89.f)}));
                                                        break;
                                                    case 6:
                                                        v8_20.getMethod(v10_22, new Class[] {v29, v29})).invoke(v9_6, new Object[] {Float.valueOf(v0_89.d)}));
                                                        break;
                                                    case 7:
                                                        v8_20.getMethod(v10_22, new Class[] {v30, v30})).invoke(v9_6, new Object[] {Integer.valueOf(v0_89.c)}));
                                                        break;
                                                    default:
                                                }
                                                v14_0 = v26_5;
                                                v10_2 = v27;
                                                v2_17 = v28_2;
                                                v11_4 = v31_0;
                                            }
                                            v28_0 = v2_17;
                                            v31_1 = v11_4;
                                            v26_0 = v14_0;
                                            v9_6.setLayoutParams(v3_40);
                                            if (v15_24.b == 0) {
                                                v9_6.setVisibility(v15_24.a);
                                            }
                                            v9_6.setAlpha(v15_24.c);
                                            v9_6.setRotation(v5_40.a);
                                            v9_6.setRotationX(v5_40.b);
                                            v9_6.setRotationY(v5_40.c);
                                            v9_6.setScaleX(v5_40.d);
                                            v9_6.setScaleY(v5_40.e);
                                            if (v5_40.h == -1) {
                                                if (!Float.isNaN(v5_40.f)) {
                                                    v9_6.setPivotX(v5_40.f);
                                                }
                                                if (!Float.isNaN(v5_40.g)) {
                                                    v9_6.setPivotY(v5_40.g);
                                                }
                                            } else {
                                                float v0_76 = ((android.view.View) v9_6.getParent()).findViewById(v5_40.h);
                                                if ((v0_76 != 0) && (((v9_6.getRight() - v9_6.getLeft()) > 0) && ((v9_6.getBottom() - v9_6.getTop()) > 0))) {
                                                    float v2_94 = ((((float) (v0_76.getBottom() + v0_76.getTop())) / 1073741824) - ((float) v9_6.getTop()));
                                                    v9_6.setPivotX(((((float) (v0_76.getRight() + v0_76.getLeft())) / 1073741824) - ((float) v9_6.getLeft())));
                                                    v9_6.setPivotY(v2_94);
                                                }
                                            }
                                            v9_6.setTranslationX(v5_40.i);
                                            v9_6.setTranslationY(v5_40.j);
                                            v9_6.setTranslationZ(v5_40.k);
                                            if (v5_40.l) {
                                                v9_6.setElevation(v5_40.m);
                                            }
                                        } else {
                                            v28_0 = v2_17;
                                            v21 = v3_2;
                                            v22_0 = v5_0;
                                            v31_1 = v11_4;
                                            v23_0 = v12_0;
                                            v24_0 = v13_0;
                                            v26_0 = v14_0;
                                        }
                                    }
                                }
                            } else {
                                float v0_18 = new StringBuilder("id unknown ");
                                try {
                                    int v9_2 = v9_6.getContext().getResources().getResourceEntryName(v9_6.getId());
                                } catch (Exception) {
                                    v9_2 = "UNKNOWN";
                                }
                                v0_18.append(v9_2);
                                android.util.Log.w("ConstraintSet", v0_18.toString());
                            }
                            v10_3 = (v20_2 + 1);
                            v3_2 = v21;
                            v5_0 = v22_0;
                            v12_0 = v23_0;
                            v13_0 = v24_0;
                            v14_0 = v26_0;
                            v2_17 = v28_0;
                            v11_4 = v31_1;
                            int v15 = -1;
                        }
                        v28_1 = v2_17;
                        androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v31_2 = v11_4;
                        v23_1 = v12_0;
                        v24_1 = v13_0;
                        v26_4 = v14_0;
                        float v0_75 = v5_0.iterator();
                        while (v0_75.hasNext()) {
                            float v2_84 = ((Integer) v0_75.next());
                            float v3_36 = ((a0.k) v6_30.get(v2_84));
                            if (v3_36 != 0) {
                                float v5_35 = v3_36.d;
                                if (v5_35.h0 == 1) {
                                    int v7_4 = new a0.a(this.getContext());
                                    v7_4.setVisibility(8);
                                    v7_4.setId(v2_84.intValue());
                                    androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v8_14 = v5_35.i0;
                                    if (v8_14 == null) {
                                        androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v8_15 = v5_35.j0;
                                        if (v8_15 != null) {
                                            androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v8_16 = a0.p.b(v7_4, v8_15);
                                            v5_35.i0 = v8_16;
                                            v7_4.setReferencedIds(v8_16);
                                        }
                                    } else {
                                        v7_4.setReferencedIds(v8_14);
                                    }
                                    v7_4.setType(v5_35.f0);
                                    v7_4.setMargin(v5_35.g0);
                                    androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v8_19 = androidx.constraintlayout.widget.ConstraintLayout.g();
                                    v7_4.j();
                                    v3_36.a(v8_19);
                                    this.addView(v7_4, v8_19);
                                }
                                if (v5_35.a) {
                                    float v5_38 = new a0.r(this.getContext());
                                    v5_38.setId(v2_84.intValue());
                                    float v2_86 = androidx.constraintlayout.widget.ConstraintLayout.g();
                                    v3_36.a(v2_86);
                                    this.addView(v5_38, v2_86);
                                }
                            }
                        }
                        float v0_44 = 0;
                        while (v0_44 < v4_28) {
                            float v2_81 = this.getChildAt(v0_44);
                            if ((v2_81 instanceof a0.c)) {
                                ((a0.c) v2_81).e(this);
                            }
                            v0_44++;
                        }
                        v7_1 = v31_2;
                    }
                    v7_1.p0.clear();
                    float v0_96 = this.h;
                    float v2_0 = v0_96.size();
                    androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v8_0 = 2;
                    if (v2_0 > 0) {
                        float v3_0 = 0;
                        while (v3_0 < v2_0) {
                            float v4_26 = ((a0.c) v0_96.get(v3_0));
                            float v5_34 = v4_26.m;
                            if (v4_26.isInEditMode()) {
                                v4_26.setIds(v4_26.k);
                            }
                            int v11_17;
                            int v6_27 = v4_26.j;
                            if (v6_27 != 0) {
                                v6_27.q0 = 0;
                                java.util.Arrays.fill(v6_27.p0, 0);
                                int v6_29 = 0;
                                while (v6_29 < v4_26.h) {
                                    x.a v10_10 = v4_26.g[v6_29];
                                    int v11_18 = v28_1;
                                    int v12_25 = ((android.view.View) v11_18.get(v10_10));
                                    if (v12_25 == 0) {
                                        x.a v10_13 = ((String) v5_34.get(Integer.valueOf(v10_10)));
                                        x.a v13_15 = v4_26.f(this, v10_13);
                                        if (v13_15 != null) {
                                            v4_26.g[v6_29] = v13_15;
                                            v5_34.put(Integer.valueOf(v13_15), v10_13);
                                            v12_25 = ((android.view.View) v11_18.get(v13_15));
                                        }
                                    }
                                    if (v12_25 != 0) {
                                        x.a v10_15 = v4_26.j;
                                        int v12_29 = this.h(v12_25);
                                        v10_15.getClass();
                                        if ((v12_29 != v10_15) && (v12_29 != 0)) {
                                            androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v14_12 = v10_15.p0;
                                            if ((v10_15.q0 + 1) > v14_12.length) {
                                                v10_15.p0 = ((x.d[]) java.util.Arrays.copyOf(v14_12, (v14_12.length * 2)));
                                            }
                                            androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v14_13 = v10_15.q0;
                                            v10_15.p0[v14_13] = v12_29;
                                            v10_15.q0 = (v14_13 + 1);
                                        }
                                    }
                                    v6_29++;
                                    v28_1 = v11_18;
                                }
                                v11_17 = v28_1;
                                v4_26.j.getClass();
                            } else {
                                v11_17 = v28_1;
                            }
                            v3_0++;
                            v28_1 = v11_17;
                        }
                    }
                    int v9_0 = v26_4;
                    float v0_13 = 0;
                    while (v0_13 < v9_0) {
                        this.getChildAt(v0_13);
                        v0_13++;
                    }
                    float v4_0 = this.t;
                    v4_0.clear();
                    v4_0.put(0, v7_1);
                    v4_0.put(this.getId(), v7_1);
                    float v0_22 = 0;
                    while (v0_22 < v9_0) {
                        float v2_79 = this.getChildAt(v0_22);
                        v4_0.put(v2_79.getId(), this.h(v2_79));
                        v0_22++;
                    }
                    float v0_23 = 0;
                    while (v0_23 < v9_0) {
                        float v2_77;
                        int v20_1;
                        float v2_26 = v1.getChildAt(v0_23);
                        x.a v10_5 = v1.h(v2_26);
                        if (v10_5 != null) {
                            float v3_27 = ((a0.e) v2_26.getLayoutParams());
                            v7_1.p0.add(v10_5);
                            float v5_5 = v10_5.T;
                            if (v5_5 != 0) {
                                ((x.e) v5_5).p0.remove(v10_5);
                                v10_5.A();
                            }
                            v10_5.T = v7_1;
                            v3_27.a();
                            v10_5.g0 = v2_26.getVisibility();
                            v10_5.f0 = v2_26;
                            if ((v2_26 instanceof a0.c)) {
                                ((a0.c) v2_26).h(v10_5, v7_1.u0);
                            }
                            if (!v3_27.d0) {
                                androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v14_10;
                                x.a v13_12;
                                int v11_11;
                                androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v8_9;
                                float v2_29 = v3_27.f0;
                                float v5_11 = v3_27.g0;
                                int v6_6 = v3_27.h0;
                                int v11_5 = v3_27.i0;
                                int v15_3 = v3_27.j0;
                                int v12_1 = v3_27.k0;
                                x.a v13_1 = v3_27.l0;
                                androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v14_1 = v3_27.p;
                                androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v16_0 = androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.i;
                                int v20_0 = androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.g;
                                androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v22_1 = androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.j;
                                androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v25_0 = androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.h;
                                if (v14_1 == -1) {
                                    float v2_30;
                                    float v5_14;
                                    int v11_7;
                                    androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v19;
                                    x.a v13_2;
                                    if (v2_29 == -1) {
                                        v2_30 = v11_5;
                                        v19 = v12_1;
                                        int v12_2 = v13_1;
                                        int v11_6 = v20_0;
                                        if (v5_11 != -1) {
                                            float v5_13 = ((x.d) v4_0.get(v5_11));
                                            if (v5_13 != 0) {
                                                v5_14 = v12_2;
                                                x.a v13_4 = v16_0;
                                                v10_5.t(v11_6, v5_13, v13_4, v3_27.leftMargin, v15_3);
                                                v13_2 = v11_6;
                                                v11_7 = v13_4;
                                                int v6_7;
                                                if (v6_6 == -1) {
                                                    v6_7 = v13_2;
                                                    if (v2_30 != -1) {
                                                        int v12_6 = ((x.d) v4_0.get(v2_30));
                                                        if (v12_6 != 0) {
                                                            v10_5.t(v11_7, v12_6, v11_7, v3_27.rightMargin, v19);
                                                        }
                                                    }
                                                } else {
                                                    int v12_8 = ((x.d) v4_0.get(v6_6));
                                                    if (v12_8 != 0) {
                                                        v10_5.t(v11_7, v12_8, v13_2, v3_27.rightMargin, v19);
                                                    }
                                                    v6_7 = v13_2;
                                                }
                                                x.a v13_7;
                                                androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v8_6;
                                                float v2_36 = v11_7;
                                                int v11_9 = v3_27.i;
                                                if (v11_9 == -1) {
                                                    int v11_10 = v25_0;
                                                    androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v8_3 = v3_27.j;
                                                    if (v8_3 != -1) {
                                                        androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v8_5 = ((x.d) v4_0.get(v8_3));
                                                        if (v8_5 != null) {
                                                            v8_6 = -1;
                                                            x.a v13_9 = v22_1;
                                                            v10_5.t(v11_10, v8_5, v13_9, v3_27.topMargin, v3_27.x);
                                                            v13_7 = v11_10;
                                                            v11_11 = v13_9;
                                                            androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v16_1;
                                                            int v12_13 = v3_27.k;
                                                            if (v12_13 == v8_6) {
                                                                v16_1 = v13_7;
                                                                int v12_14 = v3_27.l;
                                                                if (v12_14 != v8_6) {
                                                                    int v12_16 = ((x.d) v4_0.get(v12_14));
                                                                    if (v12_16 != 0) {
                                                                        v10_5.t(v11_11, v12_16, v11_11, v3_27.bottomMargin, v3_27.z);
                                                                    }
                                                                }
                                                            } else {
                                                                int v12_18 = ((x.d) v4_0.get(v12_13));
                                                                if (v12_18 != 0) {
                                                                    v10_5.t(v11_11, v12_18, v13_7, v3_27.bottomMargin, v3_27.z);
                                                                }
                                                                v16_1 = v13_7;
                                                            }
                                                            int v12_19 = v5_14;
                                                            float v5_15 = v3_27.m;
                                                            if (v5_15 == -1) {
                                                                v13_12 = v2_36;
                                                                v8_9 = v6_7;
                                                                float v5_16 = v3_27.n;
                                                                if (v5_16 == -1) {
                                                                    v14_10 = v16_1;
                                                                    float v5_17 = v3_27.o;
                                                                    v1 = this;
                                                                    if (v5_17 != -1) {
                                                                        this.l(v10_5, v3_27, v4_0, v5_17, v11_11);
                                                                    }
                                                                } else {
                                                                    v1 = this;
                                                                    int v6_9 = v16_1;
                                                                    this.l(v10_5, v3_27, v4_0, v5_16, v6_9);
                                                                    v14_10 = v6_9;
                                                                }
                                                            } else {
                                                                v8_9 = v6_7;
                                                                v13_12 = v2_36;
                                                                v1.l(v10_5, v3_27, v4_0, v5_15, androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.k);
                                                                v1 = this;
                                                                v14_10 = v16_1;
                                                            }
                                                            if (v12_19 >= 0) {
                                                                v10_5.d0 = v12_19;
                                                            }
                                                            float v2_41 = v3_27.F;
                                                            if (v2_41 >= 0) {
                                                                v10_5.e0 = v2_41;
                                                            }
                                                            if (v24_1) {
                                                                float v2_44 = v3_27.T;
                                                                if ((v2_44 != -1) || (v3_27.U != -1)) {
                                                                    float v5_20 = v3_27.U;
                                                                    v10_5.Y = v2_44;
                                                                    v10_5.Z = v5_20;
                                                                }
                                                            }
                                                            float v5_21 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.h;
                                                            int v12_22 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.g;
                                                            int v15_13 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.j;
                                                            int v6_11 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.i;
                                                            if (v3_27.a0) {
                                                                v20_1 = v4_0;
                                                                v10_5.I(v12_22);
                                                                v10_5.K(v3_27.width);
                                                                if (v3_27.width == -2) {
                                                                    v10_5.I(v5_21);
                                                                }
                                                            } else {
                                                                v20_1 = v4_0;
                                                                if (v3_27.width != -1) {
                                                                    v10_5.I(v6_11);
                                                                    v10_5.K(0);
                                                                } else {
                                                                    if (!v3_27.W) {
                                                                        v10_5.I(v15_13);
                                                                    } else {
                                                                        v10_5.I(v6_11);
                                                                    }
                                                                    v10_5.g(v8_9).g = v3_27.leftMargin;
                                                                    v10_5.g(v13_12).g = v3_27.rightMargin;
                                                                }
                                                            }
                                                            androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v8_10;
                                                            if (v3_27.b0) {
                                                                v8_10 = -1;
                                                                v10_5.J(v12_22);
                                                                v10_5.H(v3_27.height);
                                                                if (v3_27.height == -2) {
                                                                    v10_5.J(v5_21);
                                                                }
                                                            } else {
                                                                v8_10 = -1;
                                                                if (v3_27.height != -1) {
                                                                    v10_5.J(v6_11);
                                                                    v10_5.H(0);
                                                                } else {
                                                                    if (!v3_27.X) {
                                                                        v10_5.J(v15_13);
                                                                    } else {
                                                                        v10_5.J(v6_11);
                                                                    }
                                                                    v10_5.g(v14_10).g = v3_27.topMargin;
                                                                    v10_5.g(v11_11).g = v3_27.bottomMargin;
                                                                }
                                                            }
                                                            float v2_62 = v3_27.G;
                                                            if ((v2_62 != 0) && (v2_62.length() != 0)) {
                                                                float v5_24;
                                                                int v15_14;
                                                                float v4_13 = v2_62.length();
                                                                float v5_23 = v2_62.indexOf(44);
                                                                if ((v5_23 <= 0) || (v5_23 >= (v4_13 - 1))) {
                                                                    v15_14 = v8_10;
                                                                    v5_24 = 0;
                                                                } else {
                                                                    int v6_18;
                                                                    int v11_14 = v2_62.substring(0, v5_23);
                                                                    if (!v11_14.equalsIgnoreCase("W")) {
                                                                        if (!v11_14.equalsIgnoreCase("H")) {
                                                                            v6_18 = v8_10;
                                                                        } else {
                                                                            v6_18 = 1;
                                                                        }
                                                                    } else {
                                                                        v6_18 = 0;
                                                                    }
                                                                    v5_24 = (v5_23 + 1);
                                                                    v15_14 = v6_18;
                                                                }
                                                                float v2_64;
                                                                int v6_20 = v2_62.indexOf(58);
                                                                try {
                                                                    if ((v6_20 < 0) || (v6_20 >= (v4_13 - 1))) {
                                                                        float v2_63 = v2_62.substring(v5_24);
                                                                        if (v2_63.length() <= 0) {
                                                                            v2_64 = 0;
                                                                        } else {
                                                                            v2_64 = Float.parseFloat(v2_63);
                                                                        }
                                                                    } else {
                                                                        float v4_16 = v2_62.substring(v5_24, v6_20);
                                                                        float v2_65 = v2_62.substring((v6_20 + 1));
                                                                        if ((v4_16.length() <= 0) || (v2_65.length() <= 0)) {
                                                                        } else {
                                                                            float v4_17 = Float.parseFloat(v4_16);
                                                                            float v2_66 = Float.parseFloat(v2_65);
                                                                            if ((v4_17 <= 0) || (v2_66 <= 0)) {
                                                                            } else {
                                                                                if (v15_14 != 1) {
                                                                                    v2_64 = Math.abs((v4_17 / v2_66));
                                                                                } else {
                                                                                    v2_64 = Math.abs((v2_66 / v4_17));
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                    if (v2_64 > 0) {
                                                                        v10_5.W = v2_64;
                                                                        v10_5.X = v15_14;
                                                                    }
                                                                } catch (NumberFormatException) {
                                                                }
                                                            } else {
                                                                v10_5.W = 0;
                                                            }
                                                            float v4_20 = v10_5.k0;
                                                            v4_20[0] = v3_27.H;
                                                            v4_20[1] = v3_27.I;
                                                            v10_5.i0 = v3_27.J;
                                                            v10_5.j0 = v3_27.K;
                                                            float v2_73 = v3_27.Z;
                                                            if ((v2_73 >= 0) && (v2_73 <= 3)) {
                                                                v10_5.q = v2_73;
                                                            }
                                                            float v2_74 = v3_27.L;
                                                            float v4_22 = v3_27.N;
                                                            float v5_29 = v3_27.P;
                                                            int v6_22 = v3_27.R;
                                                            v10_5.r = v2_74;
                                                            v10_5.u = v4_22;
                                                            if (v5_29 == 2147483647) {
                                                                v5_29 = 0;
                                                            }
                                                            v10_5.v = v5_29;
                                                            v10_5.w = v6_22;
                                                            if ((v6_22 > 0) && ((v6_22 < 1065353216) && (v2_74 == 0))) {
                                                                v10_5.r = 2;
                                                            }
                                                            float v2_76 = v3_27.M;
                                                            float v5_32 = v3_27.O;
                                                            int v6_23 = v3_27.Q;
                                                            float v3_30 = v3_27.S;
                                                            v10_5.s = v2_76;
                                                            v10_5.x = v5_32;
                                                            if (v6_23 == 2147483647) {
                                                                v6_23 = 0;
                                                            }
                                                            v10_5.y = v6_23;
                                                            v10_5.z = v3_30;
                                                            if ((v3_30 <= 0) || ((v3_30 >= 1065353216) || (v2_76 != 0))) {
                                                                v2_77 = 2;
                                                            } else {
                                                                v2_77 = 2;
                                                                v10_5.s = 2;
                                                            }
                                                            v0_23++;
                                                            v8_0 = v2_77;
                                                            v4_0 = v20_1;
                                                        }
                                                    }
                                                    v13_7 = v11_10;
                                                    v8_6 = -1;
                                                    v11_11 = v22_1;
                                                } else {
                                                    int v11_12;
                                                    int v12_12 = ((x.d) v4_0.get(v11_9));
                                                    if (v12_12 == 0) {
                                                        v11_12 = v25_0;
                                                    } else {
                                                        v11_12 = v25_0;
                                                        v10_5.t(v11_12, v12_12, v25_0, v3_27.topMargin, v3_27.x);
                                                    }
                                                    v13_7 = v11_12;
                                                    v11_11 = v22_1;
                                                    v8_6 = -1;
                                                }
                                            }
                                        }
                                        v13_2 = v11_6;
                                        v5_14 = v12_2;
                                        v11_7 = v16_0;
                                    } else {
                                        int v11_8;
                                        float v2_33 = ((x.d) v4_0.get(v2_29));
                                        if (v2_33 == 0) {
                                            v2_30 = v11_5;
                                            v19 = v12_1;
                                            v5_14 = v13_1;
                                            v11_8 = v20_0;
                                        } else {
                                            v5_14 = v13_1;
                                            v19 = v12_1;
                                            v2_30 = v11_5;
                                            v11_8 = v20_0;
                                            v10_5.t(v11_8, v2_33, v20_0, v3_27.leftMargin, v15_3);
                                        }
                                        v13_2 = v11_8;
                                    }
                                } else {
                                    int v12_21 = ((x.d) v4_0.get(v14_1));
                                    if (v12_21 != 0) {
                                        float v2_43 = v3_27.r;
                                        int v11_13 = androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.l;
                                        v10_5.t(v11_13, v12_21, v11_13, v3_27.q, 0);
                                        v10_5.D = v2_43;
                                    }
                                    v13_12 = v16_0;
                                    v8_9 = v20_0;
                                    v11_11 = v22_1;
                                    v14_10 = v25_0;
                                }
                            } else {
                                x.a v10_7 = ((x.f) v10_5);
                                float v2_78 = v3_27.m0;
                                float v5_33 = v3_27.n0;
                                float v3_32 = v3_27.o0;
                                int v11_16 = v3_32 cmp -1082130432;
                                if (v11_16 == 0) {
                                    if (v2_78 == -1) {
                                        if ((v5_33 != -1) && (v5_33 > -1)) {
                                            v10_7.p0 = -1082130432;
                                            v10_7.q0 = -1;
                                            v10_7.r0 = v5_33;
                                            v20_1 = v4_0;
                                            v2_77 = v8_0;
                                        }
                                    } else {
                                        if (v2_78 > -1) {
                                            v10_7.p0 = -1082130432;
                                            v10_7.q0 = v2_78;
                                            v10_7.r0 = -1;
                                        }
                                    }
                                } else {
                                    if (v11_16 <= 0) {
                                    } else {
                                        v10_7.p0 = v3_32;
                                        v10_7.q0 = -1;
                                        v10_7.r0 = -1;
                                    }
                                }
                                v20_1 = v4_0;
                                v2_77 = v8_0;
                            }
                        }
                    }
                }
                if (v23_1 != 0) {
                    v7_1.q0.W(v7_1);
                }
            }
            v12_0 = 0;
        }
        v7_1.v0.getClass();
        v1.k(v7_1, v1.o, p34, p35);
        float v0_29 = v7_1.o();
        float v4_4 = v7_1.D0;
        float v5_3 = v7_1.E0;
        int v6_3 = v1.u;
        float v3_21 = (v7_1.i() + v6_3.e);
        float v0_32 = (android.view.View.resolveSizeAndState((v0_29 + v6_3.d), p34, 0) & 16777215);
        float v2_23 = (android.view.View.resolveSizeAndState(v3_21, p35, 0) & 16777215);
        float v0_33 = Math.min(v1.l, v0_32);
        float v2_25 = Math.min(v1.m, v2_23);
        if (v4_4 != 0) {
            v0_33 |= 16777216;
        }
        if (v5_3 != 0) {
            v2_25 |= 16777216;
        }
        v1.setMeasuredDimension(v0_33, v2_25);
        return;
    }

    public final void onViewAdded(android.view.View p5)
    {
        super.onViewAdded(p5);
        android.util.SparseArray v0_4 = this.h(p5);
        if (((p5 instanceof a0.r)) && (!(v0_4 instanceof x.f))) {
            android.util.SparseArray v0_0 = ((a0.e) p5.getLayoutParams());
            int v1_1 = new x.f();
            v0_0.p0 = v1_1;
            v0_0.d0 = 1;
            v1_1.O(v0_0.V);
        }
        if ((p5 instanceof a0.c)) {
            ((a0.c) p5).j();
            ((a0.e) p5.getLayoutParams()).e0 = 1;
            int v1_4 = this.h;
            if (!v1_4.contains(((a0.c) p5))) {
                v1_4.add(((a0.c) p5));
            }
        }
        this.g.put(p5.getId(), p5);
        this.n = 1;
        return;
    }

    public final void onViewRemoved(android.view.View p3)
    {
        super.onViewRemoved(p3);
        this.g.remove(p3.getId());
        java.util.ArrayList v0_2 = this.h(p3);
        this.i.p0.remove(v0_2);
        v0_2.A();
        this.h.remove(p3);
        this.n = 1;
        return;
    }

    public final void requestLayout()
    {
        this.n = 1;
        super.requestLayout();
        return;
    }

    public void setConstraintSet(a0.p p1)
    {
        this.p = p1;
        return;
    }

    public void setId(int p3)
    {
        android.util.SparseArray v1 = this.g;
        v1.remove(this.getId());
        super.setId(p3);
        v1.put(this.getId(), this);
        return;
    }

    public void setMaxHeight(int p2)
    {
        if (p2 != this.m) {
            this.m = p2;
            this.requestLayout();
            return;
        } else {
            return;
        }
    }

    public void setMaxWidth(int p2)
    {
        if (p2 != this.l) {
            this.l = p2;
            this.requestLayout();
            return;
        } else {
            return;
        }
    }

    public void setMinHeight(int p2)
    {
        if (p2 != this.k) {
            this.k = p2;
            this.requestLayout();
            return;
        } else {
            return;
        }
    }

    public void setMinWidth(int p2)
    {
        if (p2 != this.j) {
            this.j = p2;
            this.requestLayout();
            return;
        } else {
            return;
        }
    }

    public void setOnConstraintsChanged(a0.q p1)
    {
        p1 = this.q;
        if (p1 != null) {
            p1.getClass();
        }
        return;
    }

    public void setOptimizationLevel(int p2)
    {
        this.o = p2;
        x.e v0 = this.i;
        v0.C0 = p2;
        v.c.q = v0.S(512);
        return;
    }

    public final boolean shouldDelayChildPressedState()
    {
        return 0;
    }
}
