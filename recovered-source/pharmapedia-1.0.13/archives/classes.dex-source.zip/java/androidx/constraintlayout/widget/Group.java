// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.constraintlayout.widget;
public class Group extends a0.c {

    public Group(android.content.Context p1)
    {
        super(p1);
        return;
    }

    public Group(android.content.Context p2, android.util.AttributeSet p3)
    {
        super(p2, p3);
        java.util.HashMap v0_1 = new int[32];
        super.g = v0_1;
        super.m = new java.util.HashMap();
        super.i = p2;
        super.g(p3);
        return;
    }

    public Group(android.content.Context p1, android.util.AttributeSet p2, int p3)
    {
        super(p1, p2, p3);
        java.util.HashMap v3_2 = new int[32];
        super.g = v3_2;
        super.m = new java.util.HashMap();
        super.i = p1;
        super.g(p2);
        return;
    }

    public final void e(androidx.constraintlayout.widget.ConstraintLayout p1)
    {
        this.d(p1);
        return;
    }

    public final void i()
    {
        x.d v0_1 = ((a0.e) this.getLayoutParams());
        v0_1.p0.K(0);
        v0_1.p0.H(0);
        return;
    }

    public final void onAttachedToWindow()
    {
        super.onAttachedToWindow();
        androidx.constraintlayout.widget.ConstraintLayout v0_0 = this.getParent();
        if ((v0_0 != null) && ((v0_0 instanceof androidx.constraintlayout.widget.ConstraintLayout))) {
            this.d(((androidx.constraintlayout.widget.ConstraintLayout) v0_0));
        }
        return;
    }

    public void setElevation(float p2)
    {
        super.setElevation(p2);
        androidx.constraintlayout.widget.ConstraintLayout v2_1 = this.getParent();
        if ((v2_1 != null) && ((v2_1 instanceof androidx.constraintlayout.widget.ConstraintLayout))) {
            this.d(((androidx.constraintlayout.widget.ConstraintLayout) v2_1));
        }
        return;
    }

    public void setVisibility(int p2)
    {
        super.setVisibility(p2);
        androidx.constraintlayout.widget.ConstraintLayout v2_1 = this.getParent();
        if ((v2_1 != null) && ((v2_1 instanceof androidx.constraintlayout.widget.ConstraintLayout))) {
            this.d(((androidx.constraintlayout.widget.ConstraintLayout) v2_1));
        }
        return;
    }
}
