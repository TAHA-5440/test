// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.constraintlayout.widget;
public final enum class ConstraintAttribute$AttributeType extends java.lang.Enum {
    public static final enum androidx.constraintlayout.widget.ConstraintAttribute$AttributeType g;
    public static final enum androidx.constraintlayout.widget.ConstraintAttribute$AttributeType h;
    public static final enum androidx.constraintlayout.widget.ConstraintAttribute$AttributeType i;
    public static final enum androidx.constraintlayout.widget.ConstraintAttribute$AttributeType j;
    public static final enum androidx.constraintlayout.widget.ConstraintAttribute$AttributeType k;
    public static final enum androidx.constraintlayout.widget.ConstraintAttribute$AttributeType l;
    public static final enum androidx.constraintlayout.widget.ConstraintAttribute$AttributeType m;
    public static final enum androidx.constraintlayout.widget.ConstraintAttribute$AttributeType n;
    public static final synthetic androidx.constraintlayout.widget.ConstraintAttribute$AttributeType[] o;

    static ConstraintAttribute$AttributeType()
    {
        androidx.constraintlayout.widget.ConstraintAttribute$AttributeType[] v0_1 = new androidx.constraintlayout.widget.ConstraintAttribute$AttributeType("INT_TYPE", 0);
        androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.g = v0_1;
        androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.h = new androidx.constraintlayout.widget.ConstraintAttribute$AttributeType("FLOAT_TYPE", 1);
        androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.i = new androidx.constraintlayout.widget.ConstraintAttribute$AttributeType("COLOR_TYPE", 2);
        androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.j = new androidx.constraintlayout.widget.ConstraintAttribute$AttributeType("COLOR_DRAWABLE_TYPE", 3);
        androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.k = new androidx.constraintlayout.widget.ConstraintAttribute$AttributeType("STRING_TYPE", 4);
        androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.l = new androidx.constraintlayout.widget.ConstraintAttribute$AttributeType("BOOLEAN_TYPE", 5);
        androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.m = new androidx.constraintlayout.widget.ConstraintAttribute$AttributeType("DIMENSION_TYPE", 6);
        androidx.constraintlayout.widget.ConstraintAttribute$AttributeType v7_3 = new androidx.constraintlayout.widget.ConstraintAttribute$AttributeType("REFERENCE_TYPE", 7);
        androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.n = v7_3;
        androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.o = new androidx.constraintlayout.widget.ConstraintAttribute$AttributeType[] {v0_1, v7_3});
        return;
    }

    public static androidx.constraintlayout.widget.ConstraintAttribute$AttributeType valueOf(String p1)
    {
        return ((androidx.constraintlayout.widget.ConstraintAttribute$AttributeType) Enum.valueOf(androidx.constraintlayout.widget.ConstraintAttribute$AttributeType, p1));
    }

    public static androidx.constraintlayout.widget.ConstraintAttribute$AttributeType[] values()
    {
        return ((androidx.constraintlayout.widget.ConstraintAttribute$AttributeType[]) androidx.constraintlayout.widget.ConstraintAttribute$AttributeType.o.clone());
    }
}
