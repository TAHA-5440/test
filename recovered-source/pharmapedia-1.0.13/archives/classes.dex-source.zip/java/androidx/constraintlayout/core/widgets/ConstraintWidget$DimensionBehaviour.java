// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.constraintlayout.core.widgets;
public final enum class ConstraintWidget$DimensionBehaviour extends java.lang.Enum {
    public static final enum androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour g;
    public static final enum androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour h;
    public static final enum androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour i;
    public static final enum androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour j;
    public static final synthetic androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour[] k;

    static ConstraintWidget$DimensionBehaviour()
    {
        androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour[] v0_2 = new androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour("FIXED", 0);
        androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.g = v0_2;
        androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v1_2 = new androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour("WRAP_CONTENT", 1);
        androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.h = v1_2;
        androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v2_1 = new androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour("MATCH_CONSTRAINT", 2);
        androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.i = v2_1;
        androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v3_2 = new androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour("MATCH_PARENT", 3);
        androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.j = v3_2;
        androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.k = new androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour[] {v0_2, v1_2, v2_1, v3_2});
        return;
    }

    public static androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour valueOf(String p1)
    {
        return ((androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour) Enum.valueOf(androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour, p1));
    }

    public static androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour[] values()
    {
        return ((androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour[]) androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.k.clone());
    }
}
