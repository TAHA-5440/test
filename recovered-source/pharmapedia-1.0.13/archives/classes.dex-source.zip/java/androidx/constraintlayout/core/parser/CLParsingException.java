// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.constraintlayout.core.parser;
public class CLParsingException extends java.lang.Exception {

    public final String toString()
    {
        String v0_1 = new StringBuilder("CLParsingException (");
        v0_1.append(this.hashCode());
        v0_1.append(") : null (null at line 0)");
        return v0_1.toString();
    }
}
