// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.constraintlayout.core.widgets;
public final enum class ConstraintAnchor$Type extends java.lang.Enum {
    public static final enum androidx.constraintlayout.core.widgets.ConstraintAnchor$Type g;
    public static final enum androidx.constraintlayout.core.widgets.ConstraintAnchor$Type h;
    public static final enum androidx.constraintlayout.core.widgets.ConstraintAnchor$Type i;
    public static final enum androidx.constraintlayout.core.widgets.ConstraintAnchor$Type j;
    public static final enum androidx.constraintlayout.core.widgets.ConstraintAnchor$Type k;
    public static final enum androidx.constraintlayout.core.widgets.ConstraintAnchor$Type l;
    public static final enum androidx.constraintlayout.core.widgets.ConstraintAnchor$Type m;
    public static final enum androidx.constraintlayout.core.widgets.ConstraintAnchor$Type n;
    public static final synthetic androidx.constraintlayout.core.widgets.ConstraintAnchor$Type[] o;

    static ConstraintAnchor$Type()
    {
        androidx.constraintlayout.core.widgets.ConstraintAnchor$Type[] v0_1 = new androidx.constraintlayout.core.widgets.ConstraintAnchor$Type("NONE", 0);
        androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.g = new androidx.constraintlayout.core.widgets.ConstraintAnchor$Type("LEFT", 1);
        androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.h = new androidx.constraintlayout.core.widgets.ConstraintAnchor$Type("TOP", 2);
        androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.i = new androidx.constraintlayout.core.widgets.ConstraintAnchor$Type("RIGHT", 3);
        androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.j = new androidx.constraintlayout.core.widgets.ConstraintAnchor$Type("BOTTOM", 4);
        androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.k = new androidx.constraintlayout.core.widgets.ConstraintAnchor$Type("BASELINE", 5);
        androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.l = new androidx.constraintlayout.core.widgets.ConstraintAnchor$Type("CENTER", 6);
        androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.m = new androidx.constraintlayout.core.widgets.ConstraintAnchor$Type("CENTER_X", 7);
        androidx.constraintlayout.core.widgets.ConstraintAnchor$Type v8_3 = new androidx.constraintlayout.core.widgets.ConstraintAnchor$Type("CENTER_Y", 8);
        androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.n = v8_3;
        androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.o = new androidx.constraintlayout.core.widgets.ConstraintAnchor$Type[] {v0_1, v8_3});
        return;
    }

    public static androidx.constraintlayout.core.widgets.ConstraintAnchor$Type valueOf(String p1)
    {
        return ((androidx.constraintlayout.core.widgets.ConstraintAnchor$Type) Enum.valueOf(androidx.constraintlayout.core.widgets.ConstraintAnchor$Type, p1));
    }

    public static androidx.constraintlayout.core.widgets.ConstraintAnchor$Type[] values()
    {
        return ((androidx.constraintlayout.core.widgets.ConstraintAnchor$Type[]) androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.o.clone());
    }
}
