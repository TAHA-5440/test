// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.constraintlayout.core.widgets.analyzer;
public final class e extends androidx.constraintlayout.core.widgets.analyzer.f {
    public final androidx.constraintlayout.core.widgets.analyzer.a k;
    public y.a l;

    public e(x.d p3)
    {
        super(p3);
        int v3_3 = new androidx.constraintlayout.core.widgets.analyzer.a(super);
        super.k = v3_3;
        super.l = 0;
        super.h.e = androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.l;
        super.i.e = androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.m;
        v3_3.e = androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.n;
        super.f = 1;
        return;
    }

    public final void a(y.d p11)
    {
        if (this.j.ordinal() == 3) {
            int v11_4 = this.b;
            this.l(v11_4.I, v11_4.K, 1);
            return;
        } else {
            int v11_1 = this.e;
            float v3_7 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.i;
            if ((v11_1.c) && ((!v11_1.j) && (this.d == v3_7))) {
                float v2_3 = this.b;
                int v6_2 = v2_3.s;
                if (v6_2 == 2) {
                    int v1_0 = v2_3.T;
                    if (v1_0 != 0) {
                        int v1_2 = v1_0.e.e;
                        if (v1_2.j) {
                            v11_1.d(((int) ((((float) v1_2.g) * v2_3.z) + 1056964608)));
                        }
                    }
                } else {
                    if (v6_2 == 3) {
                        int v1_10 = v2_3.d.e;
                        if (v1_10.j) {
                            int v1_18;
                            float v2_5;
                            int v1_12;
                            int v1_15;
                            int v6_5 = v2_3.X;
                            if (v6_5 == -1) {
                                v1_12 = ((float) v1_10.g);
                                v2_5 = v2_3.W;
                                v1_15 = (v1_12 / v2_5);
                                v1_18 = ((int) (v1_15 + 1056964608));
                            } else {
                                if (v6_5 == 0) {
                                    v1_15 = (((float) v1_10.g) * v2_3.W);
                                } else {
                                    if (v6_5 == 1) {
                                        v1_12 = ((float) v1_10.g);
                                        v2_5 = v2_3.W;
                                    } else {
                                        v1_18 = 0;
                                    }
                                }
                            }
                            v11_1.d(v1_18);
                        }
                    }
                }
            }
            int v1_19 = this.h;
            int v6_6 = v1_19.l;
            if (v1_19.c) {
                float v2_8 = this.i;
                int v8_2 = v2_8.l;
                if ((v2_8.c) && ((!v1_19.j) || ((!v2_8.j) || (!v11_1.j)))) {
                    if ((!v11_1.j) && (this.d == v3_7)) {
                        int v7_13 = this.b;
                        if ((v7_13.r == 0) && (!v7_13.w())) {
                            int v0_19 = (((androidx.constraintlayout.core.widgets.analyzer.a) v6_6.get(0)).g + v1_19.f);
                            float v3_14 = (((androidx.constraintlayout.core.widgets.analyzer.a) v8_2.get(0)).g + v2_8.f);
                            int v4_3 = (v3_14 - v0_19);
                            v1_19.d(v0_19);
                            v2_8.d(v3_14);
                            v11_1.d(v4_3);
                            return;
                        }
                    }
                    if ((!v11_1.j) && ((this.d == v3_7) && ((this.a == 1) && ((v6_6.size() > 0) && (v8_2.size() > 0))))) {
                        float v3_4 = ((((androidx.constraintlayout.core.widgets.analyzer.a) v8_2.get(0)).g + v2_8.f) - (((androidx.constraintlayout.core.widgets.analyzer.a) v6_6.get(0)).g + v1_19.f));
                        int v0_4 = v11_1.m;
                        if (v3_4 >= v0_4) {
                            v11_1.d(v0_4);
                        } else {
                            v11_1.d(v3_4);
                        }
                    }
                    if ((v11_1.j) && ((v6_6.size() > 0) && (v8_2.size() > 0))) {
                        int v0_9 = ((androidx.constraintlayout.core.widgets.analyzer.a) v6_6.get(0));
                        float v3_6 = ((androidx.constraintlayout.core.widgets.analyzer.a) v8_2.get(0));
                        int v5_0 = v0_9.g;
                        int v7_2 = v3_6.g;
                        int v9_1 = this.b.e0;
                        if (v0_9 != v3_6) {
                            v5_0 = (v1_19.f + v5_0);
                            v7_2 = (v2_8.f + v7_2);
                        } else {
                            v9_1 = 1056964608;
                        }
                        v1_19.d(((int) ((((float) ((v7_2 - v5_0) - v11_1.g)) * v9_1) + (((float) v5_0) + 1056964608))));
                        v2_8.d((v1_19.g + v11_1.g));
                    }
                }
            }
            return;
        }
    }

    public final void d()
    {
        androidx.constraintlayout.core.widgets.analyzer.b v1_0 = this.b;
        androidx.constraintlayout.core.widgets.analyzer.b v3 = this.e;
        if (v1_0.a) {
            v3.d(v1_0.i());
        }
        androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v2_72 = v3.k;
        x.c v4_0 = v3.l;
        x.d v5_0 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.j;
        int v6_3 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.g;
        x.c v7_0 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.i;
        androidx.constraintlayout.core.widgets.analyzer.a v9 = this.i;
        androidx.constraintlayout.core.widgets.analyzer.a v10 = this.h;
        if (v3.j) {
            if (this.d == v5_0) {
                androidx.constraintlayout.core.widgets.analyzer.b v1_28 = this.b;
                x.d v5_1 = v1_28.T;
                if ((v5_1 != null) && (v5_1.S[1] == v6_3)) {
                    androidx.constraintlayout.core.widgets.analyzer.f.b(v10, v5_1.e.h, v1_28.I.d());
                    androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v5_1.e.i, (- this.b.K.d()));
                    return;
                }
            }
        } else {
            androidx.constraintlayout.core.widgets.analyzer.b v1_103 = this.b;
            this.d = v1_103.S[1];
            if (v1_103.E) {
                this.l = new y.a(this);
            }
            androidx.constraintlayout.core.widgets.analyzer.b v1_107 = this.d;
            if (v1_107 != v7_0) {
                if (v1_107 == v5_0) {
                    x.d v5_3 = this.b.T;
                    if ((v5_3 != null) && (v5_3.S[1] == v6_3)) {
                        androidx.constraintlayout.core.widgets.analyzer.b v1_102 = ((v5_3.i() - this.b.I.d()) - this.b.K.d());
                        androidx.constraintlayout.core.widgets.analyzer.f.b(v10, v5_3.e.h, this.b.I.d());
                        androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v5_3.e.i, (- this.b.K.d()));
                        v3.d(v1_102);
                        return;
                    }
                }
                if (v1_107 == v6_3) {
                    v3.d(this.b.i());
                }
            }
        }
        androidx.constraintlayout.core.widgets.analyzer.b v1_111 = v3.j;
        androidx.constraintlayout.core.widgets.analyzer.a v12 = this.k;
        if (v1_111 == null) {
            if ((v1_111 != null) || (this.d != v7_0)) {
                v3.b(this);
            } else {
                androidx.constraintlayout.core.widgets.analyzer.b v1_113 = this.b;
                int v14_3 = v1_113.s;
                if (v14_3 == 2) {
                    androidx.constraintlayout.core.widgets.analyzer.b v1_115 = v1_113.T;
                    if (v1_115 != null) {
                        androidx.constraintlayout.core.widgets.analyzer.b v1_117 = v1_115.e.e;
                        v4_0.add(v1_117);
                        v1_117.k.add(v3);
                        v3.b = 1;
                        v2_72.add(v10);
                        v2_72.add(v9);
                    }
                } else {
                    if ((v14_3 == 3) && (!v1_113.w())) {
                        androidx.constraintlayout.core.widgets.analyzer.b v1_120 = this.b;
                        if (v1_120.r != 3) {
                            androidx.constraintlayout.core.widgets.analyzer.b v1_122 = v1_120.d.e;
                            v4_0.add(v1_122);
                            v1_122.k.add(v3);
                            v3.b = 1;
                            v2_72.add(v10);
                            v2_72.add(v9);
                        }
                    }
                }
            }
            androidx.constraintlayout.core.widgets.analyzer.b v1_2 = this.b;
            androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v2_0 = v1_2.P;
            int v14_0 = v2_0[2];
            int v15_0 = v14_0.f;
            if ((v15_0 == 0) || (v2_0[3].f == null)) {
                if (v15_0 == 0) {
                    x.c v11_0 = v2_0[3];
                    if (v11_0.f == null) {
                        androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v2_1 = v2_0[4];
                        if (v2_1.f == null) {
                            if (!(v1_2 instanceof x.a)) {
                                androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v2_3 = v1_2.T;
                                if (v2_3 != null) {
                                    androidx.constraintlayout.core.widgets.analyzer.f.b(v10, v2_3.e.h, v1_2.q());
                                    this.c(v9, v10, 1, v3);
                                    if (this.b.E) {
                                        this.c(v12, v10, 1, this.l);
                                    }
                                    if (this.d == v7_0) {
                                        androidx.constraintlayout.core.widgets.analyzer.b v1_8 = this.b;
                                        if (v1_8.W > 0) {
                                            androidx.constraintlayout.core.widgets.analyzer.b v1_9 = v1_8.d;
                                            if (v1_9.d == v7_0) {
                                                v1_9.e.k.add(v3);
                                                v4_0.add(this.b.d.e);
                                                v3.a = this;
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            androidx.constraintlayout.core.widgets.analyzer.b v1_15 = androidx.constraintlayout.core.widgets.analyzer.f.h(v2_1);
                            if (v1_15 != null) {
                                androidx.constraintlayout.core.widgets.analyzer.f.b(v12, v1_15, 0);
                                this.c(v10, v12, -1, this.l);
                                this.c(v9, v10, 1, v3);
                            }
                        }
                    } else {
                        androidx.constraintlayout.core.widgets.analyzer.b v1_17 = androidx.constraintlayout.core.widgets.analyzer.f.h(v11_0);
                        if (v1_17 != null) {
                            androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v1_17, (- this.b.P[3].d()));
                            this.c(v10, v9, -1, v3);
                            if (this.b.E) {
                                this.c(v12, v10, 1, this.l);
                            }
                        }
                    }
                } else {
                    androidx.constraintlayout.core.widgets.analyzer.b v1_22 = androidx.constraintlayout.core.widgets.analyzer.f.h(v14_0);
                    if (v1_22 != null) {
                        androidx.constraintlayout.core.widgets.analyzer.f.b(v10, v1_22, this.b.P[2].d());
                        this.c(v9, v10, 1, v3);
                        if (this.b.E) {
                            this.c(v12, v10, 1, this.l);
                        }
                        if (this.d == v7_0) {
                            androidx.constraintlayout.core.widgets.analyzer.b v1_27 = this.b;
                            if (v1_27.W > 0) {
                                androidx.constraintlayout.core.widgets.analyzer.b v1_29 = v1_27.d;
                                if (v1_29.d == v7_0) {
                                    v1_29.e.k.add(v3);
                                    v4_0.add(this.b.d.e);
                                    v3.a = this;
                                }
                            }
                        }
                    }
                }
            } else {
                androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v2_22 = this.b;
                if (!v1_2.w()) {
                    androidx.constraintlayout.core.widgets.analyzer.b v1_38 = androidx.constraintlayout.core.widgets.analyzer.f.h(v2_22.P[2]);
                    androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v2_26 = androidx.constraintlayout.core.widgets.analyzer.f.h(this.b.P[3]);
                    if (v1_38 != null) {
                        v1_38.b(this);
                    }
                    if (v2_26 != null) {
                        v2_26.b(this);
                    }
                    this.j = androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType.h;
                } else {
                    v10.f = v2_22.P[2].d();
                    v9.f = (- this.b.P[3].d());
                }
                if (this.b.E) {
                    this.c(v12, v10, 1, this.l);
                }
            }
            if (v4_0.size() == 0) {
                v3.c = 1;
            }
        } else {
            int v14_2 = this.b;
            if (!v14_2.a) {
            } else {
                androidx.constraintlayout.core.widgets.analyzer.b v1_52 = v14_2.P;
                androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v2_27 = v1_52[2];
                x.c v4_1 = v2_27.f;
                if ((v4_1 == null) || (v1_52[3].f == null)) {
                    if (v4_1 == null) {
                        androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v2_28 = v1_52[3];
                        if (v2_28.f == null) {
                            androidx.constraintlayout.core.widgets.analyzer.b v1_53 = v1_52[4];
                            if (v1_53.f == null) {
                                if ((!(v14_2 instanceof x.a)) && ((v14_2.T != null) && (v14_2.g(androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.l).f == null))) {
                                    androidx.constraintlayout.core.widgets.analyzer.b v1_59 = this.b;
                                    androidx.constraintlayout.core.widgets.analyzer.f.b(v10, v1_59.T.e.h, v1_59.q());
                                    androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v10, v3.g);
                                    androidx.constraintlayout.core.widgets.analyzer.b v1_63 = this.b;
                                    if (v1_63.E) {
                                        androidx.constraintlayout.core.widgets.analyzer.f.b(v12, v10, v1_63.a0);
                                        return;
                                    }
                                }
                            } else {
                                androidx.constraintlayout.core.widgets.analyzer.b v1_65 = androidx.constraintlayout.core.widgets.analyzer.f.h(v1_53);
                                if (v1_65 != null) {
                                    androidx.constraintlayout.core.widgets.analyzer.f.b(v12, v1_65, 0);
                                    androidx.constraintlayout.core.widgets.analyzer.f.b(v10, v12, (- this.b.a0));
                                    androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v10, v3.g);
                                    return;
                                }
                            }
                        } else {
                            androidx.constraintlayout.core.widgets.analyzer.b v1_71 = androidx.constraintlayout.core.widgets.analyzer.f.h(v2_28);
                            if (v1_71 != null) {
                                androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v1_71, (- this.b.P[3].d()));
                                androidx.constraintlayout.core.widgets.analyzer.f.b(v10, v9, (- v3.g));
                            }
                            androidx.constraintlayout.core.widgets.analyzer.b v1_74 = this.b;
                            if (v1_74.E) {
                                androidx.constraintlayout.core.widgets.analyzer.f.b(v12, v10, v1_74.a0);
                                return;
                            }
                        }
                    } else {
                        androidx.constraintlayout.core.widgets.analyzer.b v1_77 = androidx.constraintlayout.core.widgets.analyzer.f.h(v2_27);
                        if (v1_77 != null) {
                            androidx.constraintlayout.core.widgets.analyzer.f.b(v10, v1_77, this.b.P[2].d());
                            androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v10, v3.g);
                            androidx.constraintlayout.core.widgets.analyzer.b v1_80 = this.b;
                            if (v1_80.E) {
                                androidx.constraintlayout.core.widgets.analyzer.f.b(v12, v10, v1_80.a0);
                                return;
                            }
                        }
                    }
                } else {
                    androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v2_47 = this.b;
                    if (!v14_2.w()) {
                        androidx.constraintlayout.core.widgets.analyzer.b v1_85 = androidx.constraintlayout.core.widgets.analyzer.f.h(v2_47.P[2]);
                        if (v1_85 != null) {
                            androidx.constraintlayout.core.widgets.analyzer.f.b(v10, v1_85, this.b.P[2].d());
                        }
                        androidx.constraintlayout.core.widgets.analyzer.b v1_89 = androidx.constraintlayout.core.widgets.analyzer.f.h(this.b.P[3]);
                        if (v1_89 != null) {
                            androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v1_89, (- this.b.P[3].d()));
                        }
                        v10.b = 1;
                        v9.b = 1;
                    } else {
                        v10.f = v2_47.P[2].d();
                        v9.f = (- this.b.P[3].d());
                    }
                    androidx.constraintlayout.core.widgets.analyzer.b v1_98 = this.b;
                    if (v1_98.E) {
                        androidx.constraintlayout.core.widgets.analyzer.f.b(v12, v10, v1_98.a0);
                        return;
                    }
                }
            }
        }
        return;
    }

    public final void e()
    {
        int v0_0 = this.h;
        if (v0_0.j) {
            this.b.Z = v0_0.g;
        }
        return;
    }

    public final void f()
    {
        this.c = 0;
        this.h.c();
        this.i.c();
        this.k.c();
        this.e.c();
        this.g = 0;
        return;
    }

    public final boolean k()
    {
        if (this.d != androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.i) {
            return 1;
        } else {
            if (this.b.s != 0) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public final void m()
    {
        this.g = 0;
        androidx.constraintlayout.core.widgets.analyzer.b v1_1 = this.h;
        v1_1.c();
        v1_1.j = 0;
        androidx.constraintlayout.core.widgets.analyzer.b v1_2 = this.i;
        v1_2.c();
        v1_2.j = 0;
        androidx.constraintlayout.core.widgets.analyzer.b v1_3 = this.k;
        v1_3.c();
        v1_3.j = 0;
        this.e.j = 0;
        return;
    }

    public final String toString()
    {
        String v0_1 = new StringBuilder("VerticalRun ");
        v0_1.append(this.b.h0);
        return v0_1.toString();
    }
}
