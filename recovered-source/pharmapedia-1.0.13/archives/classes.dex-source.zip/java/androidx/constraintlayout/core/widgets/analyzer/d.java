// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.constraintlayout.core.widgets.analyzer;
public final class d extends androidx.constraintlayout.core.widgets.analyzer.f {
    public static final int[] k;

    static d()
    {
        int[] v0_1 = new int[2];
        androidx.constraintlayout.core.widgets.analyzer.d.k = v0_1;
        return;
    }

    public d(x.d p2)
    {
        super(p2);
        super.h.e = androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.j;
        super.i.e = androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.k;
        super.f = 0;
        return;
    }

    public static void m(int[] p2, int p3, int p4, int p5, int p6, float p7, int p8)
    {
        int v4_1 = (p4 - p3);
        int v6_1 = (p6 - p5);
        if (p8 == -1) {
            int v3_1 = ((int) ((((float) v6_1) * p7) + 1056964608));
            int v7_1 = ((int) ((((float) v4_1) / p7) + 1056964608));
            if (v3_1 > v4_1) {
                if (v7_1 <= v6_1) {
                    p2[0] = v4_1;
                    p2[1] = v7_1;
                }
            } else {
                p2[0] = v3_1;
                p2[1] = v6_1;
                return;
            }
        } else {
            if (p8 == 0) {
                p2[0] = ((int) ((((float) v6_1) * p7) + 1056964608));
                p2[1] = v6_1;
                return;
            } else {
                if (p8 == 1) {
                    int v3_10 = ((int) ((((float) v4_1) * p7) + 1056964608));
                    p2[0] = v4_1;
                    p2[1] = v3_10;
                    return;
                }
            }
        }
        return;
    }

    public final void a(y.d p24)
    {
        if (this.j.ordinal() == 3) {
            androidx.constraintlayout.core.widgets.analyzer.b v1_7 = this.b;
            this.l(v1_7.H, v1_7.J, 0);
            return;
        } else {
            androidx.constraintlayout.core.widgets.analyzer.b v1_1 = this.e;
            int v5_0 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.i;
            int v8_0 = this.h;
            androidx.constraintlayout.core.widgets.analyzer.a v9 = this.i;
            if ((v1_1.j) || (this.d != v5_0)) {
                p24 = 1056964608;
                int v4_62 = v8_0.l;
                if (v8_0.c) {
                    int v6_26 = v9.l;
                    if ((v9.c) && ((!v8_0.j) || ((!v9.j) || (!v1_1.j)))) {
                        if ((!v1_1.j) && (this.d == v5_0)) {
                            androidx.constraintlayout.core.widgets.analyzer.b v3_37 = this.b;
                            if ((v3_37.r == 0) && (!v3_37.v())) {
                                androidx.constraintlayout.core.widgets.analyzer.b v3_62 = (((androidx.constraintlayout.core.widgets.analyzer.a) v4_62.get(0)).g + v8_0.f);
                                int v2_14 = (((androidx.constraintlayout.core.widgets.analyzer.a) v6_26.get(0)).g + v9.f);
                                int v4_66 = (v2_14 - v3_62);
                                v8_0.d(v3_62);
                                v9.d(v2_14);
                                v1_1.d(v4_66);
                                return;
                            }
                        }
                        if ((!v1_1.j) && ((this.d == v5_0) && ((this.a == 1) && ((v4_62.size() > 0) && (v6_26.size() > 0))))) {
                            int v5_18 = this.b;
                            int v7_3 = v5_18.v;
                            androidx.constraintlayout.core.widgets.analyzer.b v3_52 = Math.max(v5_18.u, Math.min(((((androidx.constraintlayout.core.widgets.analyzer.a) v6_26.get(0)).g + v9.f) - (((androidx.constraintlayout.core.widgets.analyzer.a) v4_62.get(0)).g + v8_0.f)), v1_1.m));
                            if (v7_3 > 0) {
                                v3_52 = Math.min(v7_3, v3_52);
                            }
                            v1_1.d(v3_52);
                        }
                        if (v1_1.j) {
                            androidx.constraintlayout.core.widgets.analyzer.b v3_55 = ((androidx.constraintlayout.core.widgets.analyzer.a) v4_62.get(0));
                            int v2_4 = ((androidx.constraintlayout.core.widgets.analyzer.a) v6_26.get(0));
                            int v4_63 = v3_55.g;
                            int v6_27 = v2_4.g;
                            int v10_24 = this.b.d0;
                            if (v3_55 != v2_4) {
                                v4_63 = (v8_0.f + v4_63);
                                v6_27 = (v9.f + v6_27);
                            } else {
                                v10_24 = p24;
                            }
                            v8_0.d(((int) ((((float) ((v6_27 - v4_63) - v1_1.g)) * v10_24) + (((float) v4_63) + p24))));
                            v9.d((v8_0.g + v1_1.g));
                        }
                    }
                }
            } else {
                int v4_22 = this.b;
                int v10_20 = v4_22.r;
                if (v10_20 == 2) {
                    p24 = 1056964608;
                    androidx.constraintlayout.core.widgets.analyzer.b v3_18 = v4_22.T;
                    if (v3_18 == null) {
                    } else {
                        androidx.constraintlayout.core.widgets.analyzer.b v3_20 = v3_18.d.e;
                        if (!v3_20.j) {
                        } else {
                            v1_1.d(((int) ((((float) v3_20.g) * v4_22.w) + 1056964608)));
                        }
                    }
                } else {
                    if (v10_20 == 3) {
                        int v10_22 = v4_22.s;
                        if ((v10_22 != 0) && (v10_22 != 3)) {
                            androidx.constraintlayout.core.widgets.analyzer.b v3_78;
                            androidx.constraintlayout.core.widgets.analyzer.b v3_73;
                            int v4_67;
                            androidx.constraintlayout.core.widgets.analyzer.b v3_68;
                            androidx.constraintlayout.core.widgets.analyzer.b v3_63 = v4_22.X;
                            if (v3_63 == -1) {
                                v3_68 = ((float) v4_22.e.e.g);
                                v4_67 = v4_22.W;
                                v3_73 = (v3_68 * v4_67);
                                v3_78 = ((int) (v3_73 + 1056964608));
                            } else {
                                if (v3_63 == null) {
                                    v3_73 = (((float) v4_22.e.e.g) / v4_22.W);
                                } else {
                                    if (v3_63 == 1) {
                                        v3_68 = ((float) v4_22.e.e.g);
                                        v4_67 = v4_22.W;
                                    } else {
                                        v3_78 = 0;
                                    }
                                }
                            }
                            v1_1.d(v3_78);
                        } else {
                            int v12_11;
                            androidx.constraintlayout.core.widgets.analyzer.b v3_79 = v4_22.e;
                            int v10_25 = v3_79.h;
                            androidx.constraintlayout.core.widgets.analyzer.b v3_80 = v3_79.i;
                            if (v4_22.H.f == null) {
                                v12_11 = 0;
                            } else {
                                v12_11 = 1;
                            }
                            int v13_2;
                            if (v4_22.I.f == null) {
                                v13_2 = 0;
                            } else {
                                v13_2 = 1;
                            }
                            int v14_2;
                            if (v4_22.J.f == null) {
                                v14_2 = 0;
                            } else {
                                v14_2 = 1;
                            }
                            int v15_2;
                            if (v4_22.K.f == null) {
                                v15_2 = 0;
                            } else {
                                v15_2 = 1;
                            }
                            p24 = 1056964608;
                            int v6_30 = v4_22.X;
                            if ((v12_11 == 0) || ((v13_2 == 0) || ((v14_2 == 0) || (v15_2 == 0)))) {
                                if ((v12_11 == 0) || (v14_2 == 0)) {
                                    if ((v13_2 == 0) || (v15_2 == 0)) {
                                    } else {
                                        if ((v10_25.c) && (v3_80.c)) {
                                            int v4_0 = v4_22.W;
                                            int v12_6 = (((androidx.constraintlayout.core.widgets.analyzer.a) v10_25.l.get(0)).g + v10_25.f);
                                            int v10_5 = (((androidx.constraintlayout.core.widgets.analyzer.a) v3_80.l.get(0)).g - v3_80.f);
                                            if (v6_30 != -1) {
                                                if (v6_30 == 0) {
                                                    androidx.constraintlayout.core.widgets.analyzer.b v3_1 = this.g((v10_5 - v12_6), 1);
                                                    int v6_3 = ((int) ((((float) v3_1) * v4_0) + 1056964608));
                                                    int v10_7 = this.g(v6_3, 0);
                                                    if (v6_3 != v10_7) {
                                                        v3_1 = ((int) ((((float) v10_7) / v4_0) + 1056964608));
                                                    }
                                                    v1_1.d(v10_7);
                                                    this.b.e.e.d(v3_1);
                                                } else {
                                                    if (v6_30 != 1) {
                                                    }
                                                }
                                            }
                                            androidx.constraintlayout.core.widgets.analyzer.b v3_5 = this.g((v10_5 - v12_6), 1);
                                            int v6_8 = ((int) ((((float) v3_5) / v4_0) + 1056964608));
                                            int v10_9 = this.g(v6_8, 0);
                                            if (v6_8 != v10_9) {
                                                v3_5 = ((int) ((((float) v10_9) * v4_0) + 1056964608));
                                            }
                                            v1_1.d(v10_9);
                                            this.b.e.e.d(v3_5);
                                        }
                                    }
                                } else {
                                    if ((v8_0.c) && (v9.c)) {
                                        androidx.constraintlayout.core.widgets.analyzer.b v3_11 = v4_22.W;
                                        int v4_12 = (((androidx.constraintlayout.core.widgets.analyzer.a) v8_0.l.get(0)).g + v8_0.f);
                                        int v10_15 = (((androidx.constraintlayout.core.widgets.analyzer.a) v9.l.get(0)).g - v9.f);
                                        if ((v6_30 == -1) || (v6_30 == 0)) {
                                            int v4_13 = this.g((v10_15 - v4_12), 0);
                                            int v6_12 = ((int) ((((float) v4_13) * v3_11) + 1056964608));
                                            int v10_17 = this.g(v6_12, 1);
                                            if (v6_12 != v10_17) {
                                                v4_13 = ((int) ((((float) v10_17) / v3_11) + 1056964608));
                                            }
                                            v1_1.d(v4_13);
                                            this.b.e.e.d(v10_17);
                                        } else {
                                            if (v6_30 == 1) {
                                                int v4_18 = this.g((v10_15 - v4_12), 0);
                                                int v6_16 = ((int) ((((float) v4_18) / v3_11) + 1056964608));
                                                int v10_19 = this.g(v6_16, 1);
                                                if (v6_16 != v10_19) {
                                                    v4_18 = ((int) ((((float) v10_19) * v3_11) + 1056964608));
                                                }
                                                v1_1.d(v4_18);
                                                this.b.e.e.d(v10_19);
                                            }
                                        }
                                    }
                                }
                            } else {
                                int v4_23 = v4_22.W;
                                int v12_8 = v10_25.l;
                                int[] v16 = androidx.constraintlayout.core.widgets.analyzer.d.k;
                                if ((!v10_25.j) || (!v3_80.j)) {
                                    int v21_0 = v4_23;
                                    int v22_0 = v6_30;
                                    if ((v8_0.j) && (v9.j)) {
                                        if ((v10_25.c) && (v3_80.c)) {
                                            androidx.constraintlayout.core.widgets.analyzer.d.m(v16, (v8_0.g + v8_0.f), (v9.g - v9.f), (((androidx.constraintlayout.core.widgets.analyzer.a) v12_8.get(0)).g + v10_25.f), (((androidx.constraintlayout.core.widgets.analyzer.a) v3_80.l.get(0)).g - v3_80.f), v21_0, v22_0);
                                            v1_1.d(v16[0]);
                                            this.b.e.e.d(v16[1]);
                                        } else {
                                            return;
                                        }
                                    }
                                    if ((v8_0.c) && ((v9.c) && ((v10_25.c) && (v3_80.c)))) {
                                        androidx.constraintlayout.core.widgets.analyzer.d.m(v16, (((androidx.constraintlayout.core.widgets.analyzer.a) v8_0.l.get(0)).g + v8_0.f), (((androidx.constraintlayout.core.widgets.analyzer.a) v9.l.get(0)).g - v9.f), (((androidx.constraintlayout.core.widgets.analyzer.a) v12_8.get(0)).g + v10_25.f), (((androidx.constraintlayout.core.widgets.analyzer.a) v3_80.l.get(0)).g - v3_80.f), v21_0, v22_0);
                                        v1_1.d(v16[0]);
                                        this.b.e.e.d(v16[1]);
                                    }
                                } else {
                                    if ((v8_0.c) && (v9.c)) {
                                        androidx.constraintlayout.core.widgets.analyzer.d.m(v16, (((androidx.constraintlayout.core.widgets.analyzer.a) v8_0.l.get(0)).g + v8_0.f), (((androidx.constraintlayout.core.widgets.analyzer.a) v9.l.get(0)).g - v9.f), (v10_25.g + v10_25.f), (v3_80.g - v3_80.f), v4_23, v6_30);
                                        v1_1.d(v16[0]);
                                        this.b.e.e.d(v16[1]);
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return;
        }
    }

    public final void d()
    {
        int v0_0 = this.b;
        androidx.constraintlayout.core.widgets.analyzer.b v2 = this.e;
        if (v0_0.a) {
            v2.d(v0_0.o());
        }
        androidx.constraintlayout.core.widgets.analyzer.a v1_65 = v2.k;
        x.d v3_12 = v2.l;
        int v4_0 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.j;
        androidx.constraintlayout.core.widgets.analyzer.a v5_1 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.i;
        androidx.constraintlayout.core.widgets.analyzer.a v6_1 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.g;
        androidx.constraintlayout.core.widgets.analyzer.a v8 = this.i;
        androidx.constraintlayout.core.widgets.analyzer.a v9 = this.h;
        if (v2.j) {
            if (this.d == v4_0) {
                int v0_40 = this.b;
                x.d v10_0 = v0_40.T;
                if (v10_0 != null) {
                    androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v11_1 = v10_0.S[0];
                    if ((v11_1 == v6_1) || (v11_1 == v4_0)) {
                        androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v10_0.d.h, v0_40.H.d());
                        androidx.constraintlayout.core.widgets.analyzer.f.b(v8, v10_0.d.i, (- this.b.J.d()));
                        return;
                    }
                }
            }
        } else {
            int v0_89 = this.b;
            x.d v10_2 = v0_89.S[0];
            this.d = v10_2;
            if (v10_2 != v5_1) {
                if (v10_2 == v4_0) {
                    androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v11_2 = v0_89.T;
                    if (v11_2 != null) {
                        androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour v12_1 = v11_2.S[0];
                        if ((v12_1 == v6_1) || (v12_1 == v4_0)) {
                            int v0_88 = ((v11_2.o() - this.b.H.d()) - this.b.J.d());
                            androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v11_2.d.h, this.b.H.d());
                            androidx.constraintlayout.core.widgets.analyzer.f.b(v8, v11_2.d.i, (- this.b.J.d()));
                            v2.d(v0_88);
                            return;
                        }
                    }
                }
                if (v10_2 == v6_1) {
                    v2.d(v0_89.o());
                }
            }
        }
        if (!v2.j) {
            if (this.d == v5_1) {
                int v0_95 = this.b;
                androidx.constraintlayout.core.widgets.analyzer.a v5_5 = v0_95.r;
                if (v5_5 == 2) {
                    int v0_96 = v0_95.T;
                    if (v0_96 != 0) {
                        int v0_99 = v0_96.e.e;
                        v3_12.add(v0_99);
                        v0_99.k.add(v2);
                        v2.b = 1;
                        v1_65.add(v9);
                        v1_65.add(v8);
                    }
                } else {
                    if (v5_5 == 3) {
                        if (v0_95.s != 3) {
                            int v0_102 = v0_95.e.e;
                            v3_12.add(v0_102);
                            v0_102.k.add(v2);
                            this.b.e.h.k.add(v2);
                            this.b.e.i.k.add(v2);
                            v2.b = 1;
                            v1_65.add(v9);
                            v1_65.add(v8);
                            v9.l.add(v2);
                            v8.l.add(v2);
                        } else {
                            v9.a = this;
                            v8.a = this;
                            androidx.constraintlayout.core.widgets.analyzer.a v5_0 = v0_95.e;
                            v5_0.h.a = this;
                            v5_0.i.a = this;
                            v2.a = this;
                            if (!v0_95.w()) {
                                x.d v3_0 = this.b;
                                if (!this.b.v()) {
                                    v3_0.e.e.l.add(v2);
                                } else {
                                    v3_0.e.e.l.add(v2);
                                    v1_65.add(this.b.e.e);
                                }
                            } else {
                                v3_12.add(this.b.e.e);
                                this.b.e.e.k.add(v2);
                                int v0_23 = this.b.e;
                                v0_23.e.a = this;
                                v3_12.add(v0_23.h);
                                v3_12.add(this.b.e.i);
                                this.b.e.h.k.add(v2);
                                this.b.e.i.k.add(v2);
                            }
                        }
                    }
                }
            }
            int v0_36 = this.b;
            androidx.constraintlayout.core.widgets.analyzer.a v1_2 = v0_36.P;
            x.d v3_1 = v1_2[0];
            androidx.constraintlayout.core.widgets.analyzer.a v5_3 = v3_1.f;
            if ((v5_3 == null) || (v1_2[1].f == null)) {
                if (v5_3 == null) {
                    androidx.constraintlayout.core.widgets.analyzer.a v1_3 = v1_2[1];
                    if (v1_3.f == null) {
                        if (!(v0_36 instanceof x.a)) {
                            androidx.constraintlayout.core.widgets.analyzer.a v1_5 = v0_36.T;
                            if (v1_5 != null) {
                                androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v1_5.d.h, v0_36.p());
                                this.c(v8, v9, 1, v2);
                            }
                        }
                    } else {
                        int v0_39 = androidx.constraintlayout.core.widgets.analyzer.f.h(v1_3);
                        if (v0_39 != 0) {
                            androidx.constraintlayout.core.widgets.analyzer.f.b(v8, v0_39, (- this.b.P[1].d()));
                            this.c(v9, v8, -1, v2);
                            return;
                        }
                    }
                } else {
                    int v0_42 = androidx.constraintlayout.core.widgets.analyzer.f.h(v3_1);
                    if (v0_42 != 0) {
                        androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v0_42, this.b.P[0].d());
                        this.c(v8, v9, 1, v2);
                        return;
                    }
                }
            } else {
                androidx.constraintlayout.core.widgets.analyzer.a v1_17 = this.b;
                if (!v0_36.v()) {
                    int v0_46 = androidx.constraintlayout.core.widgets.analyzer.f.h(v1_17.P[0]);
                    androidx.constraintlayout.core.widgets.analyzer.a v1_21 = androidx.constraintlayout.core.widgets.analyzer.f.h(this.b.P[1]);
                    if (v0_46 != 0) {
                        v0_46.b(this);
                    }
                    if (v1_21 != null) {
                        v1_21.b(this);
                    }
                    this.j = androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType.h;
                    return;
                } else {
                    v9.f = v1_17.P[0].d();
                    v8.f = (- this.b.P[1].d());
                    return;
                }
            }
        } else {
            int v0_93 = this.b;
            if (!v0_93.a) {
            } else {
                androidx.constraintlayout.core.widgets.analyzer.a v1_22 = v0_93.P;
                x.d v3_3 = v1_22[0];
                androidx.constraintlayout.core.widgets.analyzer.a v5_4 = v3_3.f;
                if ((v5_4 == null) || (v1_22[1].f == null)) {
                    if (v5_4 == null) {
                        androidx.constraintlayout.core.widgets.analyzer.a v1_23 = v1_22[1];
                        if (v1_23.f == null) {
                            if ((!(v0_93 instanceof x.a)) && ((v0_93.T != null) && (v0_93.g(androidx.constraintlayout.core.widgets.ConstraintAnchor$Type.l).f == null))) {
                                int v0_58 = this.b;
                                androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v0_58.T.d.h, v0_58.p());
                                androidx.constraintlayout.core.widgets.analyzer.f.b(v8, v9, v2.g);
                                return;
                            }
                        } else {
                            int v0_61 = androidx.constraintlayout.core.widgets.analyzer.f.h(v1_23);
                            if (v0_61 != 0) {
                                androidx.constraintlayout.core.widgets.analyzer.f.b(v8, v0_61, (- this.b.P[1].d()));
                                androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v8, (- v2.g));
                                return;
                            }
                        }
                    } else {
                        int v0_65 = androidx.constraintlayout.core.widgets.analyzer.f.h(v3_3);
                        if (v0_65 != 0) {
                            androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v0_65, this.b.P[0].d());
                            androidx.constraintlayout.core.widgets.analyzer.f.b(v8, v9, v2.g);
                            return;
                        }
                    }
                } else {
                    androidx.constraintlayout.core.widgets.analyzer.a v1_41 = this.b;
                    if (!v0_93.v()) {
                        int v0_71 = androidx.constraintlayout.core.widgets.analyzer.f.h(v1_41.P[0]);
                        if (v0_71 != 0) {
                            androidx.constraintlayout.core.widgets.analyzer.f.b(v9, v0_71, this.b.P[0].d());
                        }
                        int v0_75 = androidx.constraintlayout.core.widgets.analyzer.f.h(this.b.P[1]);
                        if (v0_75 != 0) {
                            androidx.constraintlayout.core.widgets.analyzer.f.b(v8, v0_75, (- this.b.P[1].d()));
                        }
                        v9.b = 1;
                        v8.b = 1;
                        return;
                    } else {
                        v9.f = v1_41.P[0].d();
                        v8.f = (- this.b.P[1].d());
                        return;
                    }
                }
            }
        }
        return;
    }

    public final void e()
    {
        int v0_0 = this.h;
        if (v0_0.j) {
            this.b.Y = v0_0.g;
        }
        return;
    }

    public final void f()
    {
        this.c = 0;
        this.h.c();
        this.i.c();
        this.e.c();
        this.g = 0;
        return;
    }

    public final boolean k()
    {
        if (this.d != androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.i) {
            return 1;
        } else {
            if (this.b.r != 0) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public final void n()
    {
        this.g = 0;
        androidx.constraintlayout.core.widgets.analyzer.b v1_0 = this.h;
        v1_0.c();
        v1_0.j = 0;
        androidx.constraintlayout.core.widgets.analyzer.b v1_1 = this.i;
        v1_1.c();
        v1_1.j = 0;
        this.e.j = 0;
        return;
    }

    public final String toString()
    {
        String v0_1 = new StringBuilder("HorizontalRun ");
        v0_1.append(this.b.h0);
        return v0_1.toString();
    }
}
