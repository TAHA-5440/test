// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.constraintlayout.core.widgets.analyzer;
public class b extends androidx.constraintlayout.core.widgets.analyzer.a {
    public int m;

    public b(androidx.constraintlayout.core.widgets.analyzer.f p1)
    {
        super(p1);
        if (!(p1 instanceof androidx.constraintlayout.core.widgets.analyzer.d)) {
            super.e = androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.i;
            return;
        } else {
            super.e = androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.h;
            return;
        }
    }

    public final void d(int p4)
    {
        if (!this.j) {
            this.j = 1;
            this.g = p4;
            java.util.ArrayList v4_1 = this.k;
            int v0_2 = v4_1.size();
            int v1 = 0;
            while (v1 < v0_2) {
                y.d v2_0 = v4_1.get(v1);
                v1++;
                ((y.d) v2_0).a(((y.d) v2_0));
            }
        }
        return;
    }
}
