// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.constraintlayout.core.widgets.analyzer;
final enum class DependencyNode$Type extends java.lang.Enum {
    public static final enum androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type g;
    public static final enum androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type h;
    public static final enum androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type i;
    public static final enum androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type j;
    public static final enum androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type k;
    public static final enum androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type l;
    public static final enum androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type m;
    public static final enum androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type n;
    public static final synthetic androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type[] o;

    static DependencyNode$Type()
    {
        androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type[] v0_1 = new androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type("UNKNOWN", 0);
        androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.g = v0_1;
        androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.h = new androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type("HORIZONTAL_DIMENSION", 1);
        androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.i = new androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type("VERTICAL_DIMENSION", 2);
        androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.j = new androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type("LEFT", 3);
        androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.k = new androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type("RIGHT", 4);
        androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.l = new androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type("TOP", 5);
        androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.m = new androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type("BOTTOM", 6);
        androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type v7_3 = new androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type("BASELINE", 7);
        androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.n = v7_3;
        androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.o = new androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type[] {v0_1, v7_3});
        return;
    }

    public static androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type valueOf(String p1)
    {
        return ((androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type) Enum.valueOf(androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type, p1));
    }

    public static androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type[] values()
    {
        return ((androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type[]) androidx.constraintlayout.core.widgets.analyzer.DependencyNode$Type.o.clone());
    }
}
