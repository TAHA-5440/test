// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.constraintlayout.core.widgets.analyzer;
public abstract class f implements y.d {
    public int a;
    public x.d b;
    public y.g c;
    public androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour d;
    public final androidx.constraintlayout.core.widgets.analyzer.b e;
    public int f;
    public boolean g;
    public final androidx.constraintlayout.core.widgets.analyzer.a h;
    public final androidx.constraintlayout.core.widgets.analyzer.a i;
    public androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType j;

    public f(x.d p2)
    {
        this.e = new androidx.constraintlayout.core.widgets.analyzer.b(this);
        this.f = 0;
        this.g = 0;
        this.h = new androidx.constraintlayout.core.widgets.analyzer.a(this);
        this.i = new androidx.constraintlayout.core.widgets.analyzer.a(this);
        this.j = androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType.g;
        this.b = p2;
        return;
    }

    public static void b(androidx.constraintlayout.core.widgets.analyzer.a p1, androidx.constraintlayout.core.widgets.analyzer.a p2, int p3)
    {
        p1.l.add(p2);
        p1.f = p3;
        p2.k.add(p1);
        return;
    }

    public static androidx.constraintlayout.core.widgets.analyzer.a h(x.c p2)
    {
        androidx.constraintlayout.core.widgets.analyzer.a v2_1 = p2.f;
        if (v2_1 != null) {
            x.d v0 = v2_1.d;
            androidx.constraintlayout.core.widgets.analyzer.a v2_12 = v2_1.e.ordinal();
            if (v2_12 == 1) {
                return v0.d.h;
            } else {
                if (v2_12 == 2) {
                    return v0.e.h;
                } else {
                    if (v2_12 == 3) {
                        return v0.d.i;
                    } else {
                        if (v2_12 == 4) {
                            return v0.e.i;
                        } else {
                            if (v2_12 == 5) {
                                return v0.e.k;
                            }
                        }
                    }
                }
            }
        }
        return 0;
    }

    public static androidx.constraintlayout.core.widgets.analyzer.a i(x.c p1, int p2)
    {
        androidx.constraintlayout.core.widgets.analyzer.a v1_1 = p1.f;
        if (v1_1 != null) {
            androidx.constraintlayout.core.widgets.analyzer.e v2_1;
            int v0_3 = v1_1.d;
            if (p2 != null) {
                v2_1 = v0_3.e;
            } else {
                v2_1 = v0_3.d;
            }
            androidx.constraintlayout.core.widgets.analyzer.a v1_6 = v1_1.e.ordinal();
            if ((v1_6 == 1) || (v1_6 == 2)) {
                return v2_1.h;
            } else {
                if ((v1_6 == 3) || (v1_6 == 4)) {
                    return v2_1.i;
                }
            }
        }
        return 0;
    }

    public final void c(androidx.constraintlayout.core.widgets.analyzer.a p3, androidx.constraintlayout.core.widgets.analyzer.a p4, int p5, androidx.constraintlayout.core.widgets.analyzer.b p6)
    {
        p3.l.add(p4);
        p3.l.add(this.e);
        p3.h = p5;
        p3.i = p6;
        p4.k.add(p3);
        p6.k.add(p3);
        return;
    }

    public abstract void d();

    public abstract void e();

    public abstract void f();

    public final int g(int p2, int p3)
    {
        int v0_0 = this.b;
        if (p3 != 0) {
            int v3_2 = v0_0.y;
            int v0_4 = Math.max(v0_0.x, p2);
            if (v3_2 > 0) {
                v0_4 = Math.min(v3_2, p2);
            }
            if (v0_4 != p2) {
                return v0_4;
            }
        } else {
            int v3_1 = v0_0.v;
            int v0_2 = Math.max(v0_0.u, p2);
            if (v3_1 > 0) {
                v0_2 = Math.min(v3_1, p2);
            }
            if (v0_2 != p2) {
                return v0_2;
            }
        }
        return p2;
    }

    public long j()
    {
        long v0_0 = this.e;
        if (!v0_0.j) {
            return 0;
        } else {
            return ((long) v0_0.g);
        }
    }

    public abstract boolean k();

    public final void l(x.c p13, x.c p14, int p15)
    {
        androidx.constraintlayout.core.widgets.analyzer.a v0 = androidx.constraintlayout.core.widgets.analyzer.f.h(p13);
        androidx.constraintlayout.core.widgets.analyzer.a v1 = androidx.constraintlayout.core.widgets.analyzer.f.h(p14);
        if ((v0.j) && (v1.j)) {
            int v13_2 = (p13.d() + v0.g);
            int v2_0 = (v1.g - p14.d());
            int v14_4 = (v2_0 - v13_2);
            androidx.constraintlayout.core.widgets.analyzer.b v3 = this.e;
            if (!v3.j) {
                float v6_0 = androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour.i;
                if (this.d == v6_0) {
                    int v4_2 = this.a;
                    if (v4_2 == 0) {
                        v3.d(this.g(v14_4, p15));
                    } else {
                        if (v4_2 == 1) {
                            v3.d(Math.min(this.g(v3.m, p15), v14_4));
                        } else {
                            if (v4_2 == 2) {
                                int v4_7 = this.b;
                                float v6_1 = v4_7.T;
                                if (v6_1 != 0) {
                                    float v6_2;
                                    if (p15 != 0) {
                                        v6_2 = v6_1.e;
                                    } else {
                                        v6_2 = v6_1.d;
                                    }
                                    float v6_3 = v6_2.e;
                                    if (v6_3.j) {
                                        int v4_8;
                                        if (p15 != 0) {
                                            v4_8 = v4_7.z;
                                        } else {
                                            v4_8 = v4_7.w;
                                        }
                                        v3.d(this.g(((int) ((((float) v6_3.g) * v4_8) + 1056964608)), p15));
                                    }
                                }
                            } else {
                                if (v4_2 == 3) {
                                    int v4_11 = this.b;
                                    androidx.constraintlayout.core.widgets.analyzer.e v9 = v4_11.d;
                                    if ((v9.d == v6_0) && (v9.a == 3)) {
                                        androidx.constraintlayout.core.widgets.analyzer.e v10_2 = v4_11.e;
                                        if ((v10_2.d == v6_0) && (v10_2.a == 3)) {
                                            if (v3.j) {
                                                int v4_17 = v3.g;
                                                float v6_15 = this.i;
                                                boolean v7_2 = this.h;
                                                if (v4_17 != v14_4) {
                                                    int v14_1;
                                                    int v14_5 = this.b;
                                                    if (p15 != 0) {
                                                        v14_1 = v14_5.e0;
                                                    } else {
                                                        v14_1 = v14_5.d0;
                                                    }
                                                    if (v0 == v1) {
                                                        v13_2 = v0.g;
                                                        v2_0 = v1.g;
                                                        v14_1 = 1056964608;
                                                    }
                                                    v7_2.d(((int) ((((float) ((v2_0 - v13_2) - v4_17)) * v14_1) + (((float) v13_2) + 1056964608))));
                                                    v6_15.d((v7_2.g + v3.g));
                                                } else {
                                                    v7_2.d(v13_2);
                                                    v6_15.d(v2_0);
                                                    return;
                                                }
                                            }
                                            return;
                                        }
                                    }
                                    if (p15 == 0) {
                                        v9 = v4_11.e;
                                    }
                                    float v6_9 = v9.e;
                                    if (v6_9.j) {
                                        int v4_15;
                                        int v4_12 = v4_11.W;
                                        float v6_10 = v6_9.g;
                                        if (p15 != 1) {
                                            v4_15 = ((int) ((v4_12 * ((float) v6_10)) + 1056964608));
                                        } else {
                                            v4_15 = ((int) ((((float) v6_10) / v4_12) + 1056964608));
                                        }
                                        v3.d(v4_15);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return;
    }
}
