// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.constraintlayout.core;
public final enum class SolverVariable$Type extends java.lang.Enum {
    public static final enum androidx.constraintlayout.core.SolverVariable$Type g;
    public static final enum androidx.constraintlayout.core.SolverVariable$Type h;
    public static final enum androidx.constraintlayout.core.SolverVariable$Type i;
    public static final enum androidx.constraintlayout.core.SolverVariable$Type j;
    public static final synthetic androidx.constraintlayout.core.SolverVariable$Type[] k;

    static SolverVariable$Type()
    {
        androidx.constraintlayout.core.SolverVariable$Type[] v0_2 = new androidx.constraintlayout.core.SolverVariable$Type("UNRESTRICTED", 0);
        androidx.constraintlayout.core.SolverVariable$Type.g = v0_2;
        androidx.constraintlayout.core.SolverVariable$Type v1_2 = new androidx.constraintlayout.core.SolverVariable$Type("CONSTANT", 1);
        androidx.constraintlayout.core.SolverVariable$Type v2_0 = new androidx.constraintlayout.core.SolverVariable$Type("SLACK", 2);
        androidx.constraintlayout.core.SolverVariable$Type.h = v2_0;
        androidx.constraintlayout.core.SolverVariable$Type v3_2 = new androidx.constraintlayout.core.SolverVariable$Type("ERROR", 3);
        androidx.constraintlayout.core.SolverVariable$Type.i = v3_2;
        androidx.constraintlayout.core.SolverVariable$Type v4_3 = new androidx.constraintlayout.core.SolverVariable$Type("UNKNOWN", 4);
        androidx.constraintlayout.core.SolverVariable$Type.j = v4_3;
        androidx.constraintlayout.core.SolverVariable$Type.k = new androidx.constraintlayout.core.SolverVariable$Type[] {v0_2, v1_2, v2_0, v3_2, v4_3});
        return;
    }

    public static androidx.constraintlayout.core.SolverVariable$Type valueOf(String p1)
    {
        return ((androidx.constraintlayout.core.SolverVariable$Type) Enum.valueOf(androidx.constraintlayout.core.SolverVariable$Type, p1));
    }

    public static androidx.constraintlayout.core.SolverVariable$Type[] values()
    {
        return ((androidx.constraintlayout.core.SolverVariable$Type[]) androidx.constraintlayout.core.SolverVariable$Type.k.clone());
    }
}
