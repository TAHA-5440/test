// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package androidx.constraintlayout.core.widgets.analyzer;
final enum class WidgetRun$RunType extends java.lang.Enum {
    public static final enum androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType g;
    public static final enum androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType h;
    public static final synthetic androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType[] i;

    static WidgetRun$RunType()
    {
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType[] v0_2 = new androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType("NONE", 0);
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType.g = v0_2;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType v1_2 = new androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType("START", 1);
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType v2_0 = new androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType("END", 2);
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType v3_2 = new androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType("CENTER", 3);
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType.h = v3_2;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType.i = new androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType[] {v0_2, v1_2, v2_0, v3_2});
        return;
    }

    public static androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType valueOf(String p1)
    {
        return ((androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType) Enum.valueOf(androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType, p1));
    }

    public static androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType[] values()
    {
        return ((androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType[]) androidx.constraintlayout.core.widgets.analyzer.WidgetRun$RunType.i.clone());
    }
}
