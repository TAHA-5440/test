// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a1;
public abstract class b {
    public static final java.util.LinkedHashSet a;

    static b()
    {
        a1.b.a = new java.util.LinkedHashSet();
        return;
    }
}
