// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a1;
public abstract class a {

    public static final boolean a(android.content.Context p0, String p1)
    {
        p0.getClass();
        p1.getClass();
        return p0.deleteSharedPreferences(p1);
    }
}
