// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a1;
public final class c {
    public final android.content.SharedPreferences a;
    public final java.util.Set b;

    public c(android.content.SharedPreferences p1, java.util.Set p2)
    {
        p1.getClass();
        this.a = p1;
        this.b = p2;
        return;
    }
}
