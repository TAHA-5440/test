// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package s3;
public class j {
    public final java.util.LinkedHashMap a;
    public final long b;
    public long c;

    public j(long p5)
    {
        this.a = new java.util.LinkedHashMap(100, 1061158912, 1);
        this.b = p5;
        return;
    }

    public final declared_synchronized Object a(Object p2)
    {
        int v2_4;
        int v2_2 = ((s3.i) this.a.get(p2));
        if (v2_2 == 0) {
            v2_4 = 0;
        } else {
            v2_4 = v2_2.a;
        }
        return v2_4;
    }

    public int b(Object p1)
    {
        return 1;
    }

    public void c(Object p1, Object p2)
    {
        return;
    }

    public final declared_synchronized Object d(Object p8, Object p9)
    {
        s3.i v0_0 = this.b(p9);
        Object v1_1 = ((long) v0_0);
        Object v4 = 0;
        if (v1_1 < this.b) {
            if (p9 != null) {
                this.c = (this.c + v1_1);
            }
            s3.i v2_1;
            Object v1_0 = this.a;
            if (p9 != null) {
                v2_1 = new s3.i(p9, v0_0);
            } else {
                v2_1 = 0;
            }
            s3.i v0_2 = ((s3.i) v1_0.put(p8, v2_1));
            if (v0_2 != null) {
                this.c = (this.c - ((long) v0_2.b));
                if (!v0_2.a.equals(p9)) {
                    this.c(p8, v0_2.a);
                }
            }
            this.e(this.b);
            if (v0_2 != null) {
                v4 = v0_2.a;
            }
            return v4;
        } else {
            this.c(p8, p9);
            return 0;
        }
    }

    public final declared_synchronized void e(long p8)
    {
        while (this.c > p8) {
            Object v0_2 = this.a.entrySet().iterator();
            Object v1_1 = ((java.util.Map$Entry) v0_2.next());
            s3.i v2_1 = ((s3.i) v1_1.getValue());
            this.c = (this.c - ((long) v2_1.b));
            Object v1_2 = v1_1.getKey();
            v0_2.remove();
            this.c(v1_2, v2_1.a);
        }
        return;
    }
}
