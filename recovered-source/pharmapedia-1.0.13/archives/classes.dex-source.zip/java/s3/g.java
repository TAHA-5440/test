// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package s3;
public interface g {

    public abstract Object get();
}
