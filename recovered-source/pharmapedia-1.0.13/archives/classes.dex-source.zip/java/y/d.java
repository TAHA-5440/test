// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package y;
public interface d {

    public abstract void a(y.d p0);
}
