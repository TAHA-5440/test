// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package e1;
public interface j {

    public abstract void a(com.bumptech.glide.i p0);
}
