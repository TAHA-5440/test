// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package e1;
public interface o {

    public abstract boolean a(CharSequence p0, int p1, int p2, e1.v p3);

    public abstract Object getResult();
}
