// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package n2;
public interface c {
}
