// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package m;
public interface s1 {

    public abstract void d(l.m p0, android.view.MenuItem p1);

    public abstract void o(l.m p0, l.p p1);
}
