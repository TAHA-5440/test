// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package m;
public interface l {

    public abstract boolean a();

    public abstract boolean c();
}
