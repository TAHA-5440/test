// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package m;
public class o extends android.widget.AutoCompleteTextView {
    public static final int[] j;
    public final m.p g;
    public final m.s0 h;
    public final m.a0 i;

    static o()
    {
        m.o.j = new int[] {16843126});
        return;
    }

    public o(android.content.Context p4, android.util.AttributeSet p5, int p6)
    {
        super(p4, p5, p6);
        m.b2.a(super, super.getContext());
        android.text.method.KeyListener v4_10 = androidx.lifecycle.j.N(p6, 0, super.getContext(), p5, m.o.j);
        if (((android.content.res.TypedArray) v4_10.i).hasValue(0)) {
            super.setDropDownBackgroundDrawable(v4_10.x(0));
        }
        v4_10.P();
        android.text.method.KeyListener v4_3 = new m.p(super);
        super.g = v4_3;
        v4_3.k(p5, p6);
        android.text.method.KeyListener v4_5 = new m.s0(super);
        super.h = v4_5;
        v4_5.h(p5, p6);
        v4_5.b();
        android.text.method.KeyListener v4_7 = new m.a0(super);
        super.i = v4_7;
        v4_7.b(p5, p6);
        android.text.method.KeyListener v5_1 = super.getKeyListener();
        if (!(v5_1 instanceof android.text.method.NumberKeyListener)) {
            boolean v6_2 = super.isFocusable();
            boolean v0_1 = super.isClickable();
            boolean v1_3 = super.isLongClickable();
            int v2 = super.getInputType();
            android.text.method.KeyListener v4_8 = v4_7.a(v5_1);
            if (v4_8 != v5_1) {
                super.setKeyListener(v4_8);
                super.setRawInputType(v2);
                super.setFocusable(v6_2);
                super.setClickable(v0_1);
                super.setLongClickable(v1_3);
            }
        }
        return;
    }

    public final void drawableStateChanged()
    {
        super.drawableStateChanged();
        m.s0 v0_0 = this.g;
        if (v0_0 != null) {
            v0_0.a();
        }
        m.s0 v0_1 = this.h;
        if (v0_1 != null) {
            v0_1.b();
        }
        return;
    }

    public android.view.ActionMode$Callback getCustomSelectionActionModeCallback()
    {
        return g6.f0.x(super.getCustomSelectionActionModeCallback());
    }

    public android.content.res.ColorStateList getSupportBackgroundTintList()
    {
        int v0_0 = this.g;
        if (v0_0 == 0) {
            return 0;
        } else {
            return v0_0.h();
        }
    }

    public android.graphics.PorterDuff$Mode getSupportBackgroundTintMode()
    {
        int v0_0 = this.g;
        if (v0_0 == 0) {
            return 0;
        } else {
            return v0_0.i();
        }
    }

    public android.content.res.ColorStateList getSupportCompoundDrawablesTintList()
    {
        return this.h.f();
    }

    public android.graphics.PorterDuff$Mode getSupportCompoundDrawablesTintMode()
    {
        return this.h.g();
    }

    public android.view.inputmethod.InputConnection onCreateInputConnection(android.view.inputmethod.EditorInfo p3)
    {
        android.view.inputmethod.InputConnection v0 = super.onCreateInputConnection(p3);
        com.bumptech.glide.d.w(p3, v0, this);
        return this.i.c(v0, p3);
    }

    public void setBackgroundDrawable(android.graphics.drawable.Drawable p1)
    {
        super.setBackgroundDrawable(p1);
        m.p v1_1 = this.g;
        if (v1_1 != null) {
            v1_1.m();
        }
        return;
    }

    public void setBackgroundResource(int p2)
    {
        super.setBackgroundResource(p2);
        m.p v0 = this.g;
        if (v0 != null) {
            v0.n(p2);
        }
        return;
    }

    public final void setCompoundDrawables(android.graphics.drawable.Drawable p1, android.graphics.drawable.Drawable p2, android.graphics.drawable.Drawable p3, android.graphics.drawable.Drawable p4)
    {
        super.setCompoundDrawables(p1, p2, p3, p4);
        m.s0 v1_1 = this.h;
        if (v1_1 != null) {
            v1_1.b();
        }
        return;
    }

    public final void setCompoundDrawablesRelative(android.graphics.drawable.Drawable p1, android.graphics.drawable.Drawable p2, android.graphics.drawable.Drawable p3, android.graphics.drawable.Drawable p4)
    {
        super.setCompoundDrawablesRelative(p1, p2, p3, p4);
        m.s0 v1_1 = this.h;
        if (v1_1 != null) {
            v1_1.b();
        }
        return;
    }

    public void setCustomSelectionActionModeCallback(android.view.ActionMode$Callback p1)
    {
        super.setCustomSelectionActionModeCallback(g6.f0.z(p1, this));
        return;
    }

    public void setDropDownBackgroundResource(int p2)
    {
        this.setDropDownBackgroundDrawable(t6.a.h(this.getContext(), p2));
        return;
    }

    public void setEmojiCompatEnabled(boolean p2)
    {
        this.i.d(p2);
        return;
    }

    public void setKeyListener(android.text.method.KeyListener p2)
    {
        super.setKeyListener(this.i.a(p2));
        return;
    }

    public void setSupportBackgroundTintList(android.content.res.ColorStateList p2)
    {
        m.p v0 = this.g;
        if (v0 != null) {
            v0.s(p2);
        }
        return;
    }

    public void setSupportBackgroundTintMode(android.graphics.PorterDuff$Mode p2)
    {
        m.p v0 = this.g;
        if (v0 != null) {
            v0.t(p2);
        }
        return;
    }

    public void setSupportCompoundDrawablesTintList(android.content.res.ColorStateList p2)
    {
        m.s0 v0 = this.h;
        v0.n(p2);
        v0.b();
        return;
    }

    public void setSupportCompoundDrawablesTintMode(android.graphics.PorterDuff$Mode p2)
    {
        m.s0 v0 = this.h;
        v0.o(p2);
        v0.b();
        return;
    }

    public final void setTextAppearance(android.content.Context p2, int p3)
    {
        super.setTextAppearance(p2, p3);
        m.s0 v0 = this.h;
        if (v0 != null) {
            v0.i(p2, p3);
        }
        return;
    }
}
