// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package f;
public abstract class h {
    public final java.util.HashMap a;
    public final java.util.HashMap b;
    public final java.util.HashMap c;
    public java.util.ArrayList d;
    public final transient java.util.HashMap e;
    public final java.util.HashMap f;
    public final android.os.Bundle g;

    public h()
    {
        this.a = new java.util.HashMap();
        this.b = new java.util.HashMap();
        this.c = new java.util.HashMap();
        this.d = new java.util.ArrayList();
        this.e = new java.util.HashMap();
        this.f = new java.util.HashMap();
        this.g = new android.os.Bundle();
        return;
    }

    public final boolean a(int p4, int p5, android.content.Intent p6)
    {
        int v4_5 = ((String) this.a.get(Integer.valueOf(p4)));
        if (v4_5 != 0) {
            g.a v0_1 = ((f.f) this.e.get(v4_5));
            if (v0_1 == null) {
                this.f.remove(v4_5);
                this.g.putParcelable(v4_5, new f.a(p5, p6));
            } else {
                f.b v1 = v0_1.a;
                if ((v1 == null) || (!this.d.contains(v4_5))) {
                } else {
                    v1.a(v0_1.b.c(p5, p6));
                    this.d.remove(v4_5);
                }
            }
            return 1;
        } else {
            return 0;
        }
    }

    public abstract void b(int p0, g.a p1, Object p2);

    public final f.e c(String p5, androidx.lifecycle.v p6, g.a p7, f.b p8)
    {
        f.d v0_0 = p6.getLifecycle();
        f.g v1_3 = ((androidx.lifecycle.z) v0_0);
        if (v1_3.i.compareTo(androidx.lifecycle.Lifecycle$State.j) >= 0) {
            StringBuilder v7_2 = new StringBuilder("LifecycleOwner ");
            v7_2.append(p6);
            f.e v6_1 = v1_3.i;
            v7_2.append(" is attempting to register while current state is ");
            v7_2.append(v6_1);
            v7_2.append(". LifecycleOwners must call register before they are STARTED.");
            throw new IllegalStateException(v7_2.toString());
        } else {
            this.e(p5);
            f.e v6_4 = this.c;
            f.g v1_2 = ((f.g) v6_4.get(p5));
            if (v1_2 == null) {
                v1_2 = new f.g(v0_0);
            }
            f.d v0_2 = new f.d(this, p5, p8, p7);
            v1_2.a.a(v0_2);
            v1_2.b.add(v0_2);
            v6_4.put(p5, v1_2);
            return new f.e(this, p5, p7, 0);
        }
    }

    public final f.e d(String p3, g.a p4, f.b p5)
    {
        this.e(p3);
        this.e.put(p3, new f.f(p4, p5));
        int v0_6 = this.f;
        if (v0_6.containsKey(p3)) {
            android.content.Intent v1_0 = v0_6.get(p3);
            v0_6.remove(p3);
            p5.a(v1_0);
        }
        int v0_1 = this.g;
        android.content.Intent v1_2 = ((f.a) v0_1.getParcelable(p3));
        if (v1_2 != null) {
            v0_1.remove(p3);
            p5.a(p4.c(v1_2.g, v1_2.h));
        }
        return new f.e(this, p3, p4, 1);
    }

    public final void e(String p7)
    {
        java.util.HashMap v0 = this.b;
        if (((Integer) v0.get(p7)) == null) {
            Integer v1_4 = ya.c.h.a(2147418112);
            while(true) {
                Integer v1_0 = (v1_4 + 65536);
                java.util.HashMap v5 = this.a;
                if (!v5.containsKey(Integer.valueOf(v1_0))) {
                    break;
                }
                v1_4 = ya.c.h.a(2147418112);
            }
            v5.put(Integer.valueOf(v1_0), p7);
            v0.put(p7, Integer.valueOf(v1_0));
            return;
        } else {
            return;
        }
    }

    public final void f(String p8)
    {
        if (!this.d.contains(p8)) {
            java.util.HashMap v0_8 = ((Integer) this.b.remove(p8));
            if (v0_8 != null) {
                this.a.remove(v0_8);
            }
        }
        this.e.remove(p8);
        java.util.HashMap v0_2 = this.f;
        if (v0_2.containsKey(p8)) {
            f.g v1_1 = r1.a.w("Dropping pending result for request ", p8, ": ");
            v1_1.append(v0_2.get(p8));
            android.util.Log.w("ActivityResultRegistry", v1_1.toString());
            v0_2.remove(p8);
        }
        java.util.HashMap v0_4 = this.g;
        if (v0_4.containsKey(p8)) {
            f.g v1_4 = r1.a.w("Dropping pending result for request ", p8, ": ");
            v1_4.append(v0_4.getParcelable(p8));
            android.util.Log.w("ActivityResultRegistry", v1_4.toString());
            v0_4.remove(p8);
        }
        java.util.HashMap v0_6 = this.c;
        f.g v1_7 = ((f.g) v0_6.get(p8));
        if (v1_7 != null) {
            java.util.ArrayList v2_2 = v1_7.b;
            int v3_1 = v2_2.size();
            int v4_1 = 0;
            while (v4_1 < v3_1) {
                androidx.lifecycle.t v5_1 = v2_2.get(v4_1);
                v4_1++;
                v1_7.a.b(((androidx.lifecycle.t) v5_1));
            }
            v2_2.clear();
            v0_6.remove(p8);
        }
        return;
    }
}
