// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package f;
public interface i {

    public abstract f.h getActivityResultRegistry();
}
