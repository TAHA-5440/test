// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package a6;
public final synthetic class a implements com.google.firebase.components.ComponentFactory {
    public final synthetic com.google.firebase.components.Qualified a;
    public final synthetic com.google.firebase.components.Qualified b;
    public final synthetic com.google.firebase.components.Qualified c;
    public final synthetic com.google.firebase.components.Qualified d;

    public synthetic a(com.google.firebase.components.Qualified p1, com.google.firebase.components.Qualified p2, com.google.firebase.components.Qualified p3, com.google.firebase.components.Qualified p4)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        this.d = p4;
        return;
    }

    public final Object create(com.google.firebase.components.ComponentContainer p5)
    {
        return com.google.firebase.appcheck.FirebaseAppCheckRegistrar.a(this.a, this.b, this.c, this.d, p5);
    }
}
