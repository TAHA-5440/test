// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package w2;
public interface a {

    public abstract boolean g(Object p0, java.io.File p1, w2.g p2);
}
