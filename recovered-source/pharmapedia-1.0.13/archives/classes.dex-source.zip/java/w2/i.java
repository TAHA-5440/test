// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package w2;
public interface i implements w2.a {

    public abstract com.bumptech.glide.load.EncodeStrategy n(w2.g p0);
}
