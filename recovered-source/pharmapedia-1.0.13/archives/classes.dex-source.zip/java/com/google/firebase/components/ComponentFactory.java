// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.google.firebase.components;
public interface ComponentFactory {

    public abstract Object create(com.google.firebase.components.ComponentContainer p0);
}
