// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.google.common.util.concurrent;
public interface ListenableFuture implements java.util.concurrent.Future {

    public abstract void addListener(Runnable p0, java.util.concurrent.Executor p1);
}
