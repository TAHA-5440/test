// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package f0;
public interface e {

    public abstract void addOnTrimMemoryListener(p0.a p0);

    public abstract void removeOnTrimMemoryListener(p0.a p0);
}
