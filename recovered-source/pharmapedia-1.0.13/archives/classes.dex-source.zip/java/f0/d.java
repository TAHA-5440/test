// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package f0;
public interface d {

    public abstract void addOnConfigurationChangedListener(p0.a p0);

    public abstract void removeOnConfigurationChangedListener(p0.a p0);
}
