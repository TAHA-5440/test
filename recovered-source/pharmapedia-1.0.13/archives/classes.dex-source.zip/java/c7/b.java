// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package c7;
public interface b {

    public abstract Object a();
}
