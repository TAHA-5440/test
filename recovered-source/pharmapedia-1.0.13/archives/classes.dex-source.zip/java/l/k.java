// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package l;
public interface k {

    public abstract void f(l.m p0);

    public abstract boolean m(l.m p0, android.view.MenuItem p1);
}
