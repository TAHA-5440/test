// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package l;
public interface l {

    public abstract boolean a(l.p p0);
}
