// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package l;
public interface b0 {

    public abstract void b(l.m p0);
}
