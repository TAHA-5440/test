// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package l;
public interface a0 {

    public abstract void b(l.p p0);

    public abstract l.p getItemData();
}
