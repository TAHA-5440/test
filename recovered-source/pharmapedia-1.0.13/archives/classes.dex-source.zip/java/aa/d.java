// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package aa;
public final class d {
    public final g7.c1 a;
    public String b;

    public d()
    {
        this.a = new g7.c1(8, 0);
        return;
    }
}
