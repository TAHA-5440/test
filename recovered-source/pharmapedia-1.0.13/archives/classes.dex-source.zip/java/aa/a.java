// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package aa;
public final class a extends aa.c {
    public final String b;
    public final p7.b c;

    public a(String p1, p7.b p2)
    {
        this.b = p1;
        if (p2 == null) {
            com.onesignal.notifications.internal.badges.impl.shortcutbadger.impl.a.j("Null attributes");
            throw 0;
        } else {
            this.c = p2;
            return;
        }
    }

    public final boolean equals(Object p5)
    {
        if (p5 != this) {
            if ((p5 instanceof aa.c)) {
                p7.b v1_6 = this.b;
                if (v1_6 != null) {
                    if (!v1_6.equals(((aa.a) ((aa.c) p5)).b)) {
                        return 0;
                    }
                } else {
                    if (((aa.a) ((aa.c) p5)).b != null) {
                        return 0;
                    }
                }
                if (this.c.equals(((aa.a) ((aa.c) p5)).c)) {
                    return 1;
                }
            }
            return 0;
        } else {
            return 1;
        }
    }

    public final int hashCode()
    {
        int v0_2;
        int v0_0 = this.b;
        if (v0_0 != 0) {
            v0_2 = v0_0.hashCode();
        } else {
            v0_2 = 0;
        }
        return (((v0_2 ^ 1000003) * 1000003) ^ this.c.hashCode());
    }

    public final String toString()
    {
        String v0_2 = new StringBuilder("Resource{schemaUrl=");
        v0_2.append(this.b);
        v0_2.append(", attributes=");
        v0_2.append(this.c);
        v0_2.append("}");
        return v0_2.toString();
    }
}
