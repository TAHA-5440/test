// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package aa;
public final synthetic class b implements java.util.function.BiConsumer {

    public final void accept(Object p5, Object p6)
    {
        int v1 = 0;
        if (!((u7.e) p5).b.isEmpty()) {
            String v5_4 = ((u7.e) p5).b;
            if (v5_4.length() <= 255) {
                int v0_1 = 0;
                while (v0_1 < v5_4.length()) {
                    char v2_1 = v5_4.charAt(v0_1);
                    if ((v2_1 >= 32) && (v2_1 <= 126)) {
                        v0_1++;
                    }
                }
                v1 = 1;
            }
        }
        u7.d.a(v1, "Attribute key should be a ASCII string with a length greater than 0 and not exceed 255 characters.");
        java.util.Objects.requireNonNull(p6, "Attribute value should be a ASCII string with a length not exceed 255 characters.");
        return;
    }
}
