// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package aa;
public abstract class c {
    public static final aa.a a;

    static c()
    {
        p7.a v0_2 = java.util.logging.Logger.getLogger(aa.c.getName());
        String v1_3 = io.opentelemetry.api.common.AttributeType.g;
        aa.a v2_5 = u7.e.a(v1_3, "service.name");
        g7.c1 v3_0 = u7.e.a(v1_3, "telemetry.sdk.language");
        String v4_1 = u7.e.a(v1_3, "telemetry.sdk.name");
        String v1_0 = u7.e.a(v1_3, "telemetry.sdk.version");
        String v5_2 = aa.c.a(0, p7.a.j);
        aa.a v2_1 = aa.c.a(0, p7.b.b(v2_5, "unknown_service:java"));
        g7.c1 v7_2 = new g7.c1(8, 0);
        v7_2.m(v4_1, "opentelemetry");
        v7_2.m(v3_0, "java");
        v7_2.m(v1_0, "1.55.0");
        String v1_2 = aa.c.a(0, v7_2.f());
        if (v1_2 != v5_2) {
            g7.c1 v3_3 = new g7.c1(8, 0);
            String v4_4 = v2_1.b;
            v3_3.n(v2_1.c);
            aa.a v2_3 = v1_2.b;
            v3_3.n(v1_2.c);
            if (v2_3 != null) {
                if (v4_4 != null) {
                    if (v2_3.equals(v4_4)) {
                        v2_1 = aa.c.a(v4_4, v3_3.f());
                    } else {
                        String v1_7 = new StringBuilder("Attempting to merge Resources with different schemaUrls. The resulting Resource will have no schemaUrl assigned. Schema 1: ");
                        v1_7.append(v4_4);
                        v1_7.append(" Schema 2: ");
                        v1_7.append(v2_3);
                        v0_2.info(v1_7.toString());
                        v2_1 = aa.c.a(0, v3_3.f());
                    }
                } else {
                    v2_1 = aa.c.a(v2_3, v3_3.f());
                }
            } else {
                v2_1 = aa.c.a(v4_4, v3_3.f());
            }
        }
        aa.c.a = v2_1;
        return;
    }

    public static aa.a a(String p1, p7.b p2)
    {
        java.util.Objects.requireNonNull(p2, "attributes");
        p2.forEach(new aa.b());
        return new aa.a(p1, p2);
    }
}
