Credential-sanitized decompiled Java approximations and instruction listings.
Not original Kotlin/Java source, a verified build, native C/C++ source, or Firebase backend code.
Every class has a bytecode listing; Java approximations are best-effort and may contain decompiler errors.
No original APK/DEX binaries or medicine records are included.
