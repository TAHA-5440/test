// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package oc;
public interface c0 {

    public abstract oc.d0 getSource();

    public abstract oc.b0 m();
}
