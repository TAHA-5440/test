// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package oc;
public interface d0 implements java.io.Closeable {

    public abstract long N(long p0, oc.i p1);

    public abstract oc.f0 a();
}
