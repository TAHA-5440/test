// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package oc;
public interface b0 implements java.io.Closeable, java.io.Flushable {

    public abstract void D(long p0, oc.i p1);

    public abstract oc.f0 a();

    public abstract void close();

    public abstract void flush();
}
