// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package ga;
public interface e {

    public abstract Object getValue();

    public abstract boolean isInitialized();
}
