// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package ga;
public final class m {
    public static final ga.m a;

    static m()
    {
        ga.m.a = new ga.m();
        return;
    }
}
