// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package ga;
public final class p {
    public static final ga.p a;

    static p()
    {
        ga.p.a = new ga.p();
        return;
    }

    public final String toString()
    {
        return "kotlin.Unit";
    }
}
