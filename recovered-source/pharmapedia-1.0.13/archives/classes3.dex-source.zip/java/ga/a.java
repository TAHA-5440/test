// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package ga;
public abstract class a {
    public static final kotlin.coroutines.intrinsics.CoroutineSingletons a;

    static a()
    {
        ga.a.a = kotlin.coroutines.intrinsics.CoroutineSingletons.g;
        return;
    }
}
