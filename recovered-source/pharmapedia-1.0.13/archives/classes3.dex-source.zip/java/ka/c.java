// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package ka;
public interface c {

    public abstract ka.g getContext();

    public abstract void resumeWith(Object p0);
}
