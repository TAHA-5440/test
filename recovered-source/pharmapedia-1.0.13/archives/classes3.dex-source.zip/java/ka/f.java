// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package ka;
public interface f {
}
