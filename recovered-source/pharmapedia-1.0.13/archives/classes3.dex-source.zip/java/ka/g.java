// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package ka;
public interface g {

    public abstract Object B(Object p0, ua.p p1);

    public abstract ka.g L(ka.g p0);

    public abstract ka.e Z(ka.f p0);

    public abstract ka.g i(ka.f p0);
}
