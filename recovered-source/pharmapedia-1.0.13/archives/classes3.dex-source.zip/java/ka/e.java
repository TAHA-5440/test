// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package ka;
public interface e implements ka.g {

    public abstract ka.f getKey();
}
