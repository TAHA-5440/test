// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public abstract class e0 {
    public static final nb.d a;
    public static final gb.k1 b;

    static e0()
    {
        gb.e0.a = nb.d.j;
        gb.e0.b = gb.k1.i;
        return;
    }
}
