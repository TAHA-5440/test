// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public interface a0 {

    public abstract gb.g0 M(long p0, gb.j1 p1, ka.g p2);

    public abstract void c0(long p0, gb.h p1);
}
