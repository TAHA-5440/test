// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public final class f1 extends gb.v0 {

    public final boolean q(Throwable p1)
    {
        return 0;
    }
}
