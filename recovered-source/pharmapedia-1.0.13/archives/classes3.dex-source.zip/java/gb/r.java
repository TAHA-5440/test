// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public final class r implements ka.f {
    public final ua.l g;
    public final ka.f h;

    public r(ka.f p1, ua.l p2)
    {
        p1.getClass();
        this.g = p2;
        if ((p1 instanceof gb.r)) {
            p1 = ((gb.r) p1).h;
        }
        this.h = p1;
        return;
    }
}
