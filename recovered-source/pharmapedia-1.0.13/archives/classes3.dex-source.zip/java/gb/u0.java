// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public interface u0 implements ka.e {

    public abstract boolean d();

    public abstract void h(java.util.concurrent.CancellationException p0);
}
