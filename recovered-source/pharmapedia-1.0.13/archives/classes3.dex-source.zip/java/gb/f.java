// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public interface f implements ka.c {

    public abstract void a(Object p0, ua.q p1);

    public abstract boolean e(Throwable p0);

    public abstract com.google.gson.internal.b f(Object p0, ua.q p1);

    public abstract void j(Object p0);
}
