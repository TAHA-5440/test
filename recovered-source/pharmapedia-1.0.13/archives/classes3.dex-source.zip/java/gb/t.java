// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public final class t implements ka.f {
    public static final synthetic gb.t g;
    public static final synthetic gb.t h;

    static synthetic t()
    {
        gb.t.g = new gb.t();
        gb.t.h = new gb.t();
        return;
    }
}
