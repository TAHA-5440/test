// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public interface s0 {

    public abstract boolean d();

    public abstract gb.c1 e();
}
