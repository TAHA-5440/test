// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public interface g0 {

    public abstract void b();
}
