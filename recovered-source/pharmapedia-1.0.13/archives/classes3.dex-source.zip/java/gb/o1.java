// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public final class o1 extends ka.a {
    public static final gb.t i;
    public boolean h;

    static o1()
    {
        gb.o1.i = new gb.t();
        return;
    }
}
