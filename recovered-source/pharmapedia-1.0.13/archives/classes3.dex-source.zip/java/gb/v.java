// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public interface v {

    public abstract ka.g M();
}
