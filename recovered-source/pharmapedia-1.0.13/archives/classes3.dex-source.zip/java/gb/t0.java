// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public final class t0 {
    public final gb.s0 a;

    public t0(gb.s0 p1)
    {
        this.a = p1;
        return;
    }
}
