// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public final class c1 extends kotlinx.coroutines.internal.a implements gb.s0 {

    public final boolean d()
    {
        return 1;
    }

    public final gb.c1 e()
    {
        return this;
    }

    public final boolean i()
    {
        return 0;
    }
}
