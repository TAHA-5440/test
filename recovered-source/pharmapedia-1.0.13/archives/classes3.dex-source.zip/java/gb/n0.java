// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public final class n0 extends lb.u {
    public long c;
}
