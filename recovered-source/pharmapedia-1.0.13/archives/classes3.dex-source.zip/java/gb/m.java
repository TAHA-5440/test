// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public interface m implements gb.u0 {
}
