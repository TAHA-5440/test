// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public final class d1 implements gb.g0, gb.k {
    public static final gb.d1 g;

    static d1()
    {
        gb.d1.g = new gb.d1();
        return;
    }

    public final boolean a(Throwable p1)
    {
        return 0;
    }

    public final void b()
    {
        return;
    }

    public final gb.u0 getParent()
    {
        return 0;
    }

    public final String toString()
    {
        return "NonDisposableHandle";
    }
}
