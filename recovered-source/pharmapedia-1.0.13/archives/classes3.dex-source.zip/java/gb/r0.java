// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public final class r0 implements gb.s0 {
    public final gb.c1 g;

    public r0(gb.c1 p1)
    {
        this.g = p1;
        return;
    }

    public final boolean d()
    {
        return 0;
    }

    public final gb.c1 e()
    {
        return this.g;
    }
}
