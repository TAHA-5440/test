// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public interface n1 {

    public abstract void b(lb.p p0, int p1);
}
