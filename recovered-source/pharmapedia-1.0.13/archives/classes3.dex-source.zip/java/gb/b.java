// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public final class b implements gb.e1 {
    public static final gb.b a;

    static b()
    {
        gb.b.a = new gb.b();
        return;
    }

    public final String toString()
    {
        return "Active";
    }
}
