// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public abstract class p0 extends gb.s implements java.io.Closeable, java.lang.AutoCloseable {

    static p0()
    {
        gb.s.h.getClass();
        return;
    }

    public abstract java.util.concurrent.Executor h0();
}
