// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package gb;
public interface k implements gb.g0 {

    public abstract boolean a(Throwable p0);

    public abstract gb.u0 getParent();
}
