// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package fc;
public abstract class l {
    public static final fc.k a;

    static l()
    {
        fc.l.a = new fc.k();
        return;
    }

    public void b(fc.p p1, fc.c0 p2)
    {
        p2.getClass();
        return;
    }

    public abstract void c(fc.x p0);
}
