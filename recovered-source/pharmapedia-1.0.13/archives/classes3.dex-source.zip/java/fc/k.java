// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package fc;
public final class k extends fc.l {

    public final void c(fc.x p3)
    {
        p3.c(okhttp3.internal.http2.ErrorCode.m, 0);
        return;
    }
}
