// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package fc;
public final class a {
    public static final fc.a a;

    static a()
    {
        fc.a.a = new fc.a();
        return;
    }
}
