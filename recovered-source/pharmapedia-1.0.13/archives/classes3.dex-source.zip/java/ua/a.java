// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package ua;
public interface a implements ga.c {

    public abstract Object invoke();
}
