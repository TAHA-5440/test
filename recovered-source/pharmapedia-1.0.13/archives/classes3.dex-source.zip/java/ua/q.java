// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package ua;
public interface q implements ga.c {

    public abstract Object invoke(Object p0, Object p1, Object p2);
}
