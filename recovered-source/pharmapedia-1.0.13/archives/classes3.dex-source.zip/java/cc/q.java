// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package cc;
public final class q extends oc.e {
    public final synthetic cc.r n;

    public q(cc.r p1)
    {
        this.n = p1;
        return;
    }

    public final void j()
    {
        this.n.c();
        return;
    }
}
