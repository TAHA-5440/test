// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package cc;
public interface x {

    public abstract boolean b();

    public abstract cc.x c();

    public abstract void cancel();

    public abstract cc.s d();

    public abstract cc.w e();

    public abstract cc.w g();
}
