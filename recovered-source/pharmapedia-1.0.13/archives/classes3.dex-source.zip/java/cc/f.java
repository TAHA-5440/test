// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package cc;
public final class f {
    public static final cc.f a;

    static f()
    {
        cc.f.a = new cc.f();
        return;
    }
}
