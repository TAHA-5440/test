// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package cc;
public interface j {

    public abstract cc.s b();

    public abstract cc.y c();
}
