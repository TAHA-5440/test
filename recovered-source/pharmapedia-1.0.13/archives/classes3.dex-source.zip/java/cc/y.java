// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package cc;
public interface y {

    public abstract boolean a(cc.s p0);

    public abstract yb.a d();

    public abstract boolean e();

    public abstract boolean f(yb.u p0);

    public abstract ha.h g();

    public abstract cc.x h();
}
