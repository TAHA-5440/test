// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package bb;
public interface e implements bb.b, ga.c {

    public abstract boolean isExternal();

    public abstract boolean isInfix();

    public abstract boolean isInline();

    public abstract boolean isOperator();

    public abstract boolean isSuspend();
}
