// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package bb;
public interface g implements bb.f, ua.p {
}
