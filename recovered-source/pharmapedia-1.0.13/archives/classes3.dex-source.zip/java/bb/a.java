// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package bb;
public interface a {

    public abstract java.util.List getAnnotations();
}
