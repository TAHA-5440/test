// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package bb;
public interface c implements bb.d, bb.a {
}
