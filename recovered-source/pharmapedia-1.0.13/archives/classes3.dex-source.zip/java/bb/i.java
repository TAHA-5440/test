// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package bb;
public interface i implements bb.h, ua.l {
}
