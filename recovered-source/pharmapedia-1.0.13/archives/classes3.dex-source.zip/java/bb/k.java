// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package bb;
public interface k implements bb.b {

    public abstract boolean isConst();

    public abstract boolean isLateinit();
}
