// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package bb;
public interface f implements bb.e {
}
