// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package bb;
public interface l implements bb.a {
}
