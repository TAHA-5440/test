// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package bb;
public interface j implements bb.k, ua.l {

    public abstract Object get(Object p0);

    public abstract Object getDelegate(Object p0);

    public abstract bb.i getGetter();
}
