// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package ma;
public interface b {

    public abstract ma.b getCallerFrame();
}
