// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package db;
public abstract class k extends db.j {
}
