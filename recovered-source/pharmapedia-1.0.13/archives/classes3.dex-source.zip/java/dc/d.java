// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package dc;
public interface d {

    public abstract void a(cc.r p0, java.io.IOException p1);

    public abstract void cancel();

    public abstract void f();

    public abstract yb.e0 h();
}
