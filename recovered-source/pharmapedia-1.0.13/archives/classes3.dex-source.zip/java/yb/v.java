// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package yb;
public interface v {

    public abstract yb.b0 a(dc.g p0);
}
