// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package yb;
public interface i implements java.lang.Cloneable {
}
