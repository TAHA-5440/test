// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package yb;
public interface f0 {
    public static final yb.b a;

    static f0()
    {
        yb.f0.a = new yb.b();
        return;
    }
}
