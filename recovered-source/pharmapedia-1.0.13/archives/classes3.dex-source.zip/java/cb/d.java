// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package cb;
public interface d implements cb.h {

    public abstract cb.h a(int p0);
}
