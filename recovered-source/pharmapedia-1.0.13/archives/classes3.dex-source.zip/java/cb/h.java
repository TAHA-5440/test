// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package cb;
public interface h {

    public abstract java.util.Iterator iterator();
}
