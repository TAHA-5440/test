// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.onesignal.core.internal.database.CBu.kcthxfgthxetfcgehtihooc;
public final class qqslrslubbjqrpywsjwpqqpaqvjll {
    public static final int BYESEPFJSJ = 3348680648;
    public static final int HVNKCVJZGR = 3573171724;
    public static final int NEGKJMRIFF = 762412167;
    public static final int YQJOKFSXWD = 1588008270;
}
