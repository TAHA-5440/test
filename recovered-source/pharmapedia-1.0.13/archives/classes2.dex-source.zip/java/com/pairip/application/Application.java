// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.pairip.application;
public class Application extends vet.pharmapedia.vetpharmapediapakistan.MyAppClass {

    public Application()
    {
        return;
    }

    protected void attachBaseContext(android.content.Context p1)
    {
        com.pairip.licensecheck.LicenseClient.checkLicense(p1);
        super.attachBaseContext(p1);
        return;
    }
}
