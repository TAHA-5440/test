// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.pairip.licensecheck;
public final synthetic class LicenseClient$$ExternalSyntheticLambda13 implements java.lang.Runnable {
    public final synthetic com.pairip.licensecheck.LicenseClient f$0;
    public final synthetic com.pairip.licensecheck.RepeatedCheckMetadata f$1;

    public synthetic LicenseClient$$ExternalSyntheticLambda13(com.pairip.licensecheck.LicenseClient p1, com.pairip.licensecheck.RepeatedCheckMetadata p2)
    {
        this.f$0 = p1;
        this.f$1 = p2;
        return;
    }

    public final void run()
    {
        com.pairip.licensecheck.LicenseClient.$r8$lambda$8YRQpF8qc5JOZUcKq79QHnbGjYY(this.f$0, this.f$1);
        return;
    }
}
