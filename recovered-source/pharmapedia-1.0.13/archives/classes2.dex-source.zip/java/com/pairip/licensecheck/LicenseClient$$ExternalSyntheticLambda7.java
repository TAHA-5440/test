// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.pairip.licensecheck;
public final synthetic class LicenseClient$$ExternalSyntheticLambda7 implements java.lang.Runnable {
    public final synthetic com.pairip.licensecheck.LicenseClient f$0;

    public synthetic LicenseClient$$ExternalSyntheticLambda7(com.pairip.licensecheck.LicenseClient p1)
    {
        this.f$0 = p1;
        return;
    }

    public final void run()
    {
        com.pairip.licensecheck.LicenseClient.$r8$lambda$GS82Fij7VQePgSFog-s63-Rcyb0(this.f$0);
        return;
    }
}
