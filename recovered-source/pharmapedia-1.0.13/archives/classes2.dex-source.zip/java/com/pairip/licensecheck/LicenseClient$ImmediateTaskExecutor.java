// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.pairip.licensecheck;
public interface LicenseClient$ImmediateTaskExecutor {

    public abstract void run(Runnable p0);
}
