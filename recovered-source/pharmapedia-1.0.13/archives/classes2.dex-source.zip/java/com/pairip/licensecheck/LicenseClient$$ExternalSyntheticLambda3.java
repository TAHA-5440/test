// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.pairip.licensecheck;
public final synthetic class LicenseClient$$ExternalSyntheticLambda3 implements java.lang.Runnable {
    public final synthetic com.pairip.licensecheck.LicenseClient f$0;
    public final synthetic com.pairip.licensecheck.LicenseCheckException f$1;

    public synthetic LicenseClient$$ExternalSyntheticLambda3(com.pairip.licensecheck.LicenseClient p1, com.pairip.licensecheck.LicenseCheckException p2)
    {
        this.f$0 = p1;
        this.f$1 = p2;
        return;
    }

    public final void run()
    {
        com.pairip.licensecheck.LicenseClient.$r8$lambda$nn58bl0tYjCXTurL0z1br2IkQ-g(this.f$0, this.f$1);
        return;
    }
}
