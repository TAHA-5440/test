// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.pairip.licensecheck;
public final synthetic class LicenseClient$$ExternalSyntheticLambda1 implements java.lang.Runnable {
    public final synthetic com.pairip.licensecheck.LicenseClient f$0;
    public final synthetic boolean f$1;
    public final synthetic com.pairip.licensecheck.LicenseCheckException f$2;
    public final synthetic boolean f$3;

    public synthetic LicenseClient$$ExternalSyntheticLambda1(com.pairip.licensecheck.LicenseClient p1, boolean p2, com.pairip.licensecheck.LicenseCheckException p3, boolean p4)
    {
        this.f$0 = p1;
        this.f$1 = p2;
        this.f$2 = p3;
        this.f$3 = p4;
        return;
    }

    public final void run()
    {
        com.pairip.licensecheck.LicenseClient.$r8$lambda$tB8S6FJPE8_x6-ohvmHs84x5lek(this.f$0, this.f$1, this.f$2, this.f$3);
        return;
    }
}
