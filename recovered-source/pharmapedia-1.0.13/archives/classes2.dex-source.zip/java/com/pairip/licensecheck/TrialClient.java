// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.pairip.licensecheck;
public final class TrialClient {

    private TrialClient()
    {
        return;
    }

    public static void stopTrial(android.content.Context p0)
    {
        com.pairip.licensecheck.LicenseClient.stopTrial(p0);
        return;
    }
}
