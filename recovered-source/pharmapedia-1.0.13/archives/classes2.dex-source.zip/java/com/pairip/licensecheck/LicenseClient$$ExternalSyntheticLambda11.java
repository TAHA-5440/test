// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.pairip.licensecheck;
public final synthetic class LicenseClient$$ExternalSyntheticLambda11 implements java.lang.Runnable {

    public synthetic LicenseClient$$ExternalSyntheticLambda11()
    {
        return;
    }

    public final void run()
    {
        com.pairip.licensecheck.LicenseClient.lambda$reportSuccessfulLicenseCheck$0();
        return;
    }
}
