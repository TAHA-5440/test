// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.pairip.licensecheck;
public class LicenseClient implements android.content.ServiceConnection {
    private static final String BACKGROUND_SERVICE_INTERFACE_CLASS_NAME = "com.android.vending.licensing.IBackgroundLicensingService";
    private static final int ERROR_INVALID_PACKAGE_NAME = 3;
    private static final int EVENTUAL_SHUTDOWN_DELAY_MILLIS = 30000;
    private static final String EXTRA_END_CUSTOM_TRIAL = "end_custom_trial";
    private static final int FIRST_ISOLATED_UID = 99000;
    private static final int FLAG_RPC_CALL = 0;
    private static final int LAST_ISOLATED_UID = 99999;
    private static final int LICENSED = 0;
    private static final int MAX_RETRIES = 3;
    private static final int MILLIS_PER_SEC = 1000;
    private static final long MIN_TRIAL_END_INTERVAL_MILLIS = 3000;
    private static final int NOT_LICENSED = 2;
    private static final String PAYLOAD_PAYWALL = "PAYWALL_INTENT";
    private static final int PER_USER_RANGE = 100000;
    private static final int REPEATED_CHECK_RETRY_DELAY_MILLIS = 300000;
    private static final int RETRY_DELAY_MILLIS = 1000;
    private static final String SERVICE_INTERFACE_CLASS_NAME = "com.android.vending.licensing.ILicensingService";
    private static final String SERVICE_PACKAGE = "com.android.vending";
    private static final String TAG = "LicenseClient";
    private static final int TRANSACTION_CHECK_LICENSE_V2 = 2;
    private static final int TRANSACTION_REPORT_SUCCESSFUL_LICENSE_CHECK = 3;
    protected static boolean backgroundLicensingServiceEnabled = False;
    protected static com.pairip.licensecheck.LicenseClient$ImmediateTaskExecutor backgroundRunner = None;
    protected static boolean customTrialEndTriggered = False;
    protected static boolean eventualShutdownEnabled = True;
    protected static Runnable exitAction = None;
    public static boolean gracefulShutdownEnabled = True;
    private static final android.os.Handler handler = None;
    private static com.pairip.licensecheck.LicenseClient instance = None;
    protected static long lastTrialEndElapsedRealtimeMillis = 0;
    protected static com.pairip.licensecheck.LicenseClient$LicenseCheckState licenseCheckState = None;
    protected static String licensePubKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1RaSUq+tHBOR5NQuT+J43pWE5PFAPNCApUPHvpz5UuGcgk1TvsH8MdFs1SmO1lr+ac4iF5BN7deT+YdMmAZYowk/2NZ/VUGkXjxtlyX7ebJmltkCqeFHKBju2c1OW+8ktc3X9vnw6dixK+lyqQhPo2qKGZGC7+fK+GDW/xMuwWf2uLPZEHi28qnZb3mMTcIgFIZq/CE9p69DteV2FRzgk+j1De+9GpErG+r8UB7mN4V9AgtmD3lCcXjH6ppU4aZU3OjcZ1KB5T4vzzx8H7uLGlNpLbZGfKkZX/Hw9CABb5GVetFe/1hg1yoBQTXyQXGyr7oHJyBIn+efk2be0fWc5wIDAQAB";
    protected static boolean localCheckEnabled = True;
    protected static com.pairip.licensecheck.LicenseClient$ImmediateTaskExecutor mainThreadRunner = None;
    protected static String packageName = "vet.pharmapedia.vetpharmapediapakistan";
    protected static boolean repeatedCheckEnabled = True;
    protected static android.os.Bundle responsePayload;
    private final android.content.Context context;
    protected com.pairip.licensecheck.LicenseClient$DelayedTaskExecutor delayedTaskExecutor;
    private long repeatedCheckStartElapsedRealtime;
    protected int retryNum;
    protected boolean waitingForRepeatedCheck;

    public static synthetic void $r8$lambda$8YRQpF8qc5JOZUcKq79QHnbGjYY(com.pairip.licensecheck.LicenseClient p0, com.pairip.licensecheck.RepeatedCheckMetadata p1)
    {
        p0.lambda$scheduleRepeatedLicenseCheck$0(p1);
        return;
    }

    public static synthetic void $r8$lambda$GS82Fij7VQePgSFog-s63-Rcyb0(com.pairip.licensecheck.LicenseClient p0)
    {
        p0.lambda$initializeLicenseCheck$0();
        return;
    }

    public static synthetic void $r8$lambda$gb-vmUiJUmqdCloCudVdY-igh7I(com.pairip.licensecheck.LicenseClient p0, android.os.IBinder p1)
    {
        p0.lambda$onServiceConnected$1(p1);
        return;
    }

    public static synthetic void $r8$lambda$nn58bl0tYjCXTurL0z1br2IkQ-g(com.pairip.licensecheck.LicenseClient p0, com.pairip.licensecheck.LicenseCheckException p1)
    {
        p0.lambda$handleError$0(p1);
        return;
    }

    public static synthetic void $r8$lambda$ot_XkRbEJeEFG1Hy-d3H6N4DX_I(com.pairip.licensecheck.LicenseClient p0, com.pairip.licensecheck.RepeatedCheckMetadata p1, android.os.Bundle p2)
    {
        p0.lambda$processResponse$0(p1, p2);
        return;
    }

    public static synthetic void $r8$lambda$q2q7YKfx3jIZHqiUNn7fQ55wwzI(com.pairip.licensecheck.LicenseClient p0, boolean p1)
    {
        p0.lambda$initializeLicenseCheck$1(p1);
        return;
    }

    public static synthetic void $r8$lambda$tB8S6FJPE8_x6-ohvmHs84x5lek(com.pairip.licensecheck.LicenseClient p0, boolean p1, com.pairip.licensecheck.LicenseCheckException p2, boolean p3)
    {
        p0.lambda$retryOrThrow$0(p1, p2, p3);
        return;
    }

    public static synthetic void $r8$lambda$x_INbtAE1cLJhbPOU3l3uRiKDN8(com.pairip.licensecheck.LicenseClient p0, boolean p1)
    {
        p0.lambda$retryOrThrow$1(p1);
        return;
    }

    public static synthetic void $r8$lambda$xzrAfByzooHDT9oIsgTdQvzthuE(com.pairip.licensecheck.LicenseClient p0, android.os.IBinder p1)
    {
        p0.lambda$onServiceConnected$0(p1);
        return;
    }

    static bridge synthetic void -$$Nest$mprocessResponse(com.pairip.licensecheck.LicenseClient p0, int p1, android.os.Bundle p2)
    {
        p0.processResponse(p1, p2);
        return;
    }

    static LicenseClient()
    {
        com.pairip.licensecheck.LicenseClient.exitAction = new com.pairip.licensecheck.LicenseClient$1();
        com.pairip.licensecheck.LicenseClient.licenseCheckState = com.pairip.licensecheck.LicenseClient$LicenseCheckState.CHECK_REQUIRED;
        com.pairip.licensecheck.LicenseClient.backgroundRunner = new com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda4();
        long v0_2 = new android.os.Handler(android.os.Looper.getMainLooper());
        com.pairip.licensecheck.LicenseClient.handler = v0_2;
        java.util.Objects.requireNonNull(v0_2);
        com.pairip.licensecheck.LicenseClient.mainThreadRunner = new com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda5(v0_2);
        com.pairip.licensecheck.LicenseClient.customTrialEndTriggered = 0;
        com.pairip.licensecheck.LicenseClient.lastTrialEndElapsedRealtimeMillis = 0;
        return;
    }

    public LicenseClient(android.content.Context p3)
    {
        this.delayedTaskExecutor = new com.pairip.licensecheck.LicenseClient$DelayedTaskExecutorImpl(0);
        this.retryNum = 0;
        this.waitingForRepeatedCheck = 0;
        this.repeatedCheckStartElapsedRealtime = 0;
        this.context = p3;
        return;
    }

    private void bindToLicensingService(boolean p5)
    {
        String v0_0;
        if (!p5) {
            v0_0 = "Connecting to the main licensing service...";
        } else {
            v0_0 = "Connecting to the background licensing service...";
        }
        String v0_3;
        android.util.Log.d("LicenseClient", v0_0);
        if (!p5) {
            v0_3 = "com.android.vending.licensing.ILicensingService";
        } else {
            v0_3 = "com.android.vending.licensing.IBackgroundLicensingService";
        }
        try {
            if (!this.context.bindService(new android.content.Intent(v0_3).setPackage("com.android.vending").setAction(v0_3), this, 1)) {
                this.retryOrThrow(new com.pairip.licensecheck.LicenseCheckException("Could not bind with the licensing service: ".concat(v0_3)), p5, p5);
            }
        } catch (com.pairip.licensecheck.LicenseCheckException v1_3) {
            this.retryOrThrow(new com.pairip.licensecheck.LicenseCheckException("Not allowed to bind with the licensing service: ".concat(v0_3), v1_3), p5, p5);
            return;
        }
        return;
    }

    public static void checkLicense(android.content.Context p2)
    {
        if (p2 != null) {
            if (!com.pairip.licensecheck.LicenseClient.isIsolatedProcess()) {
                com.pairip.licensecheck.LicenseClient.mainThreadRunner.run(new com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda6(p2));
                return;
            } else {
                android.util.Log.i("LicenseClient", "Skipping license check in isolated process.");
                return;
            }
        } else {
            android.util.Log.w("LicenseClient", "Cannot check license with null context.");
            return;
        }
    }

    private void checkLicenseInternal(android.os.IBinder p7)
    {
        if (p7 != null) {
            if (p7.getInterfaceDescriptor().equals("com.android.vending.licensing.IBackgroundLicensingService")) {
                throw new com.pairip.licensecheck.LicenseCheckException("Background licensing service does not support full license check.");
            } else {
                android.util.Log.d("LicenseClient", "Sending request to licensing service...");
                android.os.Parcel v1_1 = android.os.Parcel.obtain();
                android.os.Parcel v3 = android.os.Parcel.obtain();
                try {
                    this.populateInputDataForLicenseCheckV2(v1_1, p7);
                } catch (com.pairip.licensecheck.LicenseCheckException v7_5) {
                    this.handleError(new com.pairip.licensecheck.LicenseCheckException("Error when calling licensing service.", v7_5));
                    v1_1.recycle();
                    v3.recycle();
                    android.util.Log.d("LicenseClient", "Request to licensing service sent.");
                    return;
                } catch (com.pairip.licensecheck.LicenseCheckException v7_7) {
                    v1_1.recycle();
                    v3.recycle();
                    android.util.Log.d("LicenseClient", "Request to licensing service sent.");
                    throw v7_7;
                }
                if (!p7.transact(2, v1_1, v3, 0)) {
                    this.handleError(new com.pairip.licensecheck.LicenseCheckException("Licensing service could not process request."));
                }
                v1_1.recycle();
                v3.recycle();
                android.util.Log.d("LicenseClient", "Request to licensing service sent.");
                return;
            }
        } else {
            this.retryOrThrow(new com.pairip.licensecheck.LicenseCheckException("Received a null binder."));
            return;
        }
    }

    private android.content.Intent createCloseAppIntentOrExitIfAppInBackground()
    {
        if (!this.isForeground()) {
            com.pairip.licensecheck.LicenseClient.exitAction.run();
        }
        android.content.Intent v0_3 = new android.content.Intent(this.context, com.pairip.licensecheck.LicenseActivity);
        if (!com.pairip.licensecheck.LicenseClient.gracefulShutdownEnabled) {
            v0_3.addFlags(67108864);
            v0_3.addFlags(32768);
        } else {
            v0_3.addFlags(65536);
        }
        v0_3.addFlags(268435456);
        return v0_3;
    }

    private static com.pairip.licensecheck.ILicenseV2ResultListener createResultListener(com.pairip.licensecheck.LicenseClient p1)
    {
        return new com.pairip.licensecheck.LicenseClient$2(p1);
    }

    private static declared_synchronized com.pairip.licensecheck.LicenseClient getInstance(android.content.Context p2)
    {
        com.pairip.licensecheck.LicenseClient v1_0 = com.pairip.licensecheck.LicenseClient.instance;
        if (v1_0 == null) {
            v1_0 = new com.pairip.licensecheck.LicenseClient(p2);
            com.pairip.licensecheck.LicenseClient.instance = v1_0;
        }
        return v1_0;
    }

    public static String getLicensePubKey()
    {
        return com.pairip.licensecheck.LicenseClient.licensePubKey;
    }

    private void handleError(com.pairip.licensecheck.LicenseCheckException p3)
    {
        com.pairip.licensecheck.LicenseClient.mainThreadRunner.run(new com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda3(this, p3));
        return;
    }

    private void initiateFreshLicensingServiceConnection(boolean p2)
    {
        this.retryNum = 0;
        this.bindToLicensingService(p2);
        return;
    }

    private boolean isForeground()
    {
        int v0_1 = new android.app.ActivityManager$RunningAppProcessInfo();
        android.app.ActivityManager.getMyMemoryState(v0_1);
        if (v0_1.importance > 100) {
            return 0;
        } else {
            return 1;
        }
    }

    private static boolean isIsolatedProcess()
    {
        if (android.os.Build$VERSION.SDK_INT < 28) {
            int v0_5 = (android.os.Process.myUid() % 100000);
            if ((v0_5 < 99000) || (v0_5 > 99999)) {
                return 0;
            } else {
                return 1;
            }
        } else {
            return android.os.Process.isIsolated();
        }
    }

    static synthetic void lambda$checkLicense$0(android.content.Context p0)
    {
        com.pairip.licensecheck.LicenseClient.getInstance(p0).initializeLicenseCheck();
        return;
    }

    private synthetic void lambda$handleError$0(com.pairip.licensecheck.LicenseCheckException p3)
    {
        boolean v3_1 = android.util.Log.getStackTraceString(p3);
        com.pairip.licensecheck.LicenseClient$LicenseCheckState v0_2 = new StringBuilder("Error while checking license: ");
        v0_2.append(v3_1);
        android.util.Log.e("LicenseClient", v0_2.toString());
        if (!com.pairip.licensecheck.LicenseClient.licenseCheckState.equals(com.pairip.licensecheck.LicenseClient$LicenseCheckState.FULL_CHECK_OK)) {
            this.startErrorDialogActivity();
            return;
        } else {
            return;
        }
    }

    private synthetic void lambda$initializeLicenseCheck$0()
    {
        com.pairip.licensecheck.LicenseClient.mainThreadRunner.run(new com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda0(this, this.performLocalInstallerCheck()));
        return;
    }

    private synthetic void lambda$initializeLicenseCheck$1(boolean p2)
    {
        if (p2 != 0) {
            com.pairip.licensecheck.LicenseClient.licenseCheckState = com.pairip.licensecheck.LicenseClient$LicenseCheckState.LOCAL_CHECK_OK;
        }
        if ((p2 == 0) || (!com.pairip.licensecheck.LicenseClient.backgroundLicensingServiceEnabled)) {
            int v2_2 = 0;
        } else {
            v2_2 = 1;
        }
        this.initiateFreshLicensingServiceConnection(v2_2);
        return;
    }

    private synthetic void lambda$onServiceConnected$0(android.os.IBinder p3)
    {
        try {
            this.checkLicenseInternal(p3);
            return;
        } catch (android.os.RemoteException v3_2) {
            this.handleError(v3_2);
            return;
        } catch (android.os.RemoteException v3_1) {
            this.handleError(new com.pairip.licensecheck.LicenseCheckException("Error when getting interface descriptor.", v3_1));
            return;
        }
    }

    private synthetic void lambda$onServiceConnected$1(android.os.IBinder p3)
    {
        try {
            this.reportSuccessfulLicenseCheck(p3);
            return;
        } catch (String v3_2) {
            String v3_3 = android.util.Log.getStackTraceString(v3_2);
            String v0_2 = new StringBuilder("Error while reporting license check: ");
            v0_2.append(v3_3);
            android.util.Log.e("LicenseClient", v0_2.toString());
            return;
        }
    }

    private synthetic void lambda$processResponse$0(com.pairip.licensecheck.RepeatedCheckMetadata p3, android.os.Bundle p4)
    {
        if (p3 == null) {
            com.pairip.licensecheck.LicenseClient.licenseCheckState = com.pairip.licensecheck.LicenseClient$LicenseCheckState.FULL_CHECK_OK;
        } else {
            com.pairip.licensecheck.LicenseClient.licenseCheckState = com.pairip.licensecheck.LicenseClient$LicenseCheckState.REPEATED_CHECK_REQUIRED;
            this.repeatedCheckStartElapsedRealtime = this.getElapsedRealtimeMillis();
            this.scheduleRepeatedLicenseCheck(p3);
        }
        com.pairip.licensecheck.LicenseClient.responsePayload = p4;
        return;
    }

    static synthetic void lambda$reportSuccessfulLicenseCheck$0()
    {
        com.pairip.licensecheck.LicenseClient.licenseCheckState = com.pairip.licensecheck.LicenseClient$LicenseCheckState.LOCAL_CHECK_REPORTED;
        return;
    }

    private synthetic void lambda$retryOrThrow$0(boolean p7, com.pairip.licensecheck.LicenseCheckException p8, boolean p9)
    {
        Long v0_0 = this.retryNum;
        if (v0_0 >= 3) {
            if (p9 == null) {
                this.handleError(p8);
                return;
            } else {
                String v7_7 = String.valueOf(p8);
                StringBuilder v8_1 = new StringBuilder("Retry limit reached for: ");
                v8_1.append(v7_7);
                android.util.Log.e("LicenseClient", v8_1.toString());
                return;
            }
        } else {
            StringBuilder v8_2;
            this.retryNum = (v0_0 + 1);
            this.delayedTaskExecutor.schedule(new com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda12(this, p7), 1000);
            String v7_3 = Integer.valueOf(this.retryNum);
            if (p8 != null) {
                v8_2 = p8.getMessage();
            } else {
                v8_2 = "null";
            }
            Long v0_3 = Long.valueOf(1);
            Object[] v2_1 = new Object[3];
            v2_1[0] = v7_3;
            v2_1[1] = v8_2;
            v2_1[2] = v0_3;
            android.util.Log.d("LicenseClient", String.format("Retry #%d. License check failed with error \'%s\'. Next try in %ds...", v2_1));
            return;
        }
    }

    private synthetic void lambda$retryOrThrow$1(boolean p1)
    {
        this.bindToLicensingService(p1);
        return;
    }

    private synthetic void lambda$scheduleRepeatedLicenseCheck$0(com.pairip.licensecheck.RepeatedCheckMetadata p8)
    {
        String v0_2 = (this.getElapsedRealtimeMillis() - this.repeatedCheckStartElapsedRealtime);
        if ((this.getCurrentTimeMillis() < p8.getTimeToRetryMillis()) && (v0_2 < p8.getDurationToRetryMillis())) {
            android.util.Log.d("LicenseClient", "Repeated license check is rescheduled.");
            this.scheduleRepeatedLicenseCheck(p8);
            return;
        } else {
            this.waitingForRepeatedCheck = 0;
            this.initiateFreshLicensingServiceConnection(0);
            return;
        }
    }

    static synthetic void lambda$static$0(Runnable p1)
    {
        new Thread(p1).start();
        return;
    }

    static synthetic void lambda$stopTrial$0(android.content.Context p0)
    {
        com.pairip.licensecheck.LicenseClient.getInstance(p0).handleTrialEnd();
        return;
    }

    private boolean performLocalInstallerCheck()
    {
        try {
            if (android.os.Build$VERSION.SDK_INT >= 30) {
                String v2_12 = this.context.getPackageManager();
                if (v2_12 != null) {
                    String v3_0 = v2_12.getPackageInfo(com.pairip.licensecheck.LicenseClient.packageName, 0);
                    if (v3_0 != null) {
                        if (v3_0.applicationInfo != null) {
                            String v3_2 = v3_0.applicationInfo.flags;
                            if ((v3_2 & 1) == 0) {
                                if ((v3_2 & 128) == 0) {
                                    String v2_1 = v2_12.getInstallSourceInfo(com.pairip.licensecheck.LicenseClient.packageName);
                                    if (v2_1 != null) {
                                        String v2_2 = v2_1.getInstallingPackageName();
                                        if (v2_2 != null) {
                                            if (v2_2.equals("com.android.vending")) {
                                                return 1;
                                            } else {
                                            }
                                        }
                                        android.util.Log.i("LicenseClient", "Local install check failed due to wrong installer.");
                                        return 0;
                                    } else {
                                        android.util.Log.i("LicenseClient", "Local install check bypassed due to install source info not found.");
                                        return 0;
                                    }
                                } else {
                                }
                            }
                            android.util.Log.i("LicenseClient", "Local install check passed due to system app.");
                            return 1;
                        } else {
                        }
                    }
                    android.util.Log.i("LicenseClient", "Local install check bypassed due to app package info not found.");
                    return 0;
                } else {
                    android.util.Log.i("LicenseClient", "Local install check bypassed due to package manager not found.");
                    return 0;
                }
            } else {
                android.util.Log.i("LicenseClient", "Local install check bypassed due to old SDK version.");
                return 0;
            }
        } catch (String v2_11) {
            android.util.Log.w("LicenseClient", "Could not obtain package info for local installer check.", v2_11);
            return 0;
        }
    }

    private void populateInputDataForLicenseCheckV2(android.os.Parcel p4, android.os.IBinder p5)
    {
        p4.writeInterfaceToken(p5.getInterfaceDescriptor());
        p4.writeString(com.pairip.licensecheck.LicenseClient.packageName);
        p4.writeStrongBinder(com.pairip.licensecheck.LicenseClient.createResultListener(this).asBinder());
        android.os.Bundle v5_3 = new android.os.Bundle();
        if (com.pairip.licensecheck.LicenseClient.customTrialEndTriggered) {
            v5_3.putBoolean("end_custom_trial", 1);
        }
        if (v5_3.isEmpty()) {
            p4.writeInt(0);
            return;
        } else {
            p4.writeInt(1);
            v5_3.writeToParcel(p4, 0);
            return;
        }
    }

    private void populateInputDataForReportAutoVerifiedLicense(android.os.Parcel p1, android.os.IBinder p2)
    {
        p1.writeInterfaceToken(p2.getInterfaceDescriptor());
        p1.writeString(com.pairip.licensecheck.LicenseClient.packageName);
        p1.writeInt(0);
        return;
    }

    private void processResponse(int p4, android.os.Bundle p5)
    {
        try {
            if (p4 == 3) {
                throw new com.pairip.licensecheck.LicenseCheckException("Request package name invalid.");
            } else {
                if (p4 != null) {
                    if (p4 != 2) {
                        com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda10 v1_1 = new Object[1];
                        v1_1[0] = Integer.valueOf(p4);
                        throw new com.pairip.licensecheck.LicenseCheckException(String.format("Unexpected response code %d received.", v1_1));
                    } else {
                        this.startPaywallActivity(((android.app.PendingIntent) p5.getParcelable("PAYWALL_INTENT")));
                        return;
                    }
                } else {
                    String v4_10;
                    com.pairip.licensecheck.LicenseResponseHelper.validateResponse(p5, com.pairip.licensecheck.LicenseClient.packageName);
                    android.util.Log.i("LicenseClient", "License check succeeded.");
                    if (!com.pairip.licensecheck.LicenseClient.repeatedCheckEnabled) {
                        v4_10 = 0;
                    } else {
                        v4_10 = com.pairip.licensecheck.LicenseResponseHelper.getRepeatedCheckMetadata(p5);
                    }
                    com.pairip.licensecheck.LicenseClient.mainThreadRunner.run(new com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda10(this, v4_10, p5));
                    return;
                }
            }
        } catch (String v4_12) {
            this.handleError(v4_12);
            return;
        }
    }

    private void retryOrThrow(com.pairip.licensecheck.LicenseCheckException p2)
    {
        this.retryOrThrow(p2, 0, 0);
        return;
    }

    private void retryOrThrow(com.pairip.licensecheck.LicenseCheckException p3, boolean p4, boolean p5)
    {
        com.pairip.licensecheck.LicenseClient.mainThreadRunner.run(new com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda1(this, p5, p3, p4));
        return;
    }

    private void scheduleAppShutdown()
    {
        if (com.pairip.licensecheck.LicenseClient.eventualShutdownEnabled) {
            this.delayedTaskExecutor.schedule(com.pairip.licensecheck.LicenseClient.exitAction, 30000);
        }
        return;
    }

    private void scheduleRepeatedLicenseCheck(com.pairip.licensecheck.RepeatedCheckMetadata p7)
    {
        Object[] v0_2 = Math.min(Math.min(p7.getDurationToRetryMillis(), Math.max(0, (p7.getTimeToRetryMillis() - this.getCurrentTimeMillis()))), 300000);
        if (!this.waitingForRepeatedCheck) {
            this.waitingForRepeatedCheck = 1;
            try {
                this.context.unbindService(this);
            } catch (RuntimeException v2_3) {
                android.util.Log.e("LicenseClient", "Failed to unbind service for repeated license check.", v2_3);
            }
        }
        this.delayedTaskExecutor.schedule(new com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda13(this, p7), v0_2);
        Object[] v0_3 = new Object[1];
        v0_3[0] = Long.valueOf(v0_2);
        android.util.Log.d("LicenseClient", String.format("Repeated license check is scheduled in %d ms...", v0_3));
        return;
    }

    private void startErrorDialogActivity()
    {
        android.content.Intent v0 = this.createCloseAppIntentOrExitIfAppInBackground();
        v0.putExtra("activitytype", com.pairip.licensecheck.LicenseActivity$ActivityType.ERROR_DIALOG);
        this.scheduleAppShutdown();
        this.context.startActivity(v0);
        return;
    }

    private void startPaywallActivity(android.app.PendingIntent p3)
    {
        android.content.Intent v0 = this.createCloseAppIntentOrExitIfAppInBackground();
        v0.putExtra("paywallintent", p3);
        v0.putExtra("activitytype", com.pairip.licensecheck.LicenseActivity$ActivityType.PAYWALL);
        this.scheduleAppShutdown();
        this.context.startActivity(v0);
        return;
    }

    static void stopTrial(android.content.Context p2)
    {
        if (p2 != null) {
            if (!com.pairip.licensecheck.LicenseClient.isIsolatedProcess()) {
                com.pairip.licensecheck.LicenseClient.mainThreadRunner.run(new com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda2(p2));
                return;
            } else {
                android.util.Log.i("LicenseClient", "Skipping trial end in isolated process.");
                return;
            }
        } else {
            android.util.Log.w("LicenseClient", "Cannot trigger trial end with null context.");
            return;
        }
    }

    protected long getCurrentTimeMillis()
    {
        return System.currentTimeMillis();
    }

    protected long getElapsedRealtimeMillis()
    {
        return android.os.SystemClock.elapsedRealtime();
    }

    protected void handleTrialEnd()
    {
        String v0_0 = this.getElapsedRealtimeMillis();
        String v2_2 = com.pairip.licensecheck.LicenseClient.lastTrialEndElapsedRealtimeMillis;
        long v4 = (v0_0 - v2_2);
        if ((v2_2 <= 0) || (v4 >= 3000)) {
            android.util.Log.i("LicenseClient", "Trial end event triggered; initiating full license check.");
            com.pairip.licensecheck.LicenseClient.lastTrialEndElapsedRealtimeMillis = v0_0;
            com.pairip.licensecheck.LicenseClient.customTrialEndTriggered = 1;
            com.pairip.licensecheck.LicenseClient.licenseCheckState = com.pairip.licensecheck.LicenseClient$LicenseCheckState.CHECK_REQUIRED;
            this.waitingForRepeatedCheck = 0;
            this.initiateFreshLicensingServiceConnection(0);
            return;
        } else {
            Object[] v1 = new Object[1];
            v1[0] = Long.valueOf(v4);
            android.util.Log.w("LicenseClient", String.format("Trial end trigger throttled. Ignoring request (sent %d ms ago).", v1));
            return;
        }
    }

    public void initializeLicenseCheck()
    {
        com.pairip.licensecheck.LicenseClient$ImmediateTaskExecutor v0_3 = com.pairip.licensecheck.LicenseClient.licenseCheckState.ordinal();
        if (v0_3 == null) {
            if ((!com.pairip.licensecheck.LicenseClient.localCheckEnabled) || (com.pairip.licensecheck.LicenseClient.customTrialEndTriggered)) {
                this.initiateFreshLicensingServiceConnection(0);
                return;
            } else {
                com.pairip.licensecheck.LicenseClient.backgroundRunner.run(new com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda7(this));
                return;
            }
        } else {
            if (v0_3 == 1) {
                try {
                    com.pairip.licensecheck.LicenseResponseHelper.validateResponse(com.pairip.licensecheck.LicenseClient.responsePayload, com.pairip.licensecheck.LicenseClient.packageName);
                    return;
                } catch (com.pairip.licensecheck.LicenseClient$ImmediateTaskExecutor v0_4) {
                    this.handleError(v0_4);
                    return;
                }
            } else {
                if (v0_3 == 4) {
                    this.initiateFreshLicensingServiceConnection(0);
                    return;
                } else {
                    return;
                }
            }
        }
    }

    public void onServiceConnected(android.content.ComponentName p2, android.os.IBinder p3)
    {
        android.util.Log.d("LicenseClient", "Connected to the licensing service.");
        com.pairip.licensecheck.LicenseClient$ImmediateTaskExecutor v2_3 = com.pairip.licensecheck.LicenseClient.licenseCheckState.ordinal();
        if (v2_3 != null) {
            if (v2_3 == 2) {
                com.pairip.licensecheck.LicenseClient.backgroundRunner.run(new com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda9(this, p3));
                return;
            } else {
                if (v2_3 != 4) {
                    return;
                }
            }
        }
        com.pairip.licensecheck.LicenseClient.backgroundRunner.run(new com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda8(this, p3));
        return;
    }

    public void onServiceDisconnected(android.content.ComponentName p2)
    {
        if ((!com.pairip.licensecheck.LicenseClient.licenseCheckState.equals(com.pairip.licensecheck.LicenseClient$LicenseCheckState.REPEATED_CHECK_REQUIRED)) || (!this.waitingForRepeatedCheck)) {
            android.util.Log.w("LicenseClient", "Unexpectedly disconnected from the licensing service.");
            this.retryOrThrow(new com.pairip.licensecheck.LicenseCheckException("Licensing service unexpectedly disconnected."));
            return;
        } else {
            android.util.Log.d("LicenseClient", "Ignoring service disconnection in REPEATED_CHECK_REQUIRED state.");
            return;
        }
    }

    public void reportSuccessfulLicenseCheck(android.os.IBinder p9)
    {
        if (p9 != null) {
            android.util.Log.d("LicenseClient", "Sending request to license reporting service...");
            android.os.Parcel v3_1 = android.os.Parcel.obtain();
            android.os.Parcel v5 = android.os.Parcel.obtain();
            try {
                this.populateInputDataForReportAutoVerifiedLicense(v3_1, p9);
                com.pairip.licensecheck.LicenseClient$ImmediateTaskExecutor v9_1 = p9.transact(3, v3_1, v5, 0);
            } catch (com.pairip.licensecheck.LicenseClient$ImmediateTaskExecutor v9_3) {
                com.pairip.licensecheck.LicenseClient$ImmediateTaskExecutor v9_4 = String.valueOf(v9_3);
                StringBuilder v2_2 = new StringBuilder("Error when calling licensing service.");
                v2_2.append(v9_4);
                android.util.Log.e("LicenseClient", v2_2.toString());
                v3_1.recycle();
                v5.recycle();
                android.util.Log.d("LicenseClient", "Request to licensing reporting service sent.");
                return;
            } catch (com.pairip.licensecheck.LicenseClient$ImmediateTaskExecutor v9_8) {
                v3_1.recycle();
                v5.recycle();
                android.util.Log.d("LicenseClient", "Request to licensing reporting service sent.");
                throw v9_8;
            }
            if (v9_1 == null) {
                android.util.Log.e("LicenseClient", "Error sending request to license reporting service.");
            }
            if (v9_1 != null) {
                com.pairip.licensecheck.LicenseClient.mainThreadRunner.run(new com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda11());
            }
            v3_1.recycle();
            v5.recycle();
            android.util.Log.d("LicenseClient", "Request to licensing reporting service sent.");
            return;
        } else {
            this.retryOrThrow(new com.pairip.licensecheck.LicenseCheckException("Received a null binder."), 1, com.pairip.licensecheck.LicenseClient.backgroundLicensingServiceEnabled);
            return;
        }
    }
}
