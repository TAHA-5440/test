// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.pairip.licensecheck;
public interface LicenseClient$DelayedTaskExecutor {

    public abstract void schedule(Runnable p0, long p1);
}
