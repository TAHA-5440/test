// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.pairip.licensecheck;
public final synthetic class LicenseClient$$ExternalSyntheticLambda6 implements java.lang.Runnable {
    public final synthetic android.content.Context f$0;

    public synthetic LicenseClient$$ExternalSyntheticLambda6(android.content.Context p1)
    {
        this.f$0 = p1;
        return;
    }

    public final void run()
    {
        com.pairip.licensecheck.LicenseClient.lambda$checkLicense$0(this.f$0);
        return;
    }
}
