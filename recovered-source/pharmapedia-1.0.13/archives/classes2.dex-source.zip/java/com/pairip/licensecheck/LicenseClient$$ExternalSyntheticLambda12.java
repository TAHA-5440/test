// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.pairip.licensecheck;
public final synthetic class LicenseClient$$ExternalSyntheticLambda12 implements java.lang.Runnable {
    public final synthetic com.pairip.licensecheck.LicenseClient f$0;
    public final synthetic boolean f$1;

    public synthetic LicenseClient$$ExternalSyntheticLambda12(com.pairip.licensecheck.LicenseClient p1, boolean p2)
    {
        this.f$0 = p1;
        this.f$1 = p2;
        return;
    }

    public final void run()
    {
        com.pairip.licensecheck.LicenseClient.$r8$lambda$x_INbtAE1cLJhbPOU3l3uRiKDN8(this.f$0, this.f$1);
        return;
    }
}
