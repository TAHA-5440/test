// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.pairip.licensecheck;
public final synthetic class LicenseClient$$ExternalSyntheticLambda4 implements com.pairip.licensecheck.LicenseClient$ImmediateTaskExecutor {

    public synthetic LicenseClient$$ExternalSyntheticLambda4()
    {
        return;
    }

    public final void run(Runnable p1)
    {
        com.pairip.licensecheck.LicenseClient.lambda$static$0(p1);
        return;
    }
}
