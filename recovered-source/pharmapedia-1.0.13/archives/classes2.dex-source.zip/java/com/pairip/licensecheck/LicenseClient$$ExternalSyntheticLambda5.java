// Decompiled approximation; sanitized for publication, not original or verified buildable source.
package com.pairip.licensecheck;
public final synthetic class LicenseClient$$ExternalSyntheticLambda5 implements com.pairip.licensecheck.LicenseClient$ImmediateTaskExecutor {
    public final synthetic android.os.Handler f$0;

    public synthetic LicenseClient$$ExternalSyntheticLambda5(android.os.Handler p1)
    {
        this.f$0 = p1;
        return;
    }

    public final void run(Runnable p2)
    {
        this.f$0.post(p2);
        return;
    }
}
